#!/usr/bin/env python

import pandas as pd
from datetime import datetime
from datetime import timedelta
import pytz
import matplotlib.pyplot as plt


def run_lambda_on_col(df: pd.DataFrame, src_col: str, dest_col: str, fn) -> pd.DataFrame:
    df[dest_col] = df[src_col].apply(fn)
    return df


def convert_rel_hour_to_timestamp(hour: int, year: int = 2024) -> datetime:
    datetime
    date = datetime(year, 1, 1, 0, 0, 0, 0)
    return (date + timedelta(hours=hour)).astimezone(pytz.timezone("Europe/Budapest"))


def add_timestamp_from_rel_hour(df: pd.DataFrame, year: int = 2024) -> pd.DataFrame:
    run_lambda_on_col(df, "Hours since 00:00 Jan 1", "timestamp", lambda x: convert_rel_hour_to_timestamp(x, year))
    return df


def sum_subarray_dc_output(df: pd.DataFrame) -> pd.DataFrame:
    df["sum_dc_output"] = df["Hourly Data: Subarray 2 DC power gross (kW)"] \
                        + df["Hourly Data: Subarray 1 DC power gross (kW)"]
    return df


def convert_ha_epoch_to_timestamp(df: pd.DataFrame) -> pd.DataFrame:
    df["start"] = df["start"].apply(lambda x: datetime.fromtimestamp(x / 1000, pytz.timezone("Europe/Budapest")))
    df["end"] = df["end"].apply(lambda x: datetime.fromtimestamp(x / 1000, pytz.timezone("Europe/Budapest")))
    return df


def convert_sum_dc_output_kw_to_w(df: pd.DataFrame) -> pd.DataFrame:
    df["sum_dc_output"] = df["sum_dc_output"].apply(lambda x: x * 1000)
    return df


def add_timestamp_to_ha(df: pd.DataFrame) -> pd.DataFrame:
    # Timestamp := time until the noted value has been already produced
    df["timestamp"] = df["end"]
    return df


def align_data_based_on_timestamp(dfs: tuple[pd.DataFrame]) -> tuple[pd.DataFrame]:
    # We assume that the DataFrames are ordered by their dates ascendingly
    # and can indexed with their timestamps
    a_df, b_df = dfs
    a_df.set_index("timestamp", inplace=True)
    b_df.set_index("timestamp", inplace=True)

    max_date = max(a_df.index[0], b_df.index[0])
    a_df = a_df.truncate(before=max_date)
    b_df = b_df.truncate(before=max_date)
    return (a_df, b_df)


sam_sim = pd.read_csv("./sam-simulated-dc-output_openmeteo-weather.csv")

ha_data = pd.read_json("ha-tvl9energy_pv-dc-watts_2024-march.json")

sam_with_datetime = add_timestamp_from_rel_hour(sam_sim)

sam_with_datetime = sum_subarray_dc_output(sam_with_datetime)

sam_with_datetime = convert_sum_dc_output_kw_to_w(sam_with_datetime)

ha_data = convert_ha_epoch_to_timestamp(ha_data)
ha_data = add_timestamp_to_ha(ha_data)

print(sam_with_datetime)
print(ha_data)

ha_data, sam_with_datetime = align_data_based_on_timestamp((ha_data, sam_with_datetime))

ha_data.to_csv("./output_ha-tvl9energy_pv-dc-watts_2024-march.csv")
sam_with_datetime.to_csv("./sam_with_datetime_output.csv")

print(sam_with_datetime)
print(ha_data)

comparison_df = pd.DataFrame(
                             {
                                 "HA": ha_data["mean"],
                                 "SAM": sam_with_datetime["sum_dc_output"]
                             },
                             index=ha_data.index
                          )

plot = comparison_df.plot(title="Comparison of simulated (SAM) vs. measured (HA) PV DC output")

plt.show()
