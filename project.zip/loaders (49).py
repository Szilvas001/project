import pandas as pd
import numpy as np
import requests

from const import *
from const import CENTRAL_ENTITY_IDS


def load_measured_csv() -> pd.DataFrame:
    if not MEASURED_CSV.exists():
        print(f"[WARNING] Measured CSV nem található: {MEASURED_CSV}")
        return pd.DataFrame(columns=[MEASURED_TIME_COL, MEASURED_GHI_COL])
    dfm = pd.read_csv(MEASURED_CSV, usecols=[MEASURED_TIME_COL, MEASURED_GHI_COL])
    dfm[MEASURED_TIME_COL] = pd.to_datetime(dfm[MEASURED_TIME_COL], utc=True, errors="coerce")
    dfm = dfm.dropna(subset=[MEASURED_TIME_COL]).sort_values(MEASURED_TIME_COL).reset_index(drop=True)
    return dfm


# =============================================================================
# ÚJ: Central DB közvetlen PostgreSQL kapcsolat (HTTP API helyett)
# =============================================================================

def _get_central_db_conn():
    """
    Kapcsolódás az em-central-db PostgreSQL adatbázishoz.
    Több host-ot próbál sorban (CENTRAL_DB_HOSTS), ha az első nem elérhető.
    
    Env vars (a futtatóscriptben beállítva):
      CENTRAL_DB_HOST, CENTRAL_DB_HOSTS, CENTRAL_DB_PORT,
      CENTRAL_DB_NAME, CENTRAL_DB_USER, CENTRAL_DB_PASSWORD, CENTRAL_DB_SSLMODE
    """
    import psycopg2

    hosts_to_try = CENTRAL_DB_HOSTS if CENTRAL_DB_HOSTS else [CENTRAL_DB_HOST]
    last_err = None

    for host in hosts_to_try:
        host = host.strip()
        if not host:
            continue
        try:
            conn = psycopg2.connect(
                host=host,
                port=CENTRAL_DB_PORT,
                dbname=CENTRAL_DB_NAME,
                user=CENTRAL_DB_USER,
                password=CENTRAL_DB_PASSWORD,
                sslmode=CENTRAL_DB_SSLMODE,
                connect_timeout=15,
            )
            print(f"✓ Central DB kapcsolódva: {host}:{CENTRAL_DB_PORT}/{CENTRAL_DB_NAME}")
            return conn
        except Exception as e:
            last_err = e
            print(f"[WARN] Central DB kapcsolódás sikertelen ({host}): {e}")

    raise ConnectionError(f"Central DB nem elérhető egyik host-on sem: {hosts_to_try}. Utolsó hiba: {last_err}")


def fetch_central_df(entity_ids, start_ts, end_ts, chunk_hours: int = 6, max_retries: int = 5, timeout: int = 120):
    """
    Central szenzor adatok lekérése KÖZVETLEN PostgreSQL-ből (HTTP API helyett).

    Az em-central-db adatbázisban a Home Assistant sémát használjuk:
      - states tábla: state (érték szövegként), last_updated_ts (unix epoch float)
      - states_meta tábla: entity_id ↔ metadata_id leképezés

    Lekérdezés mintája (entity_id-nként):
      SELECT state, to_timestamp(last_updated_ts)
      FROM states
      WHERE metadata_id = (SELECT metadata_id FROM states_meta WHERE entity_id = %s)
        AND to_timestamp(last_updated_ts) >= %s
        AND to_timestamp(last_updated_ts) <= %s
      ORDER BY last_updated_ts ASC

    Kimenet: WIDE DataFrame (timestamp + entity_id oszlopok) — 
    UGYANAZ a formátum, mint a régi HTTP API verzió.
    """
    import time as _time

    start_ts = pd.to_datetime(start_ts, utc=True, errors="coerce")
    end_ts   = pd.to_datetime(end_ts,   utc=True, errors="coerce")
    if pd.isna(start_ts) or pd.isna(end_ts) or end_ts <= start_ts:
        return pd.DataFrame()

    # --- DB kapcsolat (retry-vel) ---
    conn = None
    for attempt in range(1, max_retries + 1):
        try:
            conn = _get_central_db_conn()
            break
        except Exception as e:
            print(f"[WARN] Central DB kapcsolódás hiba (próba {attempt}/{max_retries}): {e}")
            if attempt < max_retries:
                _time.sleep(min(2 ** attempt, 20))
    
    if conn is None:
        print("[ERROR] Central DB nem elérhető — üres DataFrame-et adok vissza.")
        return pd.DataFrame()

    try:
        # --- EGY nagy lekérdezés az összes entity_id-ra egyszerre ---
        # Ez SOKKAL gyorsabb, mint entity_id-nként külön query
        query = """
            SELECT 
                sm.entity_id,
                s.state,
                to_timestamp(s.last_updated_ts) AT TIME ZONE 'UTC' AS timestamp
            FROM states s
            JOIN states_meta sm ON s.metadata_id = sm.metadata_id
            WHERE sm.entity_id = ANY(%s)
              AND to_timestamp(s.last_updated_ts) >= %s
              AND to_timestamp(s.last_updated_ts) <= %s
              AND s.state NOT IN ('unknown', 'unavailable', '')
            ORDER BY s.last_updated_ts ASC
        """

        start_str = start_ts.strftime("%Y-%m-%d %H:%M:%S+00:00")
        end_str   = end_ts.strftime("%Y-%m-%d %H:%M:%S+00:00")

        df_long = pd.read_sql_query(
            query,
            conn,
            params=(list(entity_ids), start_str, end_str),
        )

        if df_long.empty:
            print(f"[WARN] Central DB: nincs adat {start_ts} — {end_ts} között ({len(entity_ids)} entity)")
            return pd.DataFrame()

        # --- Típus konverziók ---
        df_long["timestamp"] = pd.to_datetime(df_long["timestamp"], utc=True, errors="coerce")
        df_long["value"] = pd.to_numeric(df_long["state"], errors="coerce")
        df_long = df_long.dropna(subset=["timestamp", "value"])
        df_long = df_long[["timestamp", "entity_id", "value"]]
        df_long = df_long.sort_values(["timestamp", "entity_id"])
        df_long = df_long.groupby(["timestamp", "entity_id"], as_index=False).first()

        # --- WIDE formátum (ugyanaz, mint a régi API verzió) ---
        wide = df_long.pivot(index="timestamp", columns="entity_id", values="value").sort_index()

        # Hiányzó entity_id oszlopok hozzáadása (NaN)
        for eid in entity_ids:
            if eid not in wide.columns:
                wide[eid] = np.nan
        wide = wide[list(entity_ids)]

        wide = wide.reset_index()
        wide["timestamp"] = pd.to_datetime(wide["timestamp"], utc=True, errors="coerce")
        wide = wide.dropna(subset=["timestamp"]).sort_values("timestamp").drop_duplicates("timestamp")

        print(f"✓ Central DB: {len(wide)} sor, {len(entity_ids)} szenzor [{wide['timestamp'].min()} — {wide['timestamp'].max()}]")
        return wide

    except Exception as e:
        print(f"[ERROR] Central DB lekérdezés hiba: {e}")
        import traceback
        traceback.print_exc()
        return pd.DataFrame()

    finally:
        try:
            conn.close()
        except Exception:
            pass



def load_measured_from_central(periods_utc: List[Tuple[pd.Timestamp, pd.Timestamp]]) -> pd.DataFrame:
    """
    IMT14 mért GHI idősor betöltése a Central API-ból a megadott időablakokra.
    Ha nincs Central-adat, visszaesés a lokális CSV-re (MEASURED_CSV).
    Kimenet: ['timestamp', MEASURED_GHI_COL] – UTC, deduplikált, rendezett.
    """
    frames: List[pd.DataFrame] = []

    for t0, t1 in periods_utc:
        try:
            dfc = fetch_central_df([MEASURED_ENTITY_ID], t0, t1)

        except Exception:
            dfc = pd.DataFrame(columns=["timestamp"])

        if not dfc.empty and MEASURED_ENTITY_ID in dfc.columns:
            frames.append(
                dfc[["timestamp", MEASURED_ENTITY_ID]].rename(
                    columns={MEASURED_ENTITY_ID: MEASURED_GHI_COL}
                )
            )

    if not frames:
        # Fallback: helyi CSV ugyanazzal az oszlopnévvel
        dfm = load_measured_csv()
        if dfm.empty:
            return pd.DataFrame(columns=["timestamp", MEASURED_GHI_COL])
        out = dfm.rename(columns={MEASURED_TIME_COL: "timestamp"}).copy()
    else:
        out = pd.concat(frames, ignore_index=True)

    out["timestamp"] = pd.to_datetime(out["timestamp"], utc=True, errors="coerce")
    out = (
        out.dropna(subset=["timestamp"])
           .sort_values("timestamp")
           .groupby("timestamp", as_index=False).first()
    )
    return out



def load_openmeteo_csv(csv_path: str, interval: Tuple[pd.Timestamp, pd.Timestamp]) -> pd.DataFrame:
    start_ts, end_ts = interval
    with open(csv_path, "r", encoding="utf-8") as f:
        lines = [ln.rstrip("\n") for ln in f.readlines()]
    if not lines: return pd.DataFrame(columns=["timestamp"])
    data_start_idx = next((i for i, ln in enumerate(lines) if ln.lower().startswith("time,")), None)
    if data_start_idx is None: raise ValueError("Open-Meteo CSV: nem található 'time,' fejléc")
    offset_seconds = 0
    try:
        meta_header = [s.strip() for s in lines[0].split(",")]
        meta_values = [s.strip() for s in lines[1].split("," )]
        meta = {k: v for k, v in zip(meta_header, meta_values)}
        if "utc_offset_seconds" in meta:
            offset_seconds = int(float(meta["utc_offset_seconds"]))
    except Exception:
        pass
    from io import StringIO
    df = pd.read_csv(StringIO("\n".join(lines[data_start_idx:])))
    if df.empty: return pd.DataFrame(columns=["timestamp"])
    t_local = pd.to_datetime(df["time"], errors="coerce")
    df["timestamp"] = (t_local - pd.to_timedelta(offset_seconds, unit="s")).dt.tz_localize("UTC")
    for c in df.columns:
        if c not in ("time", "timestamp"):
            df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.drop(columns=["time"])
    df = df.dropna(subset=["timestamp"]).sort_values("timestamp")
    df = df[(df["timestamp"] >= start_ts) & (df["timestamp"] < end_ts)]
    df = df.groupby("timestamp", as_index=False).first()
    return df



def load_cams_from_spectrl2_view(conn, start_utc: pd.Timestamp, end_utc: pd.Timestamp) -> pd.DataFrame:
    """
    CAMS adatok betöltése a cams_spectrl2_view view-ból.
    
    Oszlopok a view-ban:
    - timestamp (timestamptz)
    - asymmetry_factor_550 → GG
    - o3 → Ózon
    - ssa → Single Scattering Albedo @ 550nm
    - aod400 → AOD @ 400nm
    - aod500 → AOD @ 500nm
    - aod1064 → AOD @ 1064nm
    - boundary_layer_height → BLH
    - wv → Water Vapour (precipitable water)
    """
    query = f"""
    SELECT 
        timestamp,
        asymmetry_factor_550,
        o3,
        ssa,
        aod400,
        aod500,
        aod1064,
        boundary_layer_height,
        wv
    FROM {CAMS_VIEW}
    WHERE timestamp >= %s AND timestamp <= %s
    ORDER BY timestamp
    """
    
    try:
        df = pd.read_sql_query(query, conn, params=(start_utc, end_utc))
        if df.empty:
            print(f"[WARN] Nincs CAMS adat {start_utc} és {end_utc} között a {CAMS_VIEW}-ban")
            return pd.DataFrame()
        
        # Timestamp konverzió UTC-re
        df['timestamp'] = pd.to_datetime(df['timestamp'], utc=True)
        
        # Oszlopok átnevezése SMARTS-kompatibilis formátumra
        df = df.rename(columns={
            'asymmetry_factor_550': 'Asymmetry_factor_at_550_nm',
            'boundary_layer_height': 'Boundary_layer_height',
            'o3': 'GEMS_Total_column_ozone',
            'ssa': 'Single_scattering_albedo_at_550_nm',
            'aod400': 'Total_aerosol_optical_depth_at_400_nm',
            'aod500': 'Total_aerosol_optical_depth_at_500_nm',
            'aod1064': 'Total_aerosol_optical_depth_at_1064_nm',
            'wv': 'Total_column_vertically_integrated_water_vapour'
        })
        
        # τ550 BECSLÉS Angström törvénnyel (τ500 → τ550)
        tau500 = pd.to_numeric(df['Total_aerosol_optical_depth_at_500_nm'], errors='coerce')
        tau400 = pd.to_numeric(df['Total_aerosol_optical_depth_at_400_nm'], errors='coerce')
        
        # Angström exponens (α) számítás
        valid = (tau400 > 0) & (tau500 > 0) & np.isfinite(tau400) & np.isfinite(tau500)
        alpha = np.where(valid, 
                       -np.log(tau500/tau400) / np.log(500.0/400.0), 
                       1.3)  # default α
        
        # τ550 = τ500 × (550/500)^(-α)
        df['Total_Aerosol_Optical_Depth_at_550nm'] = tau500 * (550.0/500.0) ** (-alpha)
        
        # SSA @ 400nm oszlop hozzáadása (ha nincs, de van 550nm)
        if 'Single_scattering_albedo_at_550_nm' in df.columns:
            df['Single_scattering_albedo_at_400_nm'] = df['Single_scattering_albedo_at_550_nm']
        
        print(f"✓ CAMS spectrl2 view: {len(df)} sor [{df['timestamp'].min()} - {df['timestamp'].max()}]")
        return df
        
    except Exception as e:
        print(f"[ERROR] CAMS spectrl2 view betöltés hiba: {e}")
        import traceback
        traceback.print_exc()
        return pd.DataFrame()

def load_cams_atm_data(conn, start_utc: pd.Timestamp, end_utc: pd.Timestamp) -> pd.DataFrame:
    """
    CAMS AOD adatok betöltése a cams_atm_data táblából.
    
    Oszlopok:
    - timestamp (timestamptz)
    - asymmetry_factor_at_550_nm → GG
    - single_scattering_albedo_at_550_nm → SSA
    - total_aerosol_optical_depth_at_340_nm → AOD @ 340nm
    - total_aerosol_optical_depth_at_500_nm → AOD @ 500nm
    - total_aerosol_optical_depth_at_1064_nm → AOD @ 1064nm
    
    ALPHA1 számítás: 340nm és 500nm közötti (λ < 500nm tartományra)
    ALPHA2 számítás: 500nm és 1064nm közötti (λ ≥ 500nm tartományra)
    """
    query = f"""
    SELECT 
        timestamp,
        asymmetry_factor_at_550_nm,
        single_scattering_albedo_at_550_nm,
        total_aerosol_optical_depth_at_340_nm,
        total_aerosol_optical_depth_at_500_nm,
        total_aerosol_optical_depth_at_1064_nm
    FROM {CAMS_ATM_DATA_TABLE}
    WHERE timestamp >= %s AND timestamp <= %s
    ORDER BY timestamp
    """
    
    try:
        df = pd.read_sql_query(query, conn, params=(start_utc, end_utc))
        if df.empty:
            print(f"[WARN] Nincs CAMS adat {start_utc} és {end_utc} között a {CAMS_ATM_DATA_TABLE}-ban")
            return pd.DataFrame()
        
        # Timestamp konverzió UTC-re
        df['timestamp'] = pd.to_datetime(df['timestamp'], utc=True)
        
        # Numerikus konverzió
        for col in df.columns:
            if col != 'timestamp':
                df[col] = pd.to_numeric(df[col], errors='coerce')
        
        # --- ALPHA1 számítás (λ < 500nm): 340nm és 500nm közötti ---
        tau340 = df['total_aerosol_optical_depth_at_340_nm']
        tau500 = df['total_aerosol_optical_depth_at_500_nm']
        tau1064 = df['total_aerosol_optical_depth_at_1064_nm']
        
        valid_alpha1 = (tau340 > 0) & (tau500 > 0) & np.isfinite(tau340) & np.isfinite(tau500)
        alpha1 = np.where(
            valid_alpha1,
            -np.log(tau340 / tau500) / np.log(340.0 / 500.0),
            1.3  # default
        )
        df['ALPHA1'] = np.clip(alpha1, 0.0, 3.0)
        
        # --- ALPHA2 számítás (λ ≥ 500nm): 500nm és 1064nm közötti ---
        valid_alpha2 = (tau500 > 0) & (tau1064 > 0) & np.isfinite(tau500) & np.isfinite(tau1064)
        alpha2 = np.where(
            valid_alpha2,
            -np.log(tau500 / tau1064) / np.log(500.0 / 1064.0),
            1.3  # default
        )
        df['ALPHA2'] = np.clip(alpha2, 0.0, 3.0)
        
        # --- TAU550 becslés Angström törvénnyel (τ500 → τ550, ALPHA2 használatával) ---
        # τ550 = τ500 × (550/500)^(-α2)
        df['TAU550'] = np.where(
            np.isfinite(tau500) & (tau500 > 0),
            tau500 * (550.0 / 500.0) ** (-df['ALPHA2']),
            0.1  # default
        )
        df['TAU550'] = np.clip(df['TAU550'], 0.0, 5.0)
        
        # Oszlopok átnevezése SMARTS-kompatibilis formátumra
        df = df.rename(columns={
            'asymmetry_factor_at_550_nm': 'Asymmetry_factor_at_550_nm',
            'single_scattering_albedo_at_550_nm': 'Single_scattering_albedo_at_550_nm',
            'total_aerosol_optical_depth_at_340_nm': 'Total_aerosol_optical_depth_at_340_nm',
            'total_aerosol_optical_depth_at_500_nm': 'Total_aerosol_optical_depth_at_500_nm',
            'total_aerosol_optical_depth_at_1064_nm': 'Total_aerosol_optical_depth_at_1064_nm',
        })
        
        # TAU550 átnevezés is
        df['Total_Aerosol_Optical_Depth_at_550nm'] = df['TAU550']
        
        print(f"✓ CAMS ATM DATA: {len(df)} sor [{df['timestamp'].min()} - {df['timestamp'].max()}]")
        print(f"  ALPHA1 range: [{df['ALPHA1'].min():.3f} - {df['ALPHA1'].max():.3f}]")
        print(f"  ALPHA2 range: [{df['ALPHA2'].min():.3f} - {df['ALPHA2'].max():.3f}]")
        print(f"  TAU550 range: [{df['TAU550'].min():.4f} - {df['TAU550'].max():.4f}]")
        
        return df
        
    except Exception as e:
        print(f"[ERROR] CAMS ATM DATA betöltés hiba: {e}")
        import traceback
        traceback.print_exc()
        return pd.DataFrame()

def load_cams_layered_data(conn, start_utc: pd.Timestamp, end_utc: pd.Timestamp) -> pd.DataFrame:
    """
    CAMS layerenkénti adatok betöltése a cams_data táblából.
    
    Oszlopok:
    - timestamp (timestamptz)
    - blh_m (float) - Boundary Layer Height
    - t_k (array[33]) - Hőmérséklet [K]
    - q_kg_kg (array[33]) - Specific humidity [kg/kg]
    - ch4_c_kg_kg (array[33]) - Metán [kg/kg]
    - co_kg_kg (array[33]) - CO [kg/kg]
    - go3_kg_kg (array[33]) - O3 [kg/kg]
    - hcho_kg_kg (array[33]) - Formaldehid [kg/kg]
    - hno3_kg_kg (array[33]) - HNO3 [kg/kg]
    - no_kg_kg (array[33]) - NO [kg/kg]
    - no2_kg_kg (array[33]) - NO2 [kg/kg]
    - so2_kg_kg (array[33]) - SO2 [kg/kg]
    
    A tömbök 33 elemből állnak (137-es szinttől a 105-ös szintig).
    Az első elem (index 0) a 137-es szint (felszín közelében).
    """
    query = f"""
        SELECT 
            timestamp,
            blh_m,
            t_k,
            q_kg_kg,
            ch4_c_kg_kg,
            co_kg_kg,
            go3_kg_kg,
            hcho_kg_kg,
            hno3_kg_kg,
            no_kg_kg,
            no2_kg_kg,
            so2_kg_kg
        FROM {CAMS_LAYERED_TABLE}
        WHERE timestamp >= %s AND timestamp <= %s
        ORDER BY timestamp
    """
    try:
        df = pd.read_sql_query(query, conn, params=(start_utc, end_utc))
        if df.empty:
            print(f"[WARN] Nincs cams_data adat {start_utc} és {end_utc} között")
            return pd.DataFrame()
        
        df['timestamp'] = pd.to_datetime(df['timestamp'], utc=True)
        print(f"✓ cams_data (layered): {len(df)} sor [{df['timestamp'].min()} - {df['timestamp'].max()}]")
        return df
        
    except Exception as e:
        print(f"[ERROR] cams_data betöltés hiba: {e}")
        return pd.DataFrame()

def load_cams_upper_aod_multilevel(
    conn,
    start_utc: pd.Timestamp,
    end_utc: pd.Timestamp,
) -> pd.DataFrame:
    """
    CAMS multilevel extinction profilból számolt UPPER AOD (BLH->TOA), valid_time alapon.

    Forrás tábla:
      - aerosol_extinction_coefficients_multilevel
        - valid_time (timestamp w/o tz)
        - forecast_hours (int)
        - aerosol_extinction_coefficient_at_{355|532|1064}_nm_level_{1..137}

    Kimenet:
      timestamp (UTC, valid_time-ból)
      Upper_aod_355, Upper_aod_532, Upper_aod_1064
      Upper_aod_335, Upper_aod_550  (Angström konverzió)

    KONZISZTENCIA (Gábor A/F/I kérésével egységben):
      Az upper integrál alsó határa min(BLH, OPTICAL_MIXING_CAP) = min(BLH, 400 m),
      így pontosan ott indul, ahol a pymiescatt oldali lokális AOD véget ér.
      - BLH < 400  : upper = BLH → TOA,   lokális = 0 → BLH          (mint eddig)
      - BLH ≥ 400  : upper = 400 → TOA,   lokális = 0 → 400          (hézag nélkül)
      A meteorológiai blh_vals megmarad (diagnosztikához), csak az integrál
      határa kapja a cap-et.
    """
    import numpy as np
    import pandas as pd

    # ---------------- konfiguráció ----------------
    VIEW_EXT = globals().get("CAMS_AERO_EXT_VIEW", "aerosol_extinction_view")
    WVS = (355, 532, 1064)
    LEVELS = list(range(1, 138))  # 1..137

    PAD_H = 12
    CHUNK_DAYS = 7
    BLH_DEFAULT_M = 500.0

    # TOA dz közelítés
    SCALE_HEIGHT_M = 7400.0
    P_SURFACE_HPA = 1013.25

    # ÚJ: pymiescatt oldalával konzisztens optikai cap
    OPTICAL_MIXING_CAP = 400.0

    # ---------------- időablak ----------------
    start_utc = pd.to_datetime(start_utc, utc=True, errors="coerce")
    end_utc = pd.to_datetime(end_utc, utc=True, errors="coerce")
    if pd.isna(start_utc) or pd.isna(end_utc) or end_utc <= start_utc:
        return pd.DataFrame(columns=[
            "timestamp",
            "Upper_aod_355", "Upper_aod_532", "Upper_aod_1064",
            "Upper_aod_335", "Upper_aod_550"
        ])

    q0 = start_utc - pd.Timedelta(hours=PAD_H)
    q1 = end_utc + pd.Timedelta(hours=PAD_H)

    # ---------------- BLH betöltés (CAMS_VIEW) ----------------
    q_blh = f"""
        SELECT timestamp, boundary_layer_height
        FROM {CAMS_VIEW}
        WHERE timestamp >= %s AND timestamp <= %s
        ORDER BY timestamp
    """
    df_blh = pd.read_sql_query(q_blh, conn, params=(q0, q1))
    if df_blh is None or df_blh.empty:
        df_blh = pd.DataFrame({"timestamp": [q0, q1], "boundary_layer_height": [BLH_DEFAULT_M, BLH_DEFAULT_M]})
    df_blh["timestamp"] = pd.to_datetime(df_blh["timestamp"], utc=True, errors="coerce")
    df_blh = df_blh.dropna(subset=["timestamp"]).drop_duplicates("timestamp").sort_values("timestamp")
    df_blh["boundary_layer_height"] = pd.to_numeric(df_blh["boundary_layer_height"], errors="coerce")
    df_blh["boundary_layer_height"] = df_blh["boundary_layer_height"].fillna(BLH_DEFAULT_M).clip(0.0, 5000.0)

    blh_series = df_blh.set_index("timestamp")["boundary_layer_height"]

    # ---------------- aerosol_extinction_view betöltés ----------------
    VIEW_EXT = globals().get("CAMS_AERO_EXT_VIEW", "aerosol_extinction_view")
    q0_naive = q0.tz_convert(None)
    q1_naive = q1.tz_convert(None)

    q_ext = f"""
        SELECT
            valid_time,
            aerosol_extinction_coefficient_at_355_nm,
            aerosol_extinction_coefficient_at_532_nm,
            aerosol_extinction_coefficient_at_1064_nm
        FROM {VIEW_EXT}
        WHERE valid_time >= %s AND valid_time <= %s
        ORDER BY valid_time ASC
    """

    try:
        df_view = pd.read_sql_query(q_ext, conn, params=(q0_naive, q1_naive))
    except Exception as e:
        print(f"[ERROR] aerosol_extinction_view betöltés hiba: {e}")
        return pd.DataFrame(columns=[
            "timestamp",
            "Upper_aod_355", "Upper_aod_532", "Upper_aod_1064",
            "Upper_aod_335", "Upper_aod_550"
        ])

    if df_view is None or df_view.empty:
        return pd.DataFrame(columns=[
            "timestamp",
            "Upper_aod_355", "Upper_aod_532", "Upper_aod_1064",
            "Upper_aod_335", "Upper_aod_550"
        ])

    def _arr137(x):
        if x is None:
            return [np.nan] * 137
        try:
            arr = np.asarray(x, dtype=float).reshape(-1)
        except Exception:
            return [np.nan] * 137

        if arr.size < 137:
            arr = np.pad(arr, (0, 137 - arr.size), constant_values=np.nan)
        elif arr.size > 137:
            arr = arr[:137]

        return arr.tolist()

    # A view array sorrendje:
    # index 1 = surface közeli modell szint
    # index 137 = TOA közeli modell szint
    for wv in WVS:
        src_col = f"aerosol_extinction_coefficient_at_{wv}_nm"
        arrs = df_view[src_col].apply(_arr137)

        for lev in LEVELS:
            df_view[f"aerosol_extinction_coefficient_at_{wv}_nm_level_{lev}"] = arrs.str[lev - 1]

    ext_cols = []
    for wv in WVS:
        for lev in LEVELS:
            ext_cols.append(f"aerosol_extinction_coefficient_at_{wv}_nm_level_{lev}")

    df_ext = df_view[["valid_time"] + ext_cols].copy()
    df_ext["timestamp"] = pd.to_datetime(df_ext["valid_time"], errors="coerce").dt.tz_localize("UTC")
    df_ext = df_ext.dropna(subset=["timestamp"]).sort_values("timestamp")
    df_ext = df_ext.drop_duplicates(subset=["timestamp"], keep="first").reset_index(drop=True)
    # ---------------- Z_HALF (TOA) fél-szint magasságok ----------------
    if "ECMWF_L137_COEFFS" in globals() and isinstance(globals()["ECMWF_L137_COEFFS"], dict) and all(
        (k in globals()["ECMWF_L137_COEFFS"]) for k in range(1, 139)
    ):
        ps_Pa = float(P_SURFACE_HPA) * 100.0
        p_half = np.zeros(138, dtype=float)
        for hl in range(1, 139):
            a, b = globals()["ECMWF_L137_COEFFS"][hl]
            p_half[hl - 1] = float(a + b * ps_Pa)

        ps = max(1.0, p_half[137])
        H = float(SCALE_HEIGHT_M)
        z_half = H * np.log(ps / np.clip(p_half, 1e-6, None))
        z_half[137] = 0.0
        z_toa = float(z_half[0])
    else:
        z_half = np.linspace(80000.0, 0.0, 138).astype(float)
        z_toa = float(z_half[0])

    z_top = z_half[:137]
    z_bot = z_half[1:138]

    # ---------------- BLH interpoláció valid_time-okra ----------------
    ts_idx = df_ext["timestamp"].values
    blh_on_ext = blh_series.reindex(blh_series.index.union(df_ext["timestamp"])).sort_index()
    blh_on_ext = blh_on_ext.interpolate(method="time").ffill().bfill()
    blh_vals = blh_on_ext.reindex(df_ext["timestamp"]).values
    blh_vals = np.clip(pd.to_numeric(blh_vals, errors="coerce"), 0.0, 5000.0)
    blh_vals = np.where(np.isfinite(blh_vals), blh_vals, BLH_DEFAULT_M).astype(float)

    # ---- ÚJ: optikai határ (konzisztens a pymiescatt oldallal) ----
    # blh_vals  : valódi meteorológiai BLH (nem használjuk az integrálhoz)
    # optical_blh_vals : min(BLH, 400 m), ez az upper integrál alsó határa
    optical_blh_vals = np.minimum(blh_vals, OPTICAL_MIXING_CAP).astype(float)

    # ---------------- per-timestamp integrálás ----------------
    def _beta_matrix_for_wv(wv: int) -> np.ndarray:
        cols = [f"aerosol_extinction_coefficient_at_{wv}_nm_level_{lev}" for lev in LEVELS]
        m = df_ext[cols].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=float)
        m = np.where(np.isfinite(m) & (m > 0), m, 0.0)

        sample = m[m > 0]
        if sample.size > 0 and np.nanmedian(sample) > 0.05:
            m = m / 1000.0
        return m

    beta355 = _beta_matrix_for_wv(355)
    beta532 = _beta_matrix_for_wv(532)
    beta1064 = _beta_matrix_for_wv(1064)

    # Overlap: alsó határ = min(BLH, 400 m) → hézagmentes illeszkedés a lokális AOD-dal
    # overlap(t, L) = max(0, min(z_top[L], z_toa) - max(z_bot[L], optical_blh_t))
    def _overlap_matrix(lower_arr: np.ndarray) -> np.ndarray:
        lower_col = lower_arr.reshape(-1, 1)
        top = np.minimum(z_top.reshape(1, -1), z_toa)
        bot = np.maximum(z_bot.reshape(1, -1), lower_col)
        ov = np.maximum(0.0, top - bot)
        return ov

    # ÚJ: optical_blh_vals-val integrálunk, nem blh_vals-val
    overlap = _overlap_matrix(optical_blh_vals)

    tau355 = np.sum(beta355 * overlap, axis=1)
    tau532 = np.sum(beta532 * overlap, axis=1)
    tau1064 = np.sum(beta1064 * overlap, axis=1)
    med = float(np.nanmedian(tau532)) if np.isfinite(np.nanmedian(tau532)) else 0.0
    if med > 3.0:
        med2 = float(np.nanmedian(tau532 / 1000.0)) if np.isfinite(np.nanmedian(tau532 / 1000.0)) else 0.0
        if 0.0 <= med2 <= 3.0:
            tau355 = tau355 / 1000.0
            tau532 = tau532 / 1000.0
            tau1064 = tau1064 / 1000.0

    def _nan_if_empty(tau: np.ndarray, beta: np.ndarray) -> np.ndarray:
        nonzero = (beta > 0).sum(axis=1)
        tau2 = tau.copy()
        tau2[nonzero == 0] = np.nan
        return tau2

    tau355 = _nan_if_empty(tau355, beta355)
    tau532 = _nan_if_empty(tau532, beta532)
    tau1064 = _nan_if_empty(tau1064, beta1064)

    # Angström konverziók
    eps = 1e-10
    a1u = np.where(
        (tau355 > eps) & (tau532 > eps),
        -np.log(tau355 / tau532) / np.log(355.0 / 532.0),
        1.3
    )
    a2u = np.where(
        (tau532 > eps) & (tau1064 > eps),
        -np.log(tau532 / tau1064) / np.log(532.0 / 1064.0),
        1.3
    )
    a1u = np.clip(a1u, -0.5, 4.0)
    a2u = np.clip(a2u, -0.5, 4.0)

    tau335 = np.where(np.isfinite(tau355), tau355 * (335.0 / 355.0) ** (-a1u), np.nan)
    tau550 = np.where(np.isfinite(tau532), tau532 * (550.0 / 532.0) ** (-a2u), np.nan)

    out = pd.DataFrame({
        "timestamp": df_ext["timestamp"].values,
        "Upper_aod_355": np.clip(tau355, 0.0, 3.0),
        "Upper_aod_532": np.clip(tau532, 0.0, 3.0),
        "Upper_aod_1064": np.clip(tau1064, 0.0, 3.0),
        "Upper_aod_335": np.clip(tau335, 0.0, 3.0),
        "Upper_aod_550": np.clip(tau550, 0.0, 3.0),
    })

    out = out.drop_duplicates("timestamp").sort_values("timestamp").reset_index(drop=True)
    if not out.empty:
        n_capped = int(np.sum(blh_vals > OPTICAL_MIXING_CAP))
        print(
            f"✓ cams_upper_aod_multilevel: {len(out)} sor "
            f"[{out['timestamp'].min()} - {out['timestamp'].max()}] "
            f"| cap-elt timestampek (BLH>{OPTICAL_MIXING_CAP:.0f}m): {n_capped}"
        )
    return out

def load_cams_ratios(conn, start_utc: pd.Timestamp, end_utc: pd.Timestamp) -> pd.DataFrame:
    """
    CAMS aeroszol összetétel arányok betöltése a cams_ratios táblából.
    
    Oszlopok:
    - timestamp
    - dust_0_03_0_55_um_kg_kg   (finom por)
    - dust_0_55_0_9_um_kg_kg    (közepes por)
    - dust_0_9_20_um_kg_kg      (durva por)
    - om_hydrophilic_kg_kg      (vízkedvelő organikus)
    - om_hydrophobic_kg_kg      (víztaszító organikus)
    - bc_hydrophilic_kg_kg      (vízkedvelő korom)
    - bc_hydrophobic_kg_kg      (víztaszító korom)
    
    Returns:
        DataFrame agregált értékekkel:
        - bc_total: összes Black Carbon
        - om_total: összes Organic Matter
        - dust_total: összes Dust
    """
    query = """
        SELECT 
            timestamp,
            dust_0_03_0_55_um_kg_kg,
            dust_0_55_0_9_um_kg_kg,
            dust_0_9_20_um_kg_kg,
            om_hydrophilic_kg_kg,
            om_hydrophobic_kg_kg,
            bc_hydrophilic_kg_kg,
            bc_hydrophobic_kg_kg
        FROM cams_ratios_combined
        WHERE timestamp >= %s AND timestamp <= %s
        ORDER BY timestamp
    """
    
    try:
        df = pd.read_sql_query(query, conn, params=(start_utc, end_utc))
        if df.empty:
            print(f"[WARN] Nincs cams_ratios adat {start_utc} és {end_utc} között")
            return pd.DataFrame()
        
        df['timestamp'] = pd.to_datetime(df['timestamp'], utc=True)
        
        # Aggregált értékek számítása
        df['bc_total'] = (
            df['bc_hydrophilic_kg_kg'].fillna(0) + 
            df['bc_hydrophobic_kg_kg'].fillna(0)
        )
        df['om_total'] = (
            df['om_hydrophilic_kg_kg'].fillna(0) + 
            df['om_hydrophobic_kg_kg'].fillna(0)
        )
        df['dust_total'] = (
            df['dust_0_03_0_55_um_kg_kg'].fillna(0) + 
            df['dust_0_55_0_9_um_kg_kg'].fillna(0) + 
            df['dust_0_9_20_um_kg_kg'].fillna(0)
        )
        
        print(f"✓ cams_ratios: {len(df)} sor [{df['timestamp'].min()} - {df['timestamp'].max()}]")
        return df
        
    except Exception as e:
        print(f"[ERROR] cams_ratios betöltés hiba: {e}")
        import traceback
        traceback.print_exc()
        return pd.DataFrame()

# ---------------------------------------------------------------------
# 10s sensor grid + Median(5min) + EMA(20min) smoothing  (NEW)
# ---------------------------------------------------------------------
import numpy as np
import pandas as pd

def _smooth_series_10s(
    s: pd.Series,
    start_utc: pd.Timestamp,
    end_utc: pd.Timestamp,
    freq: str = "10S",
    median_window: int = 30,   # 30 * 10s = 5 min
    ema_span: int = 120,       # 120 * 10s = 20 min
    hi: float = None,
):
    """
    Exact procedure requested:
      1) 10s resample mean + interpolate + ffill + bfill
      2) rolling median (window=30, center=True)
      3) EMA (span=120, adjust=True)
    """
    s = pd.to_numeric(s, errors="coerce")

    if hi is not None:
        s[(s <= 0) | (s > hi)] = np.nan

    # resample to 10s
    grid = s.resample(freq).mean()

    # enforce full grid index (important)
    idx = pd.date_range(
        start=start_utc.floor(freq),
        end=end_utc.ceil(freq),
        freq=freq,
        tz="UTC"
    )
    grid = grid.reindex(idx)

    grid = grid.interpolate(method="time").ffill().bfill()

    median_f = grid.rolling(window=median_window, center=True, min_periods=1).median()
    final_signal = median_f.ewm(span=ema_span, adjust=True).mean()

    return final_signal


def build_sensor_grid_10s(df_sensor: pd.DataFrame,
                          col: str,
                          start_utc: pd.Timestamp,
                          end_utc: pd.Timestamp,
                          freq: str = "10S",
                          clip_min: float | None = None,
                          clip_max: float | None = None,
                          do_denoise: bool = False) -> pd.DataFrame:
    """
    10s rács mindenkinek (resample + interpolate + ffill/bfill).
    Median+EMA CSAK akkor, ha do_denoise=True (PM-ekre).
    """
    if df_sensor is None or df_sensor.empty:
        return pd.DataFrame({"timestamp": pd.date_range(start_utc, end_utc, freq=freq, tz="UTC"), col: np.nan})

    d = df_sensor.copy()
    d["timestamp"] = pd.to_datetime(d["timestamp"], utc=True, errors="coerce")
    d = d.dropna(subset=["timestamp"]).sort_values("timestamp").drop_duplicates("timestamp")
    d[col] = pd.to_numeric(d[col], errors="coerce")

    s = d.set_index("timestamp")[col]
    if clip_min is not None:
        s = s.where(s >= clip_min, np.nan)
    if clip_max is not None:
        s = s.where(s <= clip_max, np.nan)

    # 10s rács
    grid = s.resample(freq).mean()
    idx = pd.date_range(start_utc.floor(freq), end_utc.ceil(freq), freq=freq, tz="UTC")
    grid = grid.reindex(idx).interpolate("time").ffill().bfill()

    out = pd.DataFrame({"timestamp": grid.index, col: grid.values})

    if do_denoise:
        # PM-ekre: 5min rolling median (30*10s) + 20min EMA (120*10s)
        med = pd.Series(grid.values, index=grid.index).rolling(window=30, center=True, min_periods=1).median()
        ema = med.ewm(span=120, adjust=True).mean()
        out[f"{col}_filtered"] = ema.values

    return out


def merge_cams_to_sensor_grid_10s(
    df_sensor_10s: pd.DataFrame,
    df_cams: pd.DataFrame,
    freq: str = "10S",
):
    """
    LEFT JOIN: sensor grid is master.
    Then interpolate ONLY the CAMS columns (time interpolation).
    """

    if df_sensor_10s is None or df_sensor_10s.empty:
        return df_sensor_10s

    if df_cams is None or df_cams.empty:
        return df_sensor_10s

    s = df_sensor_10s.copy()
    c = df_cams.copy()

    s["timestamp"] = pd.to_datetime(s["timestamp"], utc=True)
    c["timestamp"] = pd.to_datetime(c["timestamp"], utc=True)

    # bucket timestamps to 10s to guarantee matches
    s["_ts_bucket"] = s["timestamp"].dt.floor(freq)
    c["_ts_bucket"] = c["timestamp"].dt.floor(freq)

    cams_cols = [x for x in c.columns if x not in ("timestamp", "_ts_bucket")]

    merged = s.merge(
        c[["_ts_bucket"] + cams_cols],
        on="_ts_bucket",
        how="left"
    ).drop(columns=["_ts_bucket"])

    # interpolate ONLY CAMS columns
    merged = merged.set_index("timestamp").sort_index()
    merged[cams_cols] = merged[cams_cols].interpolate(method="time").ffill().bfill()
    merged = merged.reset_index()

    return merged


import numpy as np
import pandas as pd

def _median_ema_filter(series: pd.Series, median_window: int = 30, ema_span: int = 120) -> pd.Series:
    """10s resample után rolling median + EMA, ahogy a Jupyter kódban."""
    s = pd.to_numeric(series, errors="coerce")
    s = s.interpolate().ffill().bfill()
    med = s.rolling(window=median_window, center=True, min_periods=1).median()
    return med.ewm(span=ema_span, adjust=True).mean()

def build_central_grid_10s_filtered(df_long: pd.DataFrame, t0: pd.Timestamp, t1: pd.Timestamp, freq: str = "10s") -> pd.DataFrame:
    """
    10s 'vödör' grid a TE specifikációd szerint:

    1) Előre legyártott 10s timestamp-rács
    2) MINDEN Central jel: 10s vödörön belüli ÁTLAG (bucket mean)
       - IMT14 irradiancia NEM megy SMARTS bemenetnek -> kivesszük innen
    3) Minden timestamphez érték biztosítása (interpolate + ffill + bfill)
    4) Zajkezelés MINDEN Central szenzorra, KIVÉVE temperature:
       - 5 perc medián (center)
       - 20 perc EMA
    + EXTRA (MOSTANI KÉRÉSED): PM outlier/tüske eltávolítás MIELŐTT bármi PM-művelet történne.
       - Hampel (rolling median + MAD) flag
       - Csak a rövid ideig tartó (<= max_event_s) tüskéket szedjük ki
    """

    import numpy as np
    import pandas as pd

    t0 = pd.to_datetime(t0, utc=True, errors="coerce")
    t1 = pd.to_datetime(t1, utc=True, errors="coerce")
    if pd.isna(t0) or pd.isna(t1) or t1 <= t0:
        return pd.DataFrame({"timestamp": pd.to_datetime([], utc=True)})

    # fix 10s rács (vödrök)
    idx = pd.date_range(t0.floor(freq), t1.ceil(freq), freq=freq, tz="UTC")

    # ha nincs adat
    if df_long is None or df_long.empty:
        return pd.DataFrame({"timestamp": idx})

    df = df_long.copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
    df = df.dropna(subset=["timestamp", "entity_id"])
    if df.empty:
        return pd.DataFrame({"timestamp": idx})

    # ------------------------------------------------------------------------------
    # 0) PM "rövid tüske" outlier eltávolítás (MINDEN PM-en), még a bucket mean előtt
    # ------------------------------------------------------------------------------
    PM_EIDS = [
        "sensor.tvl9_o_1pst_pm0_3",
        "sensor.tvl9_o_1pst_pm1",
        "sensor.tvl9_o_1pst_pm2_5",
        "sensor.tvl9_o_1pst_pm10",
    ]

    def _pm_remove_short_spikes_in_long(
        dfl: pd.DataFrame,
        pm_eids,
        window: str = "90s",      # lokális referenciaablak (idő-alapú rolling)
        k: float = 6.0,           # Hampel küszöb (MAD skála)
        rel_floor: float = 0.02,  # ha MAD ~ 0, legalább a medián 2%-a legyen a küszöb
        max_event_s: float = 30.0,# "rövid ideig tart" definíció (<= 30s)
        gap_s: float = 10.0       # flag-ek közti max gap, hogy még egy eseménynek számítson
    ) -> pd.DataFrame:
        """
        PM tüskék: rövid ideig tartó, lokális mediántól erősen eltérő értékek.
        Ezeket NaN-ra állítjuk, így:
          - a 10s vödör-átlag (mean) nem húzódik el
          - később az interpolate/ffill/bfill szépen kitölti
        """
        out = dfl

        # numeric értékek (csak PM-ekre)
        for eid in pm_eids:
            mask = (out["entity_id"] == eid)
            if not mask.any():
                continue

            sub = out.loc[mask, ["timestamp", "value"]].copy()
            sub["value"] = pd.to_numeric(sub["value"], errors="coerce")
            sub = sub.dropna(subset=["timestamp", "value"]).sort_values("timestamp")
            if len(sub) < 25:
                continue

            s = sub.set_index("timestamp")["value"]
            # rolling median + MAD (Hampel)
            med = s.rolling(window=window, center=True, min_periods=5).median()
            mad = (s - med).abs().rolling(window=window, center=True, min_periods=5).median()

            # robust küszöb: k*MAD, de legyen egy minimális "floor", különben MAD=0 esetén mindent flag-elne
            base = float(np.nanmedian(np.abs(s.to_numpy())))
            if not np.isfinite(base) or base <= 0:
                base = float(np.nanmedian(s.to_numpy()))
            if not np.isfinite(base) or base <= 0:
                base = 1.0

            floor = max(rel_floor * abs(base), 1e-6)
            thr = np.maximum(k * 1.4826 * mad.to_numpy(), floor)

            resid = (s - med).abs().to_numpy()
            flag = np.isfinite(resid) & np.isfinite(thr) & (resid > thr)

            if not flag.any():
                continue

            tflag = s.index[flag]
            # csoportosítás: ha két flagged pont között > gap_s sec, új outlier-esemény
            diff_s = pd.Series(tflag).diff().dt.total_seconds().fillna(0.0).to_numpy()
            grp = np.cumsum(diff_s > gap_s)

            gdf = pd.DataFrame({"ts": tflag, "grp": grp})
            agg = gdf.groupby("grp")["ts"].agg(["min", "max", "count"])
            agg["duration_s"] = (agg["max"] - agg["min"]).dt.total_seconds()

            short_grps = agg.index[(agg["duration_s"] <= max_event_s)]
            if len(short_grps) == 0:
                continue

            bad_ts = gdf.loc[gdf["grp"].isin(short_grps), "ts"]
            if bad_ts.empty:
                continue

            # NaN-ra állítjuk a rövid tüskék timestampjeit
            bad_ts = pd.DatetimeIndex(bad_ts.unique())
            bad_mask = mask & out["timestamp"].isin(bad_ts)
            removed = int(bad_mask.sum())
            if removed > 0:
                out.loc[bad_mask, "value"] = np.nan
                try:
                    LOGGER.info(f"[PM OUTLIER] {eid}: removed {removed} spike points (<= {max_event_s:.0f}s events)")
                except Exception:
                    pass

        return out

    df = _pm_remove_short_spikes_in_long(df, PM_EIDS)

    # --- KIVÉTEL: IMT14 nem megy SMARTS bemenetnek ---
    IMT14_EID = "sensor.tvl9_imt_14_irrad"
    df = df[df["entity_id"] != IMT14_EID]

    # --- 10s bucket mean (ettől "vödör": a 10s ablakon belüli átlag kerül be) ---
    df["ts_bucket"] = df["timestamp"].dt.floor(freq)
    df["value"] = pd.to_numeric(df["value"], errors="coerce")
    df = df.dropna(subset=["value"])

    bucket = (
        df.groupby(["ts_bucket", "entity_id"], as_index=False)["value"]
          .mean()
    )

    wide = bucket.pivot(index="ts_bucket", columns="entity_id", values="value").sort_index()

    # ráültetés a fix rácsra
    wide = wide.reindex(idx)

    # 3) minden timestamphez legyen érték (először)
    for c in wide.columns:
        s = pd.to_numeric(wide[c], errors="coerce")
        wide[c] = s.interpolate("time").ffill().bfill()

    # 4) zajkezelés: MINDEN Central szenzor, kivéve temperature
    #    (5p medián center + 20p EMA)
    TEMP_EID = "sensor.tvl9_gw2000a_outdoor_temperature"
    MED_WIN = 30   # 30 * 10s = 5 perc
    EMA_SPAN = 120 # 120 * 10s = 20 perc

    for c in list(wide.columns):
        if c == TEMP_EID:
            continue  # temperature: nincs zajkezelés

        s = pd.to_numeric(wide[c], errors="coerce")
        med = s.rolling(window=MED_WIN, center=True, min_periods=1).median()
        ema = med.ewm(span=EMA_SPAN, adjust=False).mean()
        wide[c] = ema

    out = wide.reset_index().rename(columns={"index": "timestamp"})
    return out



def attach_cams_to_10s_grid(df_sensor_10s: pd.DataFrame,
                            df_cams: pd.DataFrame,
                            cams_cols: list) -> pd.DataFrame:
    """
    10s grid mellé CAMS órás értékek hozzárendelése.
    - csak CAMS oszlopok interpolálódnak
    """
    if df_sensor_10s is None or df_sensor_10s.empty:
        return df_sensor_10s

    out = df_sensor_10s.copy()
    out["timestamp"] = pd.to_datetime(out["timestamp"], utc=True, errors="coerce")
    out = out.dropna(subset=["timestamp"]).sort_values("timestamp")
    out = out.set_index("timestamp")

    if df_cams is None or df_cams.empty:
        out = out.reset_index()
        return out

    cams = df_cams.copy()
    cams["timestamp"] = pd.to_datetime(cams["timestamp"], utc=True, errors="coerce")
    cams = cams.dropna(subset=["timestamp"]).sort_values("timestamp")
    cams = cams.set_index("timestamp")

    # csak a kért cams oszlopok
    cams = cams[[c for c in cams_cols if c in cams.columns]]

    # beírjuk a CAMS órás pontokat a 10s gridre (exact match óránként)
    for c in cams.columns:
        if c not in out.columns:
            out[c] = np.nan
        out.loc[out.index.intersection(cams.index), c] = cams.loc[out.index.intersection(cams.index), c]

    # CSAK CAMS oszlopokat interpolálunk
    cams_cols_present = [c for c in cams.columns if c in out.columns]
    out[cams_cols_present] = out[cams_cols_present].interpolate(method="time").ffill().bfill()

    return out.reset_index()