from __future__ import annotations

"""
smarts_runner.py — Párhuzamos-biztos SMARTS futtatás
=====================================================

PROBLÉMA:
  A SMARTS fix fájlneveket használ (smarts295.inp.txt, smarts295.ext.txt, Albedo/Albedo.dat).
  Ha két process egyszerre futtatja (pl. két nohup terminálból), felülírják egymás fájljait
  → hibás eredmények, crash, vagy csendben rossz számok.

MEGOLDÁS:
  Minden Python process (PID) saját SMARTS munkakönyvtárat kap:
    /tmp/smarts_worker_pid12345/
  Ez a modul betöltődésekor EGYSZER jön létre (symlink-ekkel a nagy fájlokra, másolat a kicsikre),
  és atexit-tel törlődik.

  Terminál 1 (PID 12345):  /tmp/smarts_worker_pid12345/  ← ide ír, innen olvas
  Terminál 2 (PID 67890):  /tmp/smarts_worker_pid67890/  ← ide ír, innen olvas
  → Teljesen független, nem zavarják egymást.

NINCS VÁLTOZÁS más fájlokban — run_smarts_once() szignatúrája VÁLTOZATLAN.
"""

from pathlib import Path
from typing import Optional
import os
import stat
import subprocess
import shutil
import atexit
import pandas as pd
import numpy as np

from const import SMARTS_DIR, SMARTS_TIMEOUT


# =============================================================================
# 1) PID-egyedi munkakönyvtár létrehozása (EGYSZER, modul betöltődéskor)
# =============================================================================

def _create_worker_dir(smarts_dir: Path) -> Path:
    """
    Létrehoz egy PID-egyedi SMARTS munkakönyvtárat.

    A nagy adatfájlokat (Gases/, Solar/, CIE_data/) SYMLINK-kel hivatkozza
    (gyors, nem foglal helyet). A kis fájlokat és az Albedo/ könyvtárat MÁSOLJA
    (mert ezeket írjuk futás közben).

    Returns:
        Path: a munkakönyvtár útvonala, pl. /tmp/smarts_worker_pid12345
    """
    pid = os.getpid()
    worker = Path(f"/tmp/smarts_worker_pid{pid}")

    # Ha már létezik (pl. korábbi crash után), töröljük
    if worker.exists():
        shutil.rmtree(worker, ignore_errors=True)

    worker.mkdir(parents=True)

    # Nagy, CSAK OLVASOTT könyvtárak → symlink (gyors, 0 byte)
    symlink_dirs = ["Gases", "Solar", "CIE_data"]
    for d in symlink_dirs:
        src = smarts_dir / d
        dst = worker / d
        if src.is_dir():
            dst.symlink_to(src.resolve())

    # Albedo könyvtár → MÁSOLAT (mert ide írjuk az Albedo.dat-ot)
    src_albedo = smarts_dir / "Albedo"
    dst_albedo = worker / "Albedo"
    if src_albedo.is_dir():
        shutil.copytree(src_albedo, dst_albedo)
    else:
        dst_albedo.mkdir(parents=True, exist_ok=True)

    # Futtatható SMARTS bináris → másolat (kicsi, ~1 MB)
    for exe_name in ["smarts295", "smarts295bat.exe"]:
        src_exe = smarts_dir / exe_name
        if src_exe.is_file():
            shutil.copy2(src_exe, worker / exe_name)

    print(f"✓ SMARTS worker könyvtár létrehozva: {worker}  (PID={pid})")
    return worker


def _cleanup_worker_dir(worker: Path):
    """Takarítás: törli a munkakönyvtárat (symlink-ek nem törlik az eredetit!)."""
    if worker and worker.exists():
        try:
            shutil.rmtree(worker, ignore_errors=True)
            print(f"✓ SMARTS worker könyvtár törölve: {worker}")
        except Exception as e:
            print(f"[WARN] Worker könyvtár törlés hiba: {e}")


# --- Modul szintű inicializáció ---
_WORKER_DIR: Path = _create_worker_dir(SMARTS_DIR)
atexit.register(_cleanup_worker_dir, _WORKER_DIR)


def get_worker_dir() -> Path:
    """
    Visszaadja az aktuális process SMARTS worker könyvtárát.
    Más modulok (pl. smarts_cards.py) is használhatják,
    ha Albedo.dat-ot akarnak írni a helyes könyvtárba.
    """
    return _WORKER_DIR


# =============================================================================
# 2) Segédfüggvények (VÁLTOZATLAN logika)
# =============================================================================

def _ensure_executable(p: Path):
    if not p.exists():
        raise FileNotFoundError(f"SMARTS nem található: {p}")
    mode = p.stat().st_mode
    if not (mode & stat.S_IXUSR):
        p.chmod(mode | stat.S_IXUSR)


def _clean_smarts_outputs(smarts_dir: Path):
    for fn in ["smarts295.out.txt", "smarts295.ext.txt",
               "smarts295.scn.txt", "smarts295.inp.txt"]:
        fp = smarts_dir / fn
        if fp.exists():
            try:
                fp.unlink()
            except Exception:
                pass


def _detect_is_tilt_from_input(input_text: str) -> bool:
    """
    A smarts_cards tipikusan a Card16-ot így írja:
      -1, <TILT>, <WAZIM>
    Ebből detektáljuk, hogy tilt futásról van-e szó.
    """
    for ln in (input_text or "").splitlines():
        t = ln.strip()
        if not t:
            continue
        if t.lstrip().startswith("-1"):
            parts = [p.strip() for p in t.split(",")]
            if len(parts) >= 2:
                try:
                    tilt = float(parts[1])
                    return abs(tilt) > 1e-6
                except Exception:
                    pass
    return False


def _parse_file17(text: str) -> pd.DataFrame:
    """
    ÚJ: több oszlop kezelése.
    SMARTS FILE17-ben a 'Wvlgth ...' fejléc alapján több irradiancia oszlopot olvasunk.
    """
    lines = text.splitlines()

    def _is_float(s: str) -> bool:
        try:
            float(s)
            return True
        except Exception:
            return False

    header = None
    data = []

    for ln in lines:
        t = ln.strip()
        if not t:
            continue

        # fejléc sor (tipikusan: Wvlgth  GloHor  DirNor  DifHor  DirHor ...)
        if t.lower().startswith("wvlgth"):
            header = t.split()
            continue

        parts = t.split()
        if len(parts) < 2:
            continue
        if _is_float(parts[0]) and _is_float(parts[1]):
            if header is not None:
                k = min(len(header), len(parts))
                data.append([float(x) for x in parts[:k]])
            else:
                data.append([float(x) for x in parts])

    if not data:
        return pd.DataFrame(columns=["wavelength_nm", "ghi_w_m2_per_nm"])

    arr = np.array(data, dtype=float)
    ncols = arr.shape[1]

    if header is not None and len(header) == ncols:
        cols = header
    else:
        cols = ["Wvlgth"] + [f"col{i}" for i in range(1, ncols)]

    df = pd.DataFrame(arr, columns=cols)

    # rename wavelength
    wl_col = df.columns[0]
    df = df.rename(columns={wl_col: "wavelength_nm"})

    def _norm(c: str) -> str:
        c = c.lower()
        return "".join(ch for ch in c if ch.isalnum())

    rename = {}
    for c in df.columns[1:]:
        cc = _norm(c)

        if "glohor" in cc or ("global" in cc and "hor" in cc):
            rename[c] = "ghi_w_m2_per_nm"
        elif "dirnor" in cc or ("direct" in cc and "nor" in cc):
            rename[c] = "dni_w_m2_per_nm"
        elif "difhor" in cc or ("diffuse" in cc and "hor" in cc):
            rename[c] = "dhi_w_m2_per_nm"
        elif "dirhor" in cc or ("direct" in cc and "hor" in cc):
            rename[c] = "dir_horiz_w_m2_per_nm"
        elif "dirtilt" in cc or ("direct" in cc and "tilt" in cc):
            rename[c] = "dir_tilt_w_m2_per_nm"
        elif "diftlt" in cc or "diftilt" in cc or ("diffuse" in cc and "tilt" in cc):
            rename[c] = "diff_tilt_w_m2_per_nm"
        elif "glotlt" in cc or ("global" in cc and "tilt" in cc):
            rename[c] = "gti_w_m2_per_nm"

    df = df.rename(columns=rename)

    # backward compat: ha csak 1 oszlop van és nem lett felismerve -> ghi
    non_wl = [c for c in df.columns if c != "wavelength_nm"]
    if len(non_wl) == 1 and non_wl[0] != "ghi_w_m2_per_nm":
        df = df.rename(columns={non_wl[0]: "ghi_w_m2_per_nm"})

    return df


# =============================================================================
# 3) FŐ FÜGGVÉNY: run_smarts_once() — MOST MÁR _WORKER_DIR-BEN DOLGOZIK
# =============================================================================

def run_smarts_once(input_text: str, *, return_is_tilt: bool = False):
    """
    SMARTS futtatás a PID-egyedi worker könyvtárban.

    VÁLTOZÁS az eredetihez képest:
      - NEM a közös SMARTS_DIR-ben dolgozik, hanem a _WORKER_DIR-ben
      - NEM használ os.chdir()-t (az globális és thread-unsafe)
      - Helyette: subprocess cwd= paraméterrel futtat

    Szignatúra VÁLTOZATLAN:
      return_is_tilt=False: kompatibilis mód (csak DataFrame / None)
      return_is_tilt=True : (DataFrame/None, is_tilt: bool)
    """
    is_tilt = _detect_is_tilt_from_input(input_text)

    workdir = _WORKER_DIR

    exe_bat = workdir / "smarts295bat.exe"
    exe_std = workdir / "smarts295"
    exe = exe_bat if exe_bat.exists() else exe_std
    _ensure_executable(exe)

    try:
        _clean_smarts_outputs(workdir)

        # Input fájl írása a WORKER könyvtárba
        with open(workdir / "smarts295.inp.txt", "w",
                  encoding="ascii", errors="ignore") as f:
            f.write(input_text)

        # SMARTS futtatás — cwd= a worker könyvtár (NEM os.chdir!)
        if exe is exe_bat:
            proc = subprocess.run(
                [str(exe)],
                text=True, capture_output=True,
                timeout=SMARTS_TIMEOUT,
                cwd=str(workdir),
            )
        else:
            proc = subprocess.run(
                [str(exe)],
                input="Y\n",
                text=True, capture_output=True,
                timeout=SMARTS_TIMEOUT,
                cwd=str(workdir),
            )

        if proc.returncode != 0:
            return (None, is_tilt) if return_is_tilt else None

        # Eredmény olvasása a WORKER könyvtárból
        ext = workdir / "smarts295.ext.txt"
        if not ext.exists():
            return (None, is_tilt) if return_is_tilt else None

        text = ext.read_text(encoding="ascii", errors="ignore")
        df = _parse_file17(text)

        return (df, is_tilt) if return_is_tilt else df

    except subprocess.TimeoutExpired:
        return (None, is_tilt) if return_is_tilt else None