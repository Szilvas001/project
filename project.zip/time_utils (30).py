from __future__ import annotations
from typing import List, Tuple
import pandas as pd

def parse_periods_to_utc(periods: List[Tuple[str, str]]) -> List[Tuple[pd.Timestamp, pd.Timestamp]]:
    out = []
    for start_str, end_str in periods:
        t0 = pd.Timestamp(start_str)
        t1 = pd.Timestamp(end_str)
        t0 = t0.tz_convert("UTC") if t0.tzinfo else t0.tz_localize("UTC")
        t1 = t1.tz_convert("UTC") if t1.tzinfo else t1.tz_localize("UTC")
        if not (t1 > t0):
            raise ValueError(f"Időintervallum hibás: {start_str} → {end_str}")
        out.append((t0, t1))
    return out