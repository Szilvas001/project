import sys
from datetime import time as dt_time
from typing import List, Tuple
import numpy as np
import pandas as pd
import pvlib
from scipy.interpolate import interp1d, CubicSpline
import os
from pathlib import Path
from typing import Optional, Tuple



from const import *

def _compute_zenith_aoi(ts_utc, lat, lon, alt_km, panel_tilt, panel_azimuth):
    sp = _sunpos(ts_utc, lat, lon, alt_km)
    zen = float(sp["apparent_zenith"].iloc[0])
    azi = float(sp["azimuth"].iloc[0])
    aoi = pvlib.irradiance.aoi(panel_tilt, panel_azimuth, zen, azi)
    return zen, float(aoi)

# ======================= SEGÉDFÜGGVÉNYEK =======================
def dprint(msg: str):
    if DEBUG:
        print(msg)
        sys.stdout.flush()
        # DEBUG szintre logoljuk, de az alap loglevel INFO, így nem kerül fájlba
        LOGGER.debug(msg)



def _safe_float(x, default=np.nan) -> float:
    try:
        v = float(x)
        return v if np.isfinite(v) else default
    except Exception:
        return default

def _clamp(v, vmin, vmax):
    try:
        return max(vmin, min(vmax, float(v)))
    except Exception:
        return np.nan

def daytime_only(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty or "timestamp" not in df.columns:
        return df
    t = pd.to_datetime(df["timestamp"], utc=True, errors="coerce").dt.time
    mask = (t >= DAY_START_UTC) & (t <= DAY_END_UTC)
    filtered = df.loc[mask].copy()
    dprint(f"  Nappali szűrés: {len(df)} → {len(filtered)} sor")
    return filtered

# Napgeometria
def _sunpos(ts_utc, lat, lon, alt_km):
    return pvlib.solarposition.get_solarposition(
        time=ts_utc, latitude=lat, longitude=lon, altitude=alt_km*1000.0, method="nrel_numpy"
    )

def _sun_elev_deg(ts_utc, lat, lon, alt_km):
    sp = _sunpos(ts_utc, lat, lon, alt_km)
    return float(sp["apparent_elevation"].iloc[0])

def _compute_aoi(ts_utc, lat, lon, alt_km, panel_tilt, panel_azimuth):
    sp = _sunpos(ts_utc, lat, lon, alt_km)
    zen = float(sp["apparent_zenith"].iloc[0])
    azi = float(sp["azimuth"].iloc[0])
    aoi = pvlib.irradiance.aoi(panel_tilt, panel_azimuth, zen, azi)
    return float(aoi)


# SR és IAM interpolátorok
def _sr_interp():
    wl = np.array(list(SR_POINTS.keys()), float)
    sr = np.array(list(SR_POINTS.values()), float)
    idx = np.argsort(wl)
    return interp1d(wl[idx], sr[idx], kind="cubic", bounds_error=False, fill_value=0.0)

def _iam_spline():
    # Kötelezően CubicSpline – ha nincs, álljon le
    if CubicSpline is None:
        raise RuntimeError("CubicSpline szükséges az IAM-hez (csak és kizárólag CubicSpline)")

    aoi_deg = np.array([0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90], dtype=float)
    iam_val = np.array([1.00, 1.00, 1.00, 1.00, 1.00, 0.995, 0.988, 0.986, 0.980, 0.976,
                        0.970, 0.960, 0.933, 0.921, 0.877, 0.819, 0.711, 0.546, 0.00], dtype=float)

    spline = CubicSpline(aoi_deg, iam_val, bc_type="natural")

    def _fn(a):
        a = np.asarray(a, dtype=float)
        a = np.clip(a, 0.0, 90.0)
        return np.clip(spline(a), 0.0, 1.0)

    return _fn

# ======================= DENORM (GHI vs GTI) =======================
# Cél:
#  - GHI (nem tilt): csak standard 1/R^2 (Earth–Sun distance) korrekció
#  - GTI (tilt): ASTM G173 alapján számolt K_beam/K_diffuse -> ebből kA_beam/kA_diffuse
#    és a meglévő base_kA-hoz viszonyított korrekció (hogy a meglévő pipeline ne sérüljön)

_GTI_K_CACHE: Optional[Tuple[float, float]] = None
_GTI_K_CACHE_PATH: Optional[str] = None

def _inv_r2_correction(ts_utc) -> float:
    """
    Standard 1/R^2 korrekció (Earth-Sun distance), dimenziótlan.
    Spencer (1971)-féle közelítés: közvetlenül az E0 = 1/R^2 értéket adja.
    """
    ts = pd.to_datetime(ts_utc, utc=True, errors="coerce")
    if ts is pd.NaT or ts is None:
        return 1.0

    try:
        doy = int(ts.dayofyear)
        g = 2.0 * np.pi * (doy - 1) / 365.0
        e0 = (
            1.00011
            + 0.034221 * np.cos(g)
            + 0.00128 * np.sin(g)
            + 0.000719 * np.cos(2 * g)
            + 0.000077 * np.sin(2 * g)
        )
        return float(e0)
    except Exception:
        return 1.0


def calculate_precise_k_factors(path_to_astm_csv: str, sr_wavelengths: np.ndarray, sr_response: np.ndarray):
    """
    K_beam és K_diffuse számítása ASTM G173 geometrián.

    Támogatott bemenet:
      - ASTMG173.csv (tipikusan header=1-es formátum, de header=0-t is megpróbálunk)
      - ASTMG173.xls/.xlsx (ha véletlenül ezt adod meg)

    Visszatér: (K_beam, K_diffuse), tipikusan ~0.60..0.61 és ~0.55..0.57.
    """
    import os

    p = str(path_to_astm_csv) if path_to_astm_csv is not None else ""
    if not p:
        try:
            LOGGER.warning("[DENORM] ASTM path empty.")
        except Exception:
            pass
        return None, None

    if not os.path.exists(p):
        try:
            LOGGER.warning(f"[DENORM] ASTM file does not exist: {p}")
        except Exception:
            pass
        return None, None

    # --- 1) Betöltés (CSV vagy XLS) ---
    df = None
    try:
        low = p.lower()
        if low.endswith(".xls") or low.endswith(".xlsx"):
            # Excel (ha van engine)
            df = pd.read_excel(p, header=1)
        else:
            # CSV: először header=1, ha nem jó, fallback header=0
            try:
                df = pd.read_csv(p, header=1)
            except Exception:
                df = pd.read_csv(p, header=0)
    except Exception as e:
        try:
            LOGGER.warning(f"[DENORM] ASTM file load error: {e}")
        except Exception:
            pass
        return None, None

    if df is None or df.empty or df.shape[1] < 4:
        try:
            LOGGER.warning("[DENORM] ASTM dataframe invalid/empty or has <4 columns.")
        except Exception:
            pass
        return None, None

    # --- 2) Oszlopok (ASTM tipikus): 0=wl(nm), 2=Global Tilt, 3=Direct Normal ---
    wl = pd.to_numeric(df.iloc[:, 0], errors="coerce")
    global_tilt = pd.to_numeric(df.iloc[:, 2], errors="coerce")
    direct_normal = pd.to_numeric(df.iloc[:, 3], errors="coerce")

    mask = wl.notna() & global_tilt.notna() & direct_normal.notna()
    wl = wl[mask].to_numpy(dtype=float)
    global_tilt = global_tilt[mask].to_numpy(dtype=float)
    direct_normal = direct_normal[mask].to_numpy(dtype=float)

    if wl.size < 50:
        try:
            LOGGER.warning(f"[DENORM] ASTM too few valid rows: {wl.size}")
        except Exception:
            pass
        return None, None

    # rendezzük hullámhossz szerint
    idx = np.argsort(wl)
    std_wl = wl[idx]
    std_global_tilt = global_tilt[idx]
    std_direct_normal = direct_normal[idx]

    # --- 3) SR interpoláció ASTM hullámhossz rácsra ---
    sr_interp = np.interp(std_wl, sr_wavelengths, sr_response, left=0.0, right=0.0)

    # --- 4) K_beam (Direct Normal) ---
    numerator_beam = np.trapz(std_direct_normal * sr_interp, std_wl)
    denominator_beam = np.trapz(std_direct_normal, std_wl)
    if not np.isfinite(denominator_beam) or denominator_beam <= 0:
        return None, None
    K_beam = numerator_beam / denominator_beam

    # --- 5) K_diffuse (Global Tilt -> Diffuse Tilt kivonással) ---
    theta_deg = 48.19 - 37.0
    theta_rad = np.radians(theta_deg)

    std_diffuse_tilt = std_global_tilt - (std_direct_normal * np.cos(theta_rad))
    std_diffuse_tilt = np.where(std_diffuse_tilt < 0, 0.0, std_diffuse_tilt)

    numerator_diffuse = np.trapz(std_diffuse_tilt * sr_interp, std_wl)
    denominator_diffuse = np.trapz(std_diffuse_tilt, std_wl)
    if not np.isfinite(denominator_diffuse) or denominator_diffuse <= 0:
        return None, None
    K_diffuse = numerator_diffuse / denominator_diffuse

    if not (np.isfinite(K_beam) and np.isfinite(K_diffuse) and K_beam > 0 and K_diffuse > 0):
        return None, None

    return float(K_beam), float(K_diffuse)



def _resolve_default_astm_path(path_to_astm_csv: Optional[str]) -> Optional[str]:
    """
    ASTM feloldás + opcionális automata letöltés + XLS->CSV konverzió.

    Keresési sorrend:
      1) explicit path_to_astm_csv (ha létezik)
      2) env: ASTM_G173_CSV_PATH / ASTMG173_CSV / ASTM_G173_CSV
      3) helpers.py mappája: ./ASTMG173.csv vagy ./ASTMG173.xls
      4) SMARTS_DIR: ASTMG173.csv vagy ASTMG173.xls
      5) cwd: ./ASTMG173.csv vagy ./ASTMG173.xls
      6) ha nincs: letöltés (kikapcsolható: ASTM_G173_NO_DOWNLOAD=1)

    Letöltés célja alapból: SMARTS_DIR/ASTMG173.csv (ha írható), különben cwd.
    """
    import os
    import tempfile
    import urllib.request
    import zipfile
    import shutil

    def _is_writable_dir(d: Path) -> bool:
        try:
            d.mkdir(parents=True, exist_ok=True)
            test = d / ".write_test"
            test.write_text("ok", encoding="utf-8")
            test.unlink(missing_ok=True)
            return True
        except Exception:
            return False

    def _convert_xls_to_csv(xls_path: Path, csv_path: Path) -> bool:
        """
        Megpróbálja az ASTMG173.xls/xlsx fájlt CSV-vé alakítani.
        Először read_excel (xlrd/openpyxl engine függő), majd fallback: read_html (ha HTML-nek álcázott).
        """
        try:
            df = pd.read_excel(str(xls_path), header=1)
        except Exception:
            # néha az .xls valójában HTML táblázat
            try:
                tables = pd.read_html(str(xls_path), header=1)
                df = tables[0] if tables else None
            except Exception:
                df = None

        if df is None or df.empty or df.shape[1] < 4:
            return False

        # csak a releváns 4 oszlop
        out = df.iloc[:, :4].copy()
        csv_path.parent.mkdir(parents=True, exist_ok=True)
        out.to_csv(str(csv_path), index=False)
        return True

    # ---------- 1) explicit ----------
    if path_to_astm_csv:
        p = Path(path_to_astm_csv)
        if p.exists():
            return str(p)

    # ---------- 2) env ----------
    env = os.getenv("ASTM_G173_CSV_PATH") or os.getenv("ASTMG173_CSV") or os.getenv("ASTM_G173_CSV")
    if env:
        p = Path(env)
        if p.exists():
            return str(p)

    # ---------- candidate dirs ----------
    candidates_dirs: list[Path] = []
    try:
        candidates_dirs.append(Path(__file__).resolve().parent)
    except Exception:
        pass

    try:
        candidates_dirs.append(Path(SMARTS_DIR))
    except Exception:
        pass

    try:
        candidates_dirs.append(Path.cwd())
    except Exception:
        pass

    # ---------- 3-5) keresés + xls->csv konverzió ----------
    for d in candidates_dirs:
        csvp = d / "ASTMG173.csv"
        if csvp.exists():
            return str(csvp)

        xlsp = d / "ASTMG173.xls"
        if xlsp.exists():
            # konvertáljuk ugyanoda CSV-re
            if _convert_xls_to_csv(xlsp, csvp):
                try:
                    print(f"✓ ASTM: XLS→CSV konverzió kész: {csvp}")
                except Exception:
                    pass
                return str(csvp)

        xlsxp = d / "ASTMG173.xlsx"
        if xlsxp.exists():
            if _convert_xls_to_csv(xlsxp, csvp):
                try:
                    print(f"✓ ASTM: XLSX→CSV konverzió kész: {csvp}")
                except Exception:
                    pass
                return str(csvp)

    # ---------- 6) automata letöltés ----------
    if (os.getenv("ASTM_G173_NO_DOWNLOAD") or "").strip() == "1":
        return None

    # célkönyvtár: SMARTS_DIR ha írható, különben cwd
    dest_dir = None
    try:
        sd = Path(SMARTS_DIR)
        if _is_writable_dir(sd):
            dest_dir = sd
    except Exception:
        dest_dir = None

    if dest_dir is None:
        try:
            cd = Path.cwd()
            if _is_writable_dir(cd):
                dest_dir = cd
        except Exception:
            dest_dir = None

    if dest_dir is None:
        return None

    dest_csv = dest_dir / "ASTMG173.csv"
    dest_xls = dest_dir / "ASTMG173.xls"
    dest_zip = dest_dir / "astmg173.zip"

    # URL lista (próbálkozunk több forrással; ha nálad nincs net, úgyis fallback lesz)
    urls = [
        os.getenv("ASTM_G173_URL", "").strip(),
        # NREL/NLR publikált fájlok (ha elérhető)
        "https://www.nrel.gov/media/docs/libraries/grid/astmg173.xls?sfvrsn=d186dec0_1",
        "https://www.nlr.gov/media/docs/libraries/grid/astmg173.xls?sfvrsn=d186dec0_1",
        "https://www.nrel.gov/media/docs/libraries/grid/zip/astmg173.zip",
        "https://www.nlr.gov/media/docs/libraries/grid/zip/astmg173.zip",
    ]
    urls = [u for u in urls if u]

    def _download(url: str, out_path: Path) -> bool:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "BESTSMARTS/1.0"})
            with urllib.request.urlopen(req, timeout=45) as resp:
                data = resp.read()
            if not data or len(data) < 1024:
                return False
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_bytes(data)
            return True
        except Exception:
            return False

    # próbáljuk először ZIP-et, aztán XLS-t
    for url in urls:
        low = url.lower()
        if low.endswith(".zip") or ".zip" in low:
            if _download(url, dest_zip):
                try:
                    with zipfile.ZipFile(str(dest_zip), "r") as z:
                        names = z.namelist()
                        # preferáljuk csv/txt, aztán xls/xlsx
                        pick = None
                        for ext in (".csv", ".txt", ".xls", ".xlsx"):
                            for n in names:
                                if n.lower().endswith(ext):
                                    pick = n
                                    break
                            if pick:
                                break
                        if not pick:
                            continue

                        with tempfile.TemporaryDirectory() as td:
                            td = Path(td)
                            z.extract(pick, path=str(td))
                            extracted = td / pick
                            if not extracted.exists():
                                # néha almappában jön ki
                                extracted = next(td.rglob(Path(pick).name), None)

                            if extracted is None or not Path(extracted).exists():
                                continue

                            ex = Path(extracted)
                            if ex.suffix.lower() in (".csv", ".txt"):
                                shutil.copyfile(str(ex), str(dest_csv))
                                print(f"✓ ASTM: letöltve ZIP-ből: {dest_csv}")
                                return str(dest_csv)
                            else:
                                # xls/xlsx -> csv
                                if shutil.copyfile(str(ex), str(dest_xls)) is None:
                                    pass
                                if _convert_xls_to_csv(dest_xls, dest_csv):
                                    print(f"✓ ASTM: ZIP→XLS→CSV kész: {dest_csv}")
                                    return str(dest_csv)
                except Exception:
                    continue

        # XLS közvetlen
        if low.endswith(".xls") or ".xls" in low or low.endswith(".xlsx") or ".xlsx" in low:
            if _download(url, dest_xls):
                if _convert_xls_to_csv(dest_xls, dest_csv):
                    try:
                        print(f"✓ ASTM: letöltve + XLS→CSV kész: {dest_csv}")
                    except Exception:
                        pass
                    return str(dest_csv)

    return None


def _get_gti_k_factors_cached(path_to_astm_csv: Optional[str]) -> Tuple[float, float]:
    """
    Cache-elt (K_beam, K_diffuse) betöltés/számítás.

    ÚJ: ha nincs ASTM fájl, egyszer kiírjuk stdout-ra is (mert a LOGGER nálad fájlba logol).
    """
    global _GTI_K_CACHE, _GTI_K_CACHE_PATH

    p = _resolve_default_astm_path(path_to_astm_csv)

    # nincs ASTM -> egyszer jelezzük és cache-eljük a "missing" állapotot
    if p is None:
        if _GTI_K_CACHE is None or _GTI_K_CACHE_PATH != "<MISSING>":
            try:
                print("⚠ ASTM: nincs ASTMG173.csv (GTI K-faktorok nem számolhatók) -> tilt denorm fallback = 1.0")
                print("   Tedd ide valamelyikbe: (1) helpers.py mappa, (2) cwd, (3) SMARTS_DIR, vagy engedélyezd a letöltést.")
                print("   Tipp: SMARTS_DIR/ASTMG173.csv a legjobb.")
            except Exception:
                pass
            _GTI_K_CACHE = (float("nan"), float("nan"))
            _GTI_K_CACHE_PATH = "<MISSING>"
        return float("nan"), float("nan")

    # ha már van cache erre a path-ra
    if _GTI_K_CACHE is not None and _GTI_K_CACHE_PATH == p:
        return _GTI_K_CACHE

    # SR görbe a const.SR_POINTS-ból
    sr_wl = np.array(list(SR_POINTS.keys()), dtype=float)
    sr_resp = np.array(list(SR_POINTS.values()), dtype=float)

    k_beam, k_diffuse = calculate_precise_k_factors(p, sr_wl, sr_resp)
    if k_beam is None or k_diffuse is None:
        _GTI_K_CACHE = (float("nan"), float("nan"))
    else:
        _GTI_K_CACHE = (float(k_beam), float(k_diffuse))

    _GTI_K_CACHE_PATH = p

    # egyszeri “látható” visszajelzés a terminálra
    try:
        if np.isfinite(_GTI_K_CACHE[0]) and np.isfinite(_GTI_K_CACHE[1]):
            print(f"✓ ASTM loaded: {p} | K_beam={_GTI_K_CACHE[0]:.6f} | K_diffuse={_GTI_K_CACHE[1]:.6f}")
        else:
            print(f"⚠ ASTM load failed (parsed but invalid numbers): {p} -> tilt denorm fallback = 1.0")
    except Exception:
        pass

    return _GTI_K_CACHE



def calculate_denorm_fac(
    ts_utc,
    *,
    is_tilt: bool,
    base_kA: float = 1.0,
    component: str = "ghi",
    path_to_astm_csv: Optional[str] = None,
) -> float:
    """
    DENORM faktor (pipeline-biztos, SMARTS-kompatibilis):

    FONTOS:
      - SMARTS IMASS=3 esetén a SUNCOR = 1/R^2-t a program belül számolja és alkalmazza.
        Ezért itt ALAPÉRTELMEZÉSBEN NEM szorozzuk rá újra a 1/R^2-t (különben duplázás).
      - GHI: 1.0 (nem módosítunk)
      - GTI: ASTM G173 alapján K_beam/K_diffuse -> kA_beam=1/K_beam, kA_diffuse=1/K_diffuse,
             és visszaadjuk: (kA_component / base_kA)
        (így a meglévő srw * base_kA szerkezeted megmarad, csak “átfordítjuk” beam/diffuse-re)

    Ha valaha olyan SMARTS futásod lenne, ahol IMASS != 3 (és a SMARTS nem számol SUNCOR-t),
    akkor ide vissza lehet tenni az inv_r2-t, de a mostani inputjaiddal (IMASS=3) NEM kell.
    """
    # GHI eset: ne nyúljunk bele (SMARTS már kezeli a SUNCOR-t IMASS=3 mellett)
    if not is_tilt:
        return 1.0

    # Tilt eset: ASTM K-faktorok
    k_beam, k_diffuse = _get_gti_k_factors_cached(path_to_astm_csv)
    if not np.isfinite(k_beam) or not np.isfinite(k_diffuse) or k_beam <= 0 or k_diffuse <= 0:
        # nincs ASTM -> ne rontsunk el semmit
        try:
            LOGGER.warning("[DENORM] ASTM K-factors unavailable -> tilt denorm fallback = 1.0")
        except Exception:
            pass
        return 1.0

    kA_beam = 1.0 / float(k_beam)
    kA_diff = 1.0 / float(k_diffuse)

    base = float(base_kA) if np.isfinite(base_kA) and float(base_kA) > 0 else 1.0

    c = (component or "").strip().lower()
    if c in ("beam", "dir", "direct", "dni", "dir_tilt"):
        kA_comp = kA_beam
    elif c in ("diffuse", "dif", "dhi", "diff_tilt"):
        kA_comp = kA_diff
    else:
        # ismeretlen komponens -> ne korrigáljunk
        return 1.0

    return float(kA_comp / base)

