#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DASHBOARD v8 — INTEGRATED TABLE (pipeline output)
=================================================

Ez a dashboard NEM újraszámol SR×kA×IAM-ot a raw spektrumokból.
A smarts_spectral_pipeline.py által elmentett integrált értékeket
olvassa közvetlenül a public.smarts_spectral_allsky_integrated
táblából (suffix-figyelembevétellel).

Használat:
  # default oszlopok
  python dashboard_minimal.py [...]

  # suffix-es oszlopok (pl. blhcap)
  SPECTRAL_SUFFIX=_blhcap python dashboard_minimal.py [...]

Mit csinál:
  1) A dashboard RMSE / nRMSE / MBE / bin / scatter / korreláció logikája a
     meglévő v7 logika szerint működik (VÁLTOZATLAN).
  2) A SMARTS GHI / GTI idősorok KÖZVETLENÜL az INTEGRATED táblából jönnek:
        ghi_fixed       ← ghi{_suffix}          (már SR×kA×IAM alkalmazva)
        gti1225_fixed   ← gti1225beam{_suffix} + gti1225diffuse{_suffix}
        gti1545_fixed   ← gti1545beam{_suffix} + gti1545diffuse{_suffix}
  3) Ezzel a dashboard konzisztens a pipeline által végzett számítással;
     nincs "újraszámolás" és potenciális eltérés.
  4) A HTML tabok: Idősoros, Input Signals, 10min Bins, Glob. Bins,
     Korreláció, Nagy hiba korreláció, Scatter — mind változatlanul.

Megjegyzés:
  - A korreláció továbbra is a GHI hiba (mért IMT14 − SMARTS) ellen számolódik.
  - A GTI modellek a pipeline által tárolt beam+diffuse összegeként állnak elő.
  - Ha a SUFFIX-es oszlopok nem léteznek, default-ra esik vissza (warn-ol).
"""

from __future__ import annotations

import json
import math
import os
import re
import signal
import sys
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import psycopg2
import psycopg2.extras
from psycopg2 import sql as psql
from scipy.interpolate import CubicSpline, interp1d

try:
    import pvlib
except Exception as exc:  # pragma: no cover
    raise RuntimeError("pvlib kötelező ehhez a dashboardhoz") from exc

try:
    import const as C  # type: ignore
except Exception:
    C = None

try:
    import loaders as DASH_LOADERS  # type: ignore
except Exception:
    DASH_LOADERS = None

try:
    from aod_pymiescatt import calculate_new_aod_params as CALCULATE_NEW_AOD_PARAMS  # type: ignore
except Exception:
    CALCULATE_NEW_AOD_PARAMS = None


# ═══════════════════════════════════════════════════════════
# KONSTANSOK
# ═══════════════════════════════════════════════════════════

# Central entity ID-k
IMT14_GHI_ENTITY = "sensor.tvl9_imt_14_irrad"
IMT15_GTI_ENTITY = "sensor.tvl9_imt_15_irrad"
IMT16_GTI_ENTITY = "sensor.tvl9_imt_16_irrad"
CELLTEMP_ENTITY_ID = "sensor.tvl9_imt_14_celltemp"

PM_ENTITY_IDS = [
    "sensor.tvl9_o_1pst_pm10",
    "sensor.tvl9_o_1pst_pm2_5",
    "sensor.tvl9_o_1pst_pm1",
    "sensor.tvl9_o_1pst_pm0_3",
]

CENTRAL_ENTITY_IDS = list(dict.fromkeys(PM_ENTITY_IDS + [
    "sensor.tvl9_gw2000a_humidity",
    "sensor.tvl9_gw2000a_outdoor_temperature",
    "sensor.tvl9_o_1pst_carbon_dioxide",
    "sensor.tvl9_o_1pst_nox_index",
    "sensor.tvl9_gw2000a_relative_pressure",
    IMT14_GHI_ENTITY,
    IMT16_GTI_ENTITY,
    IMT15_GTI_ENTITY,
    CELLTEMP_ENTITY_ID,
]))

# Táblák
DEFAULT_TABLE_FQ = os.getenv("TABLE_MINIMAL_SMARTS", "public.smarts_igas1_iload0_bucket10s_denoise_v1")
TABLE_FQ = os.getenv("TABLE_FQ", DEFAULT_TABLE_FQ)
CAMS_VIEW = os.getenv("CAMS_VIEW", "public.cams_spectrl2_view")
SMARTS_INPUT_TABLE = os.getenv("SMARTS_INPUT_TABLE", "public.smarts_input_data")
COMBINED_GAS_TABLE = os.getenv("COMBINED_GAS_TABLE", "public.combined_gas")
SPECTRAL_TABLE = os.getenv("SPECTRAL_TABLE", "public.smarts_spectral_allsky")
INTEGRATED_TABLE = os.getenv("INTEGRATED_TABLE", "public.smarts_spectral_allsky_integrated")
OUT_HTML = os.getenv("OUT_HTML", "dashboard_quick_gti_ghi_corr.html")
GRID_FREQ = os.getenv("GRID_FREQ", "10s")

# Statisztikai küszöbök (meglévő dashboard logika)
DAYLIGHT_MIN_GHI = float(os.getenv("DAYLIGHT_MIN_GHI", "20"))
BIN_FREQ = "10min"
DAYTIME_GHI_MIN = 70.0
STATS_MAX_GHI_WM2 = 1400.0
STATS_MAX_GTI_WM2 = 1600.0
STATS_OUTLIER_IQR_K = 6.0
SMARTS_MAX = float(os.getenv("SMARTS_MAX", "1500"))
MAX_POINTS_PER_SERIES = int(os.getenv("DASH_MAX_POINTS", "4500"))
STATEMENT_TIMEOUT_MS = int(os.getenv("DB_STATEMENT_TIMEOUT_MS", "120000"))

# Spektrális korrekció
WLMIN = float(getattr(C, "WLMIN", 350.0)) if C is not None else 350.0
WLMAX = float(getattr(C, "WLMAX", 1200.0)) if C is not None else 1200.0
# FIX_DENORM_FACTOR (/0.57) HELYETT: ASTM G173-03 alapú kA számítás (_am15_kA_from_sr)
DEFAULT_LAT = float(getattr(C, "DEFAULT_LAT", 47.4979)) if C is not None else 47.4979
DEFAULT_LON = float(getattr(C, "DEFAULT_LON", 19.0402)) if C is not None else 19.0402
DEFAULT_ALT_KM = float(getattr(C, "DEFAULT_ALT_KM", 0.102)) if C is not None else 0.102
PANEL_TILT = 0.0
PANEL_AZIMUTH = float(os.getenv("GHI_AZIMUTH", "180.0"))
GTI1_TILT = float(os.getenv("GTI1_TILT", getattr(C, "STRING0_TILT_DEG", 12.25) if C is not None else 12.25))
GTI2_TILT = float(os.getenv("GTI2_TILT", getattr(C, "STRING1_TILT_DEG", 15.45) if C is not None else 15.45))
GTI_AZIMUTH = float(os.getenv("GTI_AZIMUTH", "183.0"))

# CAMS oszlopok (legacy view)f
CAMS_DEFAULT_COLS = [
    "Solar_zenith_angle",
    "Total_Aerosol_Optical_Depth_at_550nm",
    "Total_column_water_vapour",
    "Total_column_ozone",
    "Boundary_layer_height",
    "2m_temperature",
    "Relative_humidity",
]

# CAMS spectrl2 nyers oszlopok
CAMS_SPECTRL2_COLS = [
    "asymmetry_factor_550",
    "o3", "ssa",
    "aod400", "aod500", "aod1064",
    "boundary_layer_height", "wv",
]

# SMARTS input data oszlopok
SMARTS_INPUT_COLS = [
    "Asymmetry_factor_at_550_nm",
    "Boundary_layer_height",
    "Single_scattering_albedo_at_550_nm",
    "Total_Aerosol_Optical_Depth_at_550nm",
    "Total_aerosol_optical_depth_at_400_nm",
    "Total_aerosol_optical_depth_at_500_nm",
    "Total_aerosol_optical_depth_at_1020_nm",
    "Total_column_vertically_integrated_water_vapour",
    "Surface_pressure",
    "2m_temperature",
    "Relative_humidity",
]

# combined_gas oszlopok
COMBINED_GAS_COLS = [
    "Total_column_Nitrogen_dioxide",
    "Total_column_nitric_acid",
    "formaldehyde_ug_m3",
    "methane_ug_m3",
    "ozone_ug_m3",
    "sulphur_dioxide_ug_m3",
    "nitrogen_monoxide_ug_m3",
    "carbon_monoxide_ug_m3",
]

# ÚJ: ténylegesen beplugolt, nem-default SMARTS bemenetek a
# load_cams_from_spectrl2_view / load_cams_ratios / load_cams_upper_aod_multilevel láncból.
CAMS_RATIOS_TABLE = os.getenv("CAMS_RATIOS_TABLE", "public.cams_ratios_combined")
CAMS_UPPER_AOD_LABEL = "upper_aod_multilevel"

EFFECTIVE_SPECTRL2_COLS = [
    "GEMS_Total_column_ozone",
    "Total_column_vertically_integrated_water_vapour",
    "Boundary_layer_height",
    "Total_aerosol_optical_depth_at_400_nm",
    "Total_aerosol_optical_depth_at_500_nm",
    "Total_aerosol_optical_depth_at_1064_nm",
    "Total_Aerosol_Optical_Depth_at_550nm",
]
EFFECTIVE_RATIOS_COLS = [
    "bc_total",
    "om_total",
    "dust_total",
]
EFFECTIVE_UPPER_COLS = [
    "Upper_aod_355",
    "Upper_aod_532",
    "Upper_aod_1064",
    "Upper_aod_335",
    "Upper_aod_550",
]
EFFECTIVE_AOD_PARAM_LABELS = {
    "eff::TAU550": "TAU550 (effective aod_params)",
    "eff::ALPHA1": "ALPHA1 (effective aod_params)",
    "eff::ALPHA2": "ALPHA2 (effective aod_params)",
    "eff::OMEGL": "OMEGL / SSA (effective aod_params)",
    "eff::GG": "GG (effective aod_params)",
}
INPUT_SIGNALS_EXTRA_LABELS = {
    "extra::ratios::bc_total": "[ratios] bc_total (kg/kg)",
    "extra::ratios::om_total": "[ratios] om_total (kg/kg)",
    "extra::upper::Upper_aod_335": "[upper AOD min(BLH,400 m)→TOA] Upper_aod_335 (AOD, 1)",
    "extra::upper::Upper_aod_355": "[upper AOD min(BLH,400 m)→TOA] Upper_aod_355 (AOD, 1)",
    "extra::upper::Upper_aod_532": "[upper AOD min(BLH,400 m)→TOA] Upper_aod_532 (AOD, 1)",
    "extra::upper::Upper_aod_550": "[upper AOD min(BLH,400 m)→TOA] Upper_aod_550 (AOD, 1)",
    "extra::upper::Upper_aod_1064": "[upper AOD min(BLH,400 m)→TOA] Upper_aod_1064 (AOD, 1)",
    "extra::lower::Lower_aod_335": "[lower AOD 0→min(BLH,400 m)] Lower_aod_335 (AOD, 1)",
    "extra::lower::Lower_aod_355": "[lower AOD 0→min(BLH,400 m)] Lower_aod_355 (AOD, 1)",
    "extra::lower::Lower_aod_532": "[lower AOD 0→min(BLH,400 m)] Lower_aod_532 (AOD, 1)",
    "extra::lower::Lower_aod_550": "[lower AOD 0→min(BLH,400 m)] Lower_aod_550 (AOD, 1)",
    "extra::lower::Lower_aod_1064": "[lower AOD 0→min(BLH,400 m)] Lower_aod_1064 (AOD, 1)",
}
THRESHOLD_DEFAULT_WM2 = float(os.getenv("ERR_THRESHOLD_DEFAULT", "50"))
THRESHOLD_STEP_WM2 = float(os.getenv("ERR_THRESHOLD_STEP", "5"))
THRESHOLD_MAX_WM2 = float(os.getenv("ERR_THRESHOLD_MAX", "300"))

# DB input regex (pymiescatt, aod, alpha, stb.)
DB_INPUT_INCLUDE_REGEX = r"(tau|aod|alpha|beta|pw|wv|blh|ozone|no2|o3|co2|pymiescatt|albedo|dni|dhi|gti|aoi|zenith|azimuth|pressure|rh|humidity|temp|gas|methane|formaldehyde|nitric|sulphur|sulfur|monoxide)"
DB_INPUT_EXCLUDE_REGEX = r"(^id$|^pk$|uuid|_raw$)"

# Central szenzor nevek
SENSOR_NAME_MAP = {
    IMT14_GHI_ENTITY: "IMT14 (GHI)",
    IMT16_GTI_ENTITY: "IMT16 (GTI 12.25°)",
    IMT15_GTI_ENTITY: "IMT15 (GTI 15.45°)",
    CELLTEMP_ENTITY_ID: "Cell temperature",
    "sensor.tvl9_gw2000a_humidity": "Humidity",
    "sensor.tvl9_gw2000a_outdoor_temperature": "Temperature",
    "sensor.tvl9_o_1pst_carbon_dioxide": "CO₂",
    "sensor.tvl9_o_1pst_nox_index": "NOx index",
    "sensor.tvl9_gw2000a_relative_pressure": "Pressure",
    "sensor.tvl9_o_1pst_pm10": "PM10",
    "sensor.tvl9_o_1pst_pm2_5": "PM2.5",
    "sensor.tvl9_o_1pst_pm1": "PM1",
    "sensor.tvl9_o_1pst_pm0_3": "PM0.3",
}

# Raw spektrális oszlopok — SUFFIX választó
# Állítsd "_blhcap"-re, ha a pipeline --suffix blhcap futás eredményét akarod nézni.
# Üres string = default oszlopok (eredeti viselkedés).
SPECTRAL_SUFFIX = os.getenv("SPECTRAL_SUFFIX", "_blhcap")

_SPECTRAL_BASES = [
    "wavelengths",
    "ghi_spectrum",
    "gti1225_beam_spectrum",
    "gti1225_diff_spectrum",
    "gti1545_beam_spectrum",
    "gti1545_diff_spectrum",
    "ghi_raw",
    "gti1225_beam_raw",
    "gti1225_diff_raw",
    "gti1545_beam_raw",
    "gti1545_diff_raw",
]

# A tényleges DB-oszlopnevek (suffix-szel vagy anélkül)
SPECTRAL_EXPECTED_COLS = [b + SPECTRAL_SUFFIX for b in _SPECTRAL_BASES]

# Alias térkép: DB-oszlopnév → logikai név (a build_fixed_spectral_table számára)
# Ha SPECTRAL_SUFFIX="" akkor identity, különben "_blhcap" → alap név
SPECTRAL_COL_ALIAS = {b + SPECTRAL_SUFFIX: b for b in _SPECTRAL_BASES}

# A user által adott pontosabb SR készlet
SR_POINTS_5NM: Dict[float, float] = {
    350: 0.000000, 355: 0.032256, 360: 0.062123, 365: 0.109399, 370: 0.166914, 375: 0.234954,
    380: 0.301337, 385: 0.352244, 390: 0.391962, 395: 0.417343, 400: 0.438740, 405: 0.452765,
    410: 0.466791, 415: 0.477220, 420: 0.485491, 425: 0.492684, 430: 0.499876, 435: 0.507068,
    440: 0.514980, 445: 0.521813, 450: 0.532242, 455: 0.539075, 460: 0.545908, 465: 0.552741,
    470: 0.559573, 475: 0.566406, 480: 0.571801, 485: 0.578993, 490: 0.586186, 495: 0.593378,
    500: 0.600570, 505: 0.604167, 510: 0.611626, 515: 0.619084, 520: 0.625051, 525: 0.632137,
    530: 0.637731, 535: 0.645190, 540: 0.649666, 545: 0.656752, 550: 0.663837, 555: 0.670923,
    560: 0.675026, 565: 0.682485, 570: 0.688452, 575: 0.693673, 580: 0.701132, 585: 0.705980,
    590: 0.712320, 595: 0.719779, 600: 0.723508, 605: 0.730408, 610: 0.734697, 615: 0.742155,
    620: 0.747377, 625: 0.753344, 630: 0.757446, 635: 0.764532, 640: 0.768261, 645: 0.775720,
    650: 0.779450, 655: 0.786908, 660: 0.790638, 665: 0.798097, 670: 0.801826, 675: 0.805556,
    680: 0.811111, 685: 0.815972, 690: 0.819444, 695: 0.826389, 700: 0.829861, 705: 0.833333,
    710: 0.840278, 715: 0.843750, 720: 0.847222, 725: 0.854167, 730: 0.857639, 735: 0.861111,
    740: 0.868056, 745: 0.871528, 750: 0.875000, 755: 0.878472, 760: 0.885417, 765: 0.888889,
    770: 0.892361, 775: 0.899306, 780: 0.902778, 785: 0.906250, 790: 0.913194, 795: 0.916667,
    800: 0.920139, 805: 0.923611, 810: 0.929167, 815: 0.934028, 820: 0.937500, 825: 0.940972,
    830: 0.944444, 835: 0.950000, 840: 0.954861, 845: 0.958333, 850: 0.961806, 855: 0.965278,
    860: 0.968750, 865: 0.972222, 870: 0.975694, 875: 0.979167, 880: 0.982639, 885: 0.986111,
    890: 0.989583, 895: 0.993056, 900: 0.993056, 905: 0.996528, 910: 0.996528, 915: 0.996528,
    920: 0.996528, 925: 0.996528, 930: 0.996528, 935: 0.996528, 940: 1.000000, 945: 1.000000,
    950: 1.000000, 955: 1.000000, 960: 1.000000, 965: 0.996528, 970: 0.989583, 975: 0.985243,
    980: 0.977778, 985: 0.970313, 990: 0.962847, 995: 0.951910, 1000: 0.940972, 1005: 0.927778,
    1010: 0.914583, 1015: 0.897917, 1020: 0.881250, 1025: 0.861111, 1030: 0.838194, 1035: 0.813889,
    1040: 0.787654, 1045: 0.751852, 1050: 0.716049, 1055: 0.672788, 1060: 0.631019, 1065: 0.590501,
    1070: 0.555977, 1075: 0.517857, 1080: 0.486930, 1085: 0.458160, 1090: 0.428671, 1095: 0.397557,
    1100: 0.365484, 1105: 0.328189, 1110: 0.298354, 1115: 0.264789, 1120: 0.238683, 1125: 0.212577,
    1130: 0.187735, 1135: 0.163842, 1140: 0.143362, 1145: 0.119468, 1150: 0.102401, 1155: 0.085334,
    1160: 0.068267, 1165: 0.051201, 1170: 0.040960, 1175: 0.030720, 1180: 0.023894, 1185: 0.023894,
    1190: 0.020480, 1195: 0.020480, 1200: 0.000000,
}

# IAM pontok const.py-ból, fallback a megszokott halmazra
DEFAULT_IAM_POINTS: Dict[float, float] = {
    0: 1.00, 5: 1.00, 10: 1.00, 15: 1.00, 20: 1.00, 25: 0.995,
    30: 0.988, 35: 0.986, 40: 0.980, 45: 0.976, 50: 0.970,
    55: 0.960, 60: 0.933, 65: 0.921, 70: 0.877, 75: 0.819,
    80: 0.711, 85: 0.546, 90: 0.00,
}
IAM_POINTS = getattr(C, "IAM_POINTS", DEFAULT_IAM_POINTS) if C is not None else DEFAULT_IAM_POINTS


# ═══════════════════════════════════════════════════════════
# UTILITY
# ═══════════════════════════════════════════════════════════

def _sigint_handler(signum, frame):
    raise KeyboardInterrupt


signal.signal(signal.SIGINT, _sigint_handler)


def _parse_float(x: Any) -> float:
    if x is None:
        return float("nan")
    if isinstance(x, (int, float, np.number)):
        return float(x)
    s = str(x).strip()
    if s == "":
        return float("nan")
    if (s.startswith("{") and s.endswith("}")) or (s.startswith("[") and s.endswith("]")):
        try:
            j = json.loads(s)
            if isinstance(j, dict):
                for k in ("value", "state", "val"):
                    if k in j:
                        return float(j[k])
        except Exception:
            pass
    try:
        return float(s)
    except Exception:
        return float("nan")


def _fmt(x: Any, nd: int = 3) -> str:
    if x is None:
        return "n/a"
    try:
        return f"{x:.{nd}f}" if np.isfinite(float(x)) else "n/a"
    except Exception:
        return "n/a"


def _json_sanitize(obj: Any) -> Any:
    if obj is None:
        return None
    if isinstance(obj, (str, int, bool)):
        return obj
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if isinstance(obj, (np.floating,)):
        v = float(obj)
        return v if math.isfinite(v) else None
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (list, tuple)):
        return [_json_sanitize(x) for x in obj]
    if isinstance(obj, dict):
        return {str(k): _json_sanitize(v) for k, v in obj.items()}
    if isinstance(obj, pd.Timestamp):
        return None if pd.isna(obj) else obj.isoformat()
    return str(obj)


def _safe_json_array(x: Any) -> np.ndarray:
    if x is None:
        return np.array([], dtype=float)
    if isinstance(x, list):
        return np.asarray([_parse_float(v) for v in x], dtype=float)
    if isinstance(x, tuple):
        return np.asarray([_parse_float(v) for v in x], dtype=float)
    if isinstance(x, np.ndarray):
        return np.asarray(x, dtype=float)
    if isinstance(x, str):
        s = x.strip()
        if s == "":
            return np.array([], dtype=float)
        try:
            val = json.loads(s)
            if isinstance(val, list):
                return np.asarray([_parse_float(v) for v in val], dtype=float)
        except Exception:
            return np.array([], dtype=float)
    return np.array([], dtype=float)


def _downsample_uniform(df: pd.DataFrame, max_points: int) -> pd.DataFrame:
    if df is None or len(df) == 0:
        return df
    if len(df) <= max_points:
        return df
    step = int(math.ceil(len(df) / max_points))
    return df.iloc[::step].copy()


def _make_grid(t0, t1, freq):
    t0 = pd.to_datetime(t0, utc=True)
    t1 = pd.to_datetime(t1, utc=True)
    try:
        return pd.date_range(t0, t1, freq=freq, tz="UTC", inclusive="left")
    except TypeError:
        return pd.date_range(t0, t1, freq=freq, tz="UTC", closed="left")


def _interp_time_inside(s, idx, edge_fill=False):
    if s is None or idx is None or len(idx) == 0:
        return pd.Series(index=idx, dtype=float)
    s = pd.to_numeric(s, errors="coerce").dropna()
    if s.empty:
        return pd.Series(index=idx, dtype=float)
    s = s[~s.index.duplicated(keep="first")].sort_index()
    u = s.index.union(idx).sort_values()
    s2 = s.reindex(u).interpolate("time", limit_area="inside")
    out = s2.reindex(idx)
    if edge_fill:
        out = out.ffill().bfill()
    return out


# ═══════════════════════════════════════════════════════════
# STATISZTIKAI SEGÉDFÜGGVÉNYEK — változatlan logika
# ═══════════════════════════════════════════════════════════

def _rmse(a, b):
    m = np.isfinite(a) & np.isfinite(b)
    if m.sum() == 0:
        return float("nan")
    return float(np.sqrt(np.mean((a[m] - b[m]) ** 2)))


def _nrmse(a, b):
    m = np.isfinite(a) & np.isfinite(b)
    if m.sum() == 0:
        return float("nan")
    denom = np.nanmean(a[m])
    if not np.isfinite(denom) or abs(denom) < 1e-9:
        return float("nan")
    return float(_rmse(a, b) / denom * 100.0)


def _robust_iqr_mask(x, k=STATS_OUTLIER_IQR_K):
    x = np.asarray(x, dtype=float)
    m = np.isfinite(x)
    if int(m.sum()) < 8:
        return m
    xx = x[m]
    q1, q3 = float(np.nanpercentile(xx, 25)), float(np.nanpercentile(xx, 75))
    iqr = q3 - q1
    if (not np.isfinite(iqr)) or iqr <= 0:
        return m
    return m & (x >= q1 - k * iqr) & (x <= q3 + k * iqr)


def _mean_abs_safe(x, min_abs=1e-9):
    x = np.asarray(x, dtype=float)
    m = np.isfinite(x)
    if not m.any():
        return float("nan")
    mu = float(np.nanmean(np.abs(x[m])))
    return mu if (np.isfinite(mu) and mu > min_abs) else float("nan")


def _stats_pair_mask(measured, predicted, ghi_gate=None, min_ghi=DAYTIME_GHI_MIN, is_gti=False):
    measured = np.asarray(measured, float)
    predicted = np.asarray(predicted, float)
    n = min(measured.size, predicted.size)
    if n <= 0:
        return np.zeros(0, dtype=bool)
    measured, predicted = measured[:n], predicted[:n]
    gate = (measured if ghi_gate is None else np.asarray(ghi_gate, float))[:n]
    m = np.isfinite(measured) & np.isfinite(predicted) & np.isfinite(gate) & (gate > float(min_ghi))
    mx = float(STATS_MAX_GTI_WM2 if is_gti else STATS_MAX_GHI_WM2)
    m &= (measured >= 0) & (predicted >= 0) & (measured <= mx) & (predicted <= mx)
    m &= _robust_iqr_mask(measured) & _robust_iqr_mask(predicted)
    return m


def _metric_bundle(measured, predicted, ghi_gate=None, is_gti=False, min_ghi=DAYTIME_GHI_MIN):
    measured, predicted = np.asarray(measured, float), np.asarray(predicted, float)
    gate = measured if ghi_gate is None else np.asarray(ghi_gate, float)
    n0 = min(measured.size, predicted.size, gate.size)
    empty = {"n": 0, "rmse": np.nan, "nrmse": np.nan, "mbe": np.nan, "nmbe": np.nan,
             "mean_measured": np.nan, "mean_predicted": np.nan}
    if n0 <= 0:
        return empty
    m = _stats_pair_mask(measured[:n0], predicted[:n0], gate[:n0], min_ghi, is_gti)
    n = int(m.sum())
    if n == 0:
        return empty
    mm, pp = measured[:n0][m], predicted[:n0][m]
    err = pp - mm
    rmse = float(np.sqrt(np.mean(err ** 2)))
    mbe = float(np.mean(err))
    d = _mean_abs_safe(mm)
    return {
        "n": n, "rmse": rmse,
        "nrmse": float(100 * rmse / d) if np.isfinite(d) else np.nan,
        "mbe": mbe,
        "nmbe": float(100 * mbe / d) if np.isfinite(d) else np.nan,
        "mean_measured": float(np.mean(mm)),
        "mean_predicted": float(np.mean(pp)),
    }


def _corr_bundle(y_err, x_target, n_norm=None, rng=None):
    y_err, x_target = np.asarray(y_err, float), np.asarray(x_target, float)
    m = np.isfinite(y_err) & np.isfinite(x_target)
    n_avail = int(m.sum())
    nan_ret = {"pearson": np.nan, "spearman": np.nan, "kendall": np.nan,
               "slope": np.nan, "r2": np.nan, "n_avail": float(n_avail), "n_used": 0.0}
    if n_avail < 3:
        return nan_ret
    idx = np.flatnonzero(m)
    if n_norm and n_avail >= n_norm >= 3:
        if rng is None:
            rng = np.random.default_rng(1337)
        sel = rng.choice(idx, size=int(n_norm), replace=False)
        yy, xx = y_err[sel], x_target[sel]
    else:
        yy, xx = y_err[idx], x_target[idx]
    n_used = len(xx)
    if np.std(xx) < 1e-12 or np.std(yy) < 1e-12:
        return {**nan_ret, "n_used": float(n_used)}
    pear = float(np.corrcoef(yy, xx)[0, 1])
    slope, intercept = np.polyfit(xx, yy, 1)
    yhat = slope * xx + intercept
    ss_res = float(np.sum((yy - yhat) ** 2))
    ss_tot = float(np.sum((yy - np.mean(yy)) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 1e-12 else np.nan
    yr = pd.Series(yy).rank(method="average").to_numpy()
    xr = pd.Series(xx).rank(method="average").to_numpy()
    spear = float(np.corrcoef(yr, xr)[0, 1]) if (np.std(yr) > 1e-12 and np.std(xr) > 1e-12) else np.nan
    try:
        from scipy.stats import kendalltau
        tau, _ = kendalltau(yy, xx)
        kend = float(tau) if tau is not None else np.nan
    except Exception:
        kend = np.nan
    return {"pearson": pear, "spearman": spear, "kendall": kend,
            "slope": float(slope), "r2": r2, "n_avail": float(n_avail), "n_used": float(n_used)}


def _compute_global_corr(err_all, abs_err_all, target_parts, target_keys, target_labels, n_min=500):
    err_all = np.asarray(err_all, float)
    abs_err_all = np.asarray(abs_err_all, float)

    x_cache, pair_counts = {}, {}
    for tk in target_keys:
        parts = target_parts.get(tk, [])
        if not parts:
            continue
        x_all = np.concatenate(parts).astype(float)
        n = min(len(err_all), len(x_all))
        if n < 3:
            continue
        e = err_all[:n]
        x = x_all[:n]
        m = np.isfinite(e) & np.isfinite(x)
        pair_counts[tk] = int(m.sum())
        x_cache[tk] = x

    eligible = [c for c in pair_counts.values() if c >= n_min]
    n_norm = min(eligible) if eligible else 0
    n_norm = min(n_norm, 20000)

    rng = np.random.default_rng(1337)
    corr_signed, corr_abs = {}, {}

    for tk, x in x_cache.items():
        n = min(len(err_all), len(x))
        if n < max(3, n_norm):
            d = {
                "pearson": np.nan, "spearman": np.nan, "kendall": np.nan,
                "slope": np.nan, "r2": np.nan, "n_avail": float(pair_counts.get(tk, 0)), "n_used": 0.0,
            }
            corr_signed[tk] = d
            corr_abs[tk] = dict(d)
            continue
        e = err_all[:n]
        ae = abs_err_all[:n]
        corr_signed[tk] = _corr_bundle(e, x, n_norm=n_norm, rng=rng)
        corr_abs[tk] = _corr_bundle(ae, x, n_norm=n_norm, rng=rng)

    aod_candidate_keys = [
        "db::pymiescatt_tau550",
        "db::tau550",
        "si::pymiescatt_tau550",
        "si::tau550",
        "si::Total_Aerosol_Optical_Depth_at_550nm",
        "cams::Total_Aerosol_Optical_Depth_at_550nm",
        "cams::aod550",
        "cams::aod500",
    ]
    aod_candidate_set = set(aod_candidate_keys)

    def _mk_item(tk, d):
        lbl = target_labels.get(tk, tk)
        if tk in aod_candidate_set:
            if "aod500" in tk.lower() or "500" in str(lbl):
                lbl = f"[AOD proxy] {lbl}"
            else:
                lbl = f"[TOTAL AOD] {lbl}"
        return {
            "key": tk,
            "label": lbl,
            "pearson": float(d.get("pearson", np.nan)),
            "spearman": float(d.get("spearman", np.nan)),
            "n_used": int(d.get("n_used", 0)),
        }

    def _pick_first_valid_aod(cm):
        for tk in aod_candidate_keys:
            d = cm.get(tk)
            if not d:
                continue
            r = d.get("pearson", np.nan)
            if np.isfinite(r):
                return tk
        return None

    def _top(cm, top_n=80):
        items = []
        by_key = {}
        for tk, d in cm.items():
            r = d.get("pearson", np.nan)
            if not np.isfinite(r):
                continue
            it = _mk_item(tk, d)
            items.append(it)
            by_key[tk] = it
        items.sort(key=lambda x: abs(x["pearson"]), reverse=True)
        pinned = []
        tk_aod = _pick_first_valid_aod(cm)
        if tk_aod is not None and tk_aod in by_key:
            pinned.append(by_key[tk_aod])
        out = []
        seen = set()
        for it in pinned + items:
            if it["key"] in seen:
                continue
            seen.add(it["key"])
            out.append(it)
            if len(out) >= top_n:
                break
        return out

    return {
        "n_norm": int(n_norm),
        "pair_counts": {k: int(v) for k, v in pair_counts.items()},
        "top_signed": _top(corr_signed, 80),
        "top_abs": _top(corr_abs, 80),
    }


def _compute_binned_metrics(ts_idx, measured, predicted, stack_by_clock=False, daylight_gate=None, is_gti=False):
    ts = pd.to_datetime(ts_idx, utc=True, errors="coerce")
    df = pd.DataFrame({"timestamp": ts, "measured": measured, "predicted": predicted}).dropna(subset=["timestamp"])
    if daylight_gate is None:
        df["daylight_gate"] = df["measured"]
    else:
        arr = np.asarray(daylight_gate, dtype=float)
        df["daylight_gate"] = arr[:len(df)]
    if df.empty:
        return {"bin_label": [], "n": [], "rmse": [], "nrmse": [], "mbe": [], "nmbe": [], "pearson": [], "r2": []}

    if stack_by_clock:
        base = df["timestamp"].dt.floor(BIN_FREQ)
        df["bin_key"] = base.dt.strftime("%H:%M")
        order = sorted(df["bin_key"].dropna().unique().tolist())
    else:
        df["bin_key"] = df["timestamp"].dt.floor(BIN_FREQ)
        order = df["bin_key"].dropna().sort_values().unique().tolist()

    labels, ns, rmses, nrmses, mbes, nmbes, pears, r2s = [], [], [], [], [], [], [], []
    for bk in order:
        sub = df.loc[df["bin_key"] == bk]
        if sub.empty:
            continue
        a = sub["measured"].to_numpy(dtype=float)
        b = sub["predicted"].to_numpy(dtype=float)
        g = sub["daylight_gate"].to_numpy(dtype=float)
        mb = _metric_bundle(a, b, ghi_gate=g, is_gti=is_gti, min_ghi=DAYTIME_GHI_MIN)
        cb = _corr_bundle(a, b)
        label = str(bk) if stack_by_clock else pd.Timestamp(bk).strftime("%Y-%m-%d %H:%M")
        labels.append(label)
        ns.append(int(mb["n"]))
        rmses.append(mb["rmse"])
        nrmses.append(mb["nrmse"])
        mbes.append(mb["mbe"])
        nmbes.append(mb["nmbe"])
        pears.append(cb["pearson"])
        r2s.append(cb["r2"])

    return {"bin_label": labels, "n": ns, "rmse": rmses, "nrmse": nrmses, "mbe": mbes, "nmbe": nmbes, "pearson": pears, "r2": r2s}


# ═══════════════════════════════════════════════════════════
# DB
# ═══════════════════════════════════════════════════════════

def _apply_timeouts(conn):
    try:
        with conn.cursor() as cur:
            cur.execute(f"SET statement_timeout = {int(STATEMENT_TIMEOUT_MS)}")
    except Exception:
        pass


def _get_main_db_conn():
    host = os.getenv("DB_HOST", getattr(C, "DB_HOST", None) if C is not None else None)
    port = int(os.getenv("DB_PORT", str(getattr(C, "DB_PORT", 5432) if C is not None else 5432)))
    dbname = os.getenv("DB_NAME", getattr(C, "DB_NAME", None) if C is not None else None)
    user = os.getenv("DB_USER", getattr(C, "DB_USER", None) if C is not None else None)
    pwd = os.getenv("DB_PASSWORD") or os.getenv("DB_PWD_CACHE") or (getattr(C, "DB_PWD_CACHE", None) if C is not None else None)
    if not all([host, dbname, user, pwd]):
        raise RuntimeError("Hiányos MAIN DB kapcsolat (DB_HOST/DB_NAME/DB_USER/DB_PASSWORD vagy const.py)")
    conn = psycopg2.connect(host=host, port=port, dbname=dbname, user=user, password=pwd)
    _apply_timeouts(conn)
    return conn


def _get_central_db_conn():
    host = os.getenv("CENTRAL_DB_HOST", getattr(C, "CENTRAL_DB_HOST", "em-central-db.ulx.hu") if C is not None else "em-central-db.ulx.hu")
    port = int(os.getenv("CENTRAL_DB_PORT", str(getattr(C, "CENTRAL_DB_PORT", 5432) if C is not None else 5432)))
    dbname = os.getenv("CENTRAL_DB_NAME", getattr(C, "CENTRAL_DB_NAME", "emr-db") if C is not None else "emr-db")
    user = os.getenv("CENTRAL_DB_USER", getattr(C, "CENTRAL_DB_USER", None) if C is not None else None)
    pwd = os.getenv("CENTRAL_DB_PASSWORD", getattr(C, "CENTRAL_DB_PASSWORD", None) if C is not None else None)
    sslmode = os.getenv("CENTRAL_DB_SSLMODE", getattr(C, "CENTRAL_DB_SSLMODE", "require") if C is not None else "require")
    if not all([host, dbname, user, pwd]):
        raise RuntimeError("Hiányos CENTRAL DB kapcsolat (CENTRAL_DB_* vagy const.py)")
    conn = psycopg2.connect(host=host, port=port, dbname=dbname, user=user, password=pwd, sslmode=sslmode)
    _apply_timeouts(conn)
    return conn


def fetch_table_columns(conn, table_fq):
    parts = str(table_fq).split(".")
    schema, table = (parts[0], parts[1]) if len(parts) == 2 else ("public", parts[0])
    q = """
    SELECT column_name
    FROM information_schema.columns
    WHERE table_schema = %s AND table_name = %s
    ORDER BY ordinal_position
    """
    with conn.cursor() as cur:
        cur.execute(q, (schema, table))
        return [r[0] for r in cur.fetchall()]


def detect_timestamp_col(cols):
    for c in cols:
        if c.lower() == "timestamp":
            return c
    for c in cols:
        if "timestamp" in c.lower():
            return c
    for c in cols:
        if c.lower() in {"ts", "time", "valid_time", "datetime"}:
            return c
    raise RuntimeError(f"Nem található timestamp oszlop: {cols[:20]}")


def _resolve_cols_ci(avail: Sequence[str], wanted: Sequence[str]) -> List[str]:
    low = {c.lower(): c for c in avail}
    out: List[str] = []
    for c in wanted:
        got = low.get(str(c).lower())
        if got:
            out.append(got)
    return out


def detect_db_input_cols(all_cols, ts_col):
    out = []
    for c in all_cols:
        cl = c.lower()
        if c == ts_col:
            continue
        if cl.startswith("smarts_"):
            continue
        if re.search(DB_INPUT_EXCLUDE_REGEX, cl):
            continue
        if re.search(DB_INPUT_INCLUDE_REGEX, cl):
            out.append(c)
    return out


def fetch_main_table(conn, table_fq, start_ts, end_ts, cols, ts_col):
    start_ts, end_ts = pd.to_datetime(start_ts, utc=True), pd.to_datetime(end_ts, utc=True)
    parts = table_fq.split(".")
    schema, table = (parts[0], parts[1]) if len(parts) == 2 else ("public", parts[0])
    sel_cols = [ts_col] + [c for c in cols if c != ts_col]
    col_idents = [psql.Identifier(c) for c in sel_cols]
    q = psql.SQL("SELECT {cols} FROM {schema}.{table} WHERE {ts} >= %s AND {ts} < %s ORDER BY {ts}").format(
        cols=psql.SQL(", ").join(col_idents), schema=psql.Identifier(schema),
        table=psql.Identifier(table), ts=psql.Identifier(ts_col))
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(q, (start_ts.to_pydatetime(), end_ts.to_pydatetime()))
        rows = cur.fetchall()
    if not rows:
        return pd.DataFrame(columns=sel_cols)
    df = pd.DataFrame(rows)
    df[ts_col] = pd.to_datetime(df[ts_col], utc=True, errors="coerce")
    df = df.dropna(subset=[ts_col]).sort_values(ts_col).drop_duplicates(subset=[ts_col])
    for c in sel_cols:
        if c != ts_col and c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    return df


def fetch_central_entities(conn, start_ts, end_ts, entity_ids):
    start_ts, end_ts = pd.to_datetime(start_ts, utc=True), pd.to_datetime(end_ts, utc=True)
    with conn.cursor() as cur:
        cur.execute("SELECT metadata_id, entity_id FROM states_meta WHERE entity_id = ANY(%s)", (entity_ids,))
        meta_rows = cur.fetchall()
    meta_map = {eid: mid for (mid, eid) in meta_rows}
    metadata_ids = [meta_map[e] for e in entity_ids if e in meta_map]
    if not metadata_ids:
        return pd.DataFrame(columns=["timestamp"] + entity_ids)
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT s.metadata_id, s.state, s.last_updated_ts
            FROM states s
            WHERE s.metadata_id = ANY(%s) AND s.last_updated_ts >= %s AND s.last_updated_ts < %s
            ORDER BY s.last_updated_ts
            """,
            (metadata_ids, float(start_ts.timestamp()), float(end_ts.timestamp())),
        )
        rows = cur.fetchall()
    if not rows:
        return pd.DataFrame(columns=["timestamp"] + entity_ids)
    inv = {mid: eid for eid, mid in meta_map.items()}
    ts, eid, val = [], [], []
    for mid, state, lut in rows:
        e = inv.get(mid)
        if not e:
            continue
        ts.append(pd.to_datetime(float(lut), unit="s", utc=True))
        eid.append(e)
        val.append(_parse_float(state))
    df_long = pd.DataFrame({"timestamp": ts, "entity_id": eid, "value": val})
    df_long = df_long.dropna(subset=["timestamp"]).sort_values("timestamp")
    wide = df_long.pivot(index="timestamp", columns="entity_id", values="value").sort_index()
    for e in entity_ids:
        if e not in wide.columns:
            wide[e] = np.nan
    wide = wide[entity_ids].reset_index()
    wide["timestamp"] = pd.to_datetime(wide["timestamp"], utc=True, errors="coerce")
    return wide.dropna(subset=["timestamp"]).sort_values("timestamp").drop_duplicates("timestamp")


def fetch_generic_table(conn, table_fq, start_ts, end_ts, cols, ts_col="timestamp"):
    start_ts, end_ts = pd.to_datetime(start_ts, utc=True), pd.to_datetime(end_ts, utc=True)
    if not cols:
        return pd.DataFrame(columns=["timestamp"])
    parts = str(table_fq).split(".")
    schema, tbl = (parts[0], parts[1]) if len(parts) == 2 else ("public", parts[0])
    col_idents = [psql.Identifier(ts_col)] + [psql.Identifier(c) for c in cols]
    q = psql.SQL("SELECT {cols} FROM {schema}.{table} WHERE {ts} >= %s AND {ts} < %s ORDER BY {ts}").format(
        cols=psql.SQL(", ").join(col_idents), schema=psql.Identifier(schema),
        table=psql.Identifier(tbl), ts=psql.Identifier(ts_col))
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(q, (start_ts.to_pydatetime(), end_ts.to_pydatetime()))
            rows = cur.fetchall()
    except Exception as e:
        print(f"  [WARN] fetch {table_fq}: {e}")
        return pd.DataFrame(columns=["timestamp"] + cols)
    if not rows:
        return pd.DataFrame(columns=["timestamp"] + cols)
    df = pd.DataFrame(rows)
    df["timestamp"] = pd.to_datetime(df[ts_col], utc=True, errors="coerce")
    df = df.dropna(subset=["timestamp"]).sort_values("timestamp").drop_duplicates("timestamp")
    for c in cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    return df


def _attach_to_grid(df, grid, cols):
    if df is None or df.empty:
        return pd.DataFrame(index=grid, columns=cols, dtype=float)
    x = df.copy()
    x["timestamp"] = pd.to_datetime(x["timestamp"], utc=True, errors="coerce")
    x = x.dropna(subset=["timestamp"]).set_index("timestamp").sort_index()
    out = pd.DataFrame(index=grid, dtype=float)
    for c in cols:
        if c in x.columns:
            s = pd.to_numeric(x[c], errors="coerce").dropna()
            if not s.empty:
                s = s[~s.index.duplicated(keep="first")].sort_index()
                u = s.index.union(grid).sort_values()
                interp = s.reindex(u).interpolate("time").ffill().bfill()
                out[c] = interp.reindex(grid)
    return out


def fetch_spectral_table(conn, table_fq, start_ts, end_ts, ts_col, cols):
    start_ts, end_ts = pd.to_datetime(start_ts, utc=True), pd.to_datetime(end_ts, utc=True)
    parts = str(table_fq).split(".")
    schema, tbl = (parts[0], parts[1]) if len(parts) == 2 else ("public", parts[0])
    sel_cols = [ts_col] + [c for c in cols if c != ts_col]
    col_idents = [psql.Identifier(c) for c in sel_cols]
    q = psql.SQL("SELECT {cols} FROM {schema}.{table} WHERE {ts} >= %s AND {ts} < %s ORDER BY {ts}").format(
        cols=psql.SQL(", ").join(col_idents), schema=psql.Identifier(schema),
        table=psql.Identifier(tbl), ts=psql.Identifier(ts_col))
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(q, (start_ts.to_pydatetime(), end_ts.to_pydatetime()))
            rows = cur.fetchall()
    except psycopg2.errors.QueryCanceled as e:
        conn.rollback()  # FONTOS: a tranzakciót resetelni kell timeout után
        print(f"  [WARN] spectral fetch timeout {table_fq}: {e}")
        return pd.DataFrame(columns=sel_cols)
    except Exception as e:
        conn.rollback()
        print(f"  [WARN] spectral fetch {table_fq}: {e}")
        return pd.DataFrame(columns=sel_cols)
    if not rows:
        return pd.DataFrame(columns=sel_cols)
    df = pd.DataFrame(rows)
    df[ts_col] = pd.to_datetime(df[ts_col], utc=True, errors="coerce")
    return df.dropna(subset=[ts_col]).sort_values(ts_col).drop_duplicates(ts_col)


def _safe_float_local(x: Any, default: float = np.nan) -> float:
    try:
        v = float(x)
        return v if np.isfinite(v) else float(default)
    except Exception:
        return float(default)


def _fetch_effective_input_sources(conn, start_ts, end_ts):
    start_ts = pd.to_datetime(start_ts, utc=True, errors="coerce")
    end_ts = pd.to_datetime(end_ts, utc=True, errors="coerce")
    if pd.isna(start_ts) or pd.isna(end_ts) or end_ts <= start_ts:
        return pd.DataFrame(columns=["timestamp"]), pd.DataFrame(columns=["timestamp"]), pd.DataFrame(columns=["timestamp"])
    pad0 = start_ts - pd.Timedelta(hours=6)
    pad1 = end_ts + pd.Timedelta(hours=6)

    df_s = pd.DataFrame(columns=["timestamp"] + EFFECTIVE_SPECTRL2_COLS)
    df_r = pd.DataFrame(columns=["timestamp"] + EFFECTIVE_RATIOS_COLS)
    df_u = pd.DataFrame(columns=["timestamp"] + EFFECTIVE_UPPER_COLS)

    if DASH_LOADERS is not None:
        try:
            df_s0 = DASH_LOADERS.load_cams_from_spectrl2_view(conn, pad0, pad1)
            if df_s0 is not None and not df_s0.empty:
                keep = [c for c in EFFECTIVE_SPECTRL2_COLS if c in df_s0.columns]
                df_s = df_s0[["timestamp"] + keep].copy()
        except Exception as e:
            print(f"  [WARN] effective spectrl2 fetch: {e}")
        try:
            df_r0 = DASH_LOADERS.load_cams_ratios(conn, pad0, pad1)
            if df_r0 is not None and not df_r0.empty:
                keep = [c for c in EFFECTIVE_RATIOS_COLS if c in df_r0.columns]
                df_r = df_r0[["timestamp"] + keep].copy()
        except Exception as e:
            print(f"  [WARN] effective ratios fetch: {e}")
        try:
            df_u0 = DASH_LOADERS.load_cams_upper_aod_multilevel(conn, pad0, pad1)
            if df_u0 is not None and not df_u0.empty:
                keep = [c for c in EFFECTIVE_UPPER_COLS if c in df_u0.columns]
                df_u = df_u0[["timestamp"] + keep].copy()
        except Exception as e:
            print(f"  [WARN] effective upper-aod fetch: {e}")

    for df in (df_s, df_r, df_u):
        if "timestamp" in df.columns:
            df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
            df.dropna(subset=["timestamp"], inplace=True)
            df.sort_values("timestamp", inplace=True)
            df.drop_duplicates("timestamp", inplace=True)
    return df_s, df_r, df_u


def _build_cams_upper_aod_from_row(row: pd.Series) -> Dict[float, float]:
    def _sf(key: str, dflt: float = np.nan) -> float:
        v = _safe_float_local(row.get(key), np.nan)
        if not np.isfinite(v):
            v = _safe_float_local(row.get(key.lower()), np.nan)
        return float(v) if np.isfinite(v) else float(dflt)

    u355 = _sf("Upper_aod_355", np.nan)
    u532 = _sf("Upper_aod_532", np.nan)
    u1064 = _sf("Upper_aod_1064", np.nan)
    u335 = _sf("Upper_aod_335", np.nan)
    u550 = _sf("Upper_aod_550", np.nan)
    if np.isfinite(u532) and np.isfinite(u1064) and u532 >= 0 and u1064 >= 0:
        out = {532.0: float(np.clip(u532, 0.0, 3.0)), 1064.0: float(np.clip(u1064, 0.0, 3.0))}
        if np.isfinite(u355) and u355 >= 0:
            out[355.0] = float(np.clip(u355, 0.0, 3.0))
        if np.isfinite(u335) and u335 >= 0:
            out[335.0] = float(np.clip(u335, 0.0, 3.0))
        if np.isfinite(u550) and u550 >= 0:
            out[550.0] = float(np.clip(u550, 0.0, 3.0))
        return out

    tau340 = _sf("Total_aerosol_optical_depth_at_340_nm", np.nan)
    tau500 = _sf("Total_aerosol_optical_depth_at_500_nm", np.nan)
    tau1064 = _sf("Total_aerosol_optical_depth_at_1064_nm", np.nan)
    tau550 = _sf("Total_Aerosol_Optical_Depth_at_550nm", np.nan)

    if not np.isfinite(tau550):
        tau550 = _sf("TAU550", 0.10)

    def _u(t: float, dflt: float) -> float:
        return float(np.clip(0.30 * t, 0.0, 2.0)) if np.isfinite(t) and t > 0 else float(dflt)

    return {340.0: _u(tau340, 0.05), 500.0: _u(tau500, 0.03), 550.0: _u(tau550, 0.03), 1064.0: _u(tau1064, 0.01)}


def _compute_effective_aod_params(row: pd.Series) -> Dict[str, float]:
    if CALCULATE_NEW_AOD_PARAMS is None:
        return {k.split("::", 1)[1]: np.nan for k in EFFECTIVE_AOD_PARAM_LABELS.keys()}
    cams_upper_aod = _build_cams_upper_aod_from_row(row)
    try:
        out = CALCULATE_NEW_AOD_PARAMS(row, row, cams_upper_aod, row_idx=-1)
    except TypeError:
        try:
            out = CALCULATE_NEW_AOD_PARAMS(row=row, cams_ratios_row=row, cams_upper_aod=cams_upper_aod, row_idx=-1)
        except Exception:
            out = {}
    except Exception:
        out = {}
    if not isinstance(out, dict):
        out = {}
    return {
        "TAU550": _safe_float_local(out.get("TAU550"), np.nan),
        "ALPHA1": _safe_float_local(out.get("ALPHA1"), np.nan),
        "ALPHA2": _safe_float_local(out.get("ALPHA2"), np.nan),
        "OMEGL": _safe_float_local(out.get("OMEGL", out.get("SSA")), np.nan),
        "GG": _safe_float_local(out.get("GG"), np.nan),
    }


def _build_threshold_input_series(grid, daylight_grid, c_idx, main_conn, start_ts, end_ts):
    out: Dict[str, np.ndarray] = {}
    df_s, df_r, df_u = _fetch_effective_input_sources(main_conn, start_ts, end_ts)
    s_cols = [c for c in EFFECTIVE_SPECTRL2_COLS if c in df_s.columns]
    r_cols = [c for c in EFFECTIVE_RATIOS_COLS if c in df_r.columns]
    u_cols = [c for c in EFFECTIVE_UPPER_COLS if c in df_u.columns]

    s_10s = _attach_to_grid(df_s, grid, s_cols) if s_cols else pd.DataFrame(index=grid)
    r_10s = _attach_to_grid(df_r, grid, r_cols) if r_cols else pd.DataFrame(index=grid)
    u_10s = _attach_to_grid(df_u, grid, u_cols) if u_cols else pd.DataFrame(index=grid)

    for c in s_cols:
        out[f"thr::spectrl2::{c}"] = s_10s[c].reindex(daylight_grid).values.astype(np.float32)
    for c in r_cols:
        out[f"thr::ratios::{c}"] = r_10s[c].reindex(daylight_grid).values.astype(np.float32)
    for c in u_cols:
        out[f"thr::upper::{c}"] = u_10s[c].reindex(daylight_grid).values.astype(np.float32)

    eff_merge = pd.DataFrame(index=pd.Index(daylight_grid))
    pm_cols = ["sensor.tvl9_o_1pst_pm0_3", "sensor.tvl9_gw2000a_humidity"]
    for c in pm_cols:
        s = c_idx.get(c)
        if s is not None:
            eff_merge[c] = _interp_time_inside(s, grid, edge_fill=True).reindex(daylight_grid).values.astype(np.float32)
        else:
            eff_merge[c] = np.full(len(daylight_grid), np.nan, dtype=np.float32)
    for src in (s_10s, r_10s, u_10s):
        for c in src.columns:
            eff_merge[c] = src[c].reindex(daylight_grid).values.astype(np.float32)

    derived = {k: np.full(len(daylight_grid), np.nan, dtype=np.float32) for k in [kk.split("::", 1)[1] for kk in EFFECTIVE_AOD_PARAM_LABELS.keys()]}
    for i in range(len(daylight_grid)):
        row = eff_merge.iloc[i]
        ap = _compute_effective_aod_params(row)
        for k, v in ap.items():
            derived[k][i] = np.float32(v) if np.isfinite(v) else np.float32(np.nan)

    for tk, label in EFFECTIVE_AOD_PARAM_LABELS.items():
        k = tk.split("::", 1)[1]
        out[tk] = derived[k]

    return {k: v for k, v in out.items() if isinstance(v, np.ndarray)}


def _compute_local_only_aod_params(row: pd.Series) -> Dict[str, float]:
    if CALCULATE_NEW_AOD_PARAMS is None:
        return {"TAU550": np.nan, "ALPHA1": np.nan, "ALPHA2": np.nan}
    zero_upper = {335.0: 0.0, 355.0: 0.0, 532.0: 0.0, 550.0: 0.0, 1064.0: 0.0}
    try:
        out = CALCULATE_NEW_AOD_PARAMS(row, row, zero_upper, row_idx=-1)
    except TypeError:
        try:
            out = CALCULATE_NEW_AOD_PARAMS(row=row, cams_ratios_row=row, cams_upper_aod=zero_upper, row_idx=-1)
        except Exception:
            out = {}
    except Exception:
        out = {}
    if not isinstance(out, dict):
        out = {}
    tau550 = _safe_float_local(out.get("TAU550"), np.nan)
    alpha1 = _safe_float_local(out.get("ALPHA1"), 1.3 if np.isfinite(tau550) else np.nan)
    alpha2 = _safe_float_local(out.get("ALPHA2"), 1.3 if np.isfinite(tau550) else np.nan)
    return {"TAU550": tau550, "ALPHA1": alpha1, "ALPHA2": alpha2}


def _piecewise_lower_aod_from_tau_alphas(tau550: float, alpha1: float, alpha2: float) -> Dict[str, float]:
    tau550 = _safe_float_local(tau550, np.nan)
    alpha1 = _safe_float_local(alpha1, np.nan)
    alpha2 = _safe_float_local(alpha2, np.nan)
    if not np.isfinite(tau550) or tau550 < 0:
        return {
            "Lower_aod_335": np.nan,
            "Lower_aod_355": np.nan,
            "Lower_aod_532": np.nan,
            "Lower_aod_550": np.nan,
            "Lower_aod_1064": np.nan,
        }
    if not np.isfinite(alpha1):
        alpha1 = 1.3
    if not np.isfinite(alpha2):
        alpha2 = 1.3
    a550 = float(np.clip(tau550, 0.0, 3.0))
    a532 = float(np.clip(a550 * (532.0 / 550.0) ** (-alpha2), 0.0, 3.0))
    a1064 = float(np.clip(a550 * (1064.0 / 550.0) ** (-alpha2), 0.0, 3.0))
    a335 = float(np.clip(a532 * (335.0 / 532.0) ** (-alpha1), 0.0, 3.0))
    a355 = float(np.clip(a532 * (355.0 / 532.0) ** (-alpha1), 0.0, 3.0))
    return {
        "Lower_aod_335": a335,
        "Lower_aod_355": a355,
        "Lower_aod_532": a532,
        "Lower_aod_550": a550,
        "Lower_aod_1064": a1064,
    }


def _build_input_signals_extra_series(grid, daylight_grid, c_idx, main_conn, start_ts, end_ts):
    n = len(daylight_grid)
    out: Dict[str, np.ndarray] = {
        k: np.full(n, np.nan, dtype=np.float32) for k in INPUT_SIGNALS_EXTRA_LABELS.keys()
    }

    df_s, df_r, df_u = _fetch_effective_input_sources(main_conn, start_ts, end_ts)
    s_cols = [c for c in EFFECTIVE_SPECTRL2_COLS if c in df_s.columns]
    r_cols = [c for c in EFFECTIVE_RATIOS_COLS if c in df_r.columns]
    u_cols = [c for c in EFFECTIVE_UPPER_COLS if c in df_u.columns]

    s_10s = _attach_to_grid(df_s, grid, s_cols) if s_cols else pd.DataFrame(index=grid)
    r_10s = _attach_to_grid(df_r, grid, r_cols) if r_cols else pd.DataFrame(index=grid)
    u_10s = _attach_to_grid(df_u, grid, u_cols) if u_cols else pd.DataFrame(index=grid)

    if "bc_total" in r_10s.columns:
        out["extra::ratios::bc_total"] = r_10s["bc_total"].reindex(daylight_grid).values.astype(np.float32)
    if "om_total" in r_10s.columns:
        out["extra::ratios::om_total"] = r_10s["om_total"].reindex(daylight_grid).values.astype(np.float32)

    for c in ["Upper_aod_335", "Upper_aod_355", "Upper_aod_532", "Upper_aod_550", "Upper_aod_1064"]:
        if c in u_10s.columns:
            out[f"extra::upper::{c}"] = u_10s[c].reindex(daylight_grid).values.astype(np.float32)

    eff_merge = pd.DataFrame(index=pd.Index(daylight_grid))
    for c in [
        "sensor.tvl9_o_1pst_pm0_3",
        "sensor.tvl9_o_1pst_pm1",
        "sensor.tvl9_o_1pst_pm2_5",
        "sensor.tvl9_gw2000a_humidity",
    ]:
        s = c_idx.get(c)
        if s is not None:
            eff_merge[c] = _interp_time_inside(s, grid, edge_fill=True).reindex(daylight_grid).values.astype(np.float32)
        else:
            eff_merge[c] = np.full(n, np.nan, dtype=np.float32)

    for src in (s_10s, r_10s, u_10s):
        for c in src.columns:
            eff_merge[c] = src[c].reindex(daylight_grid).values.astype(np.float32)

    lower_names = ["Lower_aod_335", "Lower_aod_355", "Lower_aod_532", "Lower_aod_550", "Lower_aod_1064"]
    lower_store = {name: np.full(n, np.nan, dtype=np.float32) for name in lower_names}
    for i in range(n):
        row = eff_merge.iloc[i]
        ap = _compute_local_only_aod_params(row)
        lower = _piecewise_lower_aod_from_tau_alphas(ap.get("TAU550", np.nan), ap.get("ALPHA1", np.nan), ap.get("ALPHA2", np.nan))
        for name in lower_names:
            v = _safe_float_local(lower.get(name), np.nan)
            lower_store[name][i] = np.float32(v) if np.isfinite(v) else np.float32(np.nan)

    for name, arr in lower_store.items():
        out[f"extra::lower::{name}"] = arr

    return out


# ═══════════════════════════════════════════════════════════
# SR / IAM / NAPGEOMETRIA / RAW SPEKTRUM
# ═══════════════════════════════════════════════════════════

def _sr_interp_5nm():
    wl = np.array(list(SR_POINTS_5NM.keys()), dtype=float)
    sr = np.array(list(SR_POINTS_5NM.values()), dtype=float)
    idx = np.argsort(wl)
    return interp1d(wl[idx], sr[idx], kind="cubic", bounds_error=False, fill_value=0.0)


def _iam_spline():
    aoi_deg = np.array(sorted(float(k) for k in IAM_POINTS.keys()), dtype=float)
    iam_val = np.array([float(IAM_POINTS[float(k)] if float(k) in IAM_POINTS else IAM_POINTS[int(k)]) for k in aoi_deg], dtype=float)
    if len(aoi_deg) < 3:
        raise RuntimeError("IAM_POINTS túl rövid")
    spline = CubicSpline(aoi_deg, iam_val, bc_type="natural")

    def _fn(a):
        arr = np.asarray(a, dtype=float)
        arr = np.clip(arr, 0.0, 90.0)
        return np.clip(spline(arr), 0.0, 1.0)

    return _fn


def _am15_kA_from_sr(sr_fn) -> float:
    """
    kA = 1000 / ∫ AM1.5G_global(λ) * SR(λ) dλ   [WLMIN–WLMAX tartományban]

    Pontosan a spectrum_utils._am15_denorm_factor logikája:
      f   = ∫ AM1.5G * SR dλ / 1000   (dimenziótlan)
      kA  = 1 / f  →  SR-integrált × kA → broadband [W/m²] skálán
    """
    try:
        ref = pvlib.spectrum.get_reference_spectra(standard="ASTM G173-03")
        wl_ref = ref.index.values.astype(float)
        e_ref = ref["global"].values.astype(float)
    except Exception as exc:
        raise RuntimeError(f"ASTM G173-03 referencia spektrum nem tölthető: {exc}") from exc

    mask = (wl_ref >= WLMIN) & (wl_ref <= WLMAX)
    wl_m = wl_ref[mask]
    e_m = e_ref[mask]
    if wl_m.size < 2:
        raise RuntimeError(f"ASTM G173-03 túl kevés pont {WLMIN}–{WLMAX} nm között: {wl_m.size}")

    sr = np.clip(sr_fn(wl_m), 0.0, 1.0)
    dlam = np.diff(wl_m)
    avg = (e_m[:-1] * sr[:-1] + e_m[1:] * sr[1:]) / 2.0
    integral = float(np.sum(avg * dlam))

    if not np.isfinite(integral) or integral <= 0:
        raise RuntimeError(f"ASTM G173-03 × SR integrál érvénytelen: {integral}")

    f = integral / 1000.0   # dimenziótlan normalizáló (mint spectrum_utils-ban)
    kA = 1.0 / f            # denorm szorzó (SR-integrált × kA → W/m²)
    return kA


def _sunpos(ts_utc, lat, lon, alt_km):
    return pvlib.solarposition.get_solarposition(
        time=pd.to_datetime(ts_utc, utc=True), latitude=float(lat), longitude=float(lon), altitude=float(alt_km) * 1000.0, method="nrel_numpy"
    )


def _compute_aoi(ts_utc, lat, lon, alt_km, panel_tilt, panel_azimuth):
    sp = _sunpos(ts_utc, lat, lon, alt_km)
    zen = float(sp["apparent_zenith"].iloc[0])
    azi = float(sp["azimuth"].iloc[0])
    aoi = pvlib.irradiance.aoi(float(panel_tilt), float(panel_azimuth), zen, azi)
    return float(aoi)


def _integral_raw(wl: np.ndarray, y: np.ndarray) -> float:
    wl = np.asarray(wl, dtype=float)
    y = np.asarray(y, dtype=float)
    m = np.isfinite(wl) & np.isfinite(y) & (wl >= WLMIN) & (wl <= WLMAX)
    if int(m.sum()) < 3:
        return float("nan")
    ww = wl[m]
    yy = y[m]
    idx = np.argsort(ww)
    ww = ww[idx]
    yy = yy[idx]
    return float(np.trapz(yy, ww))


def _integral_sr_weighted(wl: np.ndarray, y: np.ndarray, sr_fn) -> float:
    wl = np.asarray(wl, dtype=float)
    y = np.asarray(y, dtype=float)
    m = np.isfinite(wl) & np.isfinite(y) & (wl >= WLMIN) & (wl <= WLMAX)
    if int(m.sum()) < 3:
        return float("nan")
    ww = wl[m]
    yy = y[m]
    idx = np.argsort(ww)
    ww = ww[idx]
    yy = yy[idx]
    sr = np.asarray(sr_fn(ww), dtype=float)
    sr = np.where(np.isfinite(sr), np.clip(sr, 0.0, 1.0), 0.0)
    return float(np.trapz(yy * sr, ww))


def _spectral_fixed_value(wl: np.ndarray, spectrum: np.ndarray, aoi_deg: float, sr_fn, iam_fn, kA: float) -> Tuple[float, float, float, float]:
    """
    Spektrális konvolúciós lánc — pontosan a smarts_workflows logikájával:
      raw  = ∫ spectrum dλ                          (nyers broadband)
      sr_w = ∫ spectrum * SR(λ) dλ                  (SR-súlyozott)
      srka = sr_w * kA                              (ASTM G173 alapú denormálás, kA = 1000/∫AM1.5G*SR dλ)
      final= srka * IAM(aoi)                        (szögkorrekció)

    GHI-re és GTI-re (beam + diffuse) egyaránt ugyanez a kA megy.
    """
    raw_val = _integral_raw(wl, spectrum)
    sr_val = _integral_sr_weighted(wl, spectrum, sr_fn)
    iam_val = float(iam_fn(aoi_deg)) if np.isfinite(aoi_deg) else float("nan")
    if np.isfinite(sr_val) and np.isfinite(kA):
        srka = sr_val * kA
        final = srka * iam_val if np.isfinite(iam_val) else float("nan")
    else:
        srka = float("nan")
        final = float("nan")
    return raw_val, sr_val, iam_val, final


def build_fixed_spectral_table(df_spec: pd.DataFrame, ts_col: str) -> pd.DataFrame:
    sr_fn = _sr_interp_5nm()
    iam_fn = _iam_spline()
    # ASTM G173-03 alapú kA — egyszer számoljuk, GHI-re és GTI-re egyaránt (spectrum_utils._am15_denorm_factor logikája)
    kA = _am15_kA_from_sr(sr_fn)
    print(f"  [spectral] ASTM G173-03 kA = {kA:.6f}  (f = {1.0/kA:.6f}, ~ 1/kA × 1000 = ∫AM1.5G×SR dλ = {1000.0/kA:.2f} W/m²)")
    rows: List[Dict[str, Any]] = []

    def _get_arr(row_dict: Dict[str, Any], col: str) -> np.ndarray:
        # Először a suffix-es oszlopnevet nézzük, visszaesésként a base nevet.
        # Így a függvény nem törik, akár suffix-es, akár default DB sorokat kap.
        if SPECTRAL_SUFFIX:
            v = row_dict.get(col + SPECTRAL_SUFFIX)
            if v is not None:
                return _safe_json_array(v)
        return _safe_json_array(row_dict.get(col))

    for row in df_spec.to_dict(orient="records"):
        ts = pd.to_datetime(row.get(ts_col), utc=True, errors="coerce")
        if pd.isna(ts):
            continue
        wl = _get_arr(row, "wavelengths")
        if wl.size < 3:
            continue

        ghi = _get_arr(row, "ghi_spectrum")
        b1225 = _get_arr(row, "gti1225_beam_spectrum")
        d1225 = _get_arr(row, "gti1225_diff_spectrum")
        b1545 = _get_arr(row, "gti1545_beam_spectrum")
        d1545 = _get_arr(row, "gti1545_diff_spectrum")

        aoi_ghi = _compute_aoi(ts, DEFAULT_LAT, DEFAULT_LON, DEFAULT_ALT_KM, PANEL_TILT, PANEL_AZIMUTH)
        aoi_1225 = _compute_aoi(ts, DEFAULT_LAT, DEFAULT_LON, DEFAULT_ALT_KM, GTI1_TILT, GTI_AZIMUTH)
        aoi_1545 = _compute_aoi(ts, DEFAULT_LAT, DEFAULT_LON, DEFAULT_ALT_KM, GTI2_TILT, GTI_AZIMUTH)

        ghi_raw = ghi_sr = ghi_iam = ghi_fixed = np.nan
        if ghi.size == wl.size:
            ghi_raw, ghi_sr, ghi_iam, ghi_fixed = _spectral_fixed_value(wl, ghi, aoi_ghi, sr_fn, iam_fn, kA)

        b1225_raw = b1225_sr = b1225_fixed = np.nan
        d1225_raw = d1225_sr = d1225_fixed = np.nan
        gti1225_fixed = np.nan
        if b1225.size == wl.size:
            b1225_raw, b1225_sr, _iam_b1225, b1225_fixed = _spectral_fixed_value(wl, b1225, aoi_1225, sr_fn, iam_fn, kA)
        if d1225.size == wl.size:
            d1225_raw, d1225_sr, _iam_d1225, d1225_fixed = _spectral_fixed_value(wl, d1225, aoi_1225, sr_fn, iam_fn, kA)
        if np.isfinite(b1225_fixed) or np.isfinite(d1225_fixed):
            gti1225_fixed = np.nansum([b1225_fixed, d1225_fixed])

        b1545_raw = b1545_sr = b1545_fixed = np.nan
        d1545_raw = d1545_sr = d1545_fixed = np.nan
        gti1545_fixed = np.nan
        if b1545.size == wl.size:
            b1545_raw, b1545_sr, _iam_b1545, b1545_fixed = _spectral_fixed_value(wl, b1545, aoi_1545, sr_fn, iam_fn, kA)
        if d1545.size == wl.size:
            d1545_raw, d1545_sr, _iam_d1545, d1545_fixed = _spectral_fixed_value(wl, d1545, aoi_1545, sr_fn, iam_fn, kA)
        if np.isfinite(b1545_fixed) or np.isfinite(d1545_fixed):
            gti1545_fixed = np.nansum([b1545_fixed, d1545_fixed])

        rows.append({
            "timestamp": ts,
            "ghi_raw_from_spectrum": ghi_raw,
            "ghi_sr_weighted": ghi_sr,
            "ghi_aoi_deg": aoi_ghi,
            "ghi_iam": ghi_iam,
            "ghi_fixed": ghi_fixed,
            "gti1225_beam_raw": b1225_raw,
            "gti1225_diff_raw": d1225_raw,
            "gti1225_beam_sr": b1225_sr,
            "gti1225_diff_sr": d1225_sr,
            "gti1225_aoi_deg": aoi_1225,
            "gti1225_fixed": gti1225_fixed,
            "gti1545_beam_raw": b1545_raw,
            "gti1545_diff_raw": d1545_raw,
            "gti1545_beam_sr": b1545_sr,
            "gti1545_diff_sr": d1545_sr,
            "gti1545_aoi_deg": aoi_1545,
            "gti1545_fixed": gti1545_fixed,
            "spectral_wl_min": float(np.nanmin(wl[(wl >= WLMIN) & (wl <= WLMAX)])) if np.any((wl >= WLMIN) & (wl <= WLMAX)) else np.nan,
            "spectral_wl_max": float(np.nanmax(wl[(wl >= WLMIN) & (wl <= WLMAX)])) if np.any((wl >= WLMIN) & (wl <= WLMAX)) else np.nan,
            "spectral_n_points": int(np.sum((wl >= WLMIN) & (wl <= WLMAX))),
        })

    if not rows:
        return pd.DataFrame(columns=[
            "timestamp", "ghi_fixed", "gti1225_fixed", "gti1545_fixed",
            "ghi_raw_from_spectrum", "ghi_sr_weighted", "ghi_aoi_deg", "ghi_iam",
        ])
    out = pd.DataFrame(rows)
    out["timestamp"] = pd.to_datetime(out["timestamp"], utc=True, errors="coerce")
    return out.dropna(subset=["timestamp"]).sort_values("timestamp").drop_duplicates("timestamp")


def fetch_integrated_as_fixed(conn, start_ts: pd.Timestamp, end_ts: pd.Timestamp,
                              suffix: str = "") -> pd.DataFrame:
    """
    Olvasás a public.smarts_spectral_allsky_integrated táblából.
    A visszaadott DataFrame oszlopai MEGEGYEZNEK a build_fixed_spectral_table()
    kimenetével, így a dashboard többi része változatlanul tudja kezelni.

    Fontos oszlopok (a régi build kimenetével 1:1):
      - timestamp, ghi_fixed, gti1225_fixed, gti1545_fixed
      - ghi_raw_from_spectrum, ghi_sr_weighted, ghi_aoi_deg, ghi_iam
      - gti1225_beam_raw, gti1225_diff_raw, gti1225_beam_sr, gti1225_diff_sr, gti1225_aoi_deg
      - gti1545_beam_raw, gti1545_diff_raw, gti1545_beam_sr, gti1545_diff_sr, gti1545_aoi_deg
      - spectral_wl_min, spectral_wl_max, spectral_n_points

    A pipeline INTEGRATED táblájának oszlopai:
      - ghi (final = SR×kA×IAM applied), gti1225beam, gti1225diffuse, gti1545beam, gti1545diffuse
      - ghi_raw, gti1225beam_raw, gti1225diffuse_raw, gti1545beam_raw, gti1545diffuse_raw
      - ghi_sr, gti1225beam_sr, gti1225diffuse_sr, gti1545beam_sr, gti1545diffuse_sr
      - ghi_aoi_deg, gti1225_aoi_deg, gti1545_aoi_deg
      - ghi_iam, gti1225_iam, gti1545_iam
      - kA_astm, wl_min, wl_max
      - ispymiescatt, isfallback
      - + suffix-es változatok (ha meg van adva pl. _blhcap)
    """
    parts = INTEGRATED_TABLE.split(".")
    schema, tbl = (parts[0], parts[1]) if len(parts) == 2 else ("public", parts[0])

    with conn.cursor() as cur:
        cur.execute(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_schema=%s AND table_name=%s ORDER BY ordinal_position",
            (schema, tbl),
        )
        # Mentsük a tényleges DB oszlopneveket, mert PG lowercases az idézőjel nélküli oszlopneveket;
        # és az SQL kvótolt idézőjelben case-sensitive, így a tényleges név kell.
        avail_actual = [r[0] for r in cur.fetchall()]
        avail_lower_to_actual = {c.lower(): c for c in avail_actual}

    if not avail_actual:
        raise RuntimeError(f"Integrált tábla nem létezik vagy üres: {INTEGRATED_TABLE}")

    def _pick(base_name: str) -> Optional[str]:
        """Először suffix-es oszlopot keres, ha nincs → default, ha az sincs → None.
        A tényleges DB-beli oszlopnevet adja vissza (helyes case-vel)."""
        if suffix:
            sfx_lower = (base_name + suffix).lower()
            if sfx_lower in avail_lower_to_actual:
                return avail_lower_to_actual[sfx_lower]
        base_lower = base_name.lower()
        if base_lower in avail_lower_to_actual:
            return avail_lower_to_actual[base_lower]
        return None

    # Oszlopok eldöntése — az INTEGRATED tábla oszlopneveinek megfelelően
    col_ghi_final    = _pick("ghi")
    col_g12_beam_fin = _pick("gti1225beam")
    col_g12_diff_fin = _pick("gti1225diffuse")
    col_g15_beam_fin = _pick("gti1545beam")
    col_g15_diff_fin = _pick("gti1545diffuse")

    col_ghi_raw      = _pick("ghi_raw")
    col_g12_beam_raw = _pick("gti1225beam_raw")
    col_g12_diff_raw = _pick("gti1225diffuse_raw")
    col_g15_beam_raw = _pick("gti1545beam_raw")
    col_g15_diff_raw = _pick("gti1545diffuse_raw")

    col_ghi_sr       = _pick("ghi_sr")
    col_g12_beam_sr  = _pick("gti1225beam_sr")
    col_g12_diff_sr  = _pick("gti1225diffuse_sr")
    col_g15_beam_sr  = _pick("gti1545beam_sr")
    col_g15_diff_sr  = _pick("gti1545diffuse_sr")

    col_ghi_aoi      = _pick("ghi_aoi_deg")
    col_g12_aoi      = _pick("gti1225_aoi_deg")
    col_g15_aoi      = _pick("gti1545_aoi_deg")
    col_ghi_iam      = _pick("ghi_iam")
    col_wl_min       = _pick("wl_min")
    col_wl_max       = _pick("wl_max")
    col_ispymie      = _pick("ispymiescatt")
    col_isfallback   = _pick("isfallback")

    # Kritikus oszlopok - ha hiányoznak, hiba
    missing_critical = []
    if col_ghi_final is None:
        missing_critical.append(f"ghi{suffix}")
    if col_g12_beam_fin is None and col_g12_diff_fin is None:
        missing_critical.append(f"gti1225beam{suffix} / gti1225diffuse{suffix}")
    if col_g15_beam_fin is None and col_g15_diff_fin is None:
        missing_critical.append(f"gti1545beam{suffix} / gti1545diffuse{suffix}")
    if missing_critical:
        raise RuntimeError(
            f"Kritikus integrált oszlop(ok) hiányzik: {missing_critical}. "
            f"Fusson-e a pipeline a '{suffix}' suffixszel?"
        )

    # SELECT épités
    def _q(col: Optional[str], alias: str) -> str:
        if col is None:
            return f"NULL::double precision AS {alias}"
        return f'"{col}" AS {alias}'

    select_parts = [
        '"timestamp" AS timestamp',
        _q(col_ghi_final,    "ghi_fixed"),
        _q(col_g12_beam_fin, "g12_beam_val"),
        _q(col_g12_diff_fin, "g12_diff_val"),
        _q(col_g15_beam_fin, "g15_beam_val"),
        _q(col_g15_diff_fin, "g15_diff_val"),
        _q(col_ghi_raw,      "ghi_raw_from_spectrum"),
        _q(col_ghi_sr,       "ghi_sr_weighted"),
        _q(col_g12_beam_raw, "gti1225_beam_raw"),
        _q(col_g12_diff_raw, "gti1225_diff_raw"),
        _q(col_g12_beam_sr,  "gti1225_beam_sr"),
        _q(col_g12_diff_sr,  "gti1225_diff_sr"),
        _q(col_g15_beam_raw, "gti1545_beam_raw"),
        _q(col_g15_diff_raw, "gti1545_diff_raw"),
        _q(col_g15_beam_sr,  "gti1545_beam_sr"),
        _q(col_g15_diff_sr,  "gti1545_diff_sr"),
        _q(col_ghi_aoi,      "ghi_aoi_deg"),
        _q(col_g12_aoi,      "gti1225_aoi_deg"),
        _q(col_g15_aoi,      "gti1545_aoi_deg"),
        _q(col_ghi_iam,      "ghi_iam"),
        _q(col_wl_min,       "spectral_wl_min"),
        _q(col_wl_max,       "spectral_wl_max"),
    ]
    # ispymie / isfallback smallint
    if col_ispymie is not None:
        select_parts.append(f'"{col_ispymie}"::int AS ispymiescatt')
    else:
        select_parts.append("NULL::int AS ispymiescatt")
    if col_isfallback is not None:
        select_parts.append(f'"{col_isfallback}"::int AS isfallback')
    else:
        select_parts.append("NULL::int AS isfallback")

    sql = (
        "SELECT " + ", ".join(select_parts) + " "
        f'FROM "{schema}"."{tbl}" '
        'WHERE "timestamp" >= %s AND "timestamp" <= %s '
        'ORDER BY "timestamp"'
    )

    print(f"  [integrated] SUFFIX='{suffix}'  "
          f"ghi={col_ghi_final}  gti12=[{col_g12_beam_fin}+{col_g12_diff_fin}]  "
          f"gti15=[{col_g15_beam_fin}+{col_g15_diff_fin}]")

    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(sql, (start_ts.to_pydatetime(), end_ts.to_pydatetime()))
        rows = cur.fetchall()

    if not rows:
        return pd.DataFrame(columns=[
            "timestamp", "ghi_fixed", "gti1225_fixed", "gti1545_fixed",
            "ghi_raw_from_spectrum", "ghi_sr_weighted", "ghi_aoi_deg", "ghi_iam",
        ])

    df = pd.DataFrame(rows)

    # beam + diffuse → *_fixed  (a pipeline-ben is így készül az INTEGRATED értékek)
    # Numpy-alapu nansum, cellánként
    def _sum_pair(a, b):
        a_v = pd.to_numeric(a, errors="coerce").to_numpy(dtype=float)
        b_v = pd.to_numeric(b, errors="coerce").to_numpy(dtype=float)
        both_nan = np.isnan(a_v) & np.isnan(b_v)
        out = np.where(np.isnan(a_v), 0.0, a_v) + np.where(np.isnan(b_v), 0.0, b_v)
        out = np.where(both_nan, np.nan, out)
        return out

    df["gti1225_fixed"] = _sum_pair(df["g12_beam_val"], df["g12_diff_val"])
    df["gti1545_fixed"] = _sum_pair(df["g15_beam_val"], df["g15_diff_val"])

    # A pipeline és a régi build_fixed egyaránt az ispymie flag nélküli tartományban
    # numerikusra castol. Minden ghi/gti*_fixed double precision, már rendben van.
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
    df = df.dropna(subset=["timestamp"]).sort_values("timestamp").drop_duplicates("timestamp")

    # spectral_n_points: a régi build 1 nm-es rács → (wl_max - wl_min) + 1
    wl_min = pd.to_numeric(df["spectral_wl_min"], errors="coerce")
    wl_max = pd.to_numeric(df["spectral_wl_max"], errors="coerce")
    df["spectral_n_points"] = np.where(
        wl_min.notna() & wl_max.notna(),
        (wl_max - wl_min + 1).astype(float),
        np.nan,
    )

    # Diag: hany sor nem-NaN ghi_fixed-del
    n_nonnan = int(df["ghi_fixed"].notna().sum())
    n_total = len(df)
    print(f"  [integrated] {n_total} sor, ghi_fixed non-NaN: {n_nonnan}")

    # A régi build nem adott 'g12_beam_val' / 'g15_beam_val' oszlopokat — ezeket eltávolítjuk
    for extra in ("g12_beam_val", "g12_diff_val", "g15_beam_val", "g15_diff_val"):
        if extra in df.columns:
            df = df.drop(columns=[extra])

    return df.reset_index(drop=True)


# ═══════════════════════════════════════════════════════════
# PERIOD HANDLING
# ═══════════════════════════════════════════════════════════

def _load_periods_from_const():
    cand = []
    if C is not None:
        for name in ("PERIODS", "PERIOD_LIST", "PERIODS_UTC", "PERIODS_LIST", "PROD_PERIODS", "TEST_PERIODS"):
            if hasattr(C, name):
                cand = getattr(C, name)
                if cand:
                    break
    periods = []
    if isinstance(cand, list) and cand:
        for it in cand:
            if isinstance(it, (list, tuple)) and len(it) >= 2:
                periods.append((pd.to_datetime(it[0], utc=True), pd.to_datetime(it[1], utc=True)))
            elif isinstance(it, dict) and "start" in it and "end" in it:
                periods.append((pd.to_datetime(it["start"], utc=True), pd.to_datetime(it["end"], utc=True)))
    if periods:
        return periods
    now = pd.Timestamp.utcnow()
    return [(now.floor("D"), now)]


# ═══════════════════════════════════════════════════════════
# HTML RENDER
# ═══════════════════════════════════════════════════════════

def build_html(payload, out_html):
    data_json = json.dumps(_json_sanitize(payload), ensure_ascii=False, separators=(",", ":"))
    html = r"""<!doctype html>
<html lang="hu">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>DASHBOARD v7 — RAW spectral + Inputok</title>
<script src="https://cdn.plot.ly/plotly-2.30.0.min.js"></script>
<style>
  body{font-family:Arial,sans-serif;margin:0;background:#fafafa}
  .topbar{display:flex;gap:8px;align-items:center;padding:10px 14px;background:#fff;border-bottom:1px solid #ddd;position:sticky;top:0;z-index:10;flex-wrap:wrap}
  select,button{padding:6px 10px;border:1px solid #bbb;border-radius:8px;background:#fff;cursor:pointer;font-size:13px}
  button.tab{cursor:pointer}button.tab.active{border-color:#223;font-weight:700;background:#eef3ff}
  .meta{color:#444;font-size:13px}.wrap{padding:12px 14px;display:grid;gap:12px}
  .card{background:#fff;border:1px solid #ddd;border-radius:14px;padding:12px;box-shadow:0 1px 2px rgba(0,0,0,.04)}
  .row{display:flex;gap:8px;flex-wrap:wrap}
  .kpi{font-size:11px;color:#333;min-width:105px}.kpi b{font-size:12px}.kpi .u{color:#888;font-size:10px}
  #plot{width:100%;height:980px}.muted{color:#666;font-size:12px}
  .corr-bar{display:inline-block;height:14px;border-radius:3px;margin-right:4px;vertical-align:middle}
  .corr-tbl{font-size:11px;border-collapse:collapse;width:100%}
  .corr-tbl td,.corr-tbl th{padding:3px 6px;border-bottom:1px solid #eee;text-align:left}
  .corr-tbl th{background:#f5f5f5}
  input[type=range]{width:220px;vertical-align:middle}
  .pill{display:inline-block;padding:2px 8px;border-radius:999px;background:#eef3ff;color:#223;font-size:12px;margin-right:8px}
</style>
</head>
<body>
<div class="topbar">
  <b>DASHBOARD v7 + RAW spectral + Korreláció</b>
  <button id="tab_ts" class="tab active" onclick="switchTab('ts')">Idősoros</button>
  <button id="tab_inputs" class="tab" onclick="switchTab('inputs')">Input Signals</button>
  <button id="tab_bin" class="tab" onclick="switchTab('bin')">10min Bins</button>
  <button id="tab_gbin" class="tab" onclick="switchTab('gbin')">Glob. Bins</button>
  <button id="tab_corr" class="tab" onclick="switchTab('corr')">Korreláció</button>
  <button id="tab_errcorr" class="tab" onclick="switchTab('errcorr')">Nagy hiba korreláció</button>
  <button id="tab_scatter" class="tab" onclick="switchTab('scatter')">Scatter</button>
  <span style="flex:1"></span>
  <label>Periódus:</label><select id="periodSel"></select>
  <label id="inputLabel" style="display:none">Input:</label><select id="inputSel" style="display:none"></select>
  <label id="thrLabel" style="display:none">|GHI hiba| küszöb:</label><input id="thrRange" type="range" min="0" max="300" step="5" value="50" style="display:none"/><span id="thrValue" class="muted" style="display:none">50 W/m²</span>
  <label id="thrVarLabel" style="display:none">Korreláló input:</label><select id="thrVarSel" style="display:none"></select>
</div>
<div class="wrap">
  <div class="card"><div class="row" id="kpis"></div></div>
  <div class="card"><div id="plot"></div><div id="corrTable" style="display:none;max-height:700px;overflow:auto"></div></div>
</div>
<script>
const DATA=__DATA_JSON__;
let CUR_TAB="ts";
let CUR_INPUT_KEY=null;
let CUR_THRESH_KEY=null;
function fmt(x,d){d=d||2;if(x===null||x===undefined)return"n/a";if(typeof x==="number"){if(!isFinite(x))return"n/a";return x.toFixed(d)}return String(x)}
function num(x){return (x===null||x===undefined)?NaN:Number(x)}
function getInputOptions(){return DATA.input_options||[]}
function getThresholdOptions(){return DATA.threshold_corr_options||[]}
function setInputUiVisible(v){document.getElementById("inputLabel").style.display=v?"":"none";document.getElementById("inputSel").style.display=v?"":"none"}
function setThresholdUiVisible(v){document.getElementById("thrLabel").style.display=v?"":"none";document.getElementById("thrRange").style.display=v?"":"none";document.getElementById("thrValue").style.display=v?"":"none";document.getElementById("thrVarLabel").style.display=v?"":"none";document.getElementById("thrVarSel").style.display=v?"":"none"}
function updateThresholdValue(){const el=document.getElementById("thrRange");document.getElementById("thrValue").textContent=`${fmt(num(el.value),0)} W/m²`}
function syncThresholdRange(p){
  const err=((p&&p.ghi&&p.ghi.error)||[]).map(num).filter(v=>isFinite(v)).map(v=>Math.abs(v));
  const maxErr=err.length?Math.max(...err):num((DATA.meta||{}).threshold_default_wm2||50);
  const el=document.getElementById("thrRange");
  const step=num((DATA.meta||{}).threshold_step_wm2||5)||5;
  const hardMax=num((DATA.meta||{}).threshold_max_wm2||300)||300;
  const dynMax=Math.max(step, Math.min(hardMax, Math.ceil(maxErr/step)*step));
  el.step=String(step); el.max=String(dynMax);
  if(num(el.value)>dynMax){el.value=String(dynMax)}
  updateThresholdValue();
}
function switchTab(t){CUR_TAB=t;document.querySelectorAll(".tab").forEach(b=>b.classList.remove("active"));document.getElementById("tab_"+t).classList.add("active");setInputUiVisible(t==="inputs");setThresholdUiVisible(t==="errcorr");renderCurrent()}
function buildKpis(m){
  const box=document.getElementById("kpis");box.innerHTML="";
  const sigs=[{pre:"GHI",r:m.ghi_rmse,nr:m.ghi_nrmse,mb:m.ghi_mbe,p:m.ghi_pearson,r2:m.ghi_r2},
              {pre:"GTI12",r:m.gti1225_rmse,nr:m.gti1225_nrmse,mb:m.gti1225_mbe,p:m.gti1225_pearson,r2:m.gti1225_r2},
              {pre:"GTI15",r:m.gti1545_rmse,nr:m.gti1545_nrmse,mb:m.gti1545_mbe,p:m.gti1545_pearson,r2:m.gti1545_r2}];
  for(const s of sigs){for(const[k,v,u]of[[s.pre+" RMSE",s.r,"W/m²"],[s.pre+" nRMSE",s.nr,"%"],[s.pre+" MBE",s.mb,"W/m²"],[s.pre+" Pearson",s.p,""] ,[s.pre+" R²",s.r2,""]]){
    const div=document.createElement("div");div.className="kpi";div.innerHTML=`<div>${k}</div><div><b>${fmt(v,k.includes("Pearson")||k.includes("R²")?4:2)}</b> <span class="u">${u}</span></div>`;box.appendChild(div)}}
  const meta=DATA.meta||{};
  const div=document.createElement("div");div.className="kpi";div.innerHTML=`<div>Source</div><div><b>RAW→SR×kA(ASTM G173)×IAM</b> <span class="u">${meta.spectral_table||"spectral"}</span></div>`;box.appendChild(div)
}
function renderTS(p){
  const x=p.ts;
  Plotly.react("plot",[
    {x,y:p.ghi.measured,mode:"lines",name:"IMT14 mért",line:{width:2},xaxis:"x",yaxis:"y"},
    {x,y:p.ghi.smarts,mode:"lines",name:"SMARTS GHI raw→SR×kA(ASTM)×IAM",line:{width:2,dash:"dot"},xaxis:"x",yaxis:"y"},
    {x,y:p.gti1225.measured,mode:"lines",name:"IMT16 mért",line:{width:2},xaxis:"x2",yaxis:"y2"},
    {x,y:p.gti1225.smarts,mode:"lines",name:"SMARTS GTI12.25 raw→SR×kA(ASTM)×IAM",line:{width:2,dash:"dot"},xaxis:"x2",yaxis:"y2"},
    {x,y:p.gti1545.measured,mode:"lines",name:"IMT15 mért",line:{width:2},xaxis:"x3",yaxis:"y3"},
    {x,y:p.gti1545.smarts,mode:"lines",name:"SMARTS GTI15.45 raw→SR×kA(ASTM)×IAM",line:{width:2,dash:"dot"},xaxis:"x3",yaxis:"y3"},
  ],{title:{text:`Idősoros — ${p.key}`,x:0.01},height:980,margin:{l:64,r:18,t:58,b:48},hovermode:"x unified",
    legend:{orientation:"h",x:0,y:1.10},grid:{rows:3,columns:1,pattern:"independent",roworder:"top to bottom"},
    xaxis:{showticklabels:false},xaxis2:{showticklabels:false,matches:"x"},
    xaxis3:{title:"idő (UTC)",matches:"x"},yaxis:{title:"GHI (W/m²)"},yaxis2:{title:"GTI 12.25°"},yaxis3:{title:"GTI 15.45°"}},
  {displayModeBar:true,responsive:true});
}
function renderInputs(p){
  const opts=getInputOptions();
  if(!CUR_INPUT_KEY && opts.length){CUR_INPUT_KEY=opts[0].key}
  const available=(p.input_series||{});
  if((!CUR_INPUT_KEY || !(CUR_INPUT_KEY in available)) && opts.length){
    const first=opts.find(o=>o.key in available) || opts[0];
    CUR_INPUT_KEY=first.key;
  }
  const meta=opts.find(o=>o.key===CUR_INPUT_KEY) || {key:CUR_INPUT_KEY,label:CUR_INPUT_KEY};
  const y=(available[CUR_INPUT_KEY]||[]);
  const x=p.ts||[];
  const err=(p.ghi.error||[]);
  Plotly.react("plot",[
    {x,y,mode:"lines",name:meta.label,line:{width:2},xaxis:"x",yaxis:"y"},
    {x,y:err,mode:"lines",name:"GHI hiba (SMARTS−mért)",line:{width:1,dash:"dot"},xaxis:"x2",yaxis:"y2"}
  ],{title:{text:`Input signal — ${meta.label} — ${p.key}`,x:0.01},height:860,margin:{l:64,r:18,t:58,b:48},hovermode:"x unified",
    legend:{orientation:"h",x:0,y:1.08},grid:{rows:2,columns:1,pattern:"independent",roworder:"top to bottom"},
    xaxis:{showticklabels:false},xaxis2:{title:"idő (UTC)",matches:"x"},
    yaxis:{title:meta.label},yaxis2:{title:"GHI hiba (W/m²)"}},
  {displayModeBar:true,responsive:true});
}
function renderBin(p){
  const b=p.binned;if(!b){document.getElementById("plot").innerHTML="<p>Nincs adat</p>";return}
  const tr=[];const C=["#2563eb","#16a34a","#dc2626"];const Cm=["#93c5fd","#86efac","#fca5a5"];
  [{k:"ghi",n:"GHI",i:0},{k:"gti1225",n:"GTI12.25",i:1},{k:"gti1545",n:"GTI15.45",i:2}].forEach(s=>{
    const bd=b[s.k];if(!bd||!bd.bin_label||bd.bin_label.length===0)return;
    tr.push({x:bd.bin_label,y:bd.rmse,type:"bar",name:s.n+" RMSE",marker:{color:C[s.i],opacity:.85}});
    tr.push({x:bd.bin_label,y:bd.mbe,type:"bar",name:s.n+" MBE",marker:{color:Cm[s.i],opacity:.7}});
  });
  Plotly.react("plot",tr,{title:{text:`10min Bins — ${p.key}`,x:0.01},height:700,margin:{l:64,r:18,t:58,b:90},
    barmode:"group",legend:{orientation:"h",x:0,y:1.08},xaxis:{title:"10min bin",tickangle:-45},yaxis:{title:"W/m²"}},
  {displayModeBar:true,responsive:true});
}
function renderGBin(){
  const gb=DATA.global_binned;if(!gb){document.getElementById("plot").innerHTML="<p>Nincs adat</p>";return}
  if(DATA.global_metrics)buildKpis(DATA.global_metrics);
  const tr=[];
  [{k:"ghi",n:"GHI",row:1},{k:"gti1225",n:"GTI12.25",row:2},{k:"gti1545",n:"GTI15.45",row:3}].forEach(s=>{
    const bd=gb[s.k];if(!bd||!bd.bin_label)return;
    const ax=s.row===1?"x":"x"+s.row,ay=s.row===1?"y":"y"+s.row;
    tr.push({x:bd.bin_label,y:bd.rmse,type:"bar",name:s.n+" RMSE",xaxis:ax,yaxis:ay,marker:{opacity:.85}});
    tr.push({x:bd.bin_label,y:bd.mbe,type:"bar",name:s.n+" MBE",xaxis:ax,yaxis:ay,marker:{opacity:.6}});
  });
  Plotly.react("plot",tr,{title:{text:"Globális 10min Bins (clock-stacked)",x:0.01},height:980,margin:{l:64,r:18,t:58,b:90},
    barmode:"group",legend:{orientation:"h",x:0,y:1.08},grid:{rows:3,columns:1,pattern:"independent",roworder:"top to bottom"},
    xaxis:{showticklabels:false},xaxis2:{showticklabels:false,matches:"x"},
    xaxis3:{title:"Napszak",matches:"x",tickangle:-45},yaxis:{title:"GHI (W/m²)"},yaxis2:{title:"GTI12.25"},yaxis3:{title:"GTI15.45"}},
  {displayModeBar:true,responsive:true});
}
function renderCorr(){
  const gc=DATA.global_corr;
  if(!gc){document.getElementById("plot").innerHTML="<p>Nincs korreláció adat</p>";return}
  document.getElementById("plot").style.display="none";
  const ct=document.getElementById("corrTable");ct.style.display="block";
  let h="<h3>Korreláció: GHI hiba vs. bemenő paraméterek (|Pearson| top 80)</h3>";
  h+=`<p class="muted">n_norm = ${gc.n_norm} (normalizált mintaszám)</p>`;
  h+="<h4>Előjeles hiba (SMARTS − mért) vs. input</h4>";
  h+="<table class='corr-tbl'><tr><th>#</th><th>Paraméter</th><th>Pearson</th><th>Spearman</th><th>Bar</th><th>N</th></tr>";
  (gc.top_signed||[]).forEach((r,i)=>{
    const w=Math.min(Math.abs(r.pearson)*200,150);
    const c=r.pearson>=0?"#2563eb":"#dc2626";
    h+=`<tr><td>${i+1}</td><td>${r.label}</td><td><b>${fmt(r.pearson,4)}</b></td><td>${fmt(r.spearman,4)}</td><td><span class="corr-bar" style="width:${w}px;background:${c}"></span></td><td>${r.n_used}</td></tr>`;
  });
  h+="</table>";
  h+="<h4 style='margin-top:20px'>|Hiba| vs. input</h4>";
  h+="<table class='corr-tbl'><tr><th>#</th><th>Paraméter</th><th>Pearson</th><th>Spearman</th><th>Bar</th><th>N</th></tr>";
  (gc.top_abs||[]).forEach((r,i)=>{
    const w=Math.min(Math.abs(r.pearson)*200,150);
    const c=r.pearson>=0?"#f59e0b":"#7c3aed";
    h+=`<tr><td>${i+1}</td><td>${r.label}</td><td><b>${fmt(r.pearson,4)}</b></td><td>${fmt(r.spearman,4)}</td><td><span class="corr-bar" style="width:${w}px;background:${c}"></span></td><td>${r.n_used}</td></tr>`;
  });
  h+="</table>";
  ct.innerHTML=h;
}
function _rankAverage(arr){
  const vals=arr.map((v,i)=>({v,i})).sort((a,b)=>a.v-b.v);
  const ranks=new Array(arr.length).fill(NaN);
  let i=0;
  while(i<vals.length){let j=i+1;while(j<vals.length&&vals[j].v===vals[i].v)j++;const r=(i+j-1)/2+1;for(let k=i;k<j;k++)ranks[vals[k].i]=r;i=j}
  return ranks;
}
function _pearson(x,y){
  const n=Math.min(x.length,y.length);if(n<3)return NaN;
  let sx=0,sy=0,sxx=0,syy=0,sxy=0,c=0;
  for(let i=0;i<n;i++){const a=num(x[i]),b=num(y[i]);if(!isFinite(a)||!isFinite(b))continue;sx+=a;sy+=b;sxx+=a*a;syy+=b*b;sxy+=a*b;c++}
  if(c<3)return NaN;
  const nume=(c*sxy)-(sx*sy);const den=Math.sqrt(Math.max((c*sxx)-(sx*sx),0)*Math.max((c*syy)-(sy*sy),0));
  return den>0?(nume/den):NaN;
}
function _corrRowsForThreshold(p,thr){
  const err=((p&&p.ghi&&p.ghi.error)||[]).map(num);
  const absErr=err.map(v=>Math.abs(v));
  const idx=[]; for(let i=0;i<absErr.length;i++){ if(isFinite(absErr[i]) && absErr[i]>=thr) idx.push(i); }
  const series=p.threshold_input_series||{};
  const opts=getThresholdOptions();
  const rows=[];
  opts.forEach(opt=>{
    const arr=(series[opt.key]||[]).map(num);
    const x=[], ys=[], ya=[];
    idx.forEach(ii=>{const xv=arr[ii], ev=err[ii], aev=absErr[ii]; if(isFinite(xv)&&isFinite(ev)&&isFinite(aev)){x.push(xv); ys.push(ev); ya.push(aev);} });
    if(x.length<3)return;
    const rp=_pearson(x,ys), sp=_pearson(_rankAverage(x), _rankAverage(ys));
    const rap=_pearson(x,ya), sap=_pearson(_rankAverage(x), _rankAverage(ya));
    if(!isFinite(rp) && !isFinite(rap)) return;
    rows.push({key:opt.key,label:opt.label,n:x.length,pearson_signed:rp,spearman_signed:sp,pearson_abs:rap,spearman_abs:sap});
  });
  rows.sort((a,b)=>Math.abs((b.pearson_signed??0)) - Math.abs((a.pearson_signed??0)));
  return {rows, nSel:idx.length};
}
function _populateThresholdVarSelect(rows){
  const sel=document.getElementById("thrVarSel");
  const prev=CUR_THRESH_KEY;
  sel.innerHTML="";
  rows.forEach(r=>{
    const o=document.createElement("option");
    o.value=r.key;
    o.textContent=`${r.label} | r=${fmt(r.pearson_signed,4)} | |r|=${fmt(Math.abs(r.pearson_signed),4)}`;
    sel.appendChild(o);
  });
  const hasPrev=rows.some(r=>r.key===prev);
  CUR_THRESH_KEY = hasPrev ? prev : (rows.length ? rows[0].key : null);
  if(CUR_THRESH_KEY!==null) sel.value=CUR_THRESH_KEY;
}
function _selMaskForThreshold(err,thr){
  const idx=[];
  for(let i=0;i<err.length;i++){
    const ev=num(err[i]);
    if(isFinite(ev) && Math.abs(ev)>=thr) idx.push(i);
  }
  return idx;
}
function renderErrCorr(p){
  const thr=num(document.getElementById("thrRange").value||0);
  document.getElementById("plot").style.display="block";
  const ct=document.getElementById("corrTable");ct.style.display="block";
  const pack=_corrRowsForThreshold(p,thr);
  const rows=pack.rows||[];
  const top=rows.slice(0,15).reverse();
  let h=`<h3>Nagy hiba korrelációk — ${p.key}</h3>`;
  h+=`<p class="muted"><span class="pill">Szűrés: |GHI hiba| ≥ ${fmt(thr,0)} W/m²</span><span class="pill">Kiválasztott pontok: ${pack.nSel}</span>Csak a load_cams_from_spectrl2_view / load_cams_ratios / load_cams_upper_aod_multilevel láncból származó, nem-default inputok.</p>`;
  if(!rows.length){
    Plotly.react("plot",[],{title:{text:`Nagy hiba korreláció — ${p.key}`,x:0.01},height:520,margin:{l:64,r:18,t:58,b:48}}, {displayModeBar:true,responsive:true});
    ct.innerHTML=h+"<p>Nincs elég pont vagy nincs érvényes input a megadott küszöbhöz.</p>";
    document.getElementById("thrVarSel").innerHTML="";
    CUR_THRESH_KEY=null;
    return;
  }
  _populateThresholdVarSelect(rows);
  const selectedKey=CUR_THRESH_KEY || rows[0].key;
  const selectedRow=rows.find(r=>r.key===selectedKey) || rows[0];
  const series=(p.threshold_input_series||{})[selectedKey] || [];
  const ts=p.ts||[];
  const err=((p&&p.ghi&&p.ghi.error)||[]).map(num);
  const meas=((p&&p.ghi&&p.ghi.measured)||[]).map(num);
  const relErr=err.map((v,i)=>{ const m=num(meas[i]); return (isFinite(v) && isFinite(m) && Math.abs(m)>1e-9) ? (100.0*v/m) : null; });
  const idxSel=_selMaskForThreshold(err,thr);
  const xSel=idxSel.map(i=>ts[i]);
  const errSel=idxSel.map(i=>err[i]);
  const relErrSel=idxSel.map(i=>relErr[i]);
  const ySel=idxSel.map(i=>num(series[i]));
  const traces=[
    {x:top.map(r=>r.pearson_signed),y:top.map(r=>r.label),type:"bar",orientation:"h",marker:{opacity:.85},customdata:top.map(r=>r.key),hovertemplate:"%{y}<br>Pearson(hiba): %{x:.4f}<extra></extra>",xaxis:"x",yaxis:"y"},
    {x:ts,y:series,mode:"lines",name:selectedRow.label,line:{width:2},xaxis:"x2",yaxis:"y2"},
    {x:xSel,y:ySel,mode:"markers",name:`${selectedRow.label} | nagy hiba pontok`,marker:{size:6,symbol:"circle-open"},xaxis:"x2",yaxis:"y2"},
    {x:ts,y:err,mode:"lines",name:"GHI hiba (SMARTS−mért)",line:{width:1,dash:"dot"},xaxis:"x3",yaxis:"y3"},
    {x:xSel,y:errSel,mode:"markers",name:`|GHI hiba| ≥ ${fmt(thr,0)} W/m²`,marker:{size:6},xaxis:"x3",yaxis:"y3"},
    {x:ts,y:relErr,mode:"lines",name:"Relatív GHI hiba (%)",line:{width:1,dash:"dash"},xaxis:"x4",yaxis:"y4"},
    {x:xSel,y:relErrSel,mode:"markers",name:`Relatív GHI hiba | |GHI hiba| ≥ ${fmt(thr,0)} W/m²`,marker:{size:6,symbol:"diamond-open"},xaxis:"x4",yaxis:"y4"},
  ];
  const figLayout={
    title:{text:`Nagy hiba korreláció — ${p.key} — |GHI hiba| ≥ ${fmt(thr,0)} W/m²`,x:0.01},
    height:Math.max(1280, top.length*24+860),
    margin:{l:280,r:18,t:58,b:48},
    hovermode:"x unified",
    legend:{orientation:"h",x:0,y:1.04},
    grid:{rows:4,columns:1,pattern:"independent",roworder:"top to bottom"},
    xaxis:{title:"Pearson (előjeles hiba)"},
    yaxis:{automargin:true},
    xaxis2:{showticklabels:false,matches:"x4"},
    yaxis2:{title:selectedRow.label,automargin:true},
    xaxis3:{showticklabels:false,matches:"x4"},
    yaxis3:{title:"GHI hiba (W/m²)",automargin:true},
    xaxis4:{title:"idő (UTC)"},
    yaxis4:{title:"Relatív GHI hiba (%)",automargin:true},
  };
  Plotly.react("plot",traces,figLayout,{displayModeBar:true,responsive:true}).then(gd=>{
    gd.removeAllListeners && gd.removeAllListeners('plotly_click');
    gd.on && gd.on('plotly_click', ev=>{
      try{
        const pt=(ev&&ev.points&&ev.points[0])||null;
        if(!pt) return;
        if(pt.data && pt.data.customdata){
          const cd=pt.data.customdata[pt.pointIndex];
          if(cd){
            CUR_THRESH_KEY=cd;
            document.getElementById("thrVarSel").value=cd;
            renderCurrent();
          }
        }
      }catch(_e){}
    });
  });
  h+=`<p class="muted">Az alsó három panelen a kiválasztott korreláló input idősora, a GHI hiba idősora és a relatív GHI hiba (%) idősora látszik. A felső sávdiagramon kattintva is választhatsz inputot.</p>`;
  h+="<table class='corr-tbl'><tr><th>#</th><th>Paraméter</th><th>Pearson (hiba)</th><th>Spearman (hiba)</th><th>Pearson (|hiba|)</th><th>Spearman (|hiba|)</th><th>N</th></tr>";
  rows.forEach((r,i)=>{const sel=r.key===selectedKey?" style='background:#eef3ff;font-weight:700'":"";h+=`<tr${sel}><td>${i+1}</td><td>${r.label}</td><td><b>${fmt(r.pearson_signed,4)}</b></td><td>${fmt(r.spearman_signed,4)}</td><td>${fmt(r.pearson_abs,4)}</td><td>${fmt(r.spearman_abs,4)}</td><td>${r.n}</td></tr>`});
  h+="</table>";
  ct.innerHTML=h;
}
function renderScatter(p){
  const tr=[];
  [{m:p.ghi.measured,s:p.ghi.smarts,n:"GHI",row:1},{m:p.gti1225.measured,s:p.gti1225.smarts,n:"GTI12.25",row:2},
   {m:p.gti1545.measured,s:p.gti1545.smarts,n:"GTI15.45",row:3}].forEach(sg=>{
    const ax=sg.row===1?"x":"x"+sg.row,ay=sg.row===1?"y":"y"+sg.row;
    tr.push({x:sg.m,y:sg.s,mode:"markers",type:"scattergl",name:sg.n,marker:{size:3,opacity:.4},xaxis:ax,yaxis:ay});
    const vals=sg.m.filter(v=>v!==null&&isFinite(v));
    if(vals.length>0){const mn=Math.min(...vals),mx=Math.max(...vals);
      tr.push({x:[mn,mx],y:[mn,mx],mode:"lines",name:"1:1",line:{color:"red",dash:"dash",width:1},xaxis:ax,yaxis:ay,showlegend:false})}
  });
  Plotly.react("plot",tr,{title:{text:`Scatter — ${p.key}`,x:0.01},height:980,margin:{l:64,r:18,t:58,b:48},
    legend:{orientation:"h",x:0,y:1.08},grid:{rows:3,columns:1,pattern:"independent",roworder:"top to bottom"},
    xaxis:{},xaxis2:{},xaxis3:{title:"Mért (W/m²)"},yaxis:{title:"SMARTS GHI"},yaxis2:{title:"SMARTS GTI12.25"},yaxis3:{title:"SMARTS GTI15.45"}},
  {displayModeBar:true,responsive:true});
}
function renderCurrent(){
  const plotDiv=document.getElementById("plot");const corrDiv=document.getElementById("corrTable");
  plotDiv.style.display="block";corrDiv.style.display="none";
  const idx=parseInt(document.getElementById("periodSel").value,10);
  const p=DATA.periods[idx];
  syncThresholdRange(p);
  if(CUR_TAB==="gbin"){setInputUiVisible(false);setThresholdUiVisible(false);renderGBin();return}
  if(CUR_TAB==="corr"){setInputUiVisible(false);setThresholdUiVisible(false);if(DATA.global_metrics)buildKpis(DATA.global_metrics);renderCorr();return}
  if(CUR_TAB==="errcorr"){setInputUiVisible(false);setThresholdUiVisible(true);buildKpis(p.metrics);renderErrCorr(p);return}
  setInputUiVisible(CUR_TAB==="inputs"); setThresholdUiVisible(false);
  buildKpis(p.metrics);
  if(CUR_TAB==="ts")renderTS(p);
  else if(CUR_TAB==="inputs")renderInputs(p);
  else if(CUR_TAB==="bin")renderBin(p);
  else if(CUR_TAB==="scatter")renderScatter(p);
}
function init(){
  const sel=document.getElementById("periodSel");
  DATA.periods.forEach((p,i)=>{const o=document.createElement("option");o.value=String(i);o.textContent=p.key;sel.appendChild(o)});
  sel.addEventListener("change",()=>renderCurrent());
  const inputSel=document.getElementById("inputSel");
  getInputOptions().forEach(o=>{const el=document.createElement("option");el.value=o.key;el.textContent=o.label;inputSel.appendChild(el)});
  if(getInputOptions().length){CUR_INPUT_KEY=getInputOptions()[0].key;inputSel.value=CUR_INPUT_KEY}
  inputSel.addEventListener("change",()=>{CUR_INPUT_KEY=inputSel.value;renderCurrent()});
  const thrSel=document.getElementById("thrVarSel");
  thrSel.addEventListener("change",()=>{CUR_THRESH_KEY=thrSel.value; if(CUR_TAB==="errcorr") renderCurrent()});
  const thr=document.getElementById("thrRange");
  thr.value=String(num((DATA.meta||{}).threshold_default_wm2||50));
  thr.addEventListener("input",()=>{updateThresholdValue(); if(CUR_TAB==="errcorr") renderCurrent()});
  updateThresholdValue();
  renderCurrent();
}
init();
</script>
</body>
</html>
"""
    html = html.replace("__DATA_JSON__", data_json)
    with open(out_html, "w", encoding="utf-8") as f:
        f.write(html)


# ═══════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════

def main(argv: List[str]) -> int:
    out_html = OUT_HTML
    table_fq = TABLE_FQ
    periods = _load_periods_from_const()

    print("=" * 100)
    print("DASHBOARD v7 — RAW spectral + INPUT SIGNALS + KORRELÁCIÓ + NAGY HIBA KORRELÁCIÓ + 10min BINS")
    print("=" * 100)
    print(f"Periódusok: {len(periods)}  |  Main tábla: {table_fq}  |  Spectral: {SPECTRAL_TABLE}  |  HTML: {out_html}")
    print(f"Model chain: {WLMIN:.0f}–{WLMAX:.0f} nm -> SR_POINTS_5NM -> kA (ASTM G173-03) -> IAM  [GHI és GTI egyaránt]")
    print("-" * 100)

    main_conn = _get_main_db_conn()
    central_conn = _get_central_db_conn()

    try:
        # Main table oszlopok a dinamikus DB inputokhoz
        all_cols = fetch_table_columns(main_conn, table_fq)
        ts_col = detect_timestamp_col(all_cols)
        db_input_cols = detect_db_input_cols(all_cols, ts_col)
        print(f"DB input oszlopok (korrelációhoz): {len(db_input_cols)}")

        # Integrált tábla ellenőrzés (a pipeline által feltöltött SR×kA×IAM értékek)
        try:
            integ_all_cols = fetch_table_columns(main_conn, INTEGRATED_TABLE)
            print(f"✓ Integrált tábla: {INTEGRATED_TABLE}  ({len(integ_all_cols)} oszlop)")
            print(f"  SPECTRAL_SUFFIX='{SPECTRAL_SUFFIX}'")
            if SPECTRAL_SUFFIX:
                sfx_cols = [c for c in integ_all_cols if c.lower().endswith(SPECTRAL_SUFFIX.lower())]
                print(f"  SUFFIX='{SPECTRAL_SUFFIX}' oszlopok talalva: {len(sfx_cols)} db")
                if len(sfx_cols) == 0:
                    print(f"  [WARN] Nincs '*{SPECTRAL_SUFFIX}' oszlop — default oszlopokra esik vissza")
        except Exception as e:
            raise RuntimeError(f"Integrált tábla nem elérhető ({INTEGRATED_TABLE}): {e}")

        # A raw spectral tábla is elérhető kell legyen egyes diagnosztikai funkciók miatt,
        # de a dashboard FŐBEN az integrált táblából olvas — itt csak ellenőrizzük.
        spectral_all_cols = []
        spectral_ts_col = "timestamp"
        spectral_cols = []
        try:
            spectral_all_cols = fetch_table_columns(main_conn, SPECTRAL_TABLE)
            spectral_ts_col = detect_timestamp_col(spectral_all_cols)
            spectral_cols = _resolve_cols_ci(spectral_all_cols, SPECTRAL_EXPECTED_COLS)
            print(f"  (raw spectral tabla is elerheto: {len(spectral_cols)} / {len(SPECTRAL_EXPECTED_COLS)} oszlop)")
        except Exception as e:
            print(f"  [INFO] Raw spectral tabla nem elerheto (nem gond, integrated-bol megyunk): {e}")
        cams_cols_avail = []
        try:
            cams_all = fetch_table_columns(main_conn, CAMS_VIEW)
            cams_cols_avail = _resolve_cols_ci(cams_all, CAMS_DEFAULT_COLS + CAMS_SPECTRL2_COLS)
            print(f"✓ CAMS view oszlopok: {len(cams_cols_avail)}")
        except Exception as e:
            print(f"[WARN] CAMS view nem elérhető: {e}")

        smarts_input_cols_avail = []
        try:
            si_all = fetch_table_columns(main_conn, SMARTS_INPUT_TABLE)
            si_ts_col = detect_timestamp_col(si_all)
            smarts_input_cols_avail = _resolve_cols_ci(si_all, SMARTS_INPUT_COLS)
            print(f"✓ SMARTS input oszlopok: {len(smarts_input_cols_avail)}")
        except Exception as e:
            si_ts_col = "timestamp"
            print(f"[WARN] SMARTS input tábla nem elérhető: {e}")

        combined_gas_cols_avail = []
        try:
            cg_all = fetch_table_columns(main_conn, COMBINED_GAS_TABLE)
            cg_ts_col = detect_timestamp_col(cg_all)
            combined_gas_cols_avail = _resolve_cols_ci(cg_all, COMBINED_GAS_COLS)
            print(f"✓ combined_gas oszlopok: {len(combined_gas_cols_avail)}")
        except Exception as e:
            cg_ts_col = "timestamp"
            print(f"[WARN] combined_gas nem elérhető: {e}")

        # Input dropdown / korreláció target label-ek
        target_labels: Dict[str, str] = {}
        target_group: Dict[str, str] = {}

        for eid in CENTRAL_ENTITY_IDS:
            if eid in (IMT14_GHI_ENTITY, IMT16_GTI_ENTITY, IMT15_GTI_ENTITY):
                continue
            tk = f"central::{eid}"
            target_labels[tk] = SENSOR_NAME_MAP.get(eid, eid)
            target_group[tk] = "Central"

        for c in cams_cols_avail:
            tk = f"cams::{c}"
            target_labels[tk] = f"{c} (CAMS)"
            target_group[tk] = "CAMS"

        for c in smarts_input_cols_avail:
            tk = f"si::{c}"
            target_labels[tk] = f"{c} (SMARTS input)"
            target_group[tk] = "SMARTS input"

        for c in combined_gas_cols_avail:
            tk = f"gas::{c}"
            target_labels[tk] = f"{c} (gas)"
            target_group[tk] = "Gas"

        for c in db_input_cols:
            tk = f"db::{c}"
            target_labels[tk] = c
            target_group[tk] = "Main DB"

        target_keys = list(target_labels.keys())
        input_options = [{"key": k, "label": f"[{target_group[k]}] {target_labels[k]}"} for k in target_keys]
        input_options.sort(key=lambda x: x["label"].lower())
        input_options.extend({"key": k, "label": v} for k, v in INPUT_SIGNALS_EXTRA_LABELS.items())
        print(f"Korrelációs célok összesen: {len(target_keys)} | Input Signals extra: {len(INPUT_SIGNALS_EXTRA_LABELS)}")

        threshold_labels: Dict[str, str] = {}
        for c in EFFECTIVE_SPECTRL2_COLS:
            threshold_labels[f"thr::spectrl2::{c}"] = f"[spectrl2] {c}"
        for c in EFFECTIVE_RATIOS_COLS:
            threshold_labels[f"thr::ratios::{c}"] = f"[ratios] {c}"
        for c in EFFECTIVE_UPPER_COLS:
            threshold_labels[f"thr::upper::{c}"] = f"[upper_aod_multilevel] {c}"
        threshold_labels.update({k: f"[effective aod_params] {v}" for k, v in EFFECTIVE_AOD_PARAM_LABELS.items()})
        threshold_corr_options = [{"key": k, "label": v} for k, v in threshold_labels.items()]

        payload = {
            "meta": {
                "table": table_fq,
                "ts_col": ts_col,
                "grid_freq": GRID_FREQ,
                "bin_freq": BIN_FREQ,
                "daytime_ghi_min": DAYTIME_GHI_MIN,
                "spectral_table": SPECTRAL_TABLE,
                "integrated_table": INTEGRATED_TABLE,
                "spectral_suffix": SPECTRAL_SUFFIX,
                "spectral_ts_col": spectral_ts_col,
                "wlmin": WLMIN,
                "wlmax": WLMAX,
                "denorm_method": "ASTM_G173-03_kA (via pipeline integrated table)",
                "gti1_tilt": GTI1_TILT,
                "gti2_tilt": GTI2_TILT,
                "gti_azimuth": GTI_AZIMUTH,
                "threshold_default_wm2": THRESHOLD_DEFAULT_WM2,
                "threshold_step_wm2": THRESHOLD_STEP_WM2,
                "threshold_max_wm2": THRESHOLD_MAX_WM2,
            },
            "periods": [],
            "input_options": input_options,
            "threshold_corr_options": threshold_corr_options,
        }

        err_all_parts = []
        abs_err_all_parts = []
        target_parts = {k: [] for k in target_keys}

        all_ts, all_ghi_m, all_ghi_s = [], [], []
        all_12_m, all_12_s = [], []
        all_15_m, all_15_s = [], []

        for pi, (start_ts, end_ts) in enumerate(periods, start=1):
            start_ts = pd.to_datetime(start_ts, utc=True)
            end_ts = pd.to_datetime(end_ts, utc=True)
            key = f"{pi:02d}. {start_ts.strftime('%Y-%m-%d %H:%M')} → {end_ts.strftime('%H:%M')}"
            print(f"\n[{pi}/{len(periods)}] {key}")

            grid = _make_grid(start_ts, end_ts, GRID_FREQ)
            if len(grid) < 3:
                print("  [SKIP] rövid")
                continue

            # Central szenzorok
            df_c = fetch_central_entities(central_conn, start_ts, end_ts, CENTRAL_ENTITY_IDS)
            if df_c.empty:
                print("  [SKIP] nincs central adat")
                continue
            c_idx = df_c.set_index("timestamp").sort_index()

            # Main table -> csak DB inputokhoz
            main_cols = db_input_cols[:]
            df_m = fetch_main_table(main_conn, table_fq, start_ts, end_ts, cols=main_cols, ts_col=ts_col)
            m_idx = df_m.set_index(ts_col).sort_index() if not df_m.empty else pd.DataFrame(index=[])

            # INTEGRATED tábla → FIX GHI / GTI előállítás (közvetlenül a pipeline outputjából).
            # A pipeline már elvégezte: SR konvolúció, kA szorzás, IAM korrekció.
            # Az itteni fetch_integrated_as_fixed() olyan DataFrame-et ad vissza, amit
            # a régi build_fixed_spectral_table() is adna (kompatibilis oszlopnevek).
            df_fixed = fetch_integrated_as_fixed(main_conn, start_ts, end_ts, suffix=SPECTRAL_SUFFIX)
            if df_fixed.empty:
                print(f"  [SKIP] nincs integrált adat (suffix='{SPECTRAL_SUFFIX}')")
                continue
            f_idx = df_fixed.set_index("timestamp").sort_index()

            # Mért sorozatok -> grid
            g_ghi_meas = _interp_time_inside(c_idx.get(IMT14_GHI_ENTITY), grid)
            g_12_meas = _interp_time_inside(c_idx.get(IMT16_GTI_ENTITY), grid)
            g_15_meas = _interp_time_inside(c_idx.get(IMT15_GTI_ENTITY), grid)

            # Raw->SR×kA(ASTM G173-03)->IAM SMARTS sorozatok -> grid
            g_ghi_sm = _interp_time_inside(f_idx.get("ghi_fixed"), grid)
            g_12_sm = _interp_time_inside(f_idx.get("gti1225_fixed"), grid)
            g_15_sm = _interp_time_inside(f_idx.get("gti1545_fixed"), grid)

            # Daylight filter (változatlan)
            mask = (g_ghi_meas > DAYLIGHT_MIN_GHI) & np.isfinite(g_ghi_meas.to_numpy())
            if int(mask.sum()) < 3:
                print("  [SKIP] nincs daylight")
                continue

            df = pd.DataFrame({
                "timestamp": grid,
                "ghi_meas": g_ghi_meas.values, "ghi_smarts": g_ghi_sm.values,
                "gti1225_meas": g_12_meas.values, "gti1225_smarts": g_12_sm.values,
                "gti1545_meas": g_15_meas.values, "gti1545_smarts": g_15_sm.values,
            })
            df = df.loc[mask.values].reset_index(drop=True)
            if df.empty:
                continue

            # ─────────────────────────────────────────────────────────────────
            # METRIKÁK (RMSE/MBE) A SMARTS_MAX ÉS DOWNSAMPLE ELŐTT SZÁMÍTVA
            # — ezzel a dashboard és a pipeline CSV azonos értékeket kapnak.
            # A pipeline CSV logika: 10s rács + (mért > DAYLIGHT_MIN_GHI) + belső
            # _metrics_bundle-ben még egy szűrés (IQR + gate > 70 + max cap).
            # A dashboardban a SMARTS_MAX és _downsample_uniform a PLOTOKHOZ kell,
            # nem szabad metrikára használni.
            # ─────────────────────────────────────────────────────────────────
            a_ghi_metric = df["ghi_meas"].values.astype(float)
            b_ghi_metric = df["ghi_smarts"].values.astype(float)
            a12_metric, b12_metric = df["gti1225_meas"].values.astype(float), df["gti1225_smarts"].values.astype(float)
            a15_metric, b15_metric = df["gti1545_meas"].values.astype(float), df["gti1545_smarts"].values.astype(float)

            m_ghi = _metric_bundle(a_ghi_metric, b_ghi_metric, ghi_gate=a_ghi_metric, min_ghi=DAYTIME_GHI_MIN)
            m_1225 = _metric_bundle(a12_metric, b12_metric, ghi_gate=a_ghi_metric, is_gti=True, min_ghi=DAYTIME_GHI_MIN)
            m_1545 = _metric_bundle(a15_metric, b15_metric, ghi_gate=a_ghi_metric, is_gti=True, min_ghi=DAYTIME_GHI_MIN)
            corr_ghi = _corr_bundle(a_ghi_metric, b_ghi_metric)
            corr_12 = _corr_bundle(a12_metric, b12_metric)
            corr_15 = _corr_bundle(a15_metric, b15_metric)

            # SMARTS_MAX szűrés a PLOT-hoz (változatlan)
            om = pd.Series(True, index=df.index)
            for sc in ["ghi_smarts", "gti1225_smarts", "gti1545_smarts"]:
                om &= (df[sc] <= SMARTS_MAX) | (~np.isfinite(df[sc].values))
            df = df.loc[om].reset_index(drop=True)
            if df.empty:
                continue

            df = _downsample_uniform(df, MAX_POINTS_PER_SERIES)

            # A továbbiakban df a plotokhoz, a metrikák FÖNT számolódtak
            a_ghi = df["ghi_meas"].values.astype(float)
            b_ghi = df["ghi_smarts"].values.astype(float)
            a12, b12 = df["gti1225_meas"].values.astype(float), df["gti1225_smarts"].values.astype(float)
            a15, b15 = df["gti1545_meas"].values.astype(float), df["gti1545_smarts"].values.astype(float)
            # corr_ghi/corr_12/corr_15 FÖNT már kiszámolva (downsample előtt) — ne írd felül!

            metrics = {}
            for pfx, mb, cb in [("ghi", m_ghi, corr_ghi), ("gti1225", m_1225, corr_12), ("gti1545", m_1545, corr_15)]:
                metrics[f"{pfx}_rmse"] = mb["rmse"]
                metrics[f"{pfx}_nrmse"] = mb["nrmse"]
                metrics[f"{pfx}_mbe"] = mb["mbe"]
                metrics[f"{pfx}_nmbe"] = mb["nmbe"]
                metrics[f"{pfx}_pearson"] = cb["pearson"]
                metrics[f"{pfx}_r2"] = cb["r2"]
                metrics[f"{pfx}_n"] = mb["n"]

            bins_ghi = _compute_binned_metrics(pd.to_datetime(df["timestamp"], utc=True), a_ghi, b_ghi, daylight_gate=a_ghi, is_gti=False)
            bins_1225 = _compute_binned_metrics(pd.to_datetime(df["timestamp"], utc=True), a12, b12, daylight_gate=a_ghi, is_gti=True)
            bins_1545 = _compute_binned_metrics(pd.to_datetime(df["timestamp"], utc=True), a15, b15, daylight_gate=a_ghi, is_gti=True)

            err_full = (b_ghi - a_ghi).astype(np.float32)
            abs_err_full = np.abs(err_full)
            err_all_parts.append(err_full)
            abs_err_all_parts.append(abs_err_full)

            daylight_grid = pd.to_datetime(df["timestamp"].values, utc=True)
            n_pts = len(daylight_grid)
            input_series: Dict[str, List[Optional[float]]] = {}

            # Central inputs
            for eid in CENTRAL_ENTITY_IDS:
                if eid in (IMT14_GHI_ENTITY, IMT16_GTI_ENTITY, IMT15_GTI_ENTITY):
                    continue
                tk = f"central::{eid}"
                s = c_idx.get(eid)
                if s is not None:
                    interped = _interp_time_inside(s, grid, edge_fill=True)
                    arr = interped.reindex(daylight_grid).values.astype(np.float32) if not interped.empty else np.full(n_pts, np.nan, dtype=np.float32)
                else:
                    arr = np.full(n_pts, np.nan, dtype=np.float32)
                target_parts[tk].append(arr[:n_pts])
                input_series[tk] = [None if not np.isfinite(float(v)) else float(v) for v in arr[:n_pts]]

            # CAMS inputs
            if cams_cols_avail:
                try:
                    df_cams = fetch_generic_table(main_conn, CAMS_VIEW, start_ts, end_ts, cams_cols_avail)
                    cams_10s = _attach_to_grid(df_cams, grid, cams_cols_avail)
                except Exception as e:
                    print(f"  [WARN] CAMS fetch: {e}")
                    cams_10s = pd.DataFrame(index=grid, columns=cams_cols_avail, dtype=float)
                for c in cams_cols_avail:
                    tk = f"cams::{c}"
                    arr = cams_10s[c].reindex(daylight_grid).values.astype(np.float32) if c in cams_10s.columns else np.full(n_pts, np.nan, dtype=np.float32)
                    target_parts[tk].append(arr[:n_pts])
                    input_series[tk] = [None if not np.isfinite(float(v)) else float(v) for v in arr[:n_pts]]

            # SMARTS input tábla inputs
            if smarts_input_cols_avail:
                try:
                    df_si = fetch_generic_table(main_conn, SMARTS_INPUT_TABLE, start_ts, end_ts, smarts_input_cols_avail, ts_col=si_ts_col)
                    si_10s = _attach_to_grid(df_si, grid, smarts_input_cols_avail)
                except Exception as e:
                    print(f"  [WARN] SMARTS input fetch: {e}")
                    si_10s = pd.DataFrame(index=grid, columns=smarts_input_cols_avail, dtype=float)
                for c in smarts_input_cols_avail:
                    tk = f"si::{c}"
                    arr = si_10s[c].reindex(daylight_grid).values.astype(np.float32) if c in si_10s.columns else np.full(n_pts, np.nan, dtype=np.float32)
                    target_parts[tk].append(arr[:n_pts])
                    input_series[tk] = [None if not np.isfinite(float(v)) else float(v) for v in arr[:n_pts]]

            # combined_gas inputs
            if combined_gas_cols_avail:
                try:
                    df_gas = fetch_generic_table(main_conn, COMBINED_GAS_TABLE, start_ts, end_ts, combined_gas_cols_avail, ts_col=cg_ts_col)
                    gas_10s = _attach_to_grid(df_gas, grid, combined_gas_cols_avail)
                except Exception as e:
                    print(f"  [WARN] combined_gas fetch: {e}")
                    gas_10s = pd.DataFrame(index=grid, columns=combined_gas_cols_avail, dtype=float)
                for c in combined_gas_cols_avail:
                    tk = f"gas::{c}"
                    arr = gas_10s[c].reindex(daylight_grid).values.astype(np.float32) if c in gas_10s.columns else np.full(n_pts, np.nan, dtype=np.float32)
                    target_parts[tk].append(arr[:n_pts])
                    input_series[tk] = [None if not np.isfinite(float(v)) else float(v) for v in arr[:n_pts]]

            # Main DB input oszlopok
            for c in db_input_cols:
                tk = f"db::{c}"
                s = m_idx.get(c) if isinstance(m_idx, pd.DataFrame) else None
                if s is not None:
                    interped = _interp_time_inside(s, grid, edge_fill=True)
                    arr = interped.reindex(daylight_grid).values.astype(np.float32) if not interped.empty else np.full(n_pts, np.nan, dtype=np.float32)
                else:
                    arr = np.full(n_pts, np.nan, dtype=np.float32)
                target_parts[tk].append(arr[:n_pts])
                input_series[tk] = [None if not np.isfinite(float(v)) else float(v) for v in arr[:n_pts]]

            input_series_extra = _build_input_signals_extra_series(grid, daylight_grid, c_idx, main_conn, start_ts, end_ts)
            for k, arr in input_series_extra.items():
                input_series[k] = [None if not np.isfinite(float(v)) else float(v) for v in arr[:n_pts]]

            threshold_input_series = _build_threshold_input_series(grid, daylight_grid, c_idx, main_conn, start_ts, end_ts)
            threshold_input_series_json = {
                k: [None if not np.isfinite(float(v)) else float(v) for v in arr[:n_pts]]
                for k, arr in threshold_input_series.items()
            }

            payload["periods"].append({
                "key": key,
                "n_points": len(df),
                "metrics": metrics,
                "ts": df["timestamp"].dt.strftime("%Y-%m-%dT%H:%M:%S.%fZ").tolist(),
                "ghi": {"measured": df["ghi_meas"].tolist(), "smarts": df["ghi_smarts"].tolist(), "error": (df["ghi_smarts"] - df["ghi_meas"]).tolist()},
                "gti1225": {"measured": df["gti1225_meas"].tolist(), "smarts": df["gti1225_smarts"].tolist()},
                "gti1545": {"measured": df["gti1545_meas"].tolist(), "smarts": df["gti1545_smarts"].tolist()},
                "binned": {"ghi": bins_ghi, "gti1225": bins_1225, "gti1545": bins_1545},
                "input_series": input_series,
                "threshold_input_series": threshold_input_series_json,
            })

            all_ts.extend(df["timestamp"].dt.strftime("%Y-%m-%dT%H:%M:%S.%fZ").tolist())
            all_ghi_m.extend(df["ghi_meas"].tolist())
            all_ghi_s.extend(df["ghi_smarts"].tolist())
            all_12_m.extend(df["gti1225_meas"].tolist())
            all_12_s.extend(df["gti1225_smarts"].tolist())
            all_15_m.extend(df["gti1545_meas"].tolist())
            all_15_s.extend(df["gti1545_smarts"].tolist())

            print(f"  ✓ {len(df)} pont  GHI RMSE={_fmt(m_ghi['rmse'],2)}  Pearson={_fmt(corr_ghi['pearson'],4)}")

        g_a_ghi = np.array(all_ghi_m, float)
        g_b_ghi = np.array(all_ghi_s, float)
        g_a_12 = np.array(all_12_m, float)
        g_b_12 = np.array(all_12_s, float)
        g_a_15 = np.array(all_15_m, float)
        g_b_15 = np.array(all_15_s, float)

        gm_ghi = _metric_bundle(g_a_ghi, g_b_ghi, ghi_gate=g_a_ghi, min_ghi=DAYTIME_GHI_MIN)
        gm_12 = _metric_bundle(g_a_12, g_b_12, ghi_gate=g_a_ghi, is_gti=True, min_ghi=DAYTIME_GHI_MIN)
        gm_15 = _metric_bundle(g_a_15, g_b_15, ghi_gate=g_a_ghi, is_gti=True, min_ghi=DAYTIME_GHI_MIN)
        gc_ghi = _corr_bundle(g_a_ghi, g_b_ghi)
        gc_12 = _corr_bundle(g_a_12, g_b_12)
        gc_15 = _corr_bundle(g_a_15, g_b_15)

        print("\n" + "=" * 100)
        print("GLOBAL METRICS")
        print(f"  GHI  RMSE={_fmt(gm_ghi['rmse'],2)}  MBE={_fmt(gm_ghi['mbe'],2)}  Pearson={_fmt(gc_ghi['pearson'],4)}  R²={_fmt(gc_ghi['r2'],4)}")
        print(f"  GT12 RMSE={_fmt(gm_12['rmse'],2)}  MBE={_fmt(gm_12['mbe'],2)}  Pearson={_fmt(gc_12['pearson'],4)}")
        print(f"  GT15 RMSE={_fmt(gm_15['rmse'],2)}  MBE={_fmt(gm_15['mbe'],2)}  Pearson={_fmt(gc_15['pearson'],4)}")

        payload["global_metrics"] = {}
        for pfx, mb, cb in [("ghi", gm_ghi, gc_ghi), ("gti1225", gm_12, gc_12), ("gti1545", gm_15, gc_15)]:
            payload["global_metrics"][f"{pfx}_rmse"] = mb["rmse"]
            payload["global_metrics"][f"{pfx}_nrmse"] = mb["nrmse"]
            payload["global_metrics"][f"{pfx}_mbe"] = mb["mbe"]
            payload["global_metrics"][f"{pfx}_nmbe"] = mb["nmbe"]
            payload["global_metrics"][f"{pfx}_pearson"] = cb["pearson"]
            payload["global_metrics"][f"{pfx}_r2"] = cb["r2"]
        payload["global_metrics"]["n_points"] = len(g_a_ghi)

        g_ts = pd.to_datetime(all_ts, utc=True, errors="coerce")
        payload["global_binned"] = {
            "ghi": _compute_binned_metrics(g_ts, g_a_ghi, g_b_ghi, stack_by_clock=True, daylight_gate=g_a_ghi, is_gti=False),
            "gti1225": _compute_binned_metrics(g_ts, g_a_12, g_b_12, stack_by_clock=True, daylight_gate=g_a_ghi, is_gti=True),
            "gti1545": _compute_binned_metrics(g_ts, g_a_15, g_b_15, stack_by_clock=True, daylight_gate=g_a_ghi, is_gti=True),
        }

        err_all = np.concatenate(err_all_parts) if err_all_parts else np.array([], dtype=np.float32)
        abs_err_all = np.concatenate(abs_err_all_parts) if abs_err_all_parts else np.array([], dtype=np.float32)
        print(f"\nKorreláció számítás: {len(err_all)} pont, {len(target_keys)} target...")
        corr_pack = _compute_global_corr(err_all, abs_err_all, target_parts, target_keys, target_labels)
        payload["global_corr"] = corr_pack

        print("\n  Top 10 |Pearson| (előjeles hiba vs. input):")
        for i, r in enumerate(corr_pack["top_signed"][:10], 1):
            print(f"    {i:2d}. {r['label'][:50]:50s}  Pearson={_fmt(r['pearson'],4)}  N={r['n_used']}")

        if not payload["periods"]:
            print("[ERROR] Nincs periódus.")
            return 2

        build_html(payload, out_html)
        print(f"\n✅ KÉSZ: {out_html}")
        return 0

    except KeyboardInterrupt:
        print("\n[STOP]")
        return 130
    finally:
        for c in [main_conn, central_conn]:
            try:
                c.close()
            except Exception:
                pass


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))