#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════
# run_full_chain.sh
# ═══════════════════════════════════════════════════════════════════════════
# Hasznalat:
#   ./run_full_chain.sh                 # teljes hibrid (Mie + empirikus)
#   ./run_full_chain.sh --no-pymiescatt # tisztan empirikus (Mie monkey-patch)
#
# Lepesek:
#   [1/5] pipeline - auto suffix "hybrid_<stamp>" vagy "nopymie_<stamp>"
#   [2/5] optimizer - kt_curves/run_<stamp>_<suffix>/ (PNG + CSV)
#   [3/5] dashboard - HTML
#   [4/5] XLSX riport a pipeline CSV-bol
#   [5/5] Nextcloud feltoltes: HTML + XLSX + CSV + kt PNG
# ═══════════════════════════════════════════════════════════════════════════

set -u

# ── CLI flag ─────────────────────────────────────────────────────
NO_PYMIESCATT=0
for arg in "$@"; do
  case "$arg" in
    --no-pymiescatt) NO_PYMIESCATT=1 ;;
    *) ;;
  esac
done

# ── KONFIG ────────────────────────────────────────────────────────
WORK_DIR="/opt/app-root/src/smarts_clearsky_model"
PIPELINE_PY="${WORK_DIR}/smarts_spectral_pipeline.py"
OPTIMIZER_PY="${WORK_DIR}/ghi_calibration_optimizer.py"
DASHBOARD_PY="${WORK_DIR}/dashboard_minimal.py"

NC_USER="svc-emgmt-upload"
NC_PASS='69*tQjbyns4ND9wG6FuT'
NC_DAV_ID="12df6306-3d92-11f1-a627-005056b8d177"
NC_REMOTE_DIR="SMARTS"

mkdir -p "${WORK_DIR}/logs"
STAMP=$(date +%Y%m%d_%H%M%S)
if [ $NO_PYMIESCATT -eq 1 ]; then
  SUFFIX_LC="nopymie_${STAMP}"
  TAG="NO_PYMIESCATT (empirikus only)"
else
  SUFFIX_LC="hybrid_${STAMP}"
  TAG="HYBRID (Mie + empirikus)"
fi
LOG="${WORK_DIR}/logs/full_run_${SUFFIX_LC}.log"
DASH_HTML="${WORK_DIR}/dashboard_${SUFFIX_LC}.html"
OUT_XLSX="${WORK_DIR}/smarts_rmse_mbe_${SUFFIX_LC}.xlsx"

# ── FAJL ELLENORZES ──────────────────────────────────────────────
for f in "${PIPELINE_PY}" "${OPTIMIZER_PY}" "${DASHBOARD_PY}"; do
  if [ ! -f "${f}" ]; then
    echo "[FATAL] Nem talalhato fajl: ${f}"
    exit 2
  fi
done

# ── ELOTESZT: Nextcloud auth ────────────────────────────────────
echo "<html><body>test</body></html>" > /tmp/test_upload_${STAMP}.html
TEST_URL="https://nextcloud.ulx.hu/remote.php/dav/files/${NC_DAV_ID}/${NC_REMOTE_DIR}/__auth_test_${STAMP}.html"
TEST_CODE=$(curl -sS -w "%{http_code}" -o /tmp/nc_test.out \
  -T /tmp/test_upload_${STAMP}.html \
  -u "${NC_USER}:${NC_PASS}" \
  "${TEST_URL}")
if [ "$TEST_CODE" = "200" ] || [ "$TEST_CODE" = "201" ] || [ "$TEST_CODE" = "204" ]; then
  echo "[OK] Nextcloud auth mukodik (HTTP $TEST_CODE)"
  curl -s -X DELETE -u "${NC_USER}:${NC_PASS}" "${TEST_URL}" > /dev/null
  rm -f /tmp/test_upload_${STAMP}.html /tmp/nc_test.out
else
  echo "[HIBA] Nextcloud auth nem jo - HTTP $TEST_CODE"
  cat /tmp/nc_test.out 2>/dev/null | head -10
  echo "ALLJ - nem inditom a fo futast"
  exit 1
fi

# ── Python szintaxis ──────────────────────────────────────────────
source /opt/app-root/bin/activate
python -c "import ast; ast.parse(open('${PIPELINE_PY}').read()); print('pipeline.py    OK')" || exit 3
python -c "import ast; ast.parse(open('${DASHBOARD_PY}').read()); print('dashboard.py   OK')" || exit 3
python -c "import ast; ast.parse(open('${OPTIMIZER_PY}').read()); print('optimizer.py   OK')" || exit 3

echo "=================================================================="
echo "  Tag     : ${TAG}"
echo "  Suffix  : ${SUFFIX_LC}"
echo "  Log     : ${LOG}"
echo "=================================================================="

if [ $NO_PYMIESCATT -eq 1 ]; then
  PIPELINE_EXTRA="--no-pymiescatt"
else
  PIPELINE_EXTRA=""
fi

nohup env \
  NC_USER="${NC_USER}" \
  NC_PASS="${NC_PASS}" \
  NC_DAV_ID="${NC_DAV_ID}" \
  NC_REMOTE_DIR="${NC_REMOTE_DIR}" \
  SUFFIX_LC="${SUFFIX_LC}" \
  DASH_HTML="${DASH_HTML}" \
  OUT_XLSX="${OUT_XLSX}" \
  WORK_DIR="${WORK_DIR}" \
  PIPELINE_PY="${PIPELINE_PY}" \
  OPTIMIZER_PY="${OPTIMIZER_PY}" \
  DASHBOARD_PY="${DASHBOARD_PY}" \
  PIPELINE_EXTRA="${PIPELINE_EXTRA}" \
  TAG="${TAG}" \
  bash -c '
set +e
cd "${WORK_DIR}"
source /opt/app-root/bin/activate

echo ""
echo "══════════════ [1/5] PIPELINE START $(date -u +%FT%TZ) ══════════════"
echo "Extra CLI: ${PIPELINE_EXTRA}"
python "${PIPELINE_PY}" --mode clearsky --suffix "${SUFFIX_LC}" ${PIPELINE_EXTRA}
PIPELINE_RC=$?
echo "══════════════ [1/5] PIPELINE DONE rc=${PIPELINE_RC} ══════════════"
if [ $PIPELINE_RC -ne 0 ]; then
  echo "[FATAL] Pipeline hiba"
  exit $PIPELINE_RC
fi

echo ""
echo "══════════════ [2/5] OPTIMIZER START $(date -u +%FT%TZ) ══════════════"
SPECTRAL_SUFFIX="_${SUFFIX_LC}" python "${OPTIMIZER_PY}"
OPT_RC=$?
echo "══════════════ [2/5] OPTIMIZER DONE rc=${OPT_RC} ══════════════"

echo ""
echo "══════════════ [3/5] DASHBOARD START $(date -u +%FT%TZ) ══════════════"
SPECTRAL_SUFFIX="_${SUFFIX_LC}" OUT_HTML="${DASH_HTML}" python "${DASHBOARD_PY}"
DASH_RC=$?
echo "══════════════ [3/5] DASHBOARD DONE rc=${DASH_RC} ══════════════"

echo ""
echo "══════════════ [4/5] XLSX RIPORT $(date -u +%FT%TZ) ══════════════"
LATEST_PIPE_CSV=$(ls -t "${WORK_DIR}"/pipeline_rmse_mbe_clearsky_${SUFFIX_LC}_*.csv 2>/dev/null | head -1)
XLSX_RC=1
if [ -n "$LATEST_PIPE_CSV" ] && [ -f "$LATEST_PIPE_CSV" ]; then
  python3 - "$LATEST_PIPE_CSV" "${OUT_XLSX}" "${SUFFIX_LC}" "${TAG}" <<"PYEOF"
import sys, csv
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

csv_path, xlsx_path, suffix, tag = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]

with open(csv_path) as f:
    rows = list(csv.DictReader(f))

wb = Workbook()
ws = wb.active
ws.title = "RMSE_MBE"

ws.cell(1, 1, f"Suffix: {suffix}   Tag: {tag}").font = Font(bold=True, size=14)
ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=10)

ghi_fill = PatternFill("solid", start_color="BBDEFB")
g12_fill = PatternFill("solid", start_color="C8E6C9")
g15_fill = PatternFill("solid", start_color="FFF9C4")
total_fill = PatternFill("solid", start_color="F0F4C3")
subhdr_fill = PatternFill("solid", start_color="263238")

headers = [
    "idx", "t0_utc", "t1_utc", "n_grid",
    "ghi_n", "ghi_rmse", "ghi_mbe", "ghi_nrmse_pct", "ghi_nmbe_pct", "ghi_mean_meas", "ghi_mean_pred",
    "gti1225_n", "gti1225_rmse", "gti1225_mbe", "gti1225_nrmse_pct", "gti1225_nmbe_pct", "gti1225_mean_meas", "gti1225_mean_pred",
    "gti1545_n", "gti1545_rmse", "gti1545_mbe", "gti1545_nrmse_pct", "gti1545_nmbe_pct", "gti1545_mean_meas", "gti1545_mean_pred",
]

row_i = 3
for j, h in enumerate(headers, start=1):
    c = ws.cell(row_i, j, h)
    c.font = Font(bold=True, color="FFFFFF")
    c.fill = subhdr_fill
    c.alignment = Alignment(horizontal="center", wrap_text=True)

thin = Side(border_style="thin", color="888888")
border_all = Border(left=thin, right=thin, top=thin, bottom=thin)

csv_keys = [
    "idx", "t0_utc", "t1_utc", "n_grid",
    "ghi_n", "ghi_rmse", "ghi_mbe", "ghi_nrmse_pct", "ghi_nmbe_pct", "ghi_mean_measured", "ghi_mean_predicted",
    "gti1225_n", "gti1225_rmse", "gti1225_mbe", "gti1225_nrmse_pct", "gti1225_nmbe_pct", "gti1225_mean_measured", "gti1225_mean_predicted",
    "gti1545_n", "gti1545_rmse", "gti1545_mbe", "gti1545_nrmse_pct", "gti1545_nmbe_pct", "gti1545_mean_measured", "gti1545_mean_predicted",
]

def _to_num(x):
    if x in (None, "", "nan", "NaN"):
        return None
    try:
        return float(x)
    except Exception:
        return str(x)

row_i = 4
for r in rows:
    idx_val = r.get("idx", "")
    is_total = (not idx_val.isdigit())
    for j, key in enumerate(csv_keys, start=1):
        v = r.get(key, "")
        if key in ("idx", "t0_utc", "t1_utc") and v:
            cell_val = v
        else:
            cell_val = _to_num(v)
        c = ws.cell(row_i, j, cell_val)
        c.border = border_all
        c.font = Font(bold=is_total, size=10)
        if is_total:
            c.fill = total_fill
        else:
            if 5 <= j <= 11:
                c.fill = ghi_fill
            elif 12 <= j <= 18:
                c.fill = g12_fill
            elif 19 <= j <= 25:
                c.fill = g15_fill
        if isinstance(cell_val, float):
            c.number_format = "0.000"
        c.alignment = Alignment(horizontal="right" if isinstance(cell_val, float) else "left")
    row_i += 1

widths = [6, 22, 22, 9] + [12]*21
for i, w in enumerate(widths, start=1):
    ws.column_dimensions[get_column_letter(i)].width = w

ws.freeze_panes = "A4"
wb.save(xlsx_path)
print(f"[OK] XLSX mentve: {xlsx_path}")
PYEOF
  XLSX_RC=$?
else
  echo "[SKIP] nincs pipeline CSV"
fi
echo "══════════════ [4/5] XLSX DONE rc=${XLSX_RC} ══════════════"

echo ""
echo "══════════════ [5/5] UPLOAD START $(date -u +%FT%TZ) ══════════════"
BASE_URL="https://nextcloud.ulx.hu/remote.php/dav/files/${NC_DAV_ID}/${NC_REMOTE_DIR}"

_upload() {
  local LOCAL="$1"
  local REMOTE_NAME="$2"
  if [ -z "$LOCAL" ] || [ ! -f "$LOCAL" ]; then
    echo "  [SKIP] nincs fajl: $LOCAL"
    return 1
  fi
  local URL="${BASE_URL}/${REMOTE_NAME}"
  echo "  Feltoltes: $(basename "$LOCAL")  ->  ${REMOTE_NAME}"
  local HTTP_CODE=$(curl -sS -w "%{http_code}" -o /tmp/nc_up_out \
    -T "$LOCAL" -u "${NC_USER}:${NC_PASS}" "${URL}")
  if [ "$HTTP_CODE" = "200" ] || [ "$HTTP_CODE" = "201" ] || [ "$HTTP_CODE" = "204" ]; then
    echo "  [OK]  HTTP $HTTP_CODE"
    return 0
  else
    echo "  [HIBA] HTTP $HTTP_CODE"
    cat /tmp/nc_up_out 2>/dev/null | head -20
    return 1
  fi
}

UPLOAD_XLSX=1
UPLOAD_HTML=1
UPLOAD_PIPE_CSV=1
UPLOAD_KT_CSV=1
UPLOAD_KT_PNG=1

if [ -f "${OUT_XLSX}" ]; then
  _upload "${OUT_XLSX}" "$(basename "${OUT_XLSX}")"
  UPLOAD_XLSX=$?
fi

if [ -f "${DASH_HTML}" ]; then
  _upload "${DASH_HTML}" "$(basename "${DASH_HTML}")"
  UPLOAD_HTML=$?
fi

LATEST_PIPE_CSV=$(ls -t "${WORK_DIR}"/pipeline_rmse_mbe_clearsky_${SUFFIX_LC}_*.csv 2>/dev/null | head -1)
if [ -n "$LATEST_PIPE_CSV" ]; then
  _upload "${LATEST_PIPE_CSV}" "$(basename "${LATEST_PIPE_CSV}")"
  UPLOAD_PIPE_CSV=$?
fi

LATEST_KT_DIR=$(ls -td "${WORK_DIR}"/kt_curves/run_*_${SUFFIX_LC} 2>/dev/null | head -1)
if [ -n "$LATEST_KT_DIR" ] && [ -d "$LATEST_KT_DIR" ]; then
  KT_CSV=$(ls -t "${LATEST_KT_DIR}"/kt_per_timestamp_*.csv 2>/dev/null | head -1)
  if [ -n "$KT_CSV" ]; then
    _upload "${KT_CSV}" "kt_per_timestamp_${SUFFIX_LC}.csv"
    UPLOAD_KT_CSV=$?
  fi
  KT_PNG=$(ls -t "${LATEST_KT_DIR}"/kt_vs_azimuth_*.png 2>/dev/null | head -1)
  if [ -n "$KT_PNG" ]; then
    _upload "${KT_PNG}" "kt_vs_azimuth_${SUFFIX_LC}.png"
    UPLOAD_KT_PNG=$?
  fi
fi

echo "══════════════ [5/5] UPLOAD DONE $(date -u +%FT%TZ) ══════════════"
echo ""
echo "════════════════════════════════════════════════════════════════"
echo "  OSSZEFOGLALO"
echo "  Tag             : ${TAG}"
echo "  Suffix          : ${SUFFIX_LC}"
echo "  Pipeline rc     : ${PIPELINE_RC}"
echo "  Optimizer rc    : ${OPT_RC}"
echo "  Dashboard rc    : ${DASH_RC}"
echo "  XLSX rc         : ${XLSX_RC}"
echo "  Upload XLSX     : ${UPLOAD_XLSX}"
echo "  Upload HTML     : ${UPLOAD_HTML}"
echo "  Upload pipe CSV : ${UPLOAD_PIPE_CSV}"
echo "  Upload kt CSV   : ${UPLOAD_KT_CSV}"
echo "  Upload kt PNG   : ${UPLOAD_KT_PNG}"
echo "  HTML lokal      : ${DASH_HTML}"
echo "  XLSX lokal      : ${OUT_XLSX}"
echo "  Nextcloud dir   : ${BASE_URL}/"
echo "════════════════════════════════════════════════════════════════"
' > "${LOG}" 2>&1 &

PID=$!
echo ""
echo "PID : ${PID}"
echo "LOG : ${LOG}"
echo ""
echo "Kovetes (Ctrl+C-vel kilep a tail-f-bol, a nohup fut tovabb):"
sleep 2
tail -f "${LOG}"
