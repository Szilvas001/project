from __future__ import annotations
import numpy as np
import pandas as pd
from const import *
import helpers

from smarts_cards import build_smarts_input_new_aod, build_smarts_input_6b_with_nox_no2
from smarts_runner import run_smarts_once
from spectrum_utils import _ghi_integral_raw, _ghi_sr_weighted


def run_smarts_new_aod(
    row,
    df,
    sr_fn,
    iam_fn,
    kA,
    aod_params,
    panel_tilt_deg: float = PANEL_TILT,
    panel_azimuth_deg: float = PANEL_AZIMUTH,
    iout_codes: list[int] | None = None,
):
    """
    Kimenetek (SR + kA + IAM alkalmazva):
      - 0° futás (IOUT_0TILT_GHI_DNI_DHI): ghi_final, dni_final, dhi_final
      - tilt futás (IOUT_TILT_BEAM_DIFFUSE): beam_final, diffuse_final

    ÚJ:
      - GHI/DNI/DHI: denorm_fac = 1/R^2
      - beam/diffuse: denorm_fac = (1/R^2) * (kA_component/base_kA), ahol kA_component ASTM K-faktorokból jön
    """
    import numpy as np
    import pandas as pd

    from spectrum_utils import _integral_raw, _integral_sr_weighted
    from smarts_runner import run_smarts_once
    from smarts_cards import build_smarts_input_new_aod

    if iout_codes is None:
        iout_codes = IOUT_0TILT_GHI_DNI_DHI

    input_txt = build_smarts_input_new_aod(
        row=row,
        df_full=df,
        aod_params=aod_params,
        panel_tilt_deg=float(panel_tilt_deg),
        panel_azimuth_deg=float(panel_azimuth_deg),
        iout_codes=list(iout_codes),
    )

    spec_df, has_tilt_cfg = run_smarts_once(input_txt, return_is_tilt=True)

    # -----------------------------
    # >>> FIX 1: DHI fallback
    # -----------------------------
    if spec_df is not None and not spec_df.empty:
        cols = set(spec_df.columns)
        if (3 in iout_codes) and ("dhi_w_m2_per_nm" not in cols):
            if ("ghi_w_m2_per_nm" in cols) and ("dir_horiz_w_m2_per_nm" in cols):
                spec_df = spec_df.copy()
                ghi = pd.to_numeric(spec_df["ghi_w_m2_per_nm"], errors="coerce")
                dirh = pd.to_numeric(spec_df["dir_horiz_w_m2_per_nm"], errors="coerce")
                spec_df["dhi_w_m2_per_nm"] = (ghi - dirh).clip(lower=0.0)

        # -----------------------------
        # >>> FIX 2: diffuse tilt fallback
        # -----------------------------
        cols = set(spec_df.columns)
        if (7 in iout_codes) and ("diff_tilt_w_m2_per_nm" not in cols) and ("dir_tilt_w_m2_per_nm" in cols):
            candidates = [c for c in spec_df.columns if c not in ("wavelength_nm", "dir_tilt_w_m2_per_nm")]
            if len(candidates) == 1:
                spec_df = spec_df.rename(columns={candidates[0]: "diff_tilt_w_m2_per_nm"})
            else:
                def _norm(s: str) -> str:
                    s = s.lower()
                    return "".join(ch for ch in s if ch.isalnum())
                pick = None
                for c in candidates:
                    cc = _norm(c)
                    if ("dif" in cc) or ("diff" in cc):
                        pick = c
                        break
                if pick is not None:
                    spec_df = spec_df.rename(columns={pick: "diff_tilt_w_m2_per_nm"})

    ts_utc = pd.to_datetime(row.get("timestamp"), utc=True, errors="coerce")
    lat = float(row.get("latitude", DEFAULT_LAT)) if row.get("latitude") is not None else DEFAULT_LAT
    lon = float(row.get("longitude", DEFAULT_LON)) if row.get("longitude") is not None else DEFAULT_LON
    alt_km = float(row.get("alt_km", DEFAULT_ALT_KM)) if row.get("alt_km") is not None else DEFAULT_ALT_KM

    aoi = helpers._compute_aoi(ts_utc, lat, lon, alt_km, float(panel_tilt_deg), float(panel_azimuth_deg))
    iam = float(iam_fn(aoi)) if callable(iam_fn) else 1.0

    # Tilt jelenlét: config + tényleges spektrum oszlopok
    has_tilt_cols = (
        spec_df is not None
        and not spec_df.empty
        and (("dir_tilt_w_m2_per_nm" in spec_df.columns) or ("diff_tilt_w_m2_per_nm" in spec_df.columns) or ("gti_w_m2_per_nm" in spec_df.columns))
    )
    has_tilt = bool(has_tilt_cfg) and bool(has_tilt_cols)

    # Denorm faktorok (helpers-ben: GHI->1/R^2; tilt->ASTM K-faktoros arány)
    denorm_ghi = helpers.calculate_denorm_fac(ts_utc, is_tilt=False, base_kA=float(kA), component="ghi")
    denorm_beam = helpers.calculate_denorm_fac(ts_utc, is_tilt=has_tilt, base_kA=float(kA), component="beam")
    denorm_diff = helpers.calculate_denorm_fac(ts_utc, is_tilt=has_tilt, base_kA=float(kA), component="diffuse")

    out = {"spec_df": spec_df}

    def _calc(prefix: str, col: str, denorm_fac: float):
        if spec_df is None or spec_df.empty or col not in spec_df.columns:
            out[f"{prefix}_raw"] = np.nan
            out[f"{prefix}_srka"] = np.nan
            out[f"{prefix}_final"] = np.nan
            return

        raw = _integral_raw(spec_df, col)
        srw = _integral_sr_weighted(spec_df, col, sr_fn)

        srka = float(srw) * float(kA)
        srka = srka * float(denorm_fac)
        final = float(srka) * float(iam)

        out[f"{prefix}_raw"] = float(raw) if np.isfinite(raw) else np.nan
        out[f"{prefix}_srka"] = float(srka) if np.isfinite(srka) else np.nan
        out[f"{prefix}_final"] = float(final) if np.isfinite(final) else np.nan

    # 0° komponensek (GHI/DNI/DHI): 1/R^2
    _calc("ghi", "ghi_w_m2_per_nm", denorm_ghi)
    _calc("dni", "dni_w_m2_per_nm", denorm_ghi)
    _calc("dhi", "dhi_w_m2_per_nm", denorm_ghi)

    # Tilt komponensek (beam/diffuse): ASTM K-faktoros korrekció
    _calc("beam", "dir_tilt_w_m2_per_nm", denorm_beam)
    _calc("diffuse", "diff_tilt_w_m2_per_nm", denorm_diff)

    return out




# ======================= ÚJ AOD SZÁMÍTÁS KONSTANSOK =======================
# Sűrűségek (g/cm³)
RHO_SOOT = 1.8      # Black Carbon
RHO_ORG = 1.2       # Organic Matter
RHO_INORG = 1.76    # Sulfate/Nitrate
RHO_DUST = 2.6      # Mineral Dust

# Komplex törésmutató indexek (550nm-nél)
# PyMieScatt konvenció: m = n + ik, ahol k > 0 az abszorpció
# FONTOS: Python complex(a, b) = a + bj, tehát POZITÍV imaginárius rész kell!
N_WATER = complex(1.33, 0.0)       # Nem abszorbeál
N_INORG = complex(1.53, 1e-7)      # Gyakorlatilag nem abszorbeál (szulfátok)
N_ORG = complex(1.53, 0.005)       # Gyengén abszorbeáló (organikus)
N_SOOT = complex(1.75, 0.44)       # Erősen abszorbeáló (korom) - POZITÍV!
N_DUST = complex(1.55, 0.005)      # Szóró, enyhe abszorpció

# Hullámhosszak a Mie számításhoz
MIE_WAVELENGTHS = [340, 500, 550, 1064]

# Validációs tartományok
VALID_RANGES = {
    'TAU550': (0.001, 3.0),
    'ALPHA1': (-0.5, 3.5),
    'ALPHA2': (-0.5, 3.5),
    'OMEGL': (0.5, 1.0),
    'GG': (0.3, 0.95),
}

# ======================= PM ZAJSZŰRÉS KONSTANSOK =======================
# O-1PST szenzor specifikus - ENYHE szűrés (variancia megtartása)

PM_VALID_RANGES = {
    'pm0_3': (0.1, 50000.0),    # count
    'pm1': (0.1, 300.0),        # µg/m³
    'pm2_5': (0.1, 500.0),      # µg/m³
    'pm10': (0.1, 1000.0),      # µg/m³
}

# Spike detection: hány szórás a kiugró (magasabb = kevesebb szűrés)
PM_SPIKE_THRESHOLD_SIGMA = 4.0

# Savitzky-Golay filter (variancia-megőrző simítás)
PM_SAVGOL_WINDOW = 7      # Ablak méret (páratlan!)
PM_SAVGOL_POLYORDER = 2   # Polinom fokszám

# Interpoláció max gap (percben)
PM_MAX_GAP_MIN = 15

# ======================= ÚJ TÁBLA OSZLOP =======================
NEW_RESULT_COLUMN = "newpymiescatt_moderate"

# DB BATCH méret
DB_BATCH_SIZE = 5000


def run_smarts_6b_nox_no2(row: pd.Series, df: pd.DataFrame, sr_fn, iam_fn, kA: float) -> dict:
    """
    SMARTS futtatás 6b Card-dal, NO2 NOx indexből becsülve.
    ÚJ: GHI-re 1/R^2 denorm hozzáadása (helpers.calculate_denorm_fac is_tilt=False).
    """
    result = {'ghi_raw': np.nan, 'ghi_srka': np.nan, 'ghi_final': np.nan}
    
    inp = build_smarts_input_6b_with_nox_no2(row, df)
    if inp is None:
        return result
    
    spec = run_smarts_once(inp)
    if spec is None or spec.empty:
        return result
    
    # Nyers GHI
    ghi_raw = _ghi_integral_raw(spec)
    if np.isfinite(ghi_raw):
        result['ghi_raw'] = ghi_raw
    
    # SR × kA
    ghi_sr = _ghi_sr_weighted(spec, sr_fn)
    if np.isfinite(ghi_sr) and ghi_sr > 0:
        ghi_srka = ghi_sr * kA

        # >>> ÚJ: 1/R^2 denorm (GHI eset) <<<
        ts = pd.to_datetime(row["timestamp"], utc=True, errors="coerce")
        denorm_ghi = helpers.calculate_denorm_fac(ts, is_tilt=False, base_kA=float(kA), component="ghi")
        ghi_srka = ghi_srka * float(denorm_ghi)

        result['ghi_srka'] = ghi_srka
        
        # IAM
        lat = helpers._safe_float(row.get("latitude", DEFAULT_LAT))
        lon = helpers._safe_float(row.get("longitude", DEFAULT_LON))
        alt = helpers._safe_float(row.get("alt_km", DEFAULT_ALT_KM))
        aoi = helpers._compute_aoi(ts, lat, lon, alt, PANEL_TILT, PANEL_AZIMUTH)
        iam_val = float(np.clip(iam_fn(aoi), 0.0, 1.0))
        
        result['ghi_final'] = ghi_srka * iam_val
    
    return result



