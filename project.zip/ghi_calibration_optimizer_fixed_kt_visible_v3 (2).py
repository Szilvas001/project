#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  GHI KALIBRÁCIÓ OPTIMALIZÁLÓ v3 — INTEGRATED TABLE                          ║
║                                                                              ║
║  Adatforrás: public.smarts_spectral_allsky_integrated                        ║
║    ghi_{suffix}          → GHI (SR×kA, IAM-mentes)                          ║
║    ghi_raw_{suffix}      → GHI (SR×kA, IAM nélkül, fallback)                ║
║    ghi_aoi_deg_{suffix}  → AOI [°] (GHI-hoz, ~0 mert vízszintes)            ║
║    ghi_iam_{suffix}      → IAM(AOI) értéke GHI-ra                           ║
║  A DHI/DNI szétbontást NEM tárolja az integrated tábla →                    ║
║  a spektrális táblából (smarts_spectral_allsky) olvassuk a DNI/DHI-t        ║
║  SR×kA konvolúcióval, pontosan a v2-es logikával.                           ║
║                                                                              ║
║  VAGY: ha van gti*/ghi_sr_* oszlop a táblaválasztás alapján:                ║
║    DNI_srka ← az integrated beam oszlop / cos(AOI_beam)                     ║
║    DHI_srka ← az integrated diffuse oszlop                                  ║
║                                                                              ║
║  Optimalizálandó paraméterek:                                                ║
║    S (érzékenység), β (tilt), γ (tilt azimuth)                              ║
║                                                                              ║
║  Célfüggvény:                                                                ║
║    GHI_model(S,β,γ) = S × [DHI_srka×F_diff_iam                              ║
║                           + DNI_srka×cos(AOI(β,γ))×IAM_beam(AOI)]           ║
║                                                                              ║
║  Pipeline:                                                                   ║
║    1. Integrated tábla betöltés (GHI_srka, DNI_srka, DHI_srka)              ║
║    2. Mért GHI betöltés (Central DB, IMT14)                                  ║
║    3. PROD_PERIODS + clearsky szűrés (zenit<70°, clearness 0.85–1.25)       ║
║    4. Stage-0 baseline k(t)                                                  ║
║    5. 1. optimalizáció (Nelder-Mead → L-BFGS-B)                             ║
║    6. Outlier nap szűrés (RMSE IQR + gradiens IQR)                          ║
║    7. 2. optimalizáció (végső S/β/γ)                                         ║
║    8. k(t) 2nd derivált szűrés (STDDEV < 0.0005)                            ║
║    9. 3. finomító optimalizáció a megtartott görbékre                        ║
║   10. Végső k(t) számítás                                                    ║
║   11. HTML dashboard (minden iteráció + végeredmény)                         ║
║                                                                              ║
║  Kimenet:                                                                    ║
║    ghi_calibration_dashboard.html  — interaktív HTML dashboard               ║
║    ghi_calibration_result.csv      — timestamp-szintű részletes CSV          ║
╚══════════════════════════════════════════════════════════════════════════════╝

Futtatás:
  cd /opt/app-root/src/smarts_clearsky_model
  python3 ghi_calibration_optimizer.py

Suffix-es futtatás:
  SPECTRAL_SUFFIX=_blhcap python3 ghi_calibration_optimizer.py
"""

from __future__ import annotations
import sys, os, json, warnings, traceback
import numpy as np
import pandas as pd
import pvlib
import psycopg2
import psycopg2.extras
from psycopg2 import sql as psql
from scipy.optimize import minimize
from scipy.interpolate import CubicSpline, interp1d

warnings.filterwarnings("ignore")

# ═══════════════════════════════════════════════════════════════════════════
# KONFIGURÁCIÓ
# ═══════════════════════════════════════════════════════════════════════════
LAT, LON, ALT_M = 47.4979, 19.0402, 102.0

DB_HOST, DB_PORT, DB_NAME = "172.16.41.11", 5432, "kristof"
DB_USER, DB_PWD = "levente", "titkos"

INTEGRATED_TABLE = os.getenv("INTEGRATED_TABLE", "public.smarts_spectral_allsky_integrated")
SPECTRAL_TABLE   = os.getenv("SPECTRAL_TABLE",   "public.smarts_spectral_allsky")
DB_STATEMENT_TIMEOUT_MS    = int(os.getenv("DB_STATEMENT_TIMEOUT_MS", "120000"))
SPECTRAL_MIN_CHUNK_MINUTES = int(os.getenv("SPECTRAL_MIN_CHUNK_MINUTES", "15"))

SPECTRAL_SUFFIX = os.getenv("SPECTRAL_SUFFIX", "").strip()
if SPECTRAL_SUFFIX and not SPECTRAL_SUFFIX.startswith("_"):
    SPECTRAL_SUFFIX = "_" + SPECTRAL_SUFFIX

# Integrated tábla suffix (pl. _20260421t154619z)
INTEGRATED_COL_SUFFIX = os.getenv("INTEGRATED_COL_SUFFIX", "").strip()

CENTRAL_DB_HOST, CENTRAL_DB_PORT, CENTRAL_DB_NAME = "em-central-db.ulx.hu", 5432, "emr-db"
CENTRAL_DB_USER, CENTRAL_DB_PWD = "levente", "sk7whN!xLLjGQjrBa3aT"
IMT14_ENTITY = "sensor.tvl9_imt_14_irrad"

ZENITH_MAX      = 70.0
MIN_GHI_MEASURED = 30.0
MIN_POINTS_DAY  = 20
IQR_MULT        = 1.5
CLEARNESS_LO, CLEARNESS_HI = 0.85, 1.25

# 2nd derivált szűrés küszöb
KT_2ND_DERIV_STDDEV_MAX = 0.0012

WLMIN, WLMAX = 350.0, 1200.0

print(f"  SPECTRAL_SUFFIX      = '{SPECTRAL_SUFFIX}'")
print(f"  INTEGRATED_COL_SUFFIX = '{INTEGRATED_COL_SUFFIX}'")
print(f"  INTEGRATED_TABLE     = {INTEGRATED_TABLE}")
print(f"  SPECTRAL_TABLE       = {SPECTRAL_TABLE}")

# ═══════════════════════════════════════════════════════════════════════════
# SR / IAM PONTOK
# ═══════════════════════════════════════════════════════════════════════════
SR_POINTS_5NM = {
    350: 0.000000, 355: 0.032256, 360: 0.062123, 365: 0.109399, 370: 0.166914, 375: 0.234954,
    380: 0.301337, 385: 0.352244, 390: 0.391962, 395: 0.417343, 400: 0.438740, 405: 0.452765,
    410: 0.466791, 415: 0.477220, 420: 0.485491, 425: 0.492684, 430: 0.499876, 435: 0.507068,
    440: 0.514980, 445: 0.521813, 450: 0.532242, 455: 0.539075, 460: 0.545908, 465: 0.552741,
    470: 0.559573, 475: 0.566406, 480: 0.571801, 485: 0.578993, 490: 0.586186, 495: 0.593378,
    500: 0.600570, 505: 0.604167, 510: 0.611626, 515: 0.619084, 520: 0.625051, 525: 0.632137,
    530: 0.637731, 535: 0.645190, 540: 0.649666, 545: 0.656752, 550: 0.663837, 555: 0.670923,
    560: 0.675026, 565: 0.682485, 570: 0.688452, 575: 0.693673, 580: 0.701132, 585: 0.705980,
    590: 0.712320, 595: 0.719779, 600: 0.723508, 605: 0.730408, 610: 0.734697, 615: 0.742155,
    620: 0.747377, 625: 0.753344, 630: 0.757446, 635: 0.764532, 640: 0.768261, 645: 0.775720,
    650: 0.779450, 655: 0.786908, 660: 0.790638, 665: 0.798097, 670: 0.801826, 675: 0.805556,
    680: 0.811111, 685: 0.815972, 690: 0.819444, 695: 0.826389, 700: 0.829861, 705: 0.833333,
    710: 0.840278, 715: 0.843750, 720: 0.847222, 725: 0.854167, 730: 0.857639, 735: 0.861111,
    740: 0.868056, 745: 0.871528, 750: 0.875000, 755: 0.878472, 760: 0.885417, 765: 0.888889,
    770: 0.892361, 775: 0.899306, 780: 0.902778, 785: 0.906250, 790: 0.913194, 795: 0.916667,
    800: 0.920139, 805: 0.923611, 810: 0.929167, 815: 0.934028, 820: 0.937500, 825: 0.940972,
    830: 0.944444, 835: 0.950000, 840: 0.954861, 845: 0.958333, 850: 0.961806, 855: 0.965278,
    860: 0.968750, 865: 0.972222, 870: 0.975694, 875: 0.979167, 880: 0.982639, 885: 0.986111,
    890: 0.989583, 895: 0.993056, 900: 0.993056, 905: 0.996528, 910: 0.996528, 915: 0.996528,
    920: 0.996528, 925: 0.996528, 930: 0.996528, 935: 0.996528, 940: 1.000000, 945: 1.000000,
    950: 1.000000, 955: 1.000000, 960: 1.000000, 965: 0.996528, 970: 0.989583, 975: 0.985243,
    980: 0.977778, 985: 0.970313, 990: 0.962847, 995: 0.951910, 1000: 0.940972, 1005: 0.927778,
    1010: 0.914583, 1015: 0.897917, 1020: 0.881250, 1025: 0.861111, 1030: 0.838194, 1035: 0.813889,
    1040: 0.787654, 1045: 0.751852, 1050: 0.716049, 1055: 0.672788, 1060: 0.631019, 1065: 0.590501,
    1070: 0.555977, 1075: 0.517857, 1080: 0.486930, 1085: 0.458160, 1090: 0.428671, 1095: 0.397557,
    1100: 0.365484, 1105: 0.328189, 1110: 0.298354, 1115: 0.264789, 1120: 0.238683, 1125: 0.212577,
    1130: 0.187735, 1135: 0.163842, 1140: 0.143362, 1145: 0.119468, 1150: 0.102401, 1155: 0.085334,
    1160: 0.068267, 1165: 0.051201, 1170: 0.040960, 1175: 0.030720, 1180: 0.023894, 1185: 0.023894,
    1190: 0.020480, 1195: 0.020480, 1200: 0.000000,
}

DEFAULT_IAM_POINTS = {
    0: 1.00, 5: 1.00, 10: 1.00, 15: 1.00, 20: 1.00, 25: 0.995,
    30: 0.988, 35: 0.986, 40: 0.980, 45: 0.976, 50: 0.970,
    55: 0.960, 60: 0.933, 65: 0.921, 70: 0.877, 75: 0.819,
    80: 0.711, 85: 0.546, 90: 0.00,
}

try:
    from const import IAM_POINTS
except Exception:
    IAM_POINTS = DEFAULT_IAM_POINTS

# ═══════════════════════════════════════════════════════════════════════════
# SR / IAM / kA INICIALIZÁLÁS
# ═══════════════════════════════════════════════════════════════════════════

def _sr_interp_5nm():
    wl = np.array(list(SR_POINTS_5NM.keys()), dtype=float)
    sr = np.array(list(SR_POINTS_5NM.values()), dtype=float)
    idx = np.argsort(wl)
    return interp1d(wl[idx], sr[idx], kind="cubic", bounds_error=False, fill_value=0.0)


def _build_iam_spline():
    aoi_deg = np.array(sorted(float(k) for k in IAM_POINTS.keys()), dtype=float)
    iam_val = np.array([float(IAM_POINTS.get(float(k), IAM_POINTS.get(int(k), 0.0))) for k in aoi_deg], dtype=float)
    spline = CubicSpline(aoi_deg, iam_val, bc_type="natural")
    def _fn(a):
        arr = np.clip(np.asarray(a, dtype=float), 0.0, 90.0)
        return np.clip(spline(arr), 0.0, 1.0)
    return _fn


def _am15_kA_from_sr(sr_fn) -> float:
    ref = pvlib.spectrum.get_reference_spectra(standard="ASTM G173-03")
    wl_ref = ref.index.values.astype(float)
    e_ref  = ref["global"].values.astype(float)
    mask = (wl_ref >= WLMIN) & (wl_ref <= WLMAX)
    wl_m = wl_ref[mask]; e_m = e_ref[mask]
    sr = np.clip(sr_fn(wl_m), 0.0, 1.0)
    dlam = np.diff(wl_m)
    avg  = (e_m[:-1] * sr[:-1] + e_m[1:] * sr[1:]) / 2.0
    integral = float(np.sum(avg * dlam))
    return 1.0 / (integral / 1000.0)


def _compute_f_diffuse_iam(iam_fn) -> float:
    theta_deg = np.linspace(0.0, 90.0, 10001)
    theta_rad = np.radians(theta_deg)
    integrand = np.asarray(iam_fn(theta_deg)) * np.cos(theta_rad) * np.sin(theta_rad)
    return float(np.clip(2.0 * float(np.trapz(integrand, theta_rad)), 0.0, 1.0))


_SR_FN   = _sr_interp_5nm()
_IAM_FN  = _build_iam_spline()
_KA      = _am15_kA_from_sr(_SR_FN)
F_DIFF_IAM = _compute_f_diffuse_iam(_IAM_FN)

print(f"kA (ASTM G173-03) = {_KA:.6f}  (∫AM1.5G×SR dλ = {1000.0/_KA:.2f} W/m²)")
print(f"F_diffuse_iam     = {F_DIFF_IAM:.6f}  (2×∫IAM(θ)cos(θ)sin(θ)dθ)")


def iam_beam(aoi_deg):
    return np.clip(_IAM_FN(np.clip(np.asarray(aoi_deg, float), 0, 90)), 0, 1)


# ═══════════════════════════════════════════════════════════════════════════
# PERIÓDUSOK
# ═══════════════════════════════════════════════════════════════════════════
PROD_PERIODS = [
# Átnézendő
    # 2025 AUGUSZTUS
    ("2025-08-10 04:19:44.002+00:00", "2025-08-10 10:02:07.588+00:00"),
    ("2025-08-11 04:42:31.134+00:00", "2025-08-11 09:12:31.916+00:00"),
    ("2025-08-11 14:19:42.164+00:00", "2025-08-11 17:11:52.020+00:00"),
    ("2025-08-13 04:42:42.555+00:00", "2025-08-13 16:54:41.616+00:00"),
    ("2025-08-14 04:32:52.255+00:00", "2025-08-14 12:39:43.063+00:00"),
    ("2025-08-15 04:46:39.700+00:00", "2025-08-15 09:33:15.840+00:00"),
    ("2025-08-16 04:40:09.309+00:00", "2025-08-16 09:04:21.981+00:00"),
    ("2025-08-19 00:00:00+00:00", "2025-08-20 00:00:00+00:00"),
    ("2025-08-24 00:00:00+00:00", "2025-08-25 00:00:00+00:00"),
    ("2025-08-27 06:02:23.389+00:00", "2025-08-27 12:13:07.588+00:00"),
    # 2025 SZEPTEMBER
    ("2025-09-01 04:43:07.353+00:00", "2025-09-01 11:51:00.000+00:00"),
    ("2025-09-02 04:33:51.000+00:00", "2025-09-02 10:53:24.000+00:00"),
    ("2025-09-07 04:39:29.000+00:00", "2025-09-07 12:07:43.000+00:00"),
    ("2025-09-12 05:09:17.396+00:00", "2025-09-12 11:59:23.920+00:00"),
    ("2025-09-15 10:53:12.247+00:00", "2025-09-15 14:44:05.813+00:00"),
    ("2025-09-19 05:03:52.523+00:00", "2025-09-19 16:14:14.997+00:00"),
    ("2025-09-20 08:15:39.774+00:00", "2025-09-20 16:09:40.073+00:00"),
    ("2025-09-21 06:42:03.053+00:00", "2025-09-21 14:57:43.272+00:00"),
    # 2025 OKTÓBER
    ("2025-10-04 05:38:13.142+00:00", "2025-10-04 15:29:09.465+00:00"),
    ("2025-10-08 05:47:40.678+00:00", "2025-10-08 15:10:31.525+00:00"),
    ("2025-10-19 06:00:59.608+00:00", "2025-10-19 10:40:22.529+00:00"),
    ("2025-10-20 06:02:17.796+00:00", "2025-10-20 13:35:29.491+00:00"),
    # 2025 NOVEMBER
    ("2025-11-01 08:25:35.064+00:00", "2025-11-01 14:54:24.155+00:00"),
    ("2025-11-05 06:10:44.304+00:00", "2025-11-05 09:46:39.406+00:00"),
    ("2025-11-06 06:14:43.636+00:00", "2025-11-06 09:54:16.363+00:00"),
    ("2025-11-07 06:16:37.625+00:00", "2025-11-07 12:49:19.591+00:00"),
    ("2025-11-18 09:58:14.582+00:00", "2025-11-18 13:16:56.660+00:00"),
    # 2025 DECEMBER
    ("2025-12-27 11:01:40.951+00:00", "2025-12-27 14:30:06.844+00:00"),
    ("2025-12-28 07:07:51.003+00:00", "2025-12-28 12:01:12.672+00:00"),
    ("2025-12-29 01:00:00.000+00:00", "2025-12-29 20:00:00.000+00:00"),
    ("2025-12-30 08:42:51.629+00:00", "2025-12-30 14:25:45.840+00:00"),
    # 2026 JANUÁR
    ("2026-01-18 07:01:02.972+00:00", "2026-01-18 15:01:39.426+00:00"),
    ("2026-01-27 06:45:50.253+00:00", "2026-01-27 13:01:44.323+00:00"),
    # 2026 FEBRUÁR
    ("2026-02-26 06:08:50.735+00:00", "2026-02-26 11:05:14.156+00:00"),
    ("2026-02-27 06:14:01.630+00:00", "2026-02-27 13:33:09.079+00:00"),
    # 2026 MÁRCIUS
    ("2026-03-06 06:26:31.871+00:00", "2026-03-06 15:57:54.366+00:00"),
    ("2026-03-07 05:44:39.765+00:00", "2026-03-07 16:05:21.717+00:00"),
    ("2026-03-08 05:52:44.027+00:00", "2026-03-08 09:59:14.490+00:00"),
    ("2026-03-09 05:48:43.360+00:00", "2026-03-09 11:10:14.231+00:00"),
	("2026-03-14 05:41:30.129+00:00", "2026-03-14 16:11:55.330+00:00"),
    ("2026-03-15 05:42:18.344+00:00", "2026-03-15 16:02:13.897+00:00"),
		#	2026 ÁPRILIS
	("2026-04-11 04:44:17.640+00:00", "2026-04-11 08:29:21.346+00:00"),
    ("2026-04-08 05:17:09.635+00:00", "2026-04-08 13:32:30.203+00:00"),
    ("2026-04-07 04:30:35.874+00:00", "2026-04-07 08:00:46.917+00:00"),
    ("2026-04-07 11:51:31.315+00:00", "2026-04-07 15:04:14.008+00:00"),
    ("2026-03-19 05:29:51.142+00:00", "2026-03-19 09:04:17.047+00:00"),
]

EXCLUDE_DATES = {
    "2025-09-12",
    "2025-09-19",
    "2025-11-18",
    "2026-03-06",
    "2026-03-07",
}

PROD_PERIODS = [(s, e) for s, e in PROD_PERIODS if s[:10] not in EXCLUDE_DATES]
print(f"EXCLUDE_DATES: {sorted(EXCLUDE_DATES)} → {len(PROD_PERIODS)} periódus maradt")


# ═══════════════════════════════════════════════════════════════════════════
# UTILITY
# ═══════════════════════════════════════════════════════════════════════════

def _interp_time_inside(s, idx, edge_fill=False):
    if s is None or idx is None or len(idx) == 0:
        return pd.Series(index=idx, dtype=float)
    s = pd.to_numeric(s, errors="coerce").dropna()
    if s.empty:
        return pd.Series(index=idx, dtype=float)
    s = s[~s.index.duplicated(keep="first")].sort_index()
    u = s.index.union(pd.DatetimeIndex(idx)).sort_values()
    s2 = s.reindex(u).interpolate("time", limit_area="inside")
    out = s2.reindex(idx)
    if edge_fill:
        out = out.ffill().bfill()
    return out


def _get_main_conn():
    conn = psycopg2.connect(host=DB_HOST, port=DB_PORT, dbname=DB_NAME,
                            user=DB_USER, password=DB_PWD)
    conn.autocommit = True
    try:
        with conn.cursor() as cur:
            cur.execute(f"SET statement_timeout = {DB_STATEMENT_TIMEOUT_MS};")
    except Exception:
        pass
    return conn


def _get_central_conn():
    conn = psycopg2.connect(host=CENTRAL_DB_HOST, port=CENTRAL_DB_PORT, dbname=CENTRAL_DB_NAME,
                            user=CENTRAL_DB_USER, password=CENTRAL_DB_PWD, sslmode="require")
    conn.autocommit = True
    return conn


def _fetch_table_columns(conn, table_fq: str):
    parts = str(table_fq).split(".")
    schema, table = (parts[0], parts[1]) if len(parts) == 2 else ("public", parts[0])
    with conn.cursor() as cur:
        cur.execute(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_schema=%s AND table_name=%s ORDER BY ordinal_position",
            (schema, table))
        return [r[0] for r in cur.fetchall()]


# ═══════════════════════════════════════════════════════════════════════════
# INTEGRATED TÁBLA OSZLOPFELISMERÉS
# ═══════════════════════════════════════════════════════════════════════════

def _find_integrated_cols(avail_cols):
    """
    Az integrated táblában megtalálja a GHI, DNI/DHI oszlopokat.
    Prioritás: INTEGRATED_COL_SUFFIX env → automatikus keresés legújabb suffix szerint.

    Visszaad: dict  ghi_col, dni_beam_col, dhi_diffuse_col, timestamp_col
    """
    low = {c.lower(): c for c in avail_cols}

    # timestamp
    ts_col = None
    for cand in ["timestamp", "ts", "time", "valid_time", "datetime"]:
        if cand in low:
            ts_col = low[cand]; break
    if ts_col is None:
        raise RuntimeError(f"Nincs timestamp oszlop: {avail_cols[:20]}")

    sfx = INTEGRATED_COL_SUFFIX.lower().lstrip("_")

    # Ha van explicit suffix
    if sfx:
        # ghi_{sfx}, ghi_raw_{sfx}, ...
        ghi_candidates = [f"ghi_{sfx}", f"ghi_raw_{sfx}", f"ghi_sr_{sfx}"]
        ghi_col = next((low[c] for c in ghi_candidates if c in low), None)
        # beam = gti*beam — de nincs közvetlen DNI oszlop; GHI alapú fallback lesz
        # Keresünk gti1225beam_{sfx} és gti1225diffuse_{sfx} → azon keresztül kinyerjük DNI/DHI-t
        beam_col_225  = low.get(f"gti1225beam_{sfx}")
        diff_col_225  = low.get(f"gti1225diffuse_{sfx}")
        beam_col_1545 = low.get(f"gti1545beam_{sfx}")
        diff_col_1545 = low.get(f"gti1545diffuse_{sfx}")
    else:
        # Automatikus: keressük a legfrissebb _YYYYMMDD... suffix-et a ghi_* oszlopok között
        import re
        ghi_pat = re.compile(r'^ghi_(\d{8}t\d{6}z)$', re.IGNORECASE)
        sfx_found = set()
        for c in avail_cols:
            m = ghi_pat.match(c)
            if m:
                sfx_found.add(m.group(1))
        if sfx_found:
            sfx = sorted(sfx_found)[-1]   # legújabb (lex)
            print(f"  Automatikus INTEGRATED_COL_SUFFIX felismerés: '{sfx}'")
        else:
            sfx = ""
            print("  Nem találtam dátummal ellátott ghi_* oszlopot az integrated táblában — default keresés")

        ghi_col_try = [f"ghi_{sfx}", f"ghi_raw_{sfx}", f"ghi_sr_{sfx}", "ghi", "ghi_w_m2"] if sfx else ["ghi", "ghi_w_m2"]
        ghi_col = next((low[c.lower()] for c in ghi_col_try if c.lower() in low), None)

        beam_col_225  = low.get(f"gti1225beam_{sfx}") if sfx else None
        diff_col_225  = low.get(f"gti1225diffuse_{sfx}") if sfx else None
        beam_col_1545 = low.get(f"gti1545beam_{sfx}") if sfx else None
        diff_col_1545 = low.get(f"gti1545diffuse_{sfx}") if sfx else None

    if ghi_col is None:
        raise RuntimeError(f"Nem találtam GHI oszlopot az integrated táblában! Elérhető: {avail_cols[:30]}")

    print(f"  Integrated oszlopok: ts={ts_col}, ghi={ghi_col}, "
          f"beam225={beam_col_225}, diff225={diff_col_225}, "
          f"beam1545={beam_col_1545}, diff1545={diff_col_1545}")

    return {
        "ts_col": ts_col,
        "ghi_col": ghi_col,
        "beam225_col": beam_col_225,
        "diff225_col": diff_col_225,
        "beam1545_col": beam_col_1545,
        "diff1545_col": diff_col_1545,
        "suffix": sfx,
    }


# ═══════════════════════════════════════════════════════════════════════════
# ADATBETÖLTÉS — INTEGRATED TÁBLA
# ═══════════════════════════════════════════════════════════════════════════

def load_integrated_data(conn, col_info: dict) -> pd.DataFrame:
    """
    Integrated táblából betölti a GHI (és ha van, beam+diffuse) értékeket
    a PROD_PERIODS időablakaiban.

    Az integrated tábla GHI oszlopa már tartalmaz IAM-ot → nekünk viszont
    IAM-mentes GHI_srka kell a modellhez.
    Ha van ghi_sr_* vagy ghi_raw_* oszlop (IAM nélküli), azt preferáljuk.
    Ha csak ghi_* van (IAM-mal), azt is elfogadjuk — a tilt-kalibrációban
    az S paraméter abszorbeálja a különbséget (a vízszintes szenzornál az
    IAM(0°)≈1.0 különben is).

    DNI_srka / DHI_srka forrás: beam225 + diff225 (vagy 1545), ha elérhető.
    Ha nincs, fallback: spektrális tábla raw konvolúció (v2 logika).
    """
    parts = INTEGRATED_TABLE.split(".")
    schema, tbl = (parts[0], parts[1]) if len(parts) == 2 else ("public", parts[0])

    ts_col   = col_info["ts_col"]
    ghi_col  = col_info["ghi_col"]
    beam_col = col_info["beam225_col"] or col_info["beam1545_col"]
    diff_col = col_info["diff225_col"] or col_info["diff1545_col"]

    sel_cols = [ts_col, ghi_col]
    if beam_col:
        sel_cols.append(beam_col)
    if diff_col and diff_col != beam_col:
        sel_cols.append(diff_col)

    q = psql.SQL(
        "SELECT {cols} FROM {schema}.{table} WHERE {ts} >= %s AND {ts} < %s ORDER BY {ts}"
    ).format(
        cols   = psql.SQL(", ").join(psql.Identifier(c) for c in sel_cols),
        schema = psql.Identifier(schema),
        table  = psql.Identifier(tbl),
        ts     = psql.Identifier(ts_col),
    )

    all_rows = []
    for i, (start_str, end_str) in enumerate(PROD_PERIODS, 1):
        p_start = pd.to_datetime(start_str, utc=True)
        p_end   = pd.to_datetime(end_str,   utc=True)
        print(f"  [{i:02d}/{len(PROD_PERIODS):02d}] integrated: {p_start.date()} → {p_end.date()}")
        try:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(q, (p_start.to_pydatetime(), p_end.to_pydatetime()))
                rows = cur.fetchall()
                all_rows.extend(rows)
                print(f"    ✓ {len(rows)} sor")
        except Exception as e:
            print(f"    [WARN] Hiba a periódusban: {e}")
            try:
                conn.rollback()
            except Exception:
                pass

    if not all_rows:
        raise RuntimeError(f"Nincs integrated adat: {INTEGRATED_TABLE}")

    df = pd.DataFrame(all_rows)
    df["timestamp"] = pd.to_datetime(df[ts_col], utc=True, errors="coerce")
    df = df.dropna(subset=["timestamp"]).sort_values("timestamp").drop_duplicates("timestamp")

    df = df.rename(columns={ghi_col: "ghi_srka"})
    df["ghi_srka"] = pd.to_numeric(df["ghi_srka"], errors="coerce")

    if beam_col and beam_col in df.columns:
        df = df.rename(columns={beam_col: "_beam_raw"})
        df["_beam_raw"] = pd.to_numeric(df["_beam_raw"], errors="coerce")
    else:
        df["_beam_raw"] = np.nan

    if diff_col and diff_col in df.columns:
        df = df.rename(columns={diff_col: "_diff_raw"})
        df["_diff_raw"] = pd.to_numeric(df["_diff_raw"], errors="coerce")
    else:
        df["_diff_raw"] = np.nan

    print(f"  ✓ Integrated: {len(df)} sor betöltve")
    return df[["timestamp", "ghi_srka", "_beam_raw", "_diff_raw"]].copy()


# ═══════════════════════════════════════════════════════════════════════════
# DNI / DHI KINYERÉS A BEAM / DIFF INTEGRATED ÉRTÉKEKBŐL
# ═══════════════════════════════════════════════════════════════════════════

def derive_dni_dhi_from_integrated(df: pd.DataFrame, col_info: dict) -> pd.DataFrame:
    """
    Az integrated tábla beam/diffuse oszlopai GTI (tilted irradiance) értékek,
    nem DNI/DHI.  A beam GTI ≈ DNI × cos(AOI_GTI), de nekünk DNI_srka kell.

    Legjobb megközelítés:
      - Ha van beam225 ÉS a GHI modellhez az AOI a GHI-ra ~0, akkor:
        A GHI modell szempontjából DNI_srka és DHI_srka kell vízszintes geometriára.
        GHI_srka = DHI_srka + DNI_srka × cos(zenith)
        DHI_srka ≈ _diff_raw   (ha vízszintes diffúz)
        DNI_srka = (GHI_srka - DHI_srka) / cos(zenith)   ha cos(zenith) > 0

    Ez csak akkor működik, ha a diff_col valóban DHI (nem GTI diffúz).
    Az integrated tábla 'gti*diffuse' oszlopai tilted diffúz értékek — ezek
    NEM azonosak a DHI-val.

    Ezért a DNI/DHI levezetéséhez a spektrális táblát kell olvasni.
    Ez a függvény csak akkor "becsül", ha a spektrális fallback sikertelen.
    """
    # Ha van mindkét raw integrated érték és a zenith elérhető:
    has_beam = df["_beam_raw"].notna().any()
    has_diff = df["_diff_raw"].notna().any()

    if has_beam and has_diff and "zenith" in df.columns:
        cos_z = np.maximum(np.cos(np.radians(df["zenith"].values)), 0.05)
        # beam_raw ≈ DNI_srka × cos(AOI_GTI_panel) — ha panel tilt=12.25° dél
        # Ez nem tökéletes, de csak fallback
        # Inkább a GHI-t bontjuk el: DHI ≈ diff_raw (ha vízszintes), DNI = (GHI - DHI)/cos(z)
        # Megjegyzés: ez durva becslés, spektrális forrás mindig jobb
        print("  [INFO] DNI/DHI becslés integrated beam+diff alapján (fallback)")
        dhi = df["_diff_raw"].clip(lower=0)
        dni = (df["ghi_srka"] - dhi) / cos_z
        dni = dni.clip(lower=0)
        df["dni_srka"] = dni
        df["dhi_srka"] = dhi
    else:
        # Nincs beam/diff → nem tudunk DNI/DHI-t becsülni
        df["dni_srka"] = np.nan
        df["dhi_srka"] = np.nan

    return df


# ═══════════════════════════════════════════════════════════════════════════
# DNI / DHI FORRÁS: SPEKTRÁLIS TÁBLA (v2 logika, fallback)
# ═══════════════════════════════════════════════════════════════════════════

def _safe_json_array(x) -> np.ndarray:
    if x is None:
        return np.array([], dtype=float)
    if isinstance(x, (list, tuple, np.ndarray)):
        return np.asarray(x, dtype=float)
    if isinstance(x, str):
        s = x.strip()
        if not s:
            return np.array([], dtype=float)
        try:
            val = json.loads(s)
            if isinstance(val, list):
                return np.asarray(val, dtype=float)
        except Exception:
            pass
    return np.array([], dtype=float)


def _integral_sr_weighted(wl: np.ndarray, y: np.ndarray) -> float:
    wl = np.asarray(wl, dtype=float); y = np.asarray(y, dtype=float)
    m = np.isfinite(wl) & np.isfinite(y) & (wl >= WLMIN) & (wl <= WLMAX)
    if int(m.sum()) < 3:
        return float("nan")
    ww = wl[m][np.argsort(wl[m])]; yy = y[m][np.argsort(wl[m])]
    sr = np.clip(_SR_FN(ww), 0.0, 1.0)
    return float(np.trapz(yy * sr, ww))


def _fetch_spectral_rows_for_interval(conn, query, start_ts, end_ts):
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(query, (start_ts.to_pydatetime(), end_ts.to_pydatetime()))
        return cur.fetchall()


def _fetch_spectral_rows_chunked(conn, query, start_ts, end_ts,
                                  min_chunk_minutes=SPECTRAL_MIN_CHUNK_MINUTES, depth=0):
    start_ts = pd.to_datetime(start_ts, utc=True)
    end_ts   = pd.to_datetime(end_ts,   utc=True)
    if end_ts <= start_ts:
        return []
    try:
        rows = _fetch_spectral_rows_for_interval(conn, query, start_ts, end_ts)
        print(f"    ✓ chunk OK: {start_ts} → {end_ts}  {len(rows)} sor")
        return rows
    except (psycopg2.errors.QueryCanceled, Exception) as exc:
        msg = str(exc).lower()
        if 'statement timeout' in msg or 'query canceled' in msg or 'canceling statement' in msg:
            try:
                conn.rollback()
            except Exception:
                pass
            span = end_ts - start_ts
            if span <= pd.Timedelta(minutes=max(1, int(min_chunk_minutes))):
                raise RuntimeError(f"Spektrális timeout minimális chunknál: {start_ts}→{end_ts}") from exc
            mid = start_ts + span / 2
            print(f"    [TIMEOUT] split: {start_ts}→{mid} + {mid}→{end_ts}")
            return (_fetch_spectral_rows_chunked(conn, query, start_ts, mid, min_chunk_minutes, depth+1) +
                    _fetch_spectral_rows_chunked(conn, query, mid,      end_ts, min_chunk_minutes, depth+1))
        raise


def load_spectral_dni_dhi() -> pd.DataFrame:
    """
    Nyers spektrális tábla → DNI_srka, DHI_srka (SR×kA konvolúció).
    Visszaad: DataFrame timestamp + dni_srka + dhi_srka
    """
    conn = _get_main_conn()
    avail_cols = _fetch_table_columns(conn, SPECTRAL_TABLE)
    low = {c.lower(): c for c in avail_cols}
    sfx = SPECTRAL_SUFFIX

    def _find(candidates):
        if sfx:
            for cand in candidates:
                key = (cand + sfx).lower()
                if key in low:
                    return low[key]
        for cand in candidates:
            if cand.lower() in low:
                return low[cand.lower()]
        return None

    ts_col = next((low[c] for c in ["timestamp", "ts", "time", "valid_time"] if c in low), None)
    if ts_col is None:
        raise RuntimeError("Nincs timestamp a spektrális táblában")
    wl_col  = _find(["wavelengths", "wavelength_nm", "wavelength", "wl"])
    ghi_col = _find(["ghi_spectrum", "ghi_w_m2_per_nm", "ghi"])
    dni_col = _find(["dni_spectrum", "dni_w_m2_per_nm", "dni"])
    dhi_col = _find(["dhi_spectrum", "dhi_w_m2_per_nm", "dhi"])
    dir_horiz_col = None
    if dhi_col is None:
        dir_horiz_col = _find(["dir_horiz_spectrum", "dir_horiz_w_m2_per_nm", "dir_horiz"])

    if wl_col is None or (dni_col is None and dhi_col is None and dir_horiz_col is None):
        conn.close()
        print("  [WARN] Nincs DNI/DHI spektrum a spektrális táblában — fallback hiányzik")
        return pd.DataFrame(columns=["timestamp", "dni_srka", "dhi_srka"])

    sel_cols = list(filter(None, [ts_col, wl_col, ghi_col, dni_col, dhi_col or dir_horiz_col]))
    parts = SPECTRAL_TABLE.split(".")
    schema, tbl = (parts[0], parts[1]) if len(parts) == 2 else ("public", parts[0])
    q = psql.SQL(
        "SELECT {cols} FROM {schema}.{table} WHERE {ts} >= %s AND {ts} < %s ORDER BY {ts}"
    ).format(
        cols=psql.SQL(", ").join(psql.Identifier(c) for c in sel_cols),
        schema=psql.Identifier(schema),
        table=psql.Identifier(tbl),
        ts=psql.Identifier(ts_col),
    )

    rows = []
    try:
        for i, (start_str, end_str) in enumerate(PROD_PERIODS, 1):
            p_start = pd.to_datetime(start_str, utc=True)
            p_end   = pd.to_datetime(end_str,   utc=True)
            print(f"  [{i:02d}/{len(PROD_PERIODS):02d}] spektrális: {p_start.date()}")
            part = _fetch_spectral_rows_chunked(conn, q, p_start, p_end)
            rows.extend(part)
    finally:
        conn.close()

    if not rows:
        print("  [WARN] Nincs spektrális adat")
        return pd.DataFrame(columns=["timestamp", "dni_srka", "dhi_srka"])

    df = pd.DataFrame(rows)
    df["timestamp"] = pd.to_datetime(df[ts_col], utc=True, errors="coerce")
    df = df.dropna(subset=["timestamp"]).sort_values("timestamp").drop_duplicates("timestamp")

    records = []
    kA = _KA
    for row in df.to_dict(orient="records"):
        ts  = row.get("timestamp")
        wl  = _safe_json_array(row.get(wl_col))
        if wl.size < 3:
            continue
        # DHI
        if dhi_col and dhi_col in row:
            dhi_spec = _safe_json_array(row.get(dhi_col))
        elif dir_horiz_col and ghi_col:
            gh_spec  = _safe_json_array(row.get(ghi_col))
            dir_spec = _safe_json_array(row.get(dir_horiz_col))
            if gh_spec.size == wl.size and dir_spec.size == wl.size:
                dhi_spec = np.clip(gh_spec - dir_spec, 0.0, None)
            else:
                dhi_spec = np.array([], dtype=float)
        else:
            dhi_spec = np.array([], dtype=float)
        # DNI
        dni_spec = _safe_json_array(row.get(dni_col)) if dni_col else np.array([], dtype=float)

        dni_srka = np.nan
        dhi_srka = np.nan
        if dni_spec.size == wl.size:
            v = _integral_sr_weighted(wl, dni_spec)
            if np.isfinite(v):
                dni_srka = v * kA
        if dhi_spec.size == wl.size:
            v = _integral_sr_weighted(wl, dhi_spec)
            if np.isfinite(v):
                dhi_srka = v * kA

        if np.isfinite(dni_srka) and np.isfinite(dhi_srka):
            records.append({"timestamp": ts, "dni_srka": dni_srka, "dhi_srka": dhi_srka})

    out = pd.DataFrame(records)
    if out.empty:
        return pd.DataFrame(columns=["timestamp", "dni_srka", "dhi_srka"])
    out["timestamp"] = pd.to_datetime(out["timestamp"], utc=True, errors="coerce")
    print(f"  ✓ Spektrális DNI/DHI: {len(out)} sor")
    return out.dropna(subset=["timestamp"]).sort_values("timestamp").drop_duplicates("timestamp")


# ═══════════════════════════════════════════════════════════════════════════
# MÉRT GHI
# ═══════════════════════════════════════════════════════════════════════════

def load_measured_ghi() -> pd.DataFrame:
    t_min = pd.to_datetime(min(s for s, e in PROD_PERIODS), utc=True)
    t_max = pd.to_datetime(max(e for s, e in PROD_PERIODS), utc=True)
    epoch_min, epoch_max = t_min.timestamp(), t_max.timestamp()
    print(f"  Kapcsolódás Central DB-hez ({CENTRAL_DB_HOST})...")
    conn = _get_central_conn()
    cur  = conn.cursor()
    cur.execute(f"SELECT metadata_id FROM states_meta WHERE entity_id = '{IMT14_ENTITY}' LIMIT 1")
    row = cur.fetchone()
    if row is None:
        print(f"  HIBA: {IMT14_ENTITY} nem található!")
        conn.close()
        return pd.DataFrame(columns=["timestamp", "ghi_measured"])
    mid = row[0]
    sql = (f"SELECT last_updated_ts, state FROM states "
           f"WHERE metadata_id = {mid} AND last_updated_ts >= {epoch_min} "
           f"AND last_updated_ts <= {epoch_max} ORDER BY last_updated_ts")
    df = pd.read_sql(sql, conn); conn.close()
    df["timestamp"]    = pd.to_datetime(df["last_updated_ts"], unit="s", utc=True)
    df["ghi_measured"] = pd.to_numeric(df["state"], errors="coerce")
    df = (df.dropna(subset=["ghi_measured"])[["timestamp", "ghi_measured"]]
            .sort_values("timestamp")
            .drop_duplicates(subset=["timestamp"], keep="first")
            .reset_index(drop=True))
    print(f"  ✓ Mért GHI (IMT14): {len(df)} sor")
    return df


# ═══════════════════════════════════════════════════════════════════════════
# NAPÁLLÁS + SZŰRÉSEK
# ═══════════════════════════════════════════════════════════════════════════

def add_solar_positions(df):
    loc = pvlib.location.Location(LAT, LON, tz="UTC", altitude=ALT_M)
    sp  = loc.get_solarposition(df["timestamp"])
    df["zenith"]       = sp["apparent_zenith"].values
    df["elevation"]    = sp["apparent_elevation"].values
    df["solar_azimuth"] = sp["azimuth"].values
    return df


def compute_solar_noon(date):
    loc   = pvlib.location.Location(LAT, LON, tz="UTC")
    times = pd.date_range(f"{date} 08:00", f"{date} 14:00", freq="1min", tz="UTC")
    sp    = loc.get_solarposition(times)
    return sp["apparent_zenith"].idxmin()


def build_period_mask(df, periods):
    ts   = pd.to_datetime(df["timestamp"], utc=True)
    mask = pd.Series(False, index=df.index)
    for start_str, end_str in periods:
        mask |= (ts >= pd.to_datetime(start_str, utc=True)) & (ts <= pd.to_datetime(end_str, utc=True))
    return mask


def filter_data(df):
    n0 = len(df)

    # PROD_PERIODS szűrés
    mask = build_period_mask(df, PROD_PERIODS)
    df   = df[mask].copy()
    print(f"  PROD_PERIODS: {n0} → {len(df)}")

    # Zenit
    df = df[df["zenith"] < ZENITH_MAX].copy()
    print(f"  Zenit < {ZENITH_MAX}°: → {len(df)}")

    # GHI minimum
    df = df[df["ghi_measured"] > MIN_GHI_MEASURED].copy()
    print(f"  GHI > {MIN_GHI_MEASURED} W/m²: → {len(df)}")

    # Clearness index (GHI_clear = DNI_srka×cos(z) + DHI_srka)
    cos_z     = np.maximum(np.cos(np.radians(df["zenith"].values)), 0.01)
    ghi_clear = df["dni_srka"].values * cos_z + df["dhi_srka"].values
    ghi_clear = np.where(ghi_clear > 10, ghi_clear, np.nan)
    clearness = df["ghi_measured"].values / ghi_clear
    df["clearness_idx"] = clearness
    cs_mask = (clearness > CLEARNESS_LO) & (clearness < CLEARNESS_HI)
    df = df[cs_mask].copy()
    print(f"  Clearness index {CLEARNESS_LO}–{CLEARNESS_HI}: → {len(df)}")

    # Solar noon ±1.5h + szimmetria (min 30 pont mindkét oldalon)
    df["date"] = df["timestamp"].dt.date
    keep_mask  = pd.Series(False, index=df.index)
    noon_info  = {}
    for d in df["date"].unique():
        try:
            noon = compute_solar_noon(d)
        except Exception:
            continue
        t_s     = noon - pd.Timedelta(hours=1.5)
        t_e     = noon + pd.Timedelta(hours=1.5)
        day_mask = (df["date"] == d) & (df["timestamp"] >= t_s) & (df["timestamp"] <= t_e)
        day_ts   = df.loc[day_mask, "timestamp"]
        if len(day_ts) < MIN_POINTS_DAY:
            continue
        before, after = (day_ts < noon).sum(), (day_ts > noon).sum()
        if before < 30 or after < 30:
            print(f"    {d}: aszimmetrikus ({before}/{after}), SKIP")
            continue
        keep_mask |= day_mask
        noon_info[d] = {"noon": noon, "n": int(day_mask.sum()), "before": int(before), "after": int(after)}

    df = df[keep_mask].copy()
    print(f"  Solar noon ±1.5h + szimmetria: → {len(df)} sor, {len(noon_info)} nap")
    return df, noon_info


# ═══════════════════════════════════════════════════════════════════════════
# MODELL + OPTIMALIZÁCIÓ
# ═══════════════════════════════════════════════════════════════════════════

def ghi_model(params, df):
    """
    GHI_model(S, β, γ) = S × [DHI_srka × F_diff_iam
                              + DNI_srka × cos(AOI(β,γ)) × IAM_beam(AOI)]
    """
    S, beta, gamma = params
    aoi_deg = np.clip(
        np.asarray(pvlib.irradiance.aoi(beta, gamma, df["zenith"].values, df["solar_azimuth"].values), float),
        0, 90)
    cos_aoi = np.maximum(np.cos(np.radians(aoi_deg)), 0.0)
    return S * (df["dhi_srka"].values * F_DIFF_IAM
                + df["dni_srka"].values * cos_aoi * iam_beam(aoi_deg))


def cost_function(params, df):
    return float(np.sqrt(np.nanmean((df["ghi_measured"].values - ghi_model(params, df)) ** 2)))


def optimize_s_beta_gamma(df, label=""):
    print(f"\n  OPTIMALIZÁCIÓ {label}: S / β (tilt) / γ (azimuth)")
    x0   = [1.0, 0.0, 180.0]
    r_nm = minimize(cost_function, x0, args=(df,), method="Nelder-Mead",
                    options={"maxiter": 10000, "xatol": 1e-4, "fatol": 1e-4})
    print(f"    Nelder-Mead: S={r_nm.x[0]:.6f}, β={r_nm.x[1]:.3f}°, γ={r_nm.x[2]:.3f}°, RMSE={r_nm.fun:.3f}")
    r_lb = minimize(cost_function, r_nm.x, args=(df,), method="L-BFGS-B",
                    bounds=[(0.8, 1.3), (-15.0, 15.0), (0.0, 360.0)],
                    options={"maxiter": 5000})
    S, b, g = r_lb.x; rmse = r_lb.fun
    print(f"    L-BFGS-B:    S={S:.6f}, β={b:.3f}°, γ={g:.3f}°, RMSE={rmse:.3f}")
    baseline = cost_function([1.0, 0.0, 180.0], df)
    print(f"    Baseline RMSE: {baseline:.3f}  →  Optimál: {rmse:.3f}  (javulás: {baseline-rmse:+.3f})")
    return float(S), float(b), float(g), float(rmse)


# ═══════════════════════════════════════════════════════════════════════════
# OUTLIER SZŰRÉS
# ═══════════════════════════════════════════════════════════════════════════

def filter_outlier_days(df, params):
    df["date"] = df["timestamp"].dt.date
    day_rmse, day_grad_std = {}, {}
    for d in df["date"].unique():
        day_df = df[df["date"] == d]
        if len(day_df) < 20:
            continue
        ghi_mod  = ghi_model(params, day_df)
        ghi_meas = day_df["ghi_measured"].values
        ratio    = ghi_meas / np.where(ghi_mod > 10, ghi_mod, np.nan)
        ratio    = ratio[np.isfinite(ratio)]
        if len(ratio) < 10:
            continue
        day_rmse[d]     = float(np.sqrt(np.mean((ghi_meas - ghi_mod) ** 2)))
        day_grad_std[d] = float(np.std(np.diff(ratio)))

    if len(day_rmse) < 5:
        print("  Kevés nap — nincs outlier szűrés")
        return df

    rmse_arr = np.array(list(day_rmse.values()))
    q1, q3  = np.percentile(rmse_arr, [25, 75]); rmse_hi = q3 + IQR_MULT * (q3 - q1)
    grad_arr = np.array(list(day_grad_std.values()))
    gq1, gq3 = np.percentile(grad_arr, [25, 75]); grad_hi = gq3 + IQR_MULT * (gq3 - gq1)

    keep, skip_r, skip_g = set(), set(), set()
    for d in day_rmse:
        if day_rmse[d] > rmse_hi:
            skip_r.add(d)
        elif d in day_grad_std and day_grad_std[d] > grad_hi:
            skip_g.add(d)
        else:
            keep.add(d)

    print(f"  Outlier szűrés: {len(day_rmse)} nap → {len(keep)} marad")
    for d in sorted(skip_r): print(f"    {d}: RMSE outlier ({day_rmse[d]:.1f} > {rmse_hi:.1f})")
    for d in sorted(skip_g): print(f"    {d}: Gradiens outlier ({day_grad_std[d]:.4f} > {grad_hi:.4f})")
    return df[df["date"].isin(keep)].copy()


# ═══════════════════════════════════════════════════════════════════════════
# k(t) SZÁMÍTÁS
# ═══════════════════════════════════════════════════════════════════════════

def compute_kt_frame(df, S, beta, gamma):
    """Számít k(t)-t az adott paraméterekkel, nem írja felül az eredeti df-et."""
    tmp      = df.copy()
    ghi_mod  = ghi_model([S, beta, gamma], tmp)
    ghi_mod  = np.where(ghi_mod > 10, ghi_mod, np.nan)
    tmp["ghi_model"] = ghi_mod
    tmp["kt"]        = tmp["ghi_measured"].values / ghi_mod
    tmp["ratio"]     = tmp["kt"]
    if "date" not in tmp.columns:
        tmp["date"] = tmp["timestamp"].dt.date
    return tmp


def filter_kt_by_2nd_deriv(df, S, beta, gamma, noon_info=None):
    """
    Megtartja azokat a napokat, amelyekre a k(t) görbe 2nd deriváltjának STDDEV < KT_2ND_DERIV_STDDEV_MAX.
    """
    tmp = compute_kt_frame(df, S, beta, gamma)
    tmp = tmp.replace([np.inf, -np.inf], np.nan).dropna(subset=["kt"])

    keep_dates, reject_dates = set(), set()
    stats = {}

    for d in sorted(tmp["date"].unique()):
        day = tmp[tmp["date"] == d].sort_values("timestamp")
        kt  = day["kt"].values
        if len(kt) < 10:
            reject_dates.add(d)
            continue
        # 2nd derivált finite diff
        d2 = np.diff(kt, n=2)
        d2 = d2[np.isfinite(d2)]
        if len(d2) < 3:
            reject_dates.add(d)
            continue
        stddev = float(np.std(d2))
        stats[d] = stddev
        if stddev < KT_2ND_DERIV_STDDEV_MAX:
            keep_dates.add(d)
        else:
            reject_dates.add(d)

    print(f"  k(t) 2nd derivált szűrés (küszöb={KT_2ND_DERIV_STDDEV_MAX}):")
    print(f"    Megtartott: {len(keep_dates)}, Eldobott: {len(reject_dates)}")
    for d in sorted(reject_dates):
        print(f"    {d}: STDDEV_2nd={stats.get(d, float('nan')):.6f} > {KT_2ND_DERIV_STDDEV_MAX}")

    if not keep_dates:
        print("  [WARN] A 2nd derivált szűrés mindenkit kiszűrt — nem szűrünk")
        return df, list(df["date"].unique()), stats

    return df[df["date"].isin(keep_dates)].copy(), sorted(keep_dates), stats


# ═══════════════════════════════════════════════════════════════════════════
# ADATOK DASHBOARD PLOTHOZ (JSON)
# ═══════════════════════════════════════════════════════════════════════════

def _kt_stage_json(df_stage, S, beta, gamma, label):
    """Egy stage k(t) adatait dict-be gyűjti a dashboardhoz."""
    tmp = compute_kt_frame(df_stage, S, beta, gamma)
    tmp = tmp.replace([np.inf, -np.inf], np.nan).dropna(subset=["kt", "solar_azimuth", "zenith"])

    days = sorted(tmp["date"].unique())
    periods = []
    for d in days:
        day_ts = tmp[tmp["date"] == d].sort_values("timestamp")
        if len(day_ts) < 3:
            continue

        day = day_ts.sort_values("solar_azimuth").copy()

        # Solar noon rel. percek
        noon = None
        if isinstance(d, object):
            try:
                noon = compute_solar_noon(d)
            except Exception:
                noon = pd.Timestamp(str(d) + " 12:00:00", tz="UTC")
        rel_min = [
            (pd.Timestamp(ts) - pd.Timestamp(noon)).total_seconds() / 60.0
            for ts in day["timestamp"]
        ]

        kt_ts = pd.to_numeric(day_ts["kt"], errors="coerce").values.astype(float)
        stddev_2nd = None
        if len(kt_ts) >= 3:
            d2_ts = np.diff(kt_ts, n=2)
            d2_ts = d2_ts[np.isfinite(d2_ts)]
            if len(d2_ts) >= 1:
                stddev_2nd = round(float(np.std(d2_ts)), 6)

        kt_az = pd.to_numeric(day["kt"], errors="coerce").values.astype(float)
        d2_curve = [None] * len(kt_az)
        if len(kt_az) >= 3:
            d2_vals = np.diff(kt_az, n=2)
            for j, v in enumerate(d2_vals, start=1):
                d2_curve[j] = round(float(v), 6) if np.isfinite(v) else None

        periods.append({
            "date": str(d),
            "azimuth": [round(float(v), 4) if np.isfinite(float(v)) else None for v in day["solar_azimuth"]],
            "zenith":  [round(float(v), 4) if np.isfinite(float(v)) else None for v in day["zenith"]],
            "kt":      [round(float(v), 5) if np.isfinite(float(v)) else None for v in day["kt"]],
            "rel_min": [round(float(v), 1) for v in rel_min],
            "d2_kt": d2_curve,
            "stddev_2nd": stddev_2nd,
        })

    kt_all = tmp["kt"].dropna()
    return {
        "label": label,
        "S": round(S, 6), "beta": round(beta, 4), "gamma": round(gamma, 3),
        "n_days": len(days), "n_points": len(tmp),
        "kt_median": round(float(kt_all.median()), 5) if len(kt_all) else None,
        "kt_std":    round(float(kt_all.std()), 5)    if len(kt_all) else None,
        "default_d2_threshold": round(float(KT_2ND_DERIV_STDDEV_MAX), 6),
        "periods": periods,
    }


# ═══════════════════════════════════════════════════════════════════════════
# HTML DASHBOARD
# ═══════════════════════════════════════════════════════════════════════════

def build_html_dashboard(stages: list, final_result: dict, output_path: str):
    """
    Interaktív HTML dashboard, minden iteráció k(t) görbéivel,
    az azimuth és zenit függvényében, plus végeredmény összefoglaló.
    """

    stages_json = json.dumps(stages, ensure_ascii=False)
    final_json  = json.dumps(final_result, ensure_ascii=False)

    html = f"""<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>GHI Kalibráció Dashboard</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
  :root {{
    --bg: #0f1117; --card: #1a1d2e; --border: #2a2d3e;
    --accent: #4f8ef7; --accent2: #f7c94f; --accent3: #4fdbf7;
    --text: #e2e8f0; --muted: #8892a4; --green: #4fdb8a; --red: #f76a6a;
  }}
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ background: var(--bg); color: var(--text); font-family: 'Segoe UI', system-ui, sans-serif; }}
  header {{
    padding: 1.5rem 2rem;
    background: linear-gradient(135deg, #1a1d2e 0%, #0f1117 100%);
    border-bottom: 1px solid var(--border);
    display: flex; align-items: center; gap: 1rem;
  }}
  header h1 {{ font-size: 1.4rem; font-weight: 700; color: var(--accent); }}
  header span {{ font-size: 0.85rem; color: var(--muted); }}
  .main {{ padding: 1.5rem 2rem; max-width: 1600px; margin: 0 auto; }}

  /* Result card */
  .result-grid {{
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 1rem; margin-bottom: 2rem;
  }}
  .kpi {{
    background: var(--card); border: 1px solid var(--border);
    border-radius: 12px; padding: 1.2rem; text-align: center;
  }}
  .kpi .label {{ font-size: 0.75rem; color: var(--muted); text-transform: uppercase; letter-spacing: 0.05em; }}
  .kpi .value {{ font-size: 1.8rem; font-weight: 700; margin-top: 0.3rem; }}
  .kpi .value.blue {{ color: var(--accent); }}
  .kpi .value.yellow {{ color: var(--accent2); }}
  .kpi .value.cyan {{ color: var(--accent3); }}
  .kpi .value.green {{ color: var(--green); }}

  /* Tabs */
  .tabs {{ display: flex; gap: 0.5rem; margin-bottom: 1rem; flex-wrap: wrap; }}
  .tab-btn {{
    padding: 0.5rem 1rem; border-radius: 8px; border: 1px solid var(--border);
    background: var(--card); color: var(--muted); cursor: pointer;
    font-size: 0.85rem; transition: all 0.15s;
  }}
  .tab-btn:hover {{ border-color: var(--accent); color: var(--text); }}
  .tab-btn.active {{ background: var(--accent); color: #fff; border-color: var(--accent); }}

  /* Chart cards */
  .chart-card {{
    background: var(--card); border: 1px solid var(--border);
    border-radius: 12px; padding: 1.2rem; margin-bottom: 1.5rem;
  }}
  .chart-card h3 {{ font-size: 1rem; margin-bottom: 0.8rem; color: var(--text); }}
  .chart-card .sub {{ font-size: 0.8rem; color: var(--muted); margin-bottom: 0.8rem; }}
  .chart-wrap {{ position: relative; width: 100%; height: 380px; }}
  canvas {{ width: 100% !important; height: 100% !important; }}

  .view {{ display: none; }}
  .view.active {{ display: block; }}

  /* Legend */
  .legend-grid {{
    display: flex; flex-wrap: wrap; gap: 0.5rem; margin-top: 0.5rem; font-size: 0.75rem;
  }}
  .legend-item {{ display: flex; align-items: center; gap: 0.3rem; }}
  .legend-dot {{ width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }}

  .two-col {{
    display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;
  }}
  @media (max-width: 900px) {{ .two-col {{ grid-template-columns: 1fr; }} }}

  .info-table {{ width: 100%; border-collapse: collapse; font-size: 0.85rem; }}
  .info-table td {{ padding: 0.4rem 0.8rem; border-bottom: 1px solid var(--border); }}
  .info-table tr:last-child td {{ border-bottom: none; }}
  .info-table td:first-child {{ color: var(--muted); width: 40%; }}
  .info-table td:last-child {{ font-weight: 600; }}
  .slider-row {{ display:flex; flex-wrap:wrap; align-items:center; gap:0.8rem; margin-bottom:0.9rem; }}
  .slider-row label {{ color: var(--muted); font-size: 0.82rem; }}
  .slider-row input[type=range] {{ width: 320px; }}
  .pill {{ display:inline-flex; align-items:center; gap:0.35rem; padding:0.28rem 0.65rem; border-radius:999px; border:1px solid var(--border); background:#141827; font-size:0.78rem; color:var(--text); }}
  .muted {{ color: var(--muted); }}
  .reject-list {{ margin-top:0.8rem; font-size:0.78rem; color:var(--muted); line-height:1.5; }}
</style>
</head>
<body>

<header>
  <div>
    <h1>🌞 GHI Kalibráció Dashboard</h1>
    <span>S × [DHI×F_diff_iam + DNI×cos(AOI)×IAM_beam] | Integrated tábla | ASTM G173-03 kA</span>
  </div>
</header>

<div class="main">

  <!-- KPI összefoglaló -->
  <div class="result-grid" id="kpiGrid"></div>

  <!-- Stage tabok -->
  <div class="tabs" id="stageTabs"></div>

  <!-- Stage view-k -->
  <div id="stageViews"></div>

</div>

<script>
const STAGES = {stages_json};
const FINAL  = {final_json};

// ── Színpaletta ──────────────────────────────────────────────────────────
const PALETTE = [
  '#4f8ef7','#f7c94f','#4fdbf7','#f76a6a','#4fdb8a','#c084fc',
  '#fb923c','#34d399','#f472b6','#60a5fa','#a3e635','#facc15',
  '#e879f9','#38bdf8','#86efac','#fda4af','#c4b5fd','#67e8f9',
  '#fbbf24','#6ee7b7','#a78bfa','#f87171','#2dd4bf','#fb7185',
];
function dayColor(i) {{ return PALETTE[i % PALETTE.length]; }}

// ── KPI ─────────────────────────────────────────────────────────────────
function renderKPI() {{
  const f = FINAL;
  const grid = document.getElementById('kpiGrid');
  const items = [
    {{ label: 'S (érzékenység)', value: f.S.toFixed(6), cls: 'blue' }},
    {{ label: 'β (szenzor tilt)', value: f.beta.toFixed(3) + '°', cls: 'yellow' }},
    {{ label: 'γ (tilt azimuth)', value: f.gamma.toFixed(1) + '°', cls: 'cyan' }},
    {{ label: 'RMSE [W/m²]', value: f.rmse.toFixed(2), cls: 'green' }},
    {{ label: 'k(t) medián', value: f.kt_median !== null ? f.kt_median.toFixed(4) : '-', cls: 'green' }},
    {{ label: 'k(t) std', value: f.kt_std !== null ? f.kt_std.toFixed(4) : '-', cls: '' }},
    {{ label: 'Felhasznált napok', value: f.n_days, cls: '' }},
    {{ label: 'Felhasznált pontok', value: f.n_points, cls: '' }},
    {{ label: 'F_diff_iam', value: f.F_diff_iam.toFixed(5), cls: '' }},
    {{ label: 'kA (ASTM G173)', value: f.kA.toFixed(5), cls: '' }},
  ];
  grid.innerHTML = items.map(it => `
    <div class="kpi">
      <div class="label">${{it.label}}</div>
      <div class="value ${{it.cls}}">${{it.value}}</div>
    </div>
  `).join('');
}}

// ── Tab váltás ────────────────────────────────────────────────────────────
function activateTab(idx) {{
  document.querySelectorAll('.tab-btn').forEach((b,i) => b.classList.toggle('active', i===idx));
  document.querySelectorAll('.view').forEach((v,i) => v.classList.toggle('active', i===idx));
}}

// ── Stage renderelés ──────────────────────────────────────────────────────
const chartRegistry = {{}};
const STAGE_STATE = {{}};

function destroyChart(id) {{
  if (chartRegistry[id]) {{ chartRegistry[id].destroy(); delete chartRegistry[id]; }}
}}

function finiteNumber(v) {{
  return v !== null && v !== undefined && Number.isFinite(v);
}}

function getThresholdForStage(stage) {{
  const key = stage.label || 'stage';
  if (!STAGE_STATE[key]) {{
    STAGE_STATE[key] = {{ threshold: Number(stage.default_d2_threshold ?? 0.0005) }};
  }}
  return Number(STAGE_STATE[key].threshold);
}}

function getFilteredPeriods(stage) {{
  const thr = getThresholdForStage(stage);
  const kept = [];
  const rejected = [];
  (stage.periods || []).forEach(p => {{
    const s = Number(p.stddev_2nd);
    if (Number.isFinite(s) && s <= thr) kept.push(p);
    else rejected.push(p);
  }});
  return {{ threshold: thr, kept, rejected }};
}}

function makeDatasets(periods, xKey, yKey='kt') {{
  return periods.map((p, i) => ({{
    label: `${{p.date}} | std2=${{finiteNumber(Number(p.stddev_2nd)) ? Number(p.stddev_2nd).toFixed(6) : 'n/a'}}`,
    data: (p[xKey] || [])
      .map((x, j) => ({{ x, y: (p[yKey] || [])[j] }}))
      .filter(pt => finiteNumber(pt.x) && finiteNumber(pt.y)),
    borderColor: dayColor(i),
    backgroundColor: dayColor(i) + '22',
    showLine: true,
    spanGaps: false,
    pointRadius: 1.5,
    pointHoverRadius: 3,
    borderWidth: 1.5,
    tension: 0.3,
    fill: false,
  }}));
}}

function buildRejectList(rejected) {{
  if (!rejected.length) return '<div class="reject-list">Nincs kiszűrt görbe ennél a küszöbnél.</div>';
  const txt = rejected
    .map(p => `${{p.date}} (${{finiteNumber(Number(p.stddev_2nd)) ? Number(p.stddev_2nd).toFixed(6) : 'n/a'}})`)
    .join(', ');
  return `<div class="reject-list"><strong>Kiszűrt görbék:</strong> ${{txt}}</div>`;
}}

function renderStageCharts(stage, containerId) {{
  const filt = getFilteredPeriods(stage);
  const periods = filt.kept;
  const statusEl = document.getElementById(containerId + '_d2status');
  const rejectEl = document.getElementById(containerId + '_rejects');
  if (statusEl) {{
    statusEl.innerHTML = `
      <span class="pill">küszöb: ${{filt.threshold.toFixed(6)}}</span>
      <span class="pill">megtartott: ${{periods.length}}</span>
      <span class="pill">kiszűrt: ${{filt.rejected.length}}</span>
    `;
  }}
  if (rejectEl) rejectEl.innerHTML = buildRejectList(filt.rejected);

  // ── 1. k(t) vs azimuth ─────────────────────────────────────────────────
  const azId = containerId + '_az';
  destroyChart(azId);
  const azCtx = document.getElementById(azId);
  if (azCtx) {{
    chartRegistry[azId] = new Chart(azCtx, {{
      type: 'scatter',
      data: {{ datasets: makeDatasets(periods, 'azimuth', 'kt') }},
      options: {{
        animation: false,
        responsive: true,
        maintainAspectRatio: false,
        plugins: {{ legend: {{ display: periods.length <= 20, position: 'right',
          labels: {{ color: '#8892a4', font: {{ size: 10 }} }} }},
          tooltip: {{ callbacks: {{ label: ctx => `${{ctx.dataset.label}}: kt=${{ctx.parsed.y?.toFixed(4)}} | az=${{ctx.parsed.x?.toFixed(1)}}°` }} }}
        }},
        scales: {{
          x: {{ title: {{ display: true, text: 'Solar azimuth [°]', color: '#8892a4' }},
               grid: {{ color: '#2a2d3e' }}, ticks: {{ color: '#8892a4' }} }},
          y: {{ title: {{ display: true, text: 'k(t)', color: '#8892a4' }},
               min: 0.80, max: 1.20, grid: {{ color: '#2a2d3e' }}, ticks: {{ color: '#8892a4' }} }},
        }},
      }},
      plugins: [{{
        id: 'hline',
        afterDraw(chart) {{
          const {{ ctx, chartArea, scales }} = chart;
          const y = scales.y.getPixelForValue(1.0);
          ctx.save();
          ctx.strokeStyle = '#f76a6a';
          ctx.lineWidth = 1;
          ctx.setLineDash([6,4]);
          ctx.beginPath(); ctx.moveTo(chartArea.left, y); ctx.lineTo(chartArea.right, y); ctx.stroke();
          ctx.restore();
        }}
      }}]
    }});
  }}

  // ── 2. k(t) vs zenit ───────────────────────────────────────────────────
  const znId = containerId + '_zn';
  destroyChart(znId);
  const znCtx = document.getElementById(znId);
  if (znCtx) {{
    chartRegistry[znId] = new Chart(znCtx, {{
      type: 'scatter',
      data: {{ datasets: makeDatasets(periods, 'zenith', 'kt') }},
      options: {{
        animation: false,
        responsive: true,
        maintainAspectRatio: false,
        plugins: {{ legend: {{ display: false }},
          tooltip: {{ callbacks: {{ label: ctx => `${{ctx.dataset.label}}: kt=${{ctx.parsed.y?.toFixed(4)}} | zen=${{ctx.parsed.x?.toFixed(1)}}°` }} }}
        }},
        scales: {{
          x: {{ title: {{ display: true, text: 'Zenit [°]', color: '#8892a4' }},
               grid: {{ color: '#2a2d3e' }}, ticks: {{ color: '#8892a4' }} }},
          y: {{ title: {{ display: true, text: 'k(t)', color: '#8892a4' }},
               min: 0.80, max: 1.20, grid: {{ color: '#2a2d3e' }}, ticks: {{ color: '#8892a4' }} }},
        }},
      }},
    }});
  }}

  // ── 3. k(t) solar noon körül (rel. perc) ───────────────────────────────
  const nmId = containerId + '_nm';
  destroyChart(nmId);
  const nmCtx = document.getElementById(nmId);
  if (nmCtx) {{
    chartRegistry[nmId] = new Chart(nmCtx, {{
      type: 'scatter',
      data: {{ datasets: makeDatasets(periods, 'rel_min', 'kt') }},
      options: {{
        animation: false,
        responsive: true,
        maintainAspectRatio: false,
        plugins: {{ legend: {{ display: false }},
          tooltip: {{ callbacks: {{ label: ctx => `${{ctx.dataset.label}}: kt=${{ctx.parsed.y?.toFixed(4)}} | +${{ctx.parsed.x?.toFixed(0)}} min` }} }}
        }},
        scales: {{
          x: {{ title: {{ display: true, text: 'Perc a solar noon körül [min]', color: '#8892a4' }},
               grid: {{ color: '#2a2d3e' }}, ticks: {{ color: '#8892a4' }} }},
          y: {{ title: {{ display: true, text: 'k(t)', color: '#8892a4' }},
               min: 0.80, max: 1.20, grid: {{ color: '#2a2d3e' }}, ticks: {{ color: '#8892a4' }} }},
        }},
      }},
    }});
  }}

  // ── 4. 2. derivált görbék ───────────────────────────────────────────────
  const d2Id = containerId + '_d2';
  destroyChart(d2Id);
  const d2Ctx = document.getElementById(d2Id);
  if (d2Ctx) {{
    chartRegistry[d2Id] = new Chart(d2Ctx, {{
      type: 'scatter',
      data: {{ datasets: makeDatasets(periods, 'rel_min', 'd2_kt') }},
      options: {{
        animation: false,
        responsive: true,
        maintainAspectRatio: false,
        plugins: {{ legend: {{ display: false }},
          tooltip: {{ callbacks: {{ label: ctx => `${{ctx.dataset.label}}: k''=${{ctx.parsed.y?.toFixed(6)}} | +${{ctx.parsed.x?.toFixed(0)}} min` }} }}
        }},
        scales: {{
          x: {{ title: {{ display: true, text: 'Perc a solar noon körül [min]', color: '#8892a4' }},
               grid: {{ color: '#2a2d3e' }}, ticks: {{ color: '#8892a4' }} }},
          y: {{ title: {{ display: true, text: 'k(t) 2. derivált (finite diff)', color: '#8892a4' }},
               grid: {{ color: '#2a2d3e' }}, ticks: {{ color: '#8892a4' }} }},
        }},
      }},
      plugins: [{{
        id: 'zeroLine',
        afterDraw(chart) {{
          const {{ ctx, chartArea, scales }} = chart;
          if (!scales.y) return;
          const y = scales.y.getPixelForValue(0.0);
          ctx.save();
          ctx.strokeStyle = '#f76a6a';
          ctx.lineWidth = 1;
          ctx.setLineDash([6,4]);
          ctx.beginPath(); ctx.moveTo(chartArea.left, y); ctx.lineTo(chartArea.right, y); ctx.stroke();
          ctx.restore();
        }}
      }}]
    }});
  }}
}}

function buildStageView(stage, idx) {{
  const vDiv = document.createElement('div');
  vDiv.className = 'view' + (idx === 0 ? ' active' : '');
  vDiv.id = 'view_' + idx;

  const defaultThr = Number(stage.default_d2_threshold ?? 0.0005);

  // Paraméter kártya
  const stageInfo = `
    <div class="chart-card" style="margin-bottom:1rem;">
      <h3>Stage paraméterek</h3>
      <div class="sub" style="margin-bottom:0.9rem;">Minden iterációban külön kiírva: tilt = β, tilt azimuth = γ</div>
      <table class="info-table">
        <tr><td>Label</td><td>${{stage.label}}</td></tr>
        <tr><td>S (érzékenység)</td><td>${{stage.S.toFixed(6)}}</td></tr>
        <tr><td>β (szenzor tilt)</td><td><strong>${{stage.beta.toFixed(4)}}°</strong></td></tr>
        <tr><td>γ (tilt azimuth)</td><td><strong>${{stage.gamma.toFixed(3)}}°</strong></td></tr>
        <tr><td>Napok száma</td><td>${{stage.n_days}}</td></tr>
        <tr><td>Pontok száma</td><td>${{stage.n_points}}</td></tr>
        <tr><td>k(t) medián</td><td>${{stage.kt_median !== null ? stage.kt_median.toFixed(5) : '-'}}</td></tr>
        <tr><td>k(t) std</td><td>${{stage.kt_std !== null ? stage.kt_std.toFixed(5) : '-'}}</td></tr>
        <tr><td>Default 2. derivált küszöb</td><td>${{defaultThr.toFixed(6)}}</td></tr>
      </table>
    </div>
  `;

  // Jelmagyarázat
  const legendItems = (stage.periods || []).slice(0, 30).map((p, i) =>
    `<div class="legend-item"><div class="legend-dot" style="background:${{dayColor(i)}}"></div>${{p.date}} | std2=${{finiteNumber(Number(p.stddev_2nd)) ? Number(p.stddev_2nd).toFixed(6) : 'n/a'}}</div>`
  ).join('');

  vDiv.innerHTML = stageInfo + `
    <div class="chart-card">
      <h3>2. derivált szűrés — interaktív küszöb</h3>
      <div class="sub">A csúszka mozgatására automatikusan kiszűri azokat a görbéket, ahol a 2. derivált STDDEV nagyobb a küszöbnél. A változás az összes alábbi ábrán azonnal látszik.</div>
      <div class="slider-row">
        <label for="view${{idx}}_d2thr">2. derivált STDDEV küszöb</label>
        <input id="view${{idx}}_d2thr" type="range" min="0.0001" max="0.0050" step="0.00005" value="${{defaultThr.toFixed(6)}}">
        <span class="pill" id="view${{idx}}_d2thr_value">${{defaultThr.toFixed(6)}}</span>
      </div>
      <div id="view${{idx}}_d2status" class="slider-row"></div>
      <div class="chart-wrap"><canvas id="view${{idx}}_d2"></canvas></div>
      <div id="view${{idx}}_rejects"></div>
    </div>
    <div class="chart-card">
      <h3>k(t) vs. Solar Azimuth</h3>
      <div class="sub">Minden periódus egy ábrán — azimuth tengelyen | referencia: piros szaggatott = 1.0 | β=${{stage.beta.toFixed(3)}}° | γ=${{stage.gamma.toFixed(3)}}°</div>
      <div class="chart-wrap"><canvas id="view${{idx}}_az"></canvas></div>
      <div class="legend-grid" style="margin-top:0.5rem">${{legendItems}}</div>
    </div>
    <div class="two-col">
      <div class="chart-card">
        <h3>k(t) vs. Zenit</h3>
        <div class="sub">Zenit szög függvényében (szűrési tartomány: 0–70°)</div>
        <div class="chart-wrap"><canvas id="view${{idx}}_zn"></canvas></div>
      </div>
      <div class="chart-card">
        <h3>k(t) — Solar noon körül</h3>
        <div class="sub">Relatív percek a solar noon-tól (szimmetria ellenőrzés)</div>
        <div class="chart-wrap"><canvas id="view${{idx}}_nm"></canvas></div>
      </div>
    </div>
  `;

  setTimeout(() => {{
    const slider = document.getElementById(`view${{idx}}_d2thr`);
    const valueEl = document.getElementById(`view${{idx}}_d2thr_value`);
    if (slider && valueEl) {{
      const sync = () => {{
        const v = Number(slider.value);
        valueEl.textContent = v.toFixed(6);
        const key = stage.label || 'stage';
        if (!STAGE_STATE[key]) STAGE_STATE[key] = {{ threshold: v }};
        STAGE_STATE[key].threshold = v;
        renderStageCharts(stage, 'view' + idx);
      }};
      slider.addEventListener('input', sync);
      slider.addEventListener('change', sync);
    }}
  }}, 0);

  return vDiv;
}}

// ── Fő renderelés ──────────────────────────────────────────────────────────
function init() {{
  renderKPI();

  const tabsEl  = document.getElementById('stageTabs');
  const viewsEl = document.getElementById('stageViews');

  STAGES.forEach((stage, idx) => {{
    // Tab gomb
    const btn = document.createElement('button');
    btn.className = 'tab-btn' + (idx === 0 ? ' active' : '');
    btn.textContent = `${{stage.label}} | β=${{stage.beta.toFixed(2)}}° | γ=${{stage.gamma.toFixed(1)}}°`;
    btn.onclick = () => {{
      activateTab(idx);
      renderStageCharts(stage, 'view' + idx);
    }};
    tabsEl.appendChild(btn);

    // View
    const vDiv = buildStageView(stage, idx);
    viewsEl.appendChild(vDiv);
  }});

  // Első stage renderelése
  if (STAGES.length > 0) {{
    renderStageCharts(STAGES[0], 'view0');
  }}
}}

document.addEventListener('DOMContentLoaded', init);
</script>
</body>
</html>"""

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"  ✓ HTML dashboard mentve: {output_path}")


# ═══════════════════════════════════════════════════════════════════════════
# MAIN PIPELINE
# ═══════════════════════════════════════════════════════════════════════════

def main():
    print("█" * 70)
    print("██  GHI KALIBRÁCIÓ OPTIMALIZÁLÓ v3 — INTEGRATED TABLE")
    print(f"██  kA={_KA:.5f}  |  F_diffuse_iam={F_DIFF_IAM:.6f}")
    print(f"██  INTEGRATED_TABLE = {INTEGRATED_TABLE}")
    print(f"██  SPECTRAL_TABLE   = {SPECTRAL_TABLE}")
    print("█" * 70)

    outdir = "/opt/app-root/src/smarts_clearsky_model"
    os.makedirs(outdir, exist_ok=True)

    # ── 1. INTEGRATED tábla betöltés ──
    print("\n" + "=" * 70); print("1. INTEGRATED TÁBLA BETÖLTÉS"); print("=" * 70)
    conn = _get_main_conn()
    avail_cols = _fetch_table_columns(conn, INTEGRATED_TABLE)
    col_info   = _find_integrated_cols(avail_cols)
    df_int     = load_integrated_data(conn, col_info)
    conn.close()

    # ── 2. DNI/DHI — elsőként spektrális tábla ──
    print("\n" + "=" * 70); print("2. DNI/DHI BETÖLTÉS (spektrális SR×kA)"); print("=" * 70)
    df_spec_dnidhI = pd.DataFrame(columns=["timestamp", "dni_srka", "dhi_srka"])
    try:
        df_spec_dnidhI = load_spectral_dni_dhi()
    except Exception as e:
        print(f"  [WARN] Spektrális DNI/DHI hiba: {e}")
        traceback.print_exc()

    # ── MERGE: integrated GHI + spektrális DNI/DHI ──
    print("\n  Merge: integrated GHI + spektrális DNI/DHI...")
    df_int = df_int.sort_values("timestamp").copy()

    if len(df_spec_dnidhI) > 0:
        df_spec_dnidhI = df_spec_dnidhI.sort_values("timestamp").copy()
        # Interpoláljuk a spektrális DNI/DHI-t az integrated időbélyegekre
        idx_int = pd.DatetimeIndex(df_int["timestamp"])

        dni_interp = _interp_time_inside(
            df_spec_dnidhI.set_index("timestamp")["dni_srka"], idx_int)
        dhi_interp = _interp_time_inside(
            df_spec_dnidhI.set_index("timestamp")["dhi_srka"], idx_int)

        df_int["dni_srka"] = dni_interp.values
        df_int["dhi_srka"] = dhi_interp.values
        n_ok = df_int[["dni_srka", "dhi_srka"]].notna().all(axis=1).sum()
        print(f"  Spektrális DNI/DHI merge: {n_ok}/{len(df_int)} sor van értékkel")
    else:
        df_int["dni_srka"] = np.nan
        df_int["dhi_srka"] = np.nan
        print("  Nincs spektrális DNI/DHI — napállás után fallback becslés következik")

    # ── 3. MÉRT GHI ──
    print("\n" + "=" * 70); print("3. MÉRT GHI (IMT14)"); print("=" * 70)
    df_meas = load_measured_ghi()

    # MERGE mért GHI → integrated timestamp-ekre
    idx_int = pd.DatetimeIndex(df_int["timestamp"])
    ghi_interp = _interp_time_inside(
        df_meas.set_index("timestamp")["ghi_measured"], idx_int)
    df_int["ghi_measured"] = ghi_interp.values
    df_int = df_int.dropna(subset=["ghi_measured", "ghi_srka"]).copy()
    print(f"  Mért GHI merge: {len(df_int)} sor")

    # ── 4. NAPÁLLÁS ──
    print("\n" + "=" * 70); print("4. NAPÁLLÁS"); print("=" * 70)
    df_int = add_solar_positions(df_int)

    # Fallback DNI/DHI ha spektrális nem volt
    if df_int["dni_srka"].isna().all():
        print("  Fallback DNI/DHI becslés integrated beam+diff alapján...")
        df_int = derive_dni_dhi_from_integrated(df_int, col_info)

    df_int = df_int.dropna(subset=["dni_srka", "dhi_srka"]).copy()
    print(f"  Érvényes sorok DNI/DHI után: {len(df_int)}")

    if len(df_int) < 100:
        print("HIBA: Túl kevés adat a szűrések után!"); return 1

    # ── 5. SZŰRÉSEK ──
    print("\n" + "=" * 70); print("5. SZŰRÉSEK (clearsky, noon, szimmetria)"); print("=" * 70)
    df, noon_info = filter_data(df_int)
    if len(df) < 100:
        print("HIBA: Túl kevés adat!"); return 1

    stages = []  # dashboard stage-ek gyűjtője

    # ── 6. BASELINE k(t) (stage-0) ──
    print("\n" + "=" * 70); print("6. BASELINE k(t) — optimalizálás előtt"); print("=" * 70)
    stages.append(_kt_stage_json(df, 1.0, 0.0, 180.0, "Stage-0: Baseline (S=1, β=0, γ=180)"))

    # ── 7. 1. OPTIMALIZÁCIÓ ──
    print("\n" + "=" * 70); print("7. 1. OPTIMALIZÁCIÓ"); print("=" * 70)
    S1, b1, g1, rmse1 = optimize_s_beta_gamma(df, "1.")
    stages.append(_kt_stage_json(df, S1, b1, g1,
                                 f"Stage-1: 1. optim. S={S1:.4f}, β={b1:.3f}°, γ={g1:.1f}°"))

    # ── 8. OUTLIER SZŰRÉS ──
    print("\n" + "=" * 70); print("8. OUTLIER NAP SZŰRÉS"); print("=" * 70)
    df = filter_outlier_days(df, [S1, b1, g1])
    if len(df) < 100:
        print("HIBA: Túl kevés adat outlier szűrés után!"); return 1
    stages.append(_kt_stage_json(df, S1, b1, g1,
                                 f"Stage-2: Outlier szűrés után (Stage-1 paraméterekkel)"))

    # ── 9. 2. OPTIMALIZÁCIÓ ──
    print("\n" + "=" * 70); print("9. 2. OPTIMALIZÁCIÓ"); print("=" * 70)
    S2, b2, g2, rmse2 = optimize_s_beta_gamma(df, "2.")
    stages.append(_kt_stage_json(df, S2, b2, g2,
                                 f"Stage-3: 2. optim. S={S2:.4f}, β={b2:.3f}°, γ={g2:.1f}°"))

    # ── 10. k(t) 2nd derivált szűrés ──
    print("\n" + "=" * 70); print("10. k(t) 2ND DERIVÁLT SZŰRÉS"); print("=" * 70)
    df_refined, kept_dates, deriv_stats = filter_kt_by_2nd_deriv(df, S2, b2, g2, noon_info)
    if len(df_refined) < 50:
        print("  [WARN] 2nd derivált szűrés után túl kevés adat — nem szűrünk")
        df_refined = df
    stages.append(_kt_stage_json(df_refined, S2, b2, g2,
                                 f"Stage-4: 2nd derivált szűrés ({len(kept_dates)} nap)"))

    # ── 11. FINOMÍTÓ 3. OPTIMALIZÁCIÓ ──
    print("\n" + "=" * 70); print("11. 3. FINOMÍTÓ OPTIMALIZÁCIÓ"); print("=" * 70)
    S_opt, b_opt, g_opt, rmse_opt = optimize_s_beta_gamma(df_refined, "3. (finomító)")
    stages.append(_kt_stage_json(df_refined, S_opt, b_opt, g_opt,
                                 f"Stage-5: VÉGSŐ S={S_opt:.4f}, β={b_opt:.3f}°, γ={g_opt:.1f}°"))

    # ── 12. VÉGSŐ k(t) ──
    print("\n" + "=" * 70); print("12. VÉGSŐ k(t) SZÁMÍTÁS"); print("=" * 70)
    df_final = compute_kt_frame(df_refined, S_opt, b_opt, g_opt)
    kt_vals  = df_final["kt"].dropna()
    print(f"  k(t) medián: {kt_vals.median():.5f}")
    print(f"  k(t) std:    {kt_vals.std():.5f}")
    print(f"  k(t) min:    {kt_vals.min():.5f}")
    print(f"  k(t) max:    {kt_vals.max():.5f}")

    # ── 13. CSV ──
    csv_path = os.path.join(outdir, "ghi_calibration_result.csv")
    out_cols = ["timestamp", "ghi_measured", "ghi_model", "kt", "ratio",
                "ghi_srka", "dni_srka", "dhi_srka",
                "zenith", "solar_azimuth", "clearness_idx", "date"]
    out_cols = [c for c in out_cols if c in df_final.columns]
    df_final[out_cols].to_csv(csv_path, index=False)
    print(f"\n  ✓ CSV: {csv_path}")

    # ── 14. HTML DASHBOARD ──
    print("\n" + "=" * 70); print("14. HTML DASHBOARD"); print("=" * 70)
    final_result = {
        "S": S_opt, "beta": b_opt, "gamma": g_opt, "rmse": rmse_opt,
        "kt_median": float(kt_vals.median()) if len(kt_vals) else None,
        "kt_std":    float(kt_vals.std())    if len(kt_vals) else None,
        "n_days":    int(df_final["date"].nunique()),
        "n_points":  int(len(df_final)),
        "F_diff_iam": F_DIFF_IAM,
        "kA": _KA,
    }
    html_path = os.path.join(outdir, "ghi_calibration_dashboard.html")
    build_html_dashboard(stages, final_result, html_path)

    # ── VÉGEREDMÉNY ──
    print("\n" + "█" * 70)
    print("██  VÉGEREDMÉNY")
    print("█" * 70)
    print(f"██  S (sensitivity):    {S_opt:.6f}")
    print(f"██  β (szenzor tilt):   {b_opt:.4f}°")
    print(f"██  γ (tilt azimuth):   {g_opt:.3f}°")
    print(f"██  RMSE:               {rmse_opt:.3f} W/m²")
    print(f"██  k(t) medián:        {kt_vals.median():.5f}")
    print(f"██  k(t) std:           {kt_vals.std():.5f}")
    print(f"██  Felhasznált napok:  {df_final['date'].nunique()}")
    print(f"██  Felhasznált pontok: {len(df_final)}")
    print(f"██  F_diffuse_iam:      {F_DIFF_IAM:.6f}")
    print(f"██  kA (ASTM G173-03): {_KA:.6f}")
    print("█" * 70)
    if abs(b_opt) < 0.3:
        print(f"  → β ≈ 0° → NEM szinuszos → csak S érzékenység hiba")
    else:
        print(f"  → β = {b_opt:.2f}° → SZINUSZOS k(t)")
        print(f"  → Amplitúdó (tilt): {abs(b_opt):.2f}°")
        print(f"  → Fázis (azimuth):  {g_opt:.1f}°")
    print(f"\n  Dashboard: {html_path}")
    print(f"  CSV:       {csv_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
