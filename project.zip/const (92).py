from __future__ import annotations

import os
import sys
import logging
from datetime import time as dt_time
from pathlib import Path
from typing import List, Tuple

# --- Measured GHI (CSV) ---
MEASURED_CSV       = Path("/opt/app-root/src/jupyter_notebook/clear_sky_with_measured_output_Kalman_pw.csv")
MEASURED_TIME_COL  = "timestamp"
MEASURED_GHI_COL   = "measured_irradiance_sensor.tvl9_imt_14_irrad"
# CAMS aerosol extinction multilevel tábla (valid_time timestamp)
CAMS_AERO_EXT_TABLE = "aerosol_extinction_coefficients_multilevel"
# DB beállítások
DB_HOST = "172.16.41.11"
DB_PORT = 5432
DB_NAME = "kristof"
DB_USER = "levente"
DB_TABLE = "public.smarts_input_data"
CAMS_VIEW = "public.cams_spectrl2_view"  # ← már megvan
COMBINED_GAS_TABLE = "combined_gas"      # ← ÚJ
CAMS_AERO_EXT_VIEW = "aerosol_extinction_view"
DB_PWD_CACHE = "titkos"
TABLE_MINIMAL_SMARTS = "public.smarts_igas1_iload0_bucket10s_denoise_v1"

# Central API
CENTRAL_BASE_URL = "https://central.energia.ulx.hu"
CENTRAL_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJjYjI3NDMzYzAyNjM0MjZjYTYxODVlMjk0YmMwOWIwYSIsImlhdCI6MTc2MzA2NTA4MSwiZXhwIjoyMDc4NDI1MDgxfQ.TanBcWl3udUnt1qCtHoBbl1JSFp4W7rGQdRlcEOIqiw"


# Central DB (közvetlen PostgreSQL) — env-ből jön a futtatóscriptből
CENTRAL_DB_HOST     = os.getenv("CENTRAL_DB_HOST", "em-central-db.ulx.hu")
CENTRAL_DB_HOSTS    = os.getenv("CENTRAL_DB_HOSTS", "em-central-db.ulx.hu,em-central-db,172.16.41.11").split(",")
CENTRAL_DB_PORT     = int(os.getenv("CENTRAL_DB_PORT", "5432"))
CENTRAL_DB_NAME     = os.getenv("CENTRAL_DB_NAME", "emr-db")
CENTRAL_DB_USER     = os.getenv("CENTRAL_DB_USER", "levente")
CENTRAL_DB_PASSWORD = os.getenv("CENTRAL_DB_PASSWORD", "sk7whN!xLLjGQjrBa3aT")
CENTRAL_DB_SSLMODE  = os.getenv("CENTRAL_DB_SSLMODE", "require")

# AOD számítás (PyMieScatt + Approx, debug nélkül)
# -----------------------------
# ======================= LOGGING =======================
LOG_PATH = Path("/opt/app-root/src/gascomparison.log")

LOGGER = logging.getLogger("gascomparison")
LOGGER.setLevel(logging.INFO)

if not LOGGER.handlers:
    fh = logging.FileHandler(LOG_PATH, mode="w", encoding="utf-8")
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")
    fh.setFormatter(fmt)

    LOGGER.addHandler(fh)

# ======================= KONFIGURÁCIÓ =======================
TEST_PERIODS : List[Tuple[str, str]] = [
    ("2025-08-10 04:19:44.002+00:00", "2025-08-10 10:02:07.588+00:00")
]
# Nappali periódus korlátok (UTC)
DAY_START_UTC = dt_time(5, 40)   # 05:40 UTC
DAY_END_UTC   = dt_time(17, 30)  # 17:30 UTC
# Új CAMS tábla
CAMS_ATM_DATA_TABLE = "public.cams_atm_data"

# --- STRING TILTEK (kérés szerint) ---
STRING0_TILT_DEG = 12.25
STRING1_TILT_DEG = 15.45

# Measured GHI entity (IMT14)
MEASURED_ENTITY_ID = "sensor.tvl9_imt_14_irrad"

PM_COLS = [
    "sensor.tvl9_o_1pst_pm10",
    "sensor.tvl9_o_1pst_pm2_5",
    "sensor.tvl9_o_1pst_pm1",
    "sensor.tvl9_o_1pst_pm0_3",
]
CENTRAL_COLS = PM_COLS + [
    "sensor.tvl9_gw2000a_humidity",
    "sensor.tvl9_gw2000a_outdoor_temperature",
    "sensor.tvl9_o_1pst_carbon_dioxide",
    "sensor.tvl9_o_1pst_nox_index",
    "sensor.tvl9_gw2000a_relative_pressure",
    "sensor.tvl9_imt_14_irrad",
]
# Backward compatible alias (loaders.py uses this name)
CENTRAL_ENTITY_IDS = CENTRAL_COLS



# Open-Meteo CSV
OPENMETEO_CSV = "/opt/app-root/src/jupyter_notebook/open-meteo-47.50N19.00E113m (1).csv"

# Periódusok – csak 2025-08-13
# Periódusok – FIX lista (kérés szerint)
# Periódusok – 2025. október-november
# Periódusok – FIX lista (kérés szerint)
PROD_PERIODS: List[Tuple[str, str]] = [
# Átnézendő
    # 2025 AUGUSZTUS
    ("2026-03-09 05:48:43.360+00:00", "2026-03-09 11:10:14.231+00:00"),


]




TEST_FLAG = "--test"

USER_PARAM_LIST = sys.argv[1:]

PERIODS = TEST_PERIODS if TEST_FLAG in USER_PARAM_LIST else PROD_PERIODS


# Alapvető konstansok
EPS = 1e-15
DEBUG = True

# Helyszín
DEFAULT_LAT = 47.4979
DEFAULT_LON = 19.0402
DEFAULT_ALT_KM = 0.102

PANEL_TILT = 0.0
PANEL_AZIMUTH = 180.0

# --- ÚJ: string tiltek (kérésed szerint) ---
STRING0_TILT_DEG = 12.25
STRING1_TILT_DEG = 15.45

# --- ÚJ: SMARTS IOUT kódok (SMARTS manual alapján) ---
# 2: direct normal (DNI), 3: diffuse horizontal (DHI), 4: global horizontal (GHI), 5: direct horizontal
IOUT_0TILT_GHI_DNI_DHI = [4, 2, 3, 5]

# 6: direct tilted, 7: diffuse tilted  (beam + diffuse a tilt síkban)
IOUT_TILT_BEAM_DIFFUSE = [6, 7]


# SMARTS
SMARTS_DIR = Path(os.getenv("SMARTS_DIR", "/opt/app-root/src/jupyter_notebook/SMARTS_295_Linux")).resolve()
SMARTS_TIMEOUT = 90
WLMIN, WLMAX = 350.0, 1200.0
PRINT_STEP_NM = 1.0
IPRT_MODE = 2
IOTOT, IOUT = 1, 4

# Fizikai korlátok
DEFAULT_CO2_PPM = 420.0
ALBEDO_CLAMP = (0.00, 0.95)
SSA_CLAMP    = (0.60, 1.00)
GG_CLAMP     = (0.45, 0.95)
ALPHA_CLAMP  = (0.00, 3.00)
TAU550_CLAMP = (0.00, 5.00)
SPR_VALID    = (0.4, 1100.0)
SUN_MIN_ELEV_DEG = 5.0

# BLH minimum – KÉRTED, HOGY MARADJON
BLH_MIN_M = 0.0

# ======================= ECMWF L137 KOEFFICIENSEK (105-137 szintek) =======================
# Forrás: https://confluence.ecmwf.int/display/UDOC/L137+model+level+definitions
# A félszint (half-level) a és b koefficiensek
# Index: 105 → 137 (33 layer), plusz a 104-es félszint a tetőhöz
# P(k+1/2) = a(k+1/2) + b(k+1/2) * P_surface

ECMWF_L137_COEFFS = {
    # level: (a [Pa], b [dimensionless])
    0:   (0.000000, 0.000000),
    1:   (2.000365, 0.000000),
    2:   (3.102241, 0.000000),
    3:   (4.666084, 0.000000),
    4:   (6.827977, 0.000000),
    5:   (9.746966, 0.000000),
    6:   (13.605424, 0.000000),
    7:   (18.608931, 0.000000),
    8:   (24.985718, 0.000000),
    9:   (32.985710, 0.000000),
    10:  (42.879242, 0.000000),
    11:  (54.955463, 0.000000),
    12:  (69.520576, 0.000000),
    13:  (86.895882, 0.000000),
    14:  (107.415741, 0.000000),
    15:  (131.425507, 0.000000),
    16:  (159.279404, 0.000000),
    17:  (191.338562, 0.000000),
    18:  (227.968948, 0.000000),
    19:  (269.539581, 0.000000),
    20:  (316.420746, 0.000000),
    21:  (368.982361, 0.000000),
    22:  (427.592499, 0.000000),
    23:  (492.616028, 0.000000),
    24:  (564.413452, 0.000000),
    25:  (643.339905, 0.000000),
    26:  (729.744141, 0.000000),
    27:  (823.967834, 0.000000),
    28:  (926.344910, 0.000000),
    29:  (1037.201172, 0.000000),
    30:  (1156.853638, 0.000000),
    31:  (1285.610352, 0.000000),
    32:  (1423.770142, 0.000000),
    33:  (1571.622925, 0.000000),
    34:  (1729.448975, 0.000000),
    35:  (1897.519287, 0.000000),
    36:  (2076.095947, 0.000000),
    37:  (2265.431641, 0.000000),
    38:  (2465.770508, 0.000000),
    39:  (2677.348145, 0.000000),
    40:  (2900.391357, 0.000000),
    41:  (3135.119385, 0.000000),
    42:  (3381.743652, 0.000000),
    43:  (3640.468262, 0.000000),
    44:  (3911.490479, 0.000000),
    45:  (4194.930664, 0.000000),
    46:  (4490.817383, 0.000000),
    47:  (4799.149414, 0.000000),
    48:  (5119.895020, 0.000000),
    49:  (5452.990723, 0.000000),
    50:  (5798.344727, 0.000000),
    51:  (6156.074219, 0.000000),
    52:  (6526.946777, 0.000000),
    53:  (6911.870605, 0.000000),
    54:  (7311.869141, 0.000000),
    55:  (7727.412109, 0.000007),
    56:  (8159.354004, 0.000024),
    57:  (8608.525391, 0.000059),
    58:  (9076.400391, 0.000112),
    59:  (9562.682617, 0.000199),
    60:  (10065.978516, 0.000340),
    61:  (10584.631836, 0.000562),
    62:  (11116.662109, 0.000890),
    63:  (11660.067383, 0.001353),
    64:  (12211.547852, 0.001992),
    65:  (12766.873047, 0.002857),
    66:  (13324.668945, 0.003971),
    67:  (13881.331055, 0.005378),
    68:  (14432.139648, 0.007133),
    69:  (14975.615234, 0.009261),
    70:  (15508.256836, 0.011806),
    71:  (16026.115234, 0.014816),
    72:  (16527.322266, 0.018318),
    73:  (17008.789063, 0.022355),
    74:  (17467.613281, 0.026964),
    75:  (17901.621094, 0.032176),
    76:  (18308.433594, 0.038026),
    77:  (18685.718750, 0.044548),
    78:  (19031.289063, 0.051773),
    79:  (19343.511719, 0.059728),
    80:  (19620.042969, 0.068448),
    81:  (19859.390625, 0.077958),
    82:  (20059.931641, 0.088286),
    83:  (20219.664063, 0.099462),
    84:  (20337.863281, 0.111505),
    85:  (20412.308594, 0.124448),
    86:  (20442.078125, 0.138313),
    87:  (20425.718750, 0.153125),
    88:  (20361.816406, 0.168910),
    89:  (20249.511719, 0.185689),
    90:  (20087.085938, 0.203491),
    91:  (19874.025391, 0.222333),
    92:  (19608.572266, 0.242244),
    93:  (19290.226563, 0.263242),
    94:  (18917.460938, 0.285354),
    95:  (18489.707031, 0.308598),
    96:  (18006.925781, 0.332939),
    97:  (17471.839844, 0.358254),
    98:  (16888.687500, 0.384363),
    99:  (16262.046875, 0.411125),
    100: (15596.695313, 0.438391),
    101: (14898.453125, 0.466003),
    102: (14173.324219, 0.493800),
    103: (13427.769531, 0.521619),
    # --- 104-138: eredeti értékek (a korábbi const.py-ból) ---
    104: (12668.257813, 0.549301),
    105: (11901.339844, 0.576692),
    106: (11133.304688, 0.603648),
    107: (10370.175781, 0.630036),
    108: (9617.515625,  0.655736),
    109: (8880.453125,  0.680643),
    110: (8163.375000,  0.704669),
    111: (7470.343750,  0.727739),
    112: (6804.421875,  0.749797),
    113: (6168.531250,  0.770798),
    114: (5564.382813,  0.790717),
    115: (4993.796875,  0.809536),
    116: (4457.375000,  0.827256),
    117: (3955.960938,  0.843881),
    118: (3489.234375,  0.859432),
    119: (3057.265625,  0.873929),
    120: (2659.140625,  0.887408),
    121: (2294.242188,  0.899900),
    122: (1961.500000,  0.911448),
    123: (1659.476563,  0.922096),
    124: (1387.546875,  0.931881),
    125: (1143.250000,  0.940860),
    126: (926.507813,   0.949064),
    127: (734.992188,   0.956550),
    128: (568.062500,   0.963352),
    129: (424.414063,   0.969513),
    130: (302.476563,   0.975078),
    131: (202.484375,   0.980072),
    132: (122.101563,   0.984542),
    133: (62.781250,    0.988500),
    134: (22.835938,    0.991984),
    135: (3.757813,     0.995003),
    136: (0.000000,     0.997630),
    137: (0.000000,     1.000000),
    138: (0.0,          1.0), 
}

# Fizikai konstansok
R_DRY = 287.058      # J/(kg·K) - száraz levegő gázállandója
G_ACCEL = 9.80665    # m/s² - gravitációs gyorsulás
M_AIR = 28.97        # g/mol - száraz levegő átlagos móltömege

# Gázok móltömegei (g/mol) - kibővítve
MOLAR_MASS_EXTENDED = {
    "CH4": 16.04,
    "CO": 28.01,
    "O3": 48.00,
    "HCHO": 30.03,   # CH2O
    "HNO3": 63.01,
    "NO": 30.01,
    "NO2": 46.01,
    "SO2": 64.07,
    "HNO2": 47.01,
    "NO3": 62.00,
}

# cams_data tábla neve
CAMS_LAYERED_TABLE = "cams_data"

# AM1.5 denormálás (RMSE)
AM15_TARGET = 1.5
AM15_TOL    = 0.10  # ±0.10 AM tolerancia

# SR(λ) - IMT szenzor
SR_POINTS =  {
350: 0.000,
360: 0.052,
370: 0.156,
380: 0.288,
390: 0.379,
400: 0.426,
410: 0.456,
420: 0.476,
430: 0.490,
440: 0.503,
450: 0.522,
460: 0.535,
470: 0.549,
480: 0.562,
490: 0.576,
500: 0.590,
510: 0.601,
520: 0.615,
530: 0.626,
540: 0.639,
550: 0.651,
560: 0.662,
570: 0.676,
580: 0.687,
590: 0.698,
600: 0.710,
610: 0.721,
620: 0.732,
630: 0.744,
640: 0.753,
650: 0.764,
660: 0.776,
670: 0.785,
680: 0.794,
690: 0.803,
700: 0.814,
710: 0.823,
720: 0.832,
730: 0.841,
740: 0.850,
750: 0.859,
760: 0.868,
770: 0.878,
780: 0.887,
790: 0.898,
800: 0.905,
810: 0.914,
820: 0.923,
830: 0.932,
840: 0.941,
850: 0.948,
860: 0.957,
870: 0.966,
880: 0.973,
890: 0.980,
900: 0.986,
910: 0.991,
920: 0.993,
930: 0.993,
940: 0.993,
950: 0.995,
960: 0.998,
970: 1.000,
980: 0.995,
990: 0.984,
1000: 0.973,
1010: 0.955,
1020: 0.932,
1030: 0.905,
1040: 0.871,
1050: 0.825,
1060: 0.771,
1070: 0.703,
1080: 0.619,
1090: 0.544,
1100: 0.481,
1110: 0.415,
1120: 0.356,
1130: 0.293,
1140: 0.236,
1150: 0.188,
1160: 0.143,
1170: 0.100,
1180: 0.063,
1190: 0.034,
1200: 0.014,
}

# IAM korrekció (CubicSpline)
IAM_POINTS = {
    0: 1.00, 5: 1.00, 10: 1.00, 15: 1.00, 20: 1.00, 25: 0.995,
    30: 0.988, 35: 0.986, 40: 0.980, 45: 0.976, 50: 0.970,
    55: 0.960, 60: 0.933, 65: 0.921, 70: 0.877, 75: 0.819,
    80: 0.711, 85: 0.546, 90: 0.00
}

# Gázok mólsúlyok (g/mol)
MOLAR_MASS = {
    "CO":   28.01,
    "NO":   30.01,
    "NO2":  46.01,
    "O3":   48.00,
    "SO2":  64.07,
    "HNO3": 63.01,
    "CH2O": 30.03,
    "CH4":  16.04,
    "NH3":  17.03,
    "HNO2": 47.01,  # H(1) + N(14) + 2*O(16)
    "NO3":  62.00,  # N(14) + 3*O(16)
}


# Kalman PW paraméterek (BESTSMARTS ipynb)
P_PW_CONST = 0.35 ** 2
P_WV_START, P_WV_END = 0.04, 0.09
DROP_EWM_HALFLIFE_H = 0.5
EARLY_HOURS_CUTOFF  = 2.0
EARLY_DIFF_THRESH   = 0.20
EARLY_PENALTY_ALPHA = 0.30
USE_EARLY_PENALTY   = True
STEP_REF_CM   = 0.25
JUMP_VAR_BETA = 3.0
JUMP_GATE_ETA = 2.0
BIAS_EWM_HALFLIFE_MIN = 60
BIAS_THRESH_CM = 0.20
BIAS_ALPHA     = 0.80
BIAS_MIN_FACTOR = 0.40

# Kalman AOD paraméterek
KALMAN_Q      = 5e-4
KALMAN_R_PMS  = 7e-4
KALMAN_R_CAMS = 2.0e-3

# ===== KÍSÉRLETI KAPCSOLÓK – MOSTANTÓL TÉNYLEG HASZNÁLJUK ŐKET =====
EXP_REF_SPECTRUM_MODE = "global"   # "global"/"direct"
EXP_SMOOTH_NOON_JUMP  = True       # CAMS AOD déli ugrás simítása (rolling median w=5)
EXP_USE_SKYLINE_CORR  = True       # skyline korrekció mért GHI-re (ha van maszk)
EXP_IAM_SCALE         = 1.00       # IAM szimmetrikus skála (utólag a spline-ra)
EXP_RESID_DIAG        = True       # reziduum-diagnosztika CSV mentés
# ===== FIX SKÁLÁK (nincs illesztés) =====
USE_FIXED_SCALES = True          # ha True, NEM hívunk optimalizálót
FIXED_kA = 0.5811                # AM denormalizáló/felskálázó faktor (fix)


# Illesztési szűrések és robusztusítás
PAIR_TOLERANCE_S = 60              # mért–modell párosítási tolerancia (s)
FIT_MIN_GHI      = 150.0           # W/m² – ennél kisebb mért GHI nem megy az illesztésbe
FIT_MIN_ELEV     = 10.0            # deg – legalább ennyi napmagasság az illesztéshez
FIT_MAX_AOI      = 75.0            # deg – IAM bizonytalanság elkerülésére
COSZ_POW         = 2.0             # cosZ súlyozás hatványa
HUBER_DELTA      = 80.0            # W/m² – Huber küszöb robusztus súlyozáshoz
IRLS_ITERS       = 4               # IRLS iterációk száma
