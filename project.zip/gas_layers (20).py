from __future__ import annotations

from typing import Optional, Tuple
import numpy as np
import pandas as pd

from const import *   
import helpers   

CAMS_GAS_ORDER = [
    # Nem kivonandók (nincs háttér)
    "HNO3",   # 1. futás
    "NO",     # 2. futás
    "NO2",    # 3. futás
    "SO2",    # 4. futás
    # Kivonandók (növekvő háttér szerint)
    "CH2O",   # 5. futás - háttér: 0.003
    "O3",     # 6. futás - háttér: 0.03
    "CO",     # 7. futás - háttér: 0.1
    "CH4",    # 8. futás - háttér: 1.8 (legnagyobb, UTOLSÓ!)
]

# Mapping: SMARTS gáznév → CAMS Ap oszlopnév
CAMS_AP_COLUMN_MAP = {
    "CH2O": "ApCH2O",
    "CH4":  "ApCH4",
    "CO":   "ApCO",
    "HNO3": "ApHNO3",
    "NO":   "ApNO",
    "NO2":  "ApNO2",
    "O3":   "ApO3",
    "SO2":  "ApSO2",
}
def compute_layer_pressures(p_surface_hPa: float) -> Tuple[np.ndarray, np.ndarray]:
    """
    Layer nyomások számítása ECMWF L137 koefficiensek alapján.
    
    Args:
        p_surface_hPa: Felszíni nyomás [hPa]
    
    Returns:
        p_half: Félszint nyomások [Pa], shape=(34,) - 104-137 + felszín
        p_full: Teljes szint (layer közép) nyomások [Pa], shape=(33,)
    
    A 33 layer a 137-estől (felszín) a 105-ösig (kb. 3 km).
    """
    p_surface_Pa = p_surface_hPa * 100.0  # hPa → Pa
    
    # Félszint nyomások (34 db: 104-137 + felszín=138)
    levels = list(range(104, 139))  # 104, 105, ..., 137, 138
    p_half = np.zeros(len(levels))
    
    for i, lev in enumerate(levels):
        a, b = ECMWF_L137_COEFFS[lev]
        p_half[i] = a + b * p_surface_Pa
    
    # Teljes szint nyomások (33 db layer közép)
    # Layer k közepén: P_full[k] = (P_half[k] + P_half[k+1]) / 2
    # Ahol P_half[0] = level 104 (tető), P_half[33] = level 137 alja (felszín)
    p_full = np.zeros(33)
    for k in range(33):
        # k=0 → layer 105 (legfelső), k=32 → layer 137 (felszín)
        p_full[k] = (p_half[k] + p_half[k + 1]) / 2.0
    
    # Megfordítjuk, hogy index 0 = 137-es szint (felszín közelében)
    p_full = p_full[::-1]
    p_half_for_layers = p_half[::-1]  # Szintén megfordítva
    
    return p_half_for_layers, p_full

def compute_layer_heights(
    p_half: np.ndarray,
    t_k: np.ndarray,
    q_kg_kg: np.ndarray
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Layer vastagságok és középmagasságok számítása.
    
    Args:
        p_half: Félszint nyomások [Pa], shape=(34,), index 0 = felszín
        t_k: Hőmérséklet [K], shape=(33,), index 0 = 137-es szint (felszín)
        q_kg_kg: Specific humidity [kg/kg], shape=(33,)
    
    Returns:
        delta_z: Layer vastagságok [m], shape=(33,)
        z_top: Layer tetők magassága [m], shape=(33,)
        z_mid: Layer középmagasságok [m], shape=(33,)
    
    Képletek:
        T_v = T * (1 + 0.61 * q)  [virtuális hőmérséklet]
        deltaZ_k = (R_d * T_v_k / g) * ln(P_alatta / P_felette)
    """
    n_layers = len(t_k)
    delta_z = np.zeros(n_layers)
    z_top = np.zeros(n_layers)
    z_mid = np.zeros(n_layers)
    
    z_bottom = 0.0  # A felszín magassága
    
    for k in range(n_layers):
        # Virtuális hőmérséklet
        T_v = t_k[k] * (1.0 + 0.61 * q_kg_kg[k])
        
        # Nyomások: p_half[k] = layer alja, p_half[k+1] = layer teteje
        # (mert index 0 = felszín, és felfelé haladunk)
        P_bottom = p_half[k]
        P_top = p_half[k + 1]
        
        # Layer vastagság
        if P_top > 0 and P_bottom > P_top:
            delta_z[k] = (R_DRY * T_v / G_ACCEL) * np.log(P_bottom / P_top)
        else:
            delta_z[k] = 0.0
        
        # Layer tető magassága
        z_top[k] = z_bottom + delta_z[k]
        
        # Layer középmagassága
        z_mid[k] = (z_bottom + z_top[k]) / 2.0
        
        # Következő layer aljához
        z_bottom = z_top[k]
    
    return delta_z, z_top, z_mid

# ======================= HÁTTÉR-KONCENTRÁCIÓK (Gábor útmutatása) =======================
# Ezeket ki kell vonni a számított ppmv(1km) értékből
BACKGROUND_PPMV = {
    "CH4": 1.8,      # Metán háttér
    "CO": 0.1,       # Szén-monoxid háttér
    "O3": 0.03,      # Ózon háttér (BLH alatti szmog)
    "HCHO": 0.003,   # Formaldehid háttér (CH2O)
    "HNO2": 0.001,   # Nitrous acid háttér
    # NO, NO2, SO2, HNO3 → NEM kell kivonni!
}

# ======================= GÁZ SZCENÁRIÓK 8 FUTÁSHOZ =======================

ALL_SMARTS_GASES = ["CH2O", "CH4", "CO", "HNO2", "HNO3", "NO", "NO2", "NO3", "O3", "SO2"]

# ======================= MODERATE POLLUTION KONSTANSOK (Card 6b-hez) =======================
# Forrás: SMARTS dokumentáció - ILOAD=3 (Moderate Pollution) értékei
MODERATE_POLLUTION_PPMV = {
    "CH2O": 0.007,
    "CH4": 0.3,
    "CO": 0.35,
    "HNO2": 0.002,
    "HNO3": 0.005,
    "NO": 0.2,
    "NO2": 0.02,
    "NO3": 5e-5,
    "O3": 0.053,
    "SO2": 0.05,
}


def integrate_gas_to_1km(gas_kg_kg: np.ndarray, 
                          layer_heights_m: np.ndarray,
                          blh_m: float,
                          mol_weight: float,
                          background_ppmv: float = 0.0) -> float:
    """
    CAMS gáz kg/kg → ppmv(1km) konverzió BLH alatt.
    
    Képlet (Gábor): avg_ppmv_1km = Σ(ppmv_i × deltaZ_i) / 1000
    
    FONTOS SORREND:
    1. ELŐSZÖR normálás (integral / 1000)
    2. UTÁNA háttér kivonás
    
    Args:
        gas_kg_kg: Gáz koncentráció [kg/kg] layerenként
        layer_heights_m: Layer magasságok [m] (deltaZ_i)
        blh_m: Boundary Layer Height [m]
        mol_weight: Gáz moláris tömege [g/mol]
        background_ppmv: Háttér koncentráció [ppmv(1km)]
    
    Returns:
        ppmv_1km: Normált koncentráció [ppmv × km]
    """
    M_AIR = 28.9647  # Levegő moláris tömege [g/mol]
    
    integral = 0.0
    cumulative_height = 0.0
    
    # Layerek iterálása (alulról felfelé)
    for i in range(len(gas_kg_kg)):
        delta_z = layer_heights_m[i]  # Layer magasság [m]
        
        # Ellenőrzés: még a BLH alatt vagyunk-e?
        if cumulative_height >= blh_m:
            break
        
        # Effektív magasság (ha a layer átnyúlik a BLH-n)
        remaining = blh_m - cumulative_height
        effective_height = min(delta_z, remaining)
        
        # kg/kg → ppmv konverzió
        ppmv_i = gas_kg_kg[i] * (M_AIR / mol_weight) * 1e6
        
        # Integrál: Σ(ppmv_i × deltaZ_i)
        integral += ppmv_i * effective_height
        
        cumulative_height += delta_z
    
    # 1. ELŐSZÖR: Normálás 1 km-re
    ppmv_1km = integral / 1000.0  # [ppmv×m] / 1000 = [ppmv×km]
    
    # 2. UTÁNA: Háttér kivonás (ez UTÁN!)
    ppmv_1km = max(0.0, ppmv_1km - background_ppmv)
    
    return ppmv_1km

"""
=============================================================================
FILTER_PM_DATA_GENTLE HELYETTESÍTÉSE
=============================================================================

Ez a kód LECSERÉLI a meglévő filter_pm_data_gentle() függvényt a pipeline-ban.

HOGYAN HASZNÁLD:
1. Keresd meg a pipeline-ban a filter_pm_data_gentle() függvényt (kb. 1730. sor)
2. TÖRÖLD az egész függvényt
3. ILLESZD BE helyette az alábbi kódot

A függvény ugyanazt a nevet használja, így a hívások nem változnak!
=============================================================================
"""

def compute_l137_half_pressures_full(p_surface_hPa: float) -> dict:
    """
    ECMWF L137 félszint-nyomások teljes oszlopra.

    Elvárás: const.ECMWF_L137_COEFFS tartalmazza a 1..138 félszinteket:
      P(half_lev) = a + b * P_surface

    Vissza: dict {half_level:int -> pressure_Pa:float}, half_level=1..138
      - 138: felszín (P_surface)
      - 1: TOA közeli
    """
    p_surface_Pa = float(p_surface_hPa) * 100.0
    out = {}
    for lev in range(1, 139):  # 1..138
        if lev not in ECMWF_L137_COEFFS:
            raise KeyError(
                f"ECMWF_L137_COEFFS hiányzó kulcs: {lev}. "
                f"A const.py-ban töltsd fel 1..138-ig (te írtad, hogy már megvan)."
            )
        a, b = ECMWF_L137_COEFFS[lev]
        out[lev] = float(a + b * p_surface_Pa)
    return out


def compute_l137_half_heights_toa_m(
    p_surface_hPa: float = 1013.25,
    scale_height_m: float = 7400.0
) -> dict:
    """
    Teljes L137 félszint magasságok (z) [m] TOA-ig.

    Prioritás:
      1) Ha const-ban van előre megadott z_half (pl. ECMWF_L137_Z_HALF_M), azt használjuk.
      2) Különben közelítés: z = H * ln(Ps / P_half), ahol H=scale_height_m.

    Vissza: dict {half_level:int -> z_m:float}, 1..138
      - z(138)=0 m (felszín)
      - z(1) ~ TOA (több tíz km)
    """
    # 1) Ha van előre betöltött magasság a const-ban, azt preferáljuk
    for cand in ("ECMWF_L137_Z_HALF_M", "L137_Z_HALF_M", "ECMWF_L137_ZHALF_M"):
        if cand in globals():
            zsrc = globals()[cand]
            # lehet dict vagy list/tuple
            if isinstance(zsrc, dict):
                # elvárjuk 1..138 kulcsokat
                if all(k in zsrc for k in range(1, 139)):
                    return {k: float(zsrc[k]) for k in range(1, 139)}
            else:
                # list/tuple: indexelés 1..138 (0 lehet üres)
                try:
                    if len(zsrc) >= 139:
                        return {k: float(zsrc[k]) for k in range(1, 139)}
                except Exception:
                    pass

    # 2) Közelítés nyomásból (állandó skála-magasság)
    p_half = compute_l137_half_pressures_full(p_surface_hPa)
    ps = max(1.0, p_half[138])  # Pa
    H = float(scale_height_m)

    z = {}
    for lev in range(1, 139):
        p = max(1e-6, float(p_half[lev]))
        z[lev] = float(H * np.log(ps / p))

    # z(138) legyen 0 pontosan
    z[138] = 0.0
    return z


def integrate_extinction_above_blh_toa(
    beta_by_level: dict,
    z_half_m: dict,
    blh_m: float
) -> float:
    """
    Extinction profil integrálása BLH->TOA tartományban.

    Feltételezés:
      - beta_by_level: {full_level 1..137 -> beta_ext [1/m]}
      - z_half_m: {half_level 1..138 -> z [m]}
      - full level L a half-level (L) és (L+1) között van:
          z_top    = z_half[L]
          z_bottom = z_half[L+1]

    Vissza: tau_upper (AOD) dimenzió nélküli.
    """
    blh = float(np.clip(blh_m, 0.0, 10000.0))
    z_toa = float(z_half_m[1])

    tau = 0.0
    for L in range(1, 138):  # 1..137
        z_top = float(z_half_m[L])
        z_bot = float(z_half_m[L + 1])

        # réteg vastagság felette (BLH->TOA metszet)
        overlap = max(0.0, min(z_top, z_toa) - max(z_bot, blh))
        if overlap <= 0:
            continue

        beta = float(beta_by_level.get(L, 0.0))
        if not np.isfinite(beta) or beta <= 0:
            continue

        tau += beta * overlap

    return float(max(0.0, tau))

    
def process_cams_layered_to_single(
    df_layered: pd.DataFrame,
    p_surface_hPa: float = 1013.25
) -> pd.DataFrame:
    """
    CAMS layerenkénti adatok → single értékek (ppmv(1km)) minden timestamp-hez.
    
    Args:
        df_layered: cams_data DataFrame (timestamp + array oszlopok)
        p_surface_hPa: Felszíni nyomás [hPa] (alapértelmezett: 1013.25)
    
    Returns:
        DataFrame oszlopokkal:
        - timestamp
        - blh_m
        - ApCH4, ApCO, ApO3, ApCH2O, ApHNO3, ApNO, ApNO2, ApSO2 [ppmv(1km)]
    """
    if df_layered.empty:
        return pd.DataFrame()
    
    # Gáz oszlop → SMARTS gáznév mapping
    gas_mapping = {
        'ch4_c_kg_kg': 'CH4',
        'co_kg_kg': 'CO',
        'go3_kg_kg': 'O3',
        'hcho_kg_kg': 'HCHO',  # CH2O
        'hno3_kg_kg': 'HNO3',
        'no_kg_kg': 'NO',
        'no2_kg_kg': 'NO2',
        'so2_kg_kg': 'SO2',
    }
    
    results = []
    
    for idx, row in df_layered.iterrows():
        ts = row['timestamp']
        blh_m = float(row['blh_m']) if pd.notna(row['blh_m']) else 500.0
        
        # Tömbök kinyerése (már Python listák a PostgreSQL-ből)
        t_k = np.array(row['t_k'], dtype=float)         # Hőmérséklet [K]
        q_kg_kg = np.array(row['q_kg_kg'], dtype=float) # Specific humidity [kg/kg]
        
        # Layer nyomások számítása
        p_half, p_full = compute_layer_pressures(p_surface_hPa)
        
        # Layer magasságok számítása
        delta_z, z_top, z_mid = compute_layer_heights(p_half, t_k, q_kg_kg)
        
        # Eredmény sor inicializálása
        result_row = {'timestamp': ts, 'blh_m': blh_m}
        
        # Gázok feldolgozása
        for col_name, gas_name in gas_mapping.items():
            # SMARTS Card 6b oszlopnév
            smarts_col = f"Ap{gas_name}" if gas_name != "HCHO" else "ApCH2O"
            
            if col_name in row.index and row[col_name] is not None:
                gas_array = np.array(row[col_name], dtype=float)
                
                # ✅ HELYES HÍVÁS (Gábor képlete szerint)
                ppmv_1km = integrate_gas_to_1km(
                    gas_kg_kg=gas_array,
                    layer_heights_m=delta_z,                           # Layer vastagságok [m]
                    blh_m=blh_m,                                       # BLH [m]
                    mol_weight=MOLAR_MASS_EXTENDED[gas_name],          # Moláris tömeg [g/mol]
                    background_ppmv=BACKGROUND_PPMV.get(gas_name, 0.0) # Háttér [ppmv(1km)]
                )
                
                result_row[smarts_col] = ppmv_1km
            else:
                result_row[smarts_col] = 0.0
        
        results.append(result_row)
    
    df_out = pd.DataFrame(results)
    print(f"✓ CAMS layered → single: {len(df_out)} sor feldolgozva")
    return df_out

def estimate_no2_from_nox(nox_index: float, pm25: float = None) -> float:
    """
    NO2 becslés NOx indexből a főnök képlete szerint.
    
    Args:
        nox_index: SGP41 NOx index (1-500, 1 = tiszta levegő)
        pm25: PM2.5 érték µg/m³-ben (opcionális sanity check)
    
    Returns:
        NO2 ppmv(1km) értéke Card 6b-hez
    
    Képlet:
        est_no2 = 0.005 + (0.0001 * (nox_idx - 1))
        
    Sanity check: Ha PM2.5 > 25 és est_no2 < 0.010, akkor est_no2 = 0.010
    """
    # Alapértelmezett, ha nincs NOx index
    if not np.isfinite(nox_index) or nox_index < 1:
        nox_index = 1.0
    
    # Limit: 1-500
    nox_index = np.clip(nox_index, 1.0, 500.0)
    
    # Képlet
    est_no2 = 0.005 + (0.0001 * (nox_index - 1.0))
    
    # Sanity check PM alapján
    if pm25 is not None and np.isfinite(pm25):
        if pm25 > 25.0 and est_no2 < 0.010:
            est_no2 = 0.010
    
    # Limit: 0.001 - 0.5 ppmv
    est_no2 = np.clip(est_no2, 0.001, 0.5)
    
    return float(est_no2)
