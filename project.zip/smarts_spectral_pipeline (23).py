#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
 SMARTS SPEKTRÁLIS PIPELINE — NYERS + INTEGRÁLT (SR + IAM + ASTM G173 kA)
================================================================================

  Helyszín:  /opt/app-root/src/smarts_clearsky_model/smarts_spectral_pipeline.py

  Ez a kód egy drop-in csere. Két dolgot csinál egyetlen futtatáson belül:

    (A) NYERS SMARTS spektrumok kiszámítása minden timestamp-re
        → JSONB tároló tábla:  public.smarts_spectral_allsky
        (GHI, DNI, DHI 0° tilt + beam/diffuse 12.25° és 15.46° tiltekre)

    (B) INTEGRÁLÁS a const.py SR_POINTS, IAM_POINTS és ASTM G173 alapú kA-val
        (= ugyanaz a lánc, mint a dashboard.py: raw → SR conv → kA → IAM)
        → Eredmény tábla:  public.smarts_spectral_allsky_integrated

--------------------------------------------------------------------------------
  FUTÁSI MÓDOK (RUN_MODE)
--------------------------------------------------------------------------------

  RUN_MODE = "clearsky"      (alapértelmezett)
     → A const.py PERIODS listája szerint fut
       (ez praktikusan PROD_PERIODS, illetve --test flag esetén TEST_PERIODS).

  RUN_MODE = "allsky"
     → A lenti ALLSKY_RANGES lista szerint fut. Formátum:
       "YYYY.MM.DD-YYYY.MM.DD"   (UTC, teljes napok, inklúzív mindkét vég)

  RUN_MODE = "postprocess"
     → NEM futtat SMARTS-ot. Csak a már elmentett spektrum-táblából olvas,
       és újraszámolja az integrált értékeket a const.py aktuális SR/IAM
       alapján. Használd, ha az SR/IAM/kA módosult.

--------------------------------------------------------------------------------
  ÚJ: SUFFIX (kísérleti futások párhuzamos tárolása a táblákban)
--------------------------------------------------------------------------------

  --suffix <KULCS>  (vagy RUN_SUFFIX env)
     → Ha meg van adva, NEM a default oszlopokba ír, hanem ÚJ oszlopokba,
       amelyek neve minden base-oszlopnál  <base>_<KULCS>  formátumú.
       Kompatibilis a három RUN_MODE-dal (clearsky/allsky/postprocess).

     A timestamp PRIMARY KEY, úgyhogy ugyanahhoz a timestamphez a default
     oszlopok ÉRINTETLENÜL maradnak, és mellé kerülnek a  _<KULCS> oszlopok.
     Így egy adott timestamp-re több kísérlet futás is tárolható egy sorban.

     Suffix-követelmények:
        - csak [a-z0-9_], 1-32 karakter, NEM kezdődhet aláhúzással
        - futás előtt lowercase-re normalizáljuk

     Példa: --suffix blhcap  ("BLH Parsing & Dynamic Geometric Capping" kísérlet)

     Ekkor az oszlopok a RAW táblában:
        ghi_spectrum_blhcap, dni_spectrum_blhcap, dhi_spectrum_blhcap,
        gti1225_beam_spectrum_blhcap, gti1225_diff_spectrum_blhcap,
        gti1545_beam_spectrum_blhcap, gti1545_diff_spectrum_blhcap,
        wavelengths_blhcap,
        ghi_raw_blhcap, dni_raw_blhcap, dhi_raw_blhcap,
        gti1225_beam_raw_blhcap, gti1225_diff_raw_blhcap,
        gti1545_beam_raw_blhcap, gti1545_diff_raw_blhcap

     Az INTEGRATED táblában:
        ghi_blhcap, gti1225beam_blhcap, gti1225diffuse_blhcap,
        gti1545beam_blhcap, gti1545diffuse_blhcap,
        ghi_raw_blhcap, gti1225beam_raw_blhcap, …,
        ghi_sr_blhcap, …,
        ghi_aoi_deg_blhcap, gti1225_aoi_deg_blhcap, gti1545_aoi_deg_blhcap,
        ghi_iam_blhcap, gti1225_iam_blhcap, gti1545_iam_blhcap,
        kA_astm_blhcap, wl_min_blhcap, wl_max_blhcap

--------------------------------------------------------------------------------
  HASZNÁLAT
--------------------------------------------------------------------------------

  # Alap: clearsky, DEFAULT oszlopokba ír (PERIODS a const.py-ból)
  python smarts_spectral_pipeline.py

  # ÚJ: clearsky futás, de külön oszlopokba (suffix-szel) — kísérleti futás
  python smarts_spectral_pipeline.py --mode clearsky --suffix blhcap

  # All-sky az ALLSKY_RANGES alapján, default oszlopokba
  python smarts_spectral_pipeline.py --mode allsky

  # All-sky suffix-szel
  python smarts_spectral_pipeline.py --mode allsky --suffix blhcap

  # Csak az integrált újraszámolása (SMARTS nem fut)
  python smarts_spectral_pipeline.py --mode postprocess

  # Postprocess suffix-szel: csak az integrált suffix-oszlopokat frissíti
  python smarts_spectral_pipeline.py --mode postprocess --suffix blhcap

  # Env változóval is megadható (CLI felülírja):
  RUN_MODE=allsky RUN_SUFFIX=blhcap python smarts_spectral_pipeline.py

  A const.py --test flag is átadható a szokott módon (PERIODS → TEST_PERIODS).

================================================================================
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

# ---- scipy.trapz kompatibilitás (régebbi pandas vs újabb scipy) -------------
try:
    import scipy.integrate as _si
    if not hasattr(_si, "trapz"):
        import numpy as _np
        _si.trapz = _np.trapz
except Exception:
    pass

warnings.filterwarnings("ignore")

# ---- mappa a PYTHONPATH-re --------------------------------------------------
sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd
import psycopg2
import psycopg2.extras
from psycopg2 import sql as psql
from psycopg2.extras import execute_values
from scipy.interpolate import CubicSpline, interp1d

try:
    import pvlib
except Exception as exc:
    raise RuntimeError("pvlib kötelező a pipeline-hoz") from exc

# ---- projektbeli modulok ----------------------------------------------------
import const as C
from const import (
    DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PWD_CACHE,
    DEFAULT_LAT, DEFAULT_LON, DEFAULT_ALT_KM,
    PANEL_TILT, PANEL_AZIMUTH,
    STRING0_TILT_DEG, STRING1_TILT_DEG,
    CENTRAL_ENTITY_IDS,
    SUN_MIN_ELEV_DEG,
    IOUT_0TILT_GHI_DNI_DHI, IOUT_TILT_BEAM_DIFFUSE,
    PERIODS,
    SR_POINTS, IAM_POINTS,
)
import helpers
import loaders
from smarts_cards import build_smarts_input_new_aod
from smarts_runner import run_smarts_once
from aod_pymiescatt import calculate_new_aod_params
import aod_pymiescatt as _aod_pymiescatt_mod  # monkey-patch celbol (--no-pymiescatt)

# ============================================================================
# CONFIG  —  itt állítod a kapcsolókat (env override + CLI)
# ============================================================================

# --- futási mód: "clearsky" | "allsky" | "postprocess" ----------------------
RUN_MODE: str = os.getenv("RUN_MODE", "clearsky").strip().lower()

# --- Postprocess almod ------------------------------------------------------
POSTPROCESS_MODE: str = os.getenv("POSTPROCESS_MODE", "clearsky").strip().lower()

# --- ÚJ: SUFFIX (üres = default oszlopok; ha meg van adva, kísérleti oszlopok)
RUN_SUFFIX: str = os.getenv("RUN_SUFFIX", "").strip().lower()

# --- ALL-SKY tartományok (csak RUN_MODE="allsky") ---------------------------
ALLSKY_RANGES: List[str] = [
    # "2026.08.12-2026.09.02",
    "2026.03.01-2026.03.31",
]

# --- spektrum tároló tábla (RAW JSONB) --------------------------------------
SPECTRAL_TABLE: str = os.getenv("SPECTRAL_TABLE", "public.smarts_spectral_allsky")

# --- integrált eredmények táblája (SR × kA × IAM) ---------------------------
INTEGRATED_TABLE: str = os.getenv("INTEGRATED_TABLE", "public.smarts_spectral_allsky_integrated")

# --- ÚJ: per-periódus RMSE/MBE CSV kimenet (a pipeline futás végén) ---------
# Ha üres, nem ír CSV-t. Default: fix könyvtár a pipeline mappájában, timestamp-es fájlnévvel.
_DEFAULT_METRICS_CSV_DIR: str = "/opt/app-root/src/smarts_clearsky_model"
METRICS_CSV_PATH: str = os.getenv("METRICS_CSV_PATH", "").strip()

# --- tilt beállítások -------------------------------------------------------
GTI1_TILT_DEG: float   = float(os.getenv("GTI1_TILT", str(STRING0_TILT_DEG)))
GTI2_TILT_DEG: float   = float(os.getenv("GTI2_TILT", str(STRING1_TILT_DEG)))
GTI_AZIMUTH_DEG: float = float(os.getenv("GTI_AZIMUTH", "183.0"))
GHI_AZIMUTH_DEG: float = float(os.getenv("GHI_AZIMUTH", str(PANEL_AZIMUTH)))

# --- WL tartományok ---------------------------------------------------------
RAW_WLMIN: float = 300.0
RAW_WLMAX: float = 1200.0
INT_WLMIN: float = float(getattr(C, "WLMIN", 350.0))
INT_WLMAX: float = float(getattr(C, "WLMAX", 1200.0))

# --- batch méretek ----------------------------------------------------------
BATCH_SIZE_SPECTRAL: int = int(os.getenv("BATCH_SPECTRAL", "200"))
BATCH_SIZE_INT:      int = int(os.getenv("BATCH_INT",      "2000"))
CHUNK_DAYS:          int = int(os.getenv("CHUNK_DAYS",     "7"))

# --- AOD default fallback ---------------------------------------------------
DEFAULT_AOD: Dict[str, float] = {
    "TAU550": 0.10, "ALPHA1": 1.30, "ALPHA2": 1.30,
    "OMEGL":  0.90, "GG":     0.70,
}

# ============================================================================
# WLMIN/WLMAX OVERRIDE  — a SMARTS 300–1200 nm-en adja a nyers spektrumot
# ============================================================================
_orig_wlmin = C.WLMIN
_orig_wlmax = C.WLMAX
C.WLMIN = RAW_WLMIN
C.WLMAX = RAW_WLMAX
try:
    import smarts_cards as _sc
    _sc.WLMIN = RAW_WLMIN
    _sc.WLMAX = RAW_WLMAX
    print(f"✓ SMARTS NYERS output tartomány (WLMIN/WLMAX): "
          f"{_orig_wlmin}/{_orig_wlmax} → {RAW_WLMIN}/{RAW_WLMAX}")
except Exception as _e:
    print(f"[WARN] smarts_cards patch sikertelen: {_e}")

# ============================================================================
# SUFFIX VALIDÁLÁS + OSZLOPNÉV-GENERÁLÁS
# ============================================================================

_SUFFIX_PATTERN = re.compile(r"^[a-z0-9][a-z0-9_]{0,31}$")


def _validate_suffix(suffix: Optional[str]) -> str:
    """
    Suffix validálás. Üres / None → üres string ("", azaz: default viselkedés).
    Ellenkező esetben: [a-z0-9_], 1-32 karakter, nem kezdődhet '_'-val.
    """
    s = (suffix or "").strip().lower()
    if not s:
        return ""
    if not _SUFFIX_PATTERN.match(s):
        raise ValueError(
            f"Érvénytelen --suffix: {suffix!r}. "
            f"Követelmények: [a-z0-9_], 1–32 karakter, nem kezdődhet aláhúzással."
        )
    return s


def _sfx(name: str) -> str:
    """Hozzáfűzi az aktív RUN_SUFFIX-et (ha van). '<name>_<suffix>' vagy '<name>'."""
    return f"{name}_{RUN_SUFFIX}" if RUN_SUFFIX else name


# ============================================================================
# SEGÉDEK
# ============================================================================

def _get_conn():
    """PostgreSQL kapcsolat a const.py kredenciáljaival."""
    return psycopg2.connect(
        host=DB_HOST, port=DB_PORT, dbname=DB_NAME,
        user=DB_USER, password=DB_PWD_CACHE,
    )


def _split_table_fq(table_fq: str) -> Tuple[str, str]:
    """'schema.table' → ('schema', 'table'); 'table' → ('public', 'table')."""
    parts = str(table_fq).split(".")
    return (parts[0], parts[1]) if len(parts) == 2 else ("public", parts[0])


def _py(v):
    """numpy/pandas scalar → python natív."""
    if v is None:
        return None
    if hasattr(v, "to_pydatetime"):
        try:
            return v.to_pydatetime()
        except Exception:
            pass
    if hasattr(v, "item") and callable(getattr(v, "item")):
        try:
            return v.item()
        except Exception:
            pass
    if isinstance(v, (float, np.floating)) and not np.isfinite(v):
        return None
    return v


def _safe_float(x, dflt: float = np.nan) -> float:
    try:
        v = float(x)
        return v if np.isfinite(v) else dflt
    except Exception:
        return dflt


def _safe_json_array(x: Any) -> np.ndarray:
    """JSONB array → numpy array."""
    if x is None:
        return np.array([], dtype=float)
    if isinstance(x, np.ndarray):
        return np.asarray(x, dtype=float)
    if isinstance(x, (list, tuple)):
        return np.asarray([np.nan if v is None else float(v) for v in x], dtype=float)
    if isinstance(x, str):
        s = x.strip()
        if not s:
            return np.array([], dtype=float)
        try:
            val = json.loads(s)
            if isinstance(val, list):
                return np.asarray([np.nan if v is None else float(v) for v in val], dtype=float)
        except Exception:
            return np.array([], dtype=float)
    return np.array([], dtype=float)


def _spectrum_to_json(wl: np.ndarray, vals: Optional[np.ndarray]) -> Optional[str]:
    """numpy spektrum → JSON string."""
    if vals is None or len(vals) == 0:
        return None
    out = []
    for v in vals:
        if np.isfinite(v):
            out.append(round(float(v), 6))
        else:
            out.append(None)
    return json.dumps(out)


def _raw_integral(wl: np.ndarray, y: np.ndarray,
                  wl_min: float, wl_max: float) -> float:
    """Trapéz integrál SR nélkül, [wl_min, wl_max] tartományon."""
    wl = np.asarray(wl, dtype=float)
    y  = np.asarray(y,  dtype=float)
    m = np.isfinite(wl) & np.isfinite(y) & (wl >= wl_min) & (wl <= wl_max)
    if int(m.sum()) < 3:
        return float("nan")
    ww = wl[m]; yy = y[m]
    idx = np.argsort(ww); ww = ww[idx]; yy = yy[idx]
    return float(np.trapz(yy, ww))


# ============================================================================
# SR / IAM / kA  — pontosan a dashboard.py logikája, de const.py pontokkal
# ============================================================================

def _sr_interp_const():
    wl = np.array(list(SR_POINTS.keys()), dtype=float)
    sr = np.array(list(SR_POINTS.values()), dtype=float)
    idx = np.argsort(wl)
    return interp1d(wl[idx], sr[idx], kind="cubic",
                    bounds_error=False, fill_value=0.0)


def _iam_spline_const():
    aoi_deg = np.array(sorted(float(k) for k in IAM_POINTS.keys()), dtype=float)
    iam_val = np.array([float(IAM_POINTS[float(k)] if float(k) in IAM_POINTS
                              else IAM_POINTS[int(k)]) for k in aoi_deg],
                       dtype=float)
    if len(aoi_deg) < 3:
        raise RuntimeError("IAM_POINTS túl rövid (min. 3 pont kell)")
    spline = CubicSpline(aoi_deg, iam_val, bc_type="natural")

    def _fn(a):
        arr = np.asarray(a, dtype=float)
        arr = np.clip(arr, 0.0, 90.0)
        return np.clip(spline(arr), 0.0, 1.0)
    return _fn


def _am15_kA_from_sr(sr_fn) -> float:
    """kA = 1000 / ∫ AM1.5G_global(λ) * SR(λ) dλ    [INT_WLMIN..INT_WLMAX]"""
    ref = pvlib.spectrum.get_reference_spectra(standard="ASTM G173-03")
    wl_ref = ref.index.values.astype(float)
    e_ref  = ref["global"].values.astype(float)

    m = (wl_ref >= INT_WLMIN) & (wl_ref <= INT_WLMAX)
    wl_m = wl_ref[m]; e_m = e_ref[m]
    if wl_m.size < 2:
        raise RuntimeError(
            f"ASTM G173-03: túl kevés pont {INT_WLMIN}–{INT_WLMAX} nm között"
        )
    sr = np.clip(sr_fn(wl_m), 0.0, 1.0)
    dlam = np.diff(wl_m)
    avg  = (e_m[:-1] * sr[:-1] + e_m[1:] * sr[1:]) / 2.0
    integral = float(np.sum(avg * dlam))
    if not np.isfinite(integral) or integral <= 0:
        raise RuntimeError(f"ASTM G173-03 × SR integrál érvénytelen: {integral}")
    return 1000.0 / integral


def _integral_sr_weighted(wl: np.ndarray, y: np.ndarray, sr_fn,
                          wl_min: float, wl_max: float) -> float:
    """∫ spectrum × SR dλ   [wl_min..wl_max] tartományon."""
    wl = np.asarray(wl, dtype=float)
    y  = np.asarray(y,  dtype=float)
    m = np.isfinite(wl) & np.isfinite(y) & (wl >= wl_min) & (wl <= wl_max)
    if int(m.sum()) < 3:
        return float("nan")
    ww = wl[m]; yy = y[m]
    idx = np.argsort(ww); ww = ww[idx]; yy = yy[idx]
    sr = np.asarray(sr_fn(ww), dtype=float)
    sr = np.where(np.isfinite(sr), np.clip(sr, 0.0, 1.0), 0.0)
    return float(np.trapz(yy * sr, ww))


def _compute_aoi(ts_utc, lat: float, lon: float, alt_km: float,
                 panel_tilt: float, panel_azimuth: float) -> float:
    """pvlib AOI [deg]."""
    sp = pvlib.solarposition.get_solarposition(
        time=pd.to_datetime(ts_utc, utc=True),
        latitude=float(lat), longitude=float(lon),
        altitude=float(alt_km) * 1000.0, method="nrel_numpy",
    )
    zen = float(sp["apparent_zenith"].iloc[0])
    azi = float(sp["azimuth"].iloc[0])
    return float(pvlib.irradiance.aoi(float(panel_tilt), float(panel_azimuth),
                                      zen, azi))


@dataclass
class IntegrationContext:
    """Előre-kiszámolt, per-futás állandó objektumok."""
    sr_fn: Any
    iam_fn: Any
    kA: float
    wl_min: float
    wl_max: float

    @classmethod
    def build(cls) -> "IntegrationContext":
        sr_fn  = _sr_interp_const()
        iam_fn = _iam_spline_const()
        kA     = _am15_kA_from_sr(sr_fn)
        print(f"  [integrator] WL tartomány : {INT_WLMIN:.0f}–{INT_WLMAX:.0f} nm")
        print(f"  [integrator] SR pontok    : {len(SR_POINTS)}  "
              f"(λ={min(SR_POINTS)}..{max(SR_POINTS)} nm)")
        print(f"  [integrator] IAM pontok   : {len(IAM_POINTS)} "
              f"(aoi=0..90°)")
        print(f"  [integrator] ASTM G173 kA = {kA:.6f}   "
              f"(1/kA = {1.0/kA:.6f}, "
              f"∫AM1.5G×SR dλ = {1000.0/kA:.2f} W/m²)")
        return cls(sr_fn=sr_fn, iam_fn=iam_fn, kA=kA,
                   wl_min=INT_WLMIN, wl_max=INT_WLMAX)


def _integrate_component(wl: np.ndarray, spectrum: np.ndarray,
                         aoi_deg: float, apply_iam: bool,
                         ctx: IntegrationContext
                         ) -> Tuple[float, float, float, float, float]:
    """Egy komponens integrálása: raw → SR → kA → IAM."""
    nan = float("nan")
    if spectrum is None or wl is None:
        return nan, nan, nan, nan, nan
    if len(spectrum) != len(wl) or len(wl) < 3:
        return nan, nan, nan, nan, nan

    raw  = _raw_integral(wl, spectrum, ctx.wl_min, ctx.wl_max)
    sr_w = _integral_sr_weighted(wl, spectrum, ctx.sr_fn, ctx.wl_min, ctx.wl_max)

    if not (np.isfinite(sr_w) and np.isfinite(ctx.kA)):
        return raw, sr_w, nan, nan, nan

    srka = float(sr_w) * float(ctx.kA)

    iam_val = float("nan")
    final   = srka
    if apply_iam:
        iam_val = float(ctx.iam_fn(aoi_deg)) if np.isfinite(aoi_deg) else float("nan")
        final = srka * iam_val if np.isfinite(iam_val) else float("nan")

    return raw, sr_w, srka, iam_val, final


# ============================================================================
# OSZLOPNÉV LISTÁK  — base + dinamikus suffix-es változatok
# ============================================================================
# FIX sorrend: a tuple értékek SORRENDJE MINDIG megegyezik a spec_tuple /
# int_tuple összeállításában használt sorrenddel. A SUFFIX csak az oszlopnév-
# ábrázolást változtatja, a tuple-tartalom ugyanaz.

_SPECTRAL_BASE_COLS: Tuple[str, ...] = (
    "wavelengths",
    "ghi_spectrum", "dni_spectrum", "dhi_spectrum",
    "gti1225_beam_spectrum", "gti1225_diff_spectrum",
    "gti1545_beam_spectrum", "gti1545_diff_spectrum",
    "ghi_raw", "dni_raw", "dhi_raw",
    "gti1225_beam_raw", "gti1225_diff_raw",
    "gti1545_beam_raw", "gti1545_diff_raw",
)

_INT_BASE_COLS: Tuple[str, ...] = (
    "ghi", "gti1225beam", "gti1225diffuse", "gti1545beam", "gti1545diffuse",
    "ghi_raw", "gti1225beam_raw", "gti1225diffuse_raw",
    "gti1545beam_raw", "gti1545diffuse_raw",
    "ghi_sr",  "gti1225beam_sr",  "gti1225diffuse_sr",
    "gti1545beam_sr",  "gti1545diffuse_sr",
    "ghi_aoi_deg", "gti1225_aoi_deg", "gti1545_aoi_deg",
    "ghi_iam",     "gti1225_iam",     "gti1545_iam",
    "kA_astm", "wl_min", "wl_max",
    # ÚJ: AOD számolás típusjelzői
    "ispymiescatt",   # 1 ha PyMieScatt (Mie fizika) aktív volt, 0 ha tisztán empirikus
    "isfallback",     # 1 ha bármelyik kulcs input hiányzott és default értékkel futott
)


def _spectral_insert_cols() -> Tuple[str, ...]:
    """Az INSERT SQL-ben használt oszlopok (timestamp + suffix-elt base-ek)."""
    return ("timestamp",) + tuple(_sfx(c) for c in _SPECTRAL_BASE_COLS)


def _int_insert_cols() -> Tuple[str, ...]:
    return ("timestamp",) + tuple(_sfx(c) for c in _INT_BASE_COLS)


# ============================================================================
# DB DDL — spektrum + integrált (default oszlopokkal) + suffix-es ALTER
# ============================================================================

def ensure_spectral_table(conn) -> None:
    """
    1) Létrehozza a spektrum táblát a default (suffix nélküli) oszlopokkal, ha nem létezik.
    2) Ha RUN_SUFFIX meg van adva, ADD COLUMN IF NOT EXISTS minden suffixes oszlopra.
    """
    ddl_base = f"""
    CREATE TABLE IF NOT EXISTS {SPECTRAL_TABLE} (
        timestamp              timestamptz PRIMARY KEY,
        wavelengths            jsonb,
        ghi_spectrum           jsonb,
        dni_spectrum           jsonb,
        dhi_spectrum           jsonb,
        gti1225_beam_spectrum  jsonb,
        gti1225_diff_spectrum  jsonb,
        gti1545_beam_spectrum  jsonb,
        gti1545_diff_spectrum  jsonb,
        ghi_raw                double precision,
        dni_raw                double precision,
        dhi_raw                double precision,
        gti1225_beam_raw       double precision,
        gti1225_diff_raw       double precision,
        gti1545_beam_raw       double precision,
        gti1545_diff_raw       double precision
    );
    """
    with conn.cursor() as cur:
        cur.execute(ddl_base)

        if RUN_SUFFIX:
            # suffix-es oszlopok hozzáadása
            add_parts = []
            for base in _SPECTRAL_BASE_COLS:
                col = _sfx(base)
                # JSONB vagy double precision?
                is_jsonb = (base == "wavelengths") or base.endswith("_spectrum")
                sqltype = "jsonb" if is_jsonb else "double precision"
                add_parts.append(
                    f'ADD COLUMN IF NOT EXISTS "{col}" {sqltype}'
                )
            alter_sql = f"ALTER TABLE {SPECTRAL_TABLE} " + ",\n    ".join(add_parts) + ";"
            cur.execute(alter_sql)

    conn.commit()
    if RUN_SUFFIX:
        print(f"✓ Spektrum tábla biztosítva: {SPECTRAL_TABLE}  "
              f"(+ suffix oszlopok: *_{RUN_SUFFIX})")
    else:
        print(f"✓ Spektrum tábla biztosítva: {SPECTRAL_TABLE}")


def ensure_integrated_table(conn) -> None:
    """
    1) Létrehozza az integrált táblát a default oszlopokkal, ha nem létezik.
    2) Ha RUN_SUFFIX meg van adva, ADD COLUMN IF NOT EXISTS minden suffixes oszlopra.
    3) ALTER TABLE ADD COLUMN IF NOT EXISTS a base oszlopokra is — így régebbi
       táblákhoz is hozzáadjuk az új oszlopokat (pl. ispymiescatt, isfallback).
    """
    ddl_base = f"""
    CREATE TABLE IF NOT EXISTS {INTEGRATED_TABLE} (
        timestamp           timestamptz PRIMARY KEY,
        ghi                 double precision,
        gti1225beam         double precision,
        gti1225diffuse      double precision,
        gti1545beam         double precision,
        gti1545diffuse      double precision,
        ghi_raw             double precision,
        gti1225beam_raw     double precision,
        gti1225diffuse_raw  double precision,
        gti1545beam_raw     double precision,
        gti1545diffuse_raw  double precision,
        ghi_sr              double precision,
        gti1225beam_sr      double precision,
        gti1225diffuse_sr   double precision,
        gti1545beam_sr      double precision,
        gti1545diffuse_sr   double precision,
        ghi_aoi_deg         double precision,
        gti1225_aoi_deg     double precision,
        gti1545_aoi_deg     double precision,
        ghi_iam             double precision,
        gti1225_iam         double precision,
        gti1545_iam         double precision,
        kA_astm             double precision,
        wl_min              double precision,
        wl_max              double precision,
        ispymiescatt        smallint,
        isfallback          smallint
    );
    """
    with conn.cursor() as cur:
        cur.execute(ddl_base)

        # A base oszlopokra is ADD COLUMN IF NOT EXISTS
        # (régebbi táblákhoz hozzáadja az új ispymiescatt / isfallback oszlopokat is)
        base_add_parts = []
        for base in _INT_BASE_COLS:
            sqltype = "smallint" if base in ("ispymiescatt", "isfallback") else "double precision"
            base_add_parts.append(
                f'ADD COLUMN IF NOT EXISTS "{base}" {sqltype}'
            )
        if base_add_parts:
            alter_base_sql = f"ALTER TABLE {INTEGRATED_TABLE} " + ",\n    ".join(base_add_parts) + ";"
            cur.execute(alter_base_sql)

        if RUN_SUFFIX:
            add_parts = []
            for base in _INT_BASE_COLS:
                col = _sfx(base)
                sqltype = "smallint" if base in ("ispymiescatt", "isfallback") else "double precision"
                add_parts.append(
                    f'ADD COLUMN IF NOT EXISTS "{col}" {sqltype}'
                )
            alter_sql = f"ALTER TABLE {INTEGRATED_TABLE} " + ",\n    ".join(add_parts) + ";"
            cur.execute(alter_sql)

    conn.commit()
    if RUN_SUFFIX:
        print(f"✓ Integrált tábla biztosítva: {INTEGRATED_TABLE}  "
              f"(+ suffix oszlopok: *_{RUN_SUFFIX})   [+ ispymiescatt, isfallback]")
    else:
        print(f"✓ Integrált tábla biztosítva: {INTEGRATED_TABLE}   [+ ispymiescatt, isfallback]")


# ============================================================================
# DB INSERT — a suffix alapján dinamikusan célzott oszlopokba
# ============================================================================

def _build_upsert_sql(table: str, cols: Tuple[str, ...]) -> str:
    """
    INSERT … ON CONFLICT (timestamp) DO UPDATE SET … — a megadott oszlopokra.
    Az oszlopneveket mindig idézőjelezzük (ha az identifier case-sensitive).
    """
    q_cols = ", ".join(f'"{c}"' for c in cols)
    set_parts = ",\n        ".join(
        f'"{c}" = EXCLUDED."{c}"' for c in cols if c != "timestamp"
    )
    return (
        f"INSERT INTO {table} ({q_cols}) VALUES %s "
        f"ON CONFLICT (timestamp) DO UPDATE SET\n        {set_parts};"
    )


def insert_spectral_batch(conn, rows: Sequence[tuple]) -> int:
    """Upsert a spektrum táblába a (timestamp + suffix-elt) oszlopokba."""
    if not rows:
        return 0
    clean = [tuple(_py(x) for x in r) for r in rows]
    cols = _spectral_insert_cols()
    sql = _build_upsert_sql(SPECTRAL_TABLE, cols)
    with conn.cursor() as cur:
        execute_values(cur, sql, clean, page_size=BATCH_SIZE_SPECTRAL)
    conn.commit()
    return len(clean)


def insert_integrated_batch(conn, rows: Sequence[tuple]) -> int:
    """Upsert az integrált táblába a (timestamp + suffix-elt) oszlopokba."""
    if not rows:
        return 0
    clean = [tuple(_py(x) for x in r) for r in rows]
    cols = _int_insert_cols()
    sql = _build_upsert_sql(INTEGRATED_TABLE, cols)
    with conn.cursor() as cur:
        execute_values(cur, sql, clean, page_size=BATCH_SIZE_INT)
    conn.commit()
    return len(clean)


# ============================================================================
# AOD összeállítás
# ============================================================================

def _clean_aod(d: dict) -> dict:
    """PyMieScatt kimenet → kötelező kulcsok + default fallback."""
    dd = dict(d or {})
    if "OMEGL" not in dd and "SSA" in dd:
        dd["OMEGL"] = dd.get("SSA")
    if "OMEGL" not in dd and "ssa" in dd:
        dd["OMEGL"] = dd.get("ssa")
    for k, dflt in DEFAULT_AOD.items():
        dd[k] = _safe_float(dd.get(k))
        if not np.isfinite(dd[k]):
            dd[k] = float(dflt)
    return dd


def _build_cams_upper_aod(row: pd.Series) -> Dict[int, float]:
    """CAMS Upper AOD rétegek kigyűjtése per-hullámhossz (nm)."""
    def _sf(key, dflt=np.nan):
        v = _safe_float(row.get(key), np.nan)
        if not np.isfinite(v):
            v = _safe_float(row.get(key.lower()), np.nan)
        return float(v) if np.isfinite(v) else float(dflt)

    u355  = _sf("Upper_aod_355",  np.nan)
    u532  = _sf("Upper_aod_532",  np.nan)
    u1064 = _sf("Upper_aod_1064", np.nan)
    u335  = _sf("Upper_aod_335",  np.nan)
    u550  = _sf("Upper_aod_550",  np.nan)

    if np.isfinite(u532) and np.isfinite(u1064) and u532 >= 0 and u1064 >= 0:
        out = {532: float(np.clip(u532, 0.0, 3.0)),
               1064: float(np.clip(u1064, 0.0, 3.0))}
        if np.isfinite(u355) and u355 >= 0: out[355] = float(np.clip(u355, 0.0, 3.0))
        if np.isfinite(u335) and u335 >= 0: out[335] = float(np.clip(u335, 0.0, 3.0))
        if np.isfinite(u550) and u550 >= 0: out[550] = float(np.clip(u550, 0.0, 3.0))
        return out

    # fallback
    tau340  = _sf("Total_aerosol_optical_depth_at_340_nm",  np.nan)
    tau500  = _sf("Total_aerosol_optical_depth_at_500_nm",  np.nan)
    tau1064 = _sf("Total_aerosol_optical_depth_at_1064_nm", np.nan)
    tau550  = _sf("Total_Aerosol_Optical_Depth_at_550nm",   np.nan)
    if not np.isfinite(tau550):
        tau550 = _sf("TAU550", 0.10)

    def _u(t, dflt):
        return float(np.clip(0.30 * t, 0.0, 2.0)) if (np.isfinite(t) and t > 0) else float(dflt)

    return {
        340:  _u(tau340,  0.05),
        500:  _u(tau500,  0.03),
        550:  _u(tau550,  0.03),
        1064: _u(tau1064, 0.01),
    }


def _compute_aod(row: pd.Series, cams_upper_aod: dict, i: int) -> dict:
    """PyMieScatt AOD robusztus hívás."""
    try:
        return calculate_new_aod_params(row, row, cams_upper_aod, row_idx=i)
    except TypeError:
        pass
    try:
        return calculate_new_aod_params(
            row=row, cams_ratios_row=row,
            cams_upper_aod=cams_upper_aod, row_idx=i,
        )
    except TypeError:
        pass
    try:
        return calculate_new_aod_params(row, None, i, False, row, row, cams_upper_aod)
    except TypeError:
        pass
    return dict(DEFAULT_AOD)


def _detect_pymiescatt_and_fallback_flags(row: pd.Series, aod_params: dict) -> Tuple[int, int]:
    """
    Eldönti, hogy az adott timestamp-nél:
      - ispymiescatt = 1 ha a PyMieScatt (Mie fizika) doméns részt vesz az AOD-ban
                      (empirical_weight < 1.0 + PM/BLH input elérhető).
                      = 0 ha tisztán empirikus / fallback.
      - isfallback   = 1 ha valamelyik kulcs input HIÁNYZOTT és default helyettesítéssel
                      futott a számítás (nincs CAMS ratios, nincs BLH, nincs PM2.5, stb.).
                      = 0 ha MINDEN kulcs input elérhető volt és az aod_params is érvényes.

    A két flag FÜGGETLEN (mindkét mód lehet 1 egyszerre: pl. Mie fut, de RH hiányzott).
    A logika MEGEGYEZIK a calculate_new_aod_params belső ágaival (aod_pymiescatt.py).
    """
    # ────────── (1) CAMS ratios elérhetőség (bc_total / om_total / dust_total) ──────────
    bc_total = helpers._safe_float(row.get("bc_total"), np.nan)
    om_total = helpers._safe_float(row.get("om_total"), np.nan)
    dust_total = helpers._safe_float(row.get("dust_total"), np.nan)
    ratios_ok = (np.isfinite(bc_total) and np.isfinite(om_total) and np.isfinite(dust_total)
                 and (bc_total + om_total + dust_total) > 0)

    # ────────── (2) BLH elérhetőség ──────────
    blh_raw = np.nan
    for k in ("boundary_layer_height", "Boundary_layer_height", "blh_m"):
        v = helpers._safe_float(row.get(k), np.nan)
        if np.isfinite(v):
            blh_raw = v; break
    blh_ok = np.isfinite(blh_raw)

    # ────────── (3) PM2.5 elérhetőség (a local extinction input-jához) ──────────
    pm_raw = np.nan
    for k in ("pm2_5", "pm25", "PM2_5", "PM25",
              "sensor.tvl9_pm_monitor_pm2_5", "sensor.tvl9_o_1pst_pm2_5"):
        v = helpers._safe_float(row.get(k), np.nan)
        if np.isfinite(v):
            pm_raw = v; break
    pm_ok = np.isfinite(pm_raw)

    # ────────── (4) RH elérhetőség (hygroscopic growth-hoz) ──────────
    rh_raw = helpers._safe_float(row.get("Relative_humidity"), np.nan)
    rh_ok = np.isfinite(rh_raw)

    # ────────── (5) aod_params érvényessége ──────────
    tau550 = helpers._safe_float(aod_params.get("TAU550"), np.nan)
    alpha1 = helpers._safe_float(aod_params.get("ALPHA1"), np.nan)
    alpha2 = helpers._safe_float(aod_params.get("ALPHA2"), np.nan)
    aod_ok = np.isfinite(tau550) and np.isfinite(alpha1) and np.isfinite(alpha2)

    # ────────── (6) empirical_weight számítás (azonos aod_pymiescatt.py-vel) ──────────
    # local_mass_bc = mass_bc (CAMS ratios-bol szarmazik; ha hianyzik, default 0.05)
    if ratios_ok:
        total_mass = bc_total + om_total + dust_total
        mass_bc = float(bc_total / total_mass) if total_mass > 0 else 0.05
    else:
        mass_bc = 0.05   # default fallback a aod_pymiescatt.py logikaban

    # Dynamic BC override: ha pm1 és pm2.5 adat van, local_mass_bc modosulhat
    local_mass_bc = float(mass_bc)
    pm1_raw = np.nan
    for k in ("pm1_0", "pm1", "sensor.tvl9_o_1pst_pm1_0", "sensor.tvl9_o_1pst_pm1"):
        v = helpers._safe_float(row.get(k), np.nan)
        if np.isfinite(v):
            pm1_raw = v; break
    if np.isfinite(pm1_raw) and np.isfinite(pm_raw) and pm_raw > 0:
        fine_ratio = float(np.clip(pm1_raw / pm_raw, 0.0, 1.0))
        intensity_factor = float(np.clip((pm1_raw - 10.0) / 40.0, 0.0, 1.0))
        local_mass_bc = float(np.clip(mass_bc + (0.20 * intensity_factor * fine_ratio),
                                       mass_bc, 0.30))

    # empirical_weight = 0 ha mie tiszta dominanciaju, 1 ha csak empirikus
    empirical_weight = float(np.clip((local_mass_bc - 0.08) / 0.07, 0.0, 1.0))

    # ispymiescatt = 1 ha Mie ag aktiv (empirical_weight < 1.0) ES a BC-hez kellö input is adott
    # A Mie sikeressége itt nem modellezhetö teljesen pontosan (pms.Mie_Lognormal kivetel nelkul NEM hivtuk meg),
    # de az input minimum: PM2.5 (optikai vastagsaghoz) es BLH elérhetö.
    # HA a globalis DISABLE_PYMIESCATT aktiv, ispymie = 0 (a monkey-patch miatt a belso
    # Mie ag sose fut, a calculate_new_aod_params empirical_weight=1.0-t allit be).
    if DISABLE_PYMIESCATT:
        ispymie = 0
    else:
        ispymie = 1 if (empirical_weight < 1.0 and pm_ok and blh_ok) else 0

    # isfallback = 1 ha barmelyik kulcs input hianyzott VAGY az aod_params nem érvényes
    isfallback = 0 if (ratios_ok and blh_ok and pm_ok and rh_ok and aod_ok) else 1

    return (int(ispymie), int(isfallback))


# ============================================================================
# SMARTS WRAPPER — teljes nyers spektrum kinyerése
# ============================================================================

def _extract_spectrum(spec_df: pd.DataFrame, col_name: str) -> Optional[np.ndarray]:
    if spec_df is None or spec_df.empty or col_name not in spec_df.columns:
        return None
    return pd.to_numeric(spec_df[col_name], errors="coerce").to_numpy(dtype=float)


def run_smarts_spectral(row: pd.Series, df_full: pd.DataFrame,
                         aod_params: dict,
                         panel_tilt_deg: float, panel_azimuth_deg: float,
                         iout_codes: list[int]) -> Dict[str, Any]:
    """SMARTS futtatás egy sorra → teljes λ-rács + komponensek."""
    try:
        input_txt = build_smarts_input_new_aod(
            row=row, df_full=df_full,
            aod_params=aod_params,
            panel_tilt_deg=float(panel_tilt_deg),
            panel_azimuth_deg=float(panel_azimuth_deg),
            iout_codes=list(iout_codes),
        )
    except Exception:
        return {}

    spec_df, _ = run_smarts_once(input_txt, return_is_tilt=True)
    if spec_df is None or spec_df.empty:
        return {}

    # DHI fallback
    cols = set(spec_df.columns)
    if (3 in iout_codes) and ("dhi_w_m2_per_nm" not in cols):
        if ("ghi_w_m2_per_nm" in cols) and ("dir_horiz_w_m2_per_nm" in cols):
            spec_df = spec_df.copy()
            ghi_s = pd.to_numeric(spec_df["ghi_w_m2_per_nm"],       errors="coerce")
            dirh  = pd.to_numeric(spec_df["dir_horiz_w_m2_per_nm"], errors="coerce")
            spec_df["dhi_w_m2_per_nm"] = (ghi_s - dirh).clip(lower=0.0)

    # Diffuse tilt fallback
    cols = set(spec_df.columns)
    if (7 in iout_codes) and ("diff_tilt_w_m2_per_nm" not in cols) and ("dir_tilt_w_m2_per_nm" in cols):
        cand = [c for c in spec_df.columns
                if c not in ("wavelength_nm", "dir_tilt_w_m2_per_nm")]
        if len(cand) == 1:
            spec_df = spec_df.rename(columns={cand[0]: "diff_tilt_w_m2_per_nm"})
        else:
            for c in cand:
                if "dif" in c.lower():
                    spec_df = spec_df.rename(columns={c: "diff_tilt_w_m2_per_nm"})
                    break

    wl = pd.to_numeric(spec_df["wavelength_nm"], errors="coerce").to_numpy(dtype=float)
    out: Dict[str, Any] = {"wavelengths": wl}

    for col_name, key in (
        ("ghi_w_m2_per_nm",       "ghi"),
        ("dni_w_m2_per_nm",       "dni"),
        ("dhi_w_m2_per_nm",       "dhi"),
        ("dir_tilt_w_m2_per_nm",  "beam"),
        ("diff_tilt_w_m2_per_nm", "diffuse"),
    ):
        arr = _extract_spectrum(spec_df, col_name)
        out[key] = arr
        out[f"{key}_raw"] = _raw_integral(wl, arr, RAW_WLMIN, RAW_WLMAX) if arr is not None else np.nan

    return out


# ============================================================================
# IDŐABLAK KEZELÉS
# ============================================================================

def _parse_clearsky_periods() -> List[Tuple[pd.Timestamp, pd.Timestamp]]:
    """const.py PERIODS → UTC (t0, t1) tuple lista."""
    out: List[Tuple[pd.Timestamp, pd.Timestamp]] = []
    for s, e in PERIODS:
        t0 = pd.Timestamp(s); t1 = pd.Timestamp(e)
        t0 = t0.tz_convert("UTC") if t0.tzinfo else t0.tz_localize("UTC")
        t1 = t1.tz_convert("UTC") if t1.tzinfo else t1.tz_localize("UTC")
        if t1 <= t0:
            print(f"[WARN] érvénytelen PERIOD kihagyva: {s} → {e}")
            continue
        out.append((t0, t1))
    return out


def _parse_allsky_ranges(ranges: Iterable[str]
                          ) -> List[Tuple[pd.Timestamp, pd.Timestamp]]:
    """'YYYY.MM.DD-YYYY.MM.DD' → (t0, t1) UTC tuple (inkluzív)."""
    out: List[Tuple[pd.Timestamp, pd.Timestamp]] = []
    for s in ranges:
        raw = str(s).strip()
        if not raw:
            continue
        parts = raw.split("-")
        if len(parts) != 2:
            print(f"[WARN] érvénytelen ALLSKY_RANGES elem: '{raw}'")
            continue
        d0 = parts[0].strip().replace(".", "-")
        d1 = parts[1].strip().replace(".", "-")
        try:
            t0 = pd.Timestamp(f"{d0} 00:00:00", tz="UTC")
            t1 = pd.Timestamp(f"{d1} 23:59:59.999999", tz="UTC")
        except Exception as e:
            print(f"[WARN] ALLSKY_RANGES parse hiba '{raw}': {e}")
            continue
        if t1 <= t0:
            print(f"[WARN] ALLSKY tartomány fordított: '{raw}' — kihagyva")
            continue
        out.append((t0, t1))
    return out


def _resolve_periods(mode: str) -> List[Tuple[pd.Timestamp, pd.Timestamp]]:
    m = (mode or "").strip().lower()
    if m == "clearsky":
        return _parse_clearsky_periods()
    if m == "allsky":
        return _parse_allsky_ranges(ALLSKY_RANGES)
    if m == "postprocess":
        sub = (POSTPROCESS_MODE or "").strip().lower()
        if sub == "allsky":
            return _parse_allsky_ranges(ALLSKY_RANGES)
        return _parse_clearsky_periods()
    raise ValueError(f"Ismeretlen RUN_MODE: {mode!r}")


# ============================================================================
# SMARTS + INTEGRÁLÁS CHUNK-ON
# ============================================================================

def _process_chunk_live(conn, chunk_periods: List[Tuple[pd.Timestamp, pd.Timestamp]],
                        ctx: IntegrationContext) -> Tuple[int, int, int]:
    """NYERS SMARTS + INTEGRÁLT számítás chunk-ra. Mindkét táblába ír."""
    if not chunk_periods:
        return 0, 0, 0

    chunk_t0 = min(t0 for t0, _ in chunk_periods)
    chunk_t1 = max(t1 for _, t1 in chunk_periods)

    print(f"\n{'─' * 78}")
    print(f"CHUNK (live):  {chunk_t0} → {chunk_t1}   ({len(chunk_periods)} period)")
    print(f"{'─' * 78}")

    # 1) CENTRAL ----------------------------------------------------------
    central_frames = []
    for t0, t1 in chunk_periods:
        try:
            dfc = loaders.fetch_central_df(CENTRAL_ENTITY_IDS, t0, t1)
            if dfc is not None and not dfc.empty:
                central_frames.append(dfc)
        except Exception as e:
            print(f"  [WARN] Central fetch hiba {t0.date()}: {e}")

    if central_frames:
        df_wide = pd.concat(central_frames, ignore_index=True)
        df_wide["timestamp"] = pd.to_datetime(df_wide["timestamp"], utc=True, errors="coerce")
        df_wide = (df_wide.dropna(subset=["timestamp"])
                          .sort_values("timestamp")
                          .groupby("timestamp", as_index=False).first())
        df_long = df_wide.melt(id_vars=["timestamp"],
                               var_name="entity_id",
                               value_name="value").dropna(subset=["value"])
    else:
        df_long = pd.DataFrame(columns=["timestamp", "entity_id", "value"])

    # 2) CAMS -------------------------------------------------------------
    cams_t0 = chunk_t0 - pd.Timedelta(hours=6)
    cams_t1 = chunk_t1 + pd.Timedelta(hours=6)

    df_cams_s = loaders.load_cams_from_spectrl2_view(conn, cams_t0, cams_t1)
    df_cams_a = loaders.load_cams_atm_data(conn, cams_t0, cams_t1)
    df_cams_r = loaders.load_cams_ratios(conn, cams_t0, cams_t1)
    df_cams_u = loaders.load_cams_upper_aod_multilevel(conn, cams_t0, cams_t1)

    df_cams_all: Optional[pd.DataFrame] = None
    for d in (df_cams_s, df_cams_a, df_cams_r, df_cams_u):
        if d is None or d.empty:
            continue
        d = d.copy()
        d["timestamp"] = pd.to_datetime(d["timestamp"], utc=True, errors="coerce")
        d = (d.dropna(subset=["timestamp"])
              .drop_duplicates("timestamp")
              .sort_values("timestamp"))
        df_cams_all = d if df_cams_all is None else df_cams_all.merge(d, on="timestamp", how="outer")

    if df_cams_all is None:
        df_cams_all = pd.DataFrame({"timestamp": pd.to_datetime([], utc=True)})

    cams_cols = [c for c in df_cams_all.columns if c != "timestamp"]

    # 3) 10 mp-es rács + CAMS attach -------------------------------------
    df_full_parts: List[pd.DataFrame] = []
    for t0, t1 in chunk_periods:
        dfl = df_long[(df_long["timestamp"] >= t0) & (df_long["timestamp"] <= t1)].copy()
        df_10s = loaders.build_central_grid_10s_filtered(dfl, t0, t1, freq="10S")

        t0w = t0 - pd.Timedelta(hours=6)
        t1w = t1 + pd.Timedelta(hours=6)
        df_cams_win = df_cams_all[
            (df_cams_all["timestamp"] >= t0w) & (df_cams_all["timestamp"] <= t1w)
        ].copy()
        df_part = loaders.attach_cams_to_10s_grid(df_10s, df_cams_win, cams_cols)
        if df_part is not None and not df_part.empty:
            df_full_parts.append(df_part)

    if not df_full_parts:
        print("  [WARN] Üres 10s grid → chunk skip")
        return 0, 0, 0

    df_full = pd.concat(df_full_parts, ignore_index=True)
    df_full["timestamp"] = pd.to_datetime(df_full["timestamp"], utc=True, errors="coerce")
    df_full = (df_full.dropna(subset=["timestamp"])
                      .drop_duplicates("timestamp")
                      .sort_values("timestamp")
                      .reset_index(drop=True))
    if df_full.empty:
        print("  [WARN] Üres df_full → chunk skip")
        return 0, 0, 0

    print(f"  ✓ 10 mp rács:  N = {len(df_full)}")

    # 4) Sorról sorra: SMARTS + integrálás --------------------------------
    batch_spec: List[tuple] = []
    batch_int:  List[tuple] = []
    n_processed = n_spec_w = n_int_w = 0
    N = len(df_full)

    for i in range(N):
        row = df_full.iloc[i]
        ts = pd.to_datetime(row["timestamp"], utc=True, errors="coerce")

        try:
            elev = helpers._sun_elev_deg(ts, DEFAULT_LAT, DEFAULT_LON, DEFAULT_ALT_KM)
            if elev < SUN_MIN_ELEV_DEG:
                continue
        except Exception:
            continue

        cams_upper_aod = _build_cams_upper_aod(row)
        aod_params = _clean_aod(_compute_aod(row, cams_upper_aod, i))

        # ÚJ: pymiescatt / fallback flagek — az aod_params és row inputok alapján
        ispymie_flag, isfb_flag = _detect_pymiescatt_and_fallback_flags(row, aod_params)

        # 3 SMARTS futás
        try:
            out_ghi = run_smarts_spectral(row, df_full, aod_params,
                                          panel_tilt_deg=0.0,
                                          panel_azimuth_deg=GHI_AZIMUTH_DEG,
                                          iout_codes=IOUT_0TILT_GHI_DNI_DHI)
        except Exception as e:
            print(f"  [WARN] GHI SMARTS @ {ts}: {e}")
            out_ghi = {}

        try:
            out_g12 = run_smarts_spectral(row, df_full, aod_params,
                                          panel_tilt_deg=GTI1_TILT_DEG,
                                          panel_azimuth_deg=GTI_AZIMUTH_DEG,
                                          iout_codes=IOUT_TILT_BEAM_DIFFUSE)
        except Exception as e:
            print(f"  [WARN] GTI12 SMARTS @ {ts}: {e}")
            out_g12 = {}

        try:
            out_g15 = run_smarts_spectral(row, df_full, aod_params,
                                          panel_tilt_deg=GTI2_TILT_DEG,
                                          panel_azimuth_deg=GTI_AZIMUTH_DEG,
                                          iout_codes=IOUT_TILT_BEAM_DIFFUSE)
        except Exception as e:
            print(f"  [WARN] GTI15 SMARTS @ {ts}: {e}")
            out_g15 = {}

        wl = out_ghi.get("wavelengths",
              out_g12.get("wavelengths",
                          out_g15.get("wavelengths")))
        if wl is None:
            continue

        # (A) NYERS SPEKTRUM batch  (sorrend MEGEGYEZIK _SPECTRAL_BASE_COLS-szal)
        spec_tuple = (
            ts,
            json.dumps([round(float(w), 1) for w in wl]),      # wavelengths
            _spectrum_to_json(wl, out_ghi.get("ghi")),          # ghi_spectrum
            _spectrum_to_json(wl, out_ghi.get("dni")),          # dni_spectrum
            _spectrum_to_json(wl, out_ghi.get("dhi")),          # dhi_spectrum
            _spectrum_to_json(wl, out_g12.get("beam")),         # gti1225_beam_spectrum
            _spectrum_to_json(wl, out_g12.get("diffuse")),      # gti1225_diff_spectrum
            _spectrum_to_json(wl, out_g15.get("beam")),         # gti1545_beam_spectrum
            _spectrum_to_json(wl, out_g15.get("diffuse")),      # gti1545_diff_spectrum
            out_ghi.get("ghi_raw", np.nan),                     # ghi_raw
            out_ghi.get("dni_raw", np.nan),                     # dni_raw
            out_ghi.get("dhi_raw", np.nan),                     # dhi_raw
            out_g12.get("beam_raw",    np.nan),                 # gti1225_beam_raw
            out_g12.get("diffuse_raw", np.nan),                 # gti1225_diff_raw
            out_g15.get("beam_raw",    np.nan),                 # gti1545_beam_raw
            out_g15.get("diffuse_raw", np.nan),                 # gti1545_diff_raw
        )
        batch_spec.append(spec_tuple)

        # (B) INTEGRÁLT batch
        int_tuple = _build_integrated_tuple(
            ts=ts, wl=wl,
            ghi_spec=out_ghi.get("ghi"),
            g12_beam=out_g12.get("beam"), g12_diff=out_g12.get("diffuse"),
            g15_beam=out_g15.get("beam"), g15_diff=out_g15.get("diffuse"),
            ctx=ctx,
            ispymiescatt=ispymie_flag,
            isfallback=isfb_flag,
        )
        batch_int.append(int_tuple)
        n_processed += 1

        if len(batch_spec) >= BATCH_SIZE_SPECTRAL:
            n_spec_w += insert_spectral_batch(conn, batch_spec); batch_spec = []
        if len(batch_int) >= BATCH_SIZE_INT:
            n_int_w  += insert_integrated_batch(conn, batch_int); batch_int = []

        if (i + 1) % 200 == 0:
            g = int_tuple[1]
            g_s = f"{g:.1f}" if (g is not None and np.isfinite(g)) else "nan"
            print(f"  [{i+1:>6}/{N}]  {ts}  GHI={g_s} W/m²")

    if batch_spec:
        n_spec_w += insert_spectral_batch(conn, batch_spec); batch_spec = []
    if batch_int:
        n_int_w  += insert_integrated_batch(conn, batch_int); batch_int = []

    print(f"  ✓ Chunk kész:  processed={n_processed}  "
          f"spectral_written={n_spec_w}  integrated_written={n_int_w}")
    return n_processed, n_spec_w, n_int_w


def _build_integrated_tuple(ts: pd.Timestamp,
                            wl: np.ndarray,
                            ghi_spec: Optional[np.ndarray],
                            g12_beam: Optional[np.ndarray],
                            g12_diff: Optional[np.ndarray],
                            g15_beam: Optional[np.ndarray],
                            g15_diff: Optional[np.ndarray],
                            ctx: IntegrationContext,
                            ispymiescatt: int = 0,
                            isfallback: int = 0) -> tuple:
    """Sorrend MEGEGYEZIK _INT_BASE_COLS-szal."""
    aoi_ghi = _compute_aoi(ts, DEFAULT_LAT, DEFAULT_LON, DEFAULT_ALT_KM,
                           0.0, GHI_AZIMUTH_DEG)
    aoi_g12 = _compute_aoi(ts, DEFAULT_LAT, DEFAULT_LON, DEFAULT_ALT_KM,
                           GTI1_TILT_DEG, GTI_AZIMUTH_DEG)
    aoi_g15 = _compute_aoi(ts, DEFAULT_LAT, DEFAULT_LON, DEFAULT_ALT_KM,
                           GTI2_TILT_DEG, GTI_AZIMUTH_DEG)

    ghi_raw, ghi_sr, _ghi_srka, ghi_iam, ghi_final = _integrate_component(
        wl, ghi_spec, aoi_ghi, apply_iam=True, ctx=ctx)

    g12b_raw, g12b_sr, _g12b_srka, g12_iam_b, g12b_final = _integrate_component(
        wl, g12_beam, aoi_g12, apply_iam=True, ctx=ctx)
    g12d_raw, g12d_sr, _g12d_srka, g12_iam_d, g12d_final = _integrate_component(
        wl, g12_diff, aoi_g12, apply_iam=True, ctx=ctx)

    g15b_raw, g15b_sr, _g15b_srka, g15_iam_b, g15b_final = _integrate_component(
        wl, g15_beam, aoi_g15, apply_iam=True, ctx=ctx)
    g15d_raw, g15d_sr, _g15d_srka, g15_iam_d, g15d_final = _integrate_component(
        wl, g15_diff, aoi_g15, apply_iam=True, ctx=ctx)

    g12_iam = g12_iam_b if np.isfinite(g12_iam_b) else g12_iam_d
    g15_iam = g15_iam_b if np.isfinite(g15_iam_b) else g15_iam_d

    return (
        ts,
        ghi_final, g12b_final, g12d_final, g15b_final, g15d_final,
        ghi_raw,   g12b_raw,   g12d_raw,   g15b_raw,   g15d_raw,
        ghi_sr,    g12b_sr,    g12d_sr,    g15b_sr,    g15d_sr,
        aoi_ghi, aoi_g12, aoi_g15,
        ghi_iam, g12_iam, g15_iam,
        float(ctx.kA), float(ctx.wl_min), float(ctx.wl_max),
        int(ispymiescatt), int(isfallback),
    )


# ============================================================================
# POSTPROCESS MÓD — csak az integrálás újraszámolása
# ============================================================================

def _fetch_spectral_window(conn, t0: pd.Timestamp, t1: pd.Timestamp) -> pd.DataFrame:
    """
    Egy időablak spektrum soraiból kiolvassa a wl + GHI + 4 GTI JSONB-eket.

    FONTOS: ha RUN_SUFFIX meg van adva, a postprocess is tudja választani,
    hogy a DEFAULT (suffix nélküli) JSONB spektrumból, vagy a suffix-es
    JSONB-ből olvasson. Itt az ALAPÉRTELMEZETT viselkedés: a suffix-es
    spektrum-oszlopokból olvas ha van, különben a default-okból.
    """
    schema, table = _split_table_fq(SPECTRAL_TABLE)

    # Suffix-es vagy default spektrum oszlopok használata
    use_sfx = bool(RUN_SUFFIX)
    col_ts     = "timestamp"
    col_wl     = _sfx("wavelengths")              if use_sfx else "wavelengths"
    col_ghi    = _sfx("ghi_spectrum")             if use_sfx else "ghi_spectrum"
    col_g12b   = _sfx("gti1225_beam_spectrum")    if use_sfx else "gti1225_beam_spectrum"
    col_g12d   = _sfx("gti1225_diff_spectrum")    if use_sfx else "gti1225_diff_spectrum"
    col_g15b   = _sfx("gti1545_beam_spectrum")    if use_sfx else "gti1545_beam_spectrum"
    col_g15d   = _sfx("gti1545_diff_spectrum")    if use_sfx else "gti1545_diff_spectrum"

    cols = [col_ts, col_wl, col_ghi, col_g12b, col_g12d, col_g15b, col_g15d]

    q = psql.SQL(
        """
        SELECT {cols}
        FROM {schema}.{table}
        WHERE {ts} >= %s AND {ts} <= %s
        ORDER BY {ts}
        """
    ).format(
        cols=psql.SQL(", ").join(psql.Identifier(c) for c in cols),
        schema=psql.Identifier(schema), table=psql.Identifier(table),
        ts=psql.Identifier(col_ts),
    )
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(q, (t0.to_pydatetime(), t1.to_pydatetime()))
        rows = cur.fetchall()
    if not rows:
        return pd.DataFrame(columns=cols)
    df = pd.DataFrame(rows)
    # alias-oljuk, hogy a feldolgozó fv. ne foglalkozzon a suffix-szel
    df = df.rename(columns={
        col_ts:   "timestamp",
        col_wl:   "wavelengths",
        col_ghi:  "ghi_spectrum",
        col_g12b: "gti1225_beam_spectrum",
        col_g12d: "gti1225_diff_spectrum",
        col_g15b: "gti1545_beam_spectrum",
        col_g15d: "gti1545_diff_spectrum",
    })
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
    return (df.dropna(subset=["timestamp"])
              .drop_duplicates("timestamp")
              .sort_values("timestamp"))


def _process_chunk_postprocess(conn, periods: List[Tuple[pd.Timestamp, pd.Timestamp]],
                                ctx: IntegrationContext) -> int:
    """Postprocess: spektrumból újraintegrál."""
    total_written = 0
    for pi, (t0, t1) in enumerate(periods, start=1):
        df = _fetch_spectral_window(conn, t0, t1)
        print(f"  [{pi}/{len(periods)}]  {t0} → {t1}   fetched={len(df)}")
        if df.empty:
            continue

        batch: List[tuple] = []
        for rec in df.to_dict(orient="records"):
            ts = rec["timestamp"]
            if pd.isna(ts):
                continue
            wl = _safe_json_array(rec.get("wavelengths"))
            if wl.size < 3:
                continue

            ghi   = _safe_json_array(rec.get("ghi_spectrum"))
            g12b  = _safe_json_array(rec.get("gti1225_beam_spectrum"))
            g12d  = _safe_json_array(rec.get("gti1225_diff_spectrum"))
            g15b  = _safe_json_array(rec.get("gti1545_beam_spectrum"))
            g15d  = _safe_json_array(rec.get("gti1545_diff_spectrum"))

            def _sized(a: np.ndarray) -> Optional[np.ndarray]:
                return a if (a.size == wl.size) else None

            tup = _build_integrated_tuple(
                ts=ts, wl=wl,
                ghi_spec=_sized(ghi),
                g12_beam=_sized(g12b), g12_diff=_sized(g12d),
                g15_beam=_sized(g15b), g15_diff=_sized(g15d),
                ctx=ctx,
                ispymiescatt=0,  # postprocess: CAMS/PM inputok nem elérhetök → 0 (ismeretlen)
                isfallback=0,    # postprocess: flagek csak clearsky/allsky módban számíthatók
            )
            batch.append(tup)

            if len(batch) >= BATCH_SIZE_INT:
                total_written += insert_integrated_batch(conn, batch)
                batch = []

        if batch:
            total_written += insert_integrated_batch(conn, batch)

        print(f"       → integrated written ({INTEGRATED_TABLE}): so far {total_written}")
    return total_written


# ============================================================================
# MAIN
# ============================================================================

# ============================================================================
# MAIN
# ============================================================================

# ----------------------------------------------------------------------------
# PER-PERIÓDUS RMSE / MBE CSV EXPORT
# ----------------------------------------------------------------------------

# A mért GHI/GTI entity-k a Central DB-ből.
_IMT14_GHI_ENTITY = "sensor.tvl9_imt_14_irrad"
_IMT16_GTI_ENTITY = "sensor.tvl9_imt_16_irrad"   # GTI 12.25°
_IMT15_GTI_ENTITY = "sensor.tvl9_imt_15_irrad"   # GTI 15.45°
_METRICS_DAYLIGHT_MIN_GHI: float = 20.0
_METRICS_DAYTIME_GHI_MIN: float = 70.0
_METRICS_STATS_MAX_GHI_WM2: float = 1400.0
_METRICS_STATS_MAX_GTI_WM2: float = 1600.0
_METRICS_STATS_OUTLIER_IQR_K: float = 6.0
_METRICS_GRID_FREQ: str = "10s"


def _metrics_interp_time(s: pd.Series, idx: pd.DatetimeIndex) -> pd.Series:
    """Idő-alapú interpoláció, belső tartományra (nincs extrapolálás)."""
    if s is None or len(idx) == 0:
        return pd.Series(index=idx, dtype=float)
    s = pd.to_numeric(s, errors="coerce").dropna()
    if s.empty:
        return pd.Series(index=idx, dtype=float)
    s = s[~s.index.duplicated(keep="first")].sort_index()
    u = s.index.union(idx).sort_values()
    s2 = s.reindex(u).interpolate("time", limit_area="inside")
    return s2.reindex(idx)


def _metrics_robust_iqr_mask(x: np.ndarray, k: float = _METRICS_STATS_OUTLIER_IQR_K) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    m = np.isfinite(x)
    if int(m.sum()) < 8:
        return m
    xx = x[m]
    q1, q3 = float(np.nanpercentile(xx, 25)), float(np.nanpercentile(xx, 75))
    iqr = q3 - q1
    if (not np.isfinite(iqr)) or iqr <= 0:
        return m
    return m & (x >= q1 - k * iqr) & (x <= q3 + k * iqr)


def _metrics_bundle(measured: np.ndarray, predicted: np.ndarray,
                    ghi_gate: Optional[np.ndarray] = None,
                    is_gti: bool = False,
                    min_ghi: float = _METRICS_DAYTIME_GHI_MIN) -> Dict[str, float]:
    measured = np.asarray(measured, dtype=float)
    predicted = np.asarray(predicted, dtype=float)
    n0 = min(measured.size, predicted.size)
    empty = {"n": 0, "rmse": float("nan"), "mbe": float("nan"),
             "nrmse_pct": float("nan"), "nmbe_pct": float("nan"),
             "mean_measured": float("nan"), "mean_predicted": float("nan")}
    if n0 <= 0:
        return empty
    measured, predicted = measured[:n0], predicted[:n0]
    gate = (measured if ghi_gate is None else np.asarray(ghi_gate, float))[:n0]
    m = np.isfinite(measured) & np.isfinite(predicted) & np.isfinite(gate) & (gate > float(min_ghi))
    mx = float(_METRICS_STATS_MAX_GTI_WM2 if is_gti else _METRICS_STATS_MAX_GHI_WM2)
    m &= (measured >= 0) & (predicted >= 0) & (measured <= mx) & (predicted <= mx)
    m &= _metrics_robust_iqr_mask(measured) & _metrics_robust_iqr_mask(predicted)
    n = int(m.sum())
    if n == 0:
        return empty
    mm = measured[m]
    pp = predicted[m]
    err = pp - mm
    rmse = float(np.sqrt(np.mean(err ** 2)))
    mbe = float(np.mean(err))
    mean_m = float(np.mean(mm))
    mean_p = float(np.mean(pp))
    denom = abs(mean_m) if (np.isfinite(mean_m) and abs(mean_m) > 1e-9) else float("nan")
    nrmse_pct = float(100.0 * rmse / denom) if np.isfinite(denom) else float("nan")
    nmbe_pct = float(100.0 * mbe / denom) if np.isfinite(denom) else float("nan")
    return {"n": n, "rmse": rmse, "mbe": mbe,
            "nrmse_pct": nrmse_pct, "nmbe_pct": nmbe_pct,
            "mean_measured": mean_m, "mean_predicted": mean_p}


def _metrics_fetch_integrated_for_period(conn,
                                         t0: pd.Timestamp,
                                         t1: pd.Timestamp,
                                         suffix: str) -> pd.DataFrame:
    """
    Beolvassa az INTEGRATED táblából a számított (SR×kA×IAM) értékeket:
        ghi(_suffix), gti1225beam(_suffix), gti1225diffuse(_suffix),
        gti1545beam(_suffix), gti1545diffuse(_suffix)
    és visszaadja timestamp + ghi + gti1225 + gti1545 DataFrame-t.
    """
    col_ghi = f"ghi{suffix}"
    col_b12 = f"gti1225beam{suffix}"
    col_d12 = f"gti1225diffuse{suffix}"
    col_b15 = f"gti1545beam{suffix}"
    col_d15 = f"gti1545diffuse{suffix}"

    schema, tbl = _split_table_fq(INTEGRATED_TABLE)
    q = psql.SQL(
        "SELECT timestamp, "
        "{ghi}::double precision AS ghi, "
        "{b12}::double precision AS b12, "
        "{d12}::double precision AS d12, "
        "{b15}::double precision AS b15, "
        "{d15}::double precision AS d15 "
        "FROM {schema}.{table} "
        "WHERE timestamp >= %s AND timestamp < %s "
        "ORDER BY timestamp"
    ).format(
        ghi=psql.Identifier(col_ghi),
        b12=psql.Identifier(col_b12),
        d12=psql.Identifier(col_d12),
        b15=psql.Identifier(col_b15),
        d15=psql.Identifier(col_d15),
        schema=psql.Identifier(schema),
        table=psql.Identifier(tbl),
    )
    with conn.cursor() as cur:
        cur.execute(q, (t0.to_pydatetime(), t1.to_pydatetime()))
        rows = cur.fetchall()
    if not rows:
        return pd.DataFrame(columns=["timestamp", "ghi", "gti1225", "gti1545"])
    df = pd.DataFrame(rows, columns=["timestamp", "ghi", "b12", "d12", "b15", "d15"])
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
    for c in ("ghi", "b12", "d12", "b15", "d15"):
        df[c] = pd.to_numeric(df[c], errors="coerce")
    # gti1225 és gti1545 komponensek összegzése (NaN-tűrő: ha mindkettő NaN → NaN marad)
    df["gti1225"] = np.where(
        np.isfinite(df["b12"].values) | np.isfinite(df["d12"].values),
        np.nansum(np.vstack([df["b12"].values, df["d12"].values]), axis=0),
        np.nan,
    )
    df["gti1545"] = np.where(
        np.isfinite(df["b15"].values) | np.isfinite(df["d15"].values),
        np.nansum(np.vstack([df["b15"].values, df["d15"].values]), axis=0),
        np.nan,
    )
    return df[["timestamp", "ghi", "gti1225", "gti1545"]].dropna(subset=["timestamp"]).sort_values("timestamp").drop_duplicates("timestamp").reset_index(drop=True)


def _metrics_fetch_measured_for_period(t0: pd.Timestamp,
                                       t1: pd.Timestamp) -> pd.DataFrame:
    """Lekéri a Central DB-ből az IMT14/15/16 mérési idősort egy periódusra (wide DF)."""
    entities = [_IMT14_GHI_ENTITY, _IMT15_GTI_ENTITY, _IMT16_GTI_ENTITY]
    try:
        dfc = loaders.fetch_central_df(entities, t0, t1)
    except Exception as e:
        print(f"  [WARN] Central fetch (metrics) hiba {t0.date()}: {e}")
        return pd.DataFrame(columns=["timestamp"] + entities)
    if dfc is None or dfc.empty:
        return pd.DataFrame(columns=["timestamp"] + entities)
    dfc = dfc.copy()
    dfc["timestamp"] = pd.to_datetime(dfc["timestamp"], utc=True, errors="coerce")
    dfc = dfc.dropna(subset=["timestamp"]).sort_values("timestamp").drop_duplicates("timestamp")
    # Biztosítjuk, hogy minden entity-oszlop létezik
    for e in entities:
        if e not in dfc.columns:
            dfc[e] = np.nan
        dfc[e] = pd.to_numeric(dfc[e], errors="coerce")
    return dfc[["timestamp"] + entities]


def _metrics_compute_for_period(conn,
                                t0: pd.Timestamp,
                                t1: pd.Timestamp,
                                suffix: str) -> Dict[str, Any]:
    """
    Egy periódus RMSE/MBE értékeit számolja:
      - Integrated tábla (a pipeline által most kiszámított suffix-es oszlopokból).
      - Central DB (IMT14/15/16 mérések).
      - 10s rács, daylight szűrés (IMT14 > 20 W/m²), IQR outlier, SMARTS_MAX.

    Ha nincs elég adat, NaN-ok kerülnek a visszaadott dict-be, de a kulcsok mindig
    elkészülnek, hogy a CSV-be minden periódusra írhassunk sort.
    """
    empty_metric = {"n": 0, "rmse": float("nan"), "mbe": float("nan"),
                    "nrmse_pct": float("nan"), "nmbe_pct": float("nan"),
                    "mean_measured": float("nan"), "mean_predicted": float("nan")}
    out: Dict[str, Any] = {
        "t0": t0.isoformat(),
        "t1": t1.isoformat(),
        "ghi":     dict(empty_metric),
        "gti1225": dict(empty_metric),
        "gti1545": dict(empty_metric),
        "n_grid":  0,
        "note":    "",
    }

    try:
        df_int = _metrics_fetch_integrated_for_period(conn, t0, t1, suffix)
    except Exception as e:
        out["note"] = f"integrated fetch error: {e}"
        return out
    if df_int.empty:
        out["note"] = "no integrated rows"
        return out

    df_meas = _metrics_fetch_measured_for_period(t0, t1)
    if df_meas.empty:
        out["note"] = "no measured rows"
        return out

    # 10s rács
    try:
        grid = pd.date_range(t0, t1, freq=_METRICS_GRID_FREQ, tz="UTC", inclusive="left")
    except TypeError:
        grid = pd.date_range(t0, t1, freq=_METRICS_GRID_FREQ, tz="UTC", closed="left")
    if len(grid) < 3:
        out["note"] = "short grid"
        return out

    i_idx = df_int.set_index("timestamp").sort_index()
    m_idx = df_meas.set_index("timestamp").sort_index()

    g_ghi_sm  = _metrics_interp_time(i_idx.get("ghi"),     grid)
    g_12_sm   = _metrics_interp_time(i_idx.get("gti1225"), grid)
    g_15_sm   = _metrics_interp_time(i_idx.get("gti1545"), grid)

    g_ghi_m   = _metrics_interp_time(m_idx.get(_IMT14_GHI_ENTITY), grid)
    g_12_m    = _metrics_interp_time(m_idx.get(_IMT16_GTI_ENTITY), grid)   # 12.25° = IMT16
    g_15_m    = _metrics_interp_time(m_idx.get(_IMT15_GTI_ENTITY), grid)   # 15.45° = IMT15

    mask = (g_ghi_m > _METRICS_DAYLIGHT_MIN_GHI) & np.isfinite(g_ghi_m.to_numpy())
    if int(mask.sum()) < 3:
        out["note"] = "no daylight"
        return out

    a_ghi = g_ghi_m.values.astype(float)[mask.values]
    b_ghi = g_ghi_sm.values.astype(float)[mask.values]
    a12   = g_12_m.values.astype(float)[mask.values]
    b12   = g_12_sm.values.astype(float)[mask.values]
    a15   = g_15_m.values.astype(float)[mask.values]
    b15   = g_15_sm.values.astype(float)[mask.values]

    m_ghi  = _metrics_bundle(a_ghi, b_ghi, ghi_gate=a_ghi, is_gti=False)
    m_1225 = _metrics_bundle(a12,   b12,   ghi_gate=a_ghi, is_gti=True)
    m_1545 = _metrics_bundle(a15,   b15,   ghi_gate=a_ghi, is_gti=True)

    out["n_grid"]   = int(mask.sum())
    out["ghi"]      = m_ghi
    out["gti1225"]  = m_1225
    out["gti1545"]  = m_1545
    return out


def _resolve_metrics_csv_path(run_mode: str, run_suffix: str) -> Optional[str]:
    """
    CSV fájl elérési út meghatározása:
      - ha METRICS_CSV_PATH env van adva: azt használjuk (abszolút vagy relatív path)
      - különben default: <_DEFAULT_METRICS_CSV_DIR>/pipeline_rmse_mbe_<mode>[_<suffix>]_<YYYYmmdd_HHMMSS>.csv
    """
    if METRICS_CSV_PATH:
        return METRICS_CSV_PATH
    try:
        os.makedirs(_DEFAULT_METRICS_CSV_DIR, exist_ok=True)
    except Exception as e:
        print(f"  [WARN] Nem sikerült létrehozni a CSV mappát ({_DEFAULT_METRICS_CSV_DIR}): {e}")
    stamp = pd.Timestamp.utcnow().strftime("%Y%m%d_%H%M%S")
    suf = f"_{run_suffix}" if run_suffix else ""
    name = f"pipeline_rmse_mbe_{run_mode}{suf}_{stamp}.csv"
    return os.path.join(_DEFAULT_METRICS_CSV_DIR, name)


def _export_rmse_mbe_csv(conn,
                         periods: List[Tuple[pd.Timestamp, pd.Timestamp]],
                         run_mode: str,
                         run_suffix: str) -> Optional[str]:
    """
    Pipeline futás után: per-periódus RMSE/MBE számítás és CSV mentés.
    Mindig minden periódusra ír sort (akkor is, ha hibás/üres → "" értékekkel).

    Megjegyzés:
      - A számított idősorok az INTEGRATED táblából jönnek (amibe most írtunk).
      - A mért idősorok a Central DB IMT14 (GHI), IMT16 (GTI 12.25°), IMT15 (GTI 15.45°).
    """
    import csv
    suffix_for_cols = f"_{run_suffix}" if run_suffix else ""
    out_path = _resolve_metrics_csv_path(run_mode, run_suffix)
    if not out_path:
        return None

    print("\n" + "=" * 90)
    print(f"PER-PERIÓDUS RMSE/MBE SZÁMÍTÁS  →  {out_path}")
    print(f"  Integrated oszlopok : ghi{suffix_for_cols}, "
          f"gti1225beam{suffix_for_cols}+gti1225diffuse{suffix_for_cols}, "
          f"gti1545beam{suffix_for_cols}+gti1545diffuse{suffix_for_cols}")
    print(f"  Mérés entity-k      : IMT14 GHI, IMT16 GTI 12.25°, IMT15 GTI 15.45°")
    print(f"  Szűrés              : GHI_mért > {_METRICS_DAYLIGHT_MIN_GHI:.0f} W/m², gate > {_METRICS_DAYTIME_GHI_MIN:.0f} W/m², IQR k={_METRICS_STATS_OUTLIER_IQR_K}")
    print(f"  Periódusok száma    : {len(periods)}")
    print("=" * 90)

    header = [
        "idx", "t0_utc", "t1_utc", "n_grid", "note",
        "ghi_n", "ghi_rmse", "ghi_mbe", "ghi_nrmse_pct", "ghi_nmbe_pct",
        "ghi_mean_measured", "ghi_mean_predicted",
        "gti1225_n", "gti1225_rmse", "gti1225_mbe", "gti1225_nrmse_pct", "gti1225_nmbe_pct",
        "gti1225_mean_measured", "gti1225_mean_predicted",
        "gti1545_n", "gti1545_rmse", "gti1545_mbe", "gti1545_nrmse_pct", "gti1545_nmbe_pct",
        "gti1545_mean_measured", "gti1545_mean_predicted",
    ]

    def _fmt(v: Any) -> str:
        if v is None:
            return ""
        try:
            vf = float(v)
            return "" if not np.isfinite(vf) else f"{vf:.6f}"
        except Exception:
            return str(v)

    rows_out: List[List[Any]] = []
    # Összesített (súlyozott + egyszerű) futtatáshoz gyűjtjük:
    all_ghi, all_12, all_15 = [], [], []

    for i, (t0, t1) in enumerate(periods, start=1):
        try:
            m = _metrics_compute_for_period(conn, t0, t1, suffix_for_cols)
        except Exception as e:
            print(f"  [{i}/{len(periods)}] HIBA: {e}")
            m = {
                "t0": t0.isoformat(), "t1": t1.isoformat(),
                "ghi":     {"n": 0, "rmse": float("nan"), "mbe": float("nan"), "nrmse_pct": float("nan"), "nmbe_pct": float("nan"), "mean_measured": float("nan"), "mean_predicted": float("nan")},
                "gti1225": {"n": 0, "rmse": float("nan"), "mbe": float("nan"), "nrmse_pct": float("nan"), "nmbe_pct": float("nan"), "mean_measured": float("nan"), "mean_predicted": float("nan")},
                "gti1545": {"n": 0, "rmse": float("nan"), "mbe": float("nan"), "nrmse_pct": float("nan"), "nmbe_pct": float("nan"), "mean_measured": float("nan"), "mean_predicted": float("nan")},
                "n_grid": 0, "note": f"error: {e}",
            }

        print(f"  [{i:02d}/{len(periods)}] {t0.strftime('%Y-%m-%d %H:%M')} → {t1.strftime('%H:%M')}  "
              f"GHI RMSE={m['ghi']['rmse']:.2f}  MBE={m['ghi']['mbe']:+.2f}  "
              f"GTI12 RMSE={m['gti1225']['rmse']:.2f}  MBE={m['gti1225']['mbe']:+.2f}  "
              f"GTI15 RMSE={m['gti1545']['rmse']:.2f}  MBE={m['gti1545']['mbe']:+.2f}  "
              f"(n={m['ghi']['n']})  {m.get('note','')}")

        all_ghi.append(m["ghi"])
        all_12.append(m["gti1225"])
        all_15.append(m["gti1545"])

        rows_out.append([
            i, m["t0"], m["t1"], m.get("n_grid", 0), m.get("note", ""),
            m["ghi"]["n"],     _fmt(m["ghi"]["rmse"]),     _fmt(m["ghi"]["mbe"]),     _fmt(m["ghi"]["nrmse_pct"]),     _fmt(m["ghi"]["nmbe_pct"]),     _fmt(m["ghi"]["mean_measured"]),     _fmt(m["ghi"]["mean_predicted"]),
            m["gti1225"]["n"], _fmt(m["gti1225"]["rmse"]), _fmt(m["gti1225"]["mbe"]), _fmt(m["gti1225"]["nrmse_pct"]), _fmt(m["gti1225"]["nmbe_pct"]), _fmt(m["gti1225"]["mean_measured"]), _fmt(m["gti1225"]["mean_predicted"]),
            m["gti1545"]["n"], _fmt(m["gti1545"]["rmse"]), _fmt(m["gti1545"]["mbe"]), _fmt(m["gti1545"]["nrmse_pct"]), _fmt(m["gti1545"]["nmbe_pct"]), _fmt(m["gti1545"]["mean_measured"]), _fmt(m["gti1545"]["mean_predicted"]),
        ])

    # --- összesítő sorok (N-súlyozott és egyszerű periódus-átlag) --------------
    def _weighted_rmse(items: List[Dict[str, float]]) -> float:
        num = 0.0; den = 0
        for it in items:
            r = it.get("rmse", float("nan"))
            n = it.get("n", 0)
            if np.isfinite(r) and n > 0:
                num += n * (r ** 2)
                den += n
        return float(np.sqrt(num / den)) if den > 0 else float("nan")

    def _weighted_mbe(items: List[Dict[str, float]]) -> float:
        num = 0.0; den = 0
        for it in items:
            v = it.get("mbe", float("nan"))
            n = it.get("n", 0)
            if np.isfinite(v) and n > 0:
                num += n * v
                den += n
        return float(num / den) if den > 0 else float("nan")

    def _simple_mean(items: List[Dict[str, float]], key: str) -> float:
        vs = [it.get(key, float("nan")) for it in items if np.isfinite(it.get(key, float("nan")))]
        return float(np.mean(vs)) if vs else float("nan")

    # Súlyozott összesen (N alapján)
    n_sum = lambda items: int(sum(max(0, int(it.get("n", 0))) for it in items))
    rows_out.append([
        "ALL (N-weighted)", "", "", "", "",
        n_sum(all_ghi), _fmt(_weighted_rmse(all_ghi)), _fmt(_weighted_mbe(all_ghi)), "", "", "", "",
        n_sum(all_12),  _fmt(_weighted_rmse(all_12)),  _fmt(_weighted_mbe(all_12)),  "", "", "", "",
        n_sum(all_15),  _fmt(_weighted_rmse(all_15)),  _fmt(_weighted_mbe(all_15)),  "", "", "", "",
    ])
    # Egyszerű átlag periódusok között
    rows_out.append([
        "ALL (simple mean of periods)", "", "", "", "",
        "", _fmt(_simple_mean(all_ghi, "rmse")), _fmt(_simple_mean(all_ghi, "mbe")), "", "", "", "",
        "", _fmt(_simple_mean(all_12,  "rmse")), _fmt(_simple_mean(all_12,  "mbe")), "", "", "", "",
        "", _fmt(_simple_mean(all_15,  "rmse")), _fmt(_simple_mean(all_15,  "mbe")), "", "", "", "",
    ])

    try:
        with open(out_path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f, delimiter=",", quoting=csv.QUOTE_MINIMAL)
            w.writerow(header)
            w.writerows(rows_out)
        print(f"\n✅ METRIKA CSV: {out_path}  ({len(periods)} periódus + 2 összesítő sor)")
        return out_path
    except Exception as e:
        print(f"\n[WARN] CSV írás sikertelen: {e}")
        return None


def _parse_cli() -> argparse.Namespace:
    """CLI — felülírja az env alapú beállításokat ha meg vannak adva."""
    p = argparse.ArgumentParser(
        description="SMARTS spektrális pipeline (raw + SR×kA×IAM integráció)",
        allow_abbrev=False,
    )
    p.add_argument("--mode", choices=["clearsky", "allsky", "postprocess"],
                   default=None,
                   help="futási mód (default: env RUN_MODE vagy 'clearsky')")
    p.add_argument("--postprocess-source", choices=["clearsky", "allsky"],
                   default=None,
                   help="postprocess módban az időablak-forrás")
    p.add_argument("--suffix", type=str, default=None,
                   help="Oszlop-suffix kísérleti futásokhoz. "
                        "Ha meg van adva, új '<base>_<suffix>' oszlopokba ír "
                        "a két táblában. Pl. --suffix blhcap")
    p.add_argument("--no-pymiescatt", action="store_true", default=False,
                   help="A calculate_new_aod_params-on belül a PyMieScatt (Mie) "
                        "agat KIKAPCSOLJA, igy a hibrid modell tisztán az empirikus "
                        "fractal parameterizacion fut. Ez a cached_mie_lognormal "
                        "monkey-patch-elesevel tortenik, igy a calculate_new_aod_params "
                        "sajat belso logikaja (a mie_success=False ag) aktivalodik, "
                        "amely automatikusan empirical_weight=1.0-t allit be.")
    args, _extra = p.parse_known_args()
    return args


# ── Globális flag: ha True, a PyMieScatt ag (Mie theory) ki van kapcsolva ─
DISABLE_PYMIESCATT: bool = False


def _apply_pymiescatt_disable_monkey_patch() -> None:
    """
    Monkey-patch: felülírja az aod_pymiescatt modul cached_mie_lognormal funkcióját
    úgy, hogy mindig NaN-ot ad vissza. Ez az aod_pymiescatt.calculate_new_aod_params
    belső ágában (mie_success = False) az empirical_weight = 1.0-ra állításához vezet,
    tehát a hibrid modell teljes empirikus módba kapcsol.

    FONTOS: ez NEM egyszerűsített modell - a calculate_new_aod_params MAJDNEM TELJESEN
    ugyanúgy fut (layer physics, CAMS ratios, upper atmosphere chemistry, ...),
    csak a Mie Theory ág helyett az empirikus Angström parameterization fut.
    """
    if not hasattr(_aod_pymiescatt_mod, "cached_mie_lognormal"):
        print("  [WARN] aod_pymiescatt modul-ban nincs cached_mie_lognormal - monkey-patch kihagyva")
        return

    _original_cached_mie = _aod_pymiescatt_mod.cached_mie_lognormal

    def _patched_cached_mie(*args, **kwargs):
        # Mindig NaN-okat visszaad -> calculate_new_aod_params belülről
        # mie_success = False -> empirical_weight = 1.0
        return (float("nan"), float("nan"), float("nan"))

    _aod_pymiescatt_mod.cached_mie_lognormal = _patched_cached_mie
    _aod_pymiescatt_mod._original_cached_mie_lognormal = _original_cached_mie
    print("  [MONKEY-PATCH] aod_pymiescatt.cached_mie_lognormal = NaN-visszaado")
    print("  [MONKEY-PATCH] calculate_new_aod_params belso agaban: mie_success=False")
    print("  [MONKEY-PATCH] -> empirical_weight = 1.0 (tisztan empirikus ag)")


def main() -> int:
    args = _parse_cli()
    global RUN_MODE, POSTPROCESS_MODE, RUN_SUFFIX, DISABLE_PYMIESCATT

    if args.mode is not None:
        RUN_MODE = args.mode
    if args.postprocess_source is not None:
        POSTPROCESS_MODE = args.postprocess_source
    if args.suffix is not None:
        RUN_SUFFIX = args.suffix.strip().lower()
    if args.no_pymiescatt:
        DISABLE_PYMIESCATT = True
        _apply_pymiescatt_disable_monkey_patch()

    # suffix validálás (ha üres → default viselkedés)
    RUN_SUFFIX = _validate_suffix(RUN_SUFFIX)

    print("=" * 90)
    print("SMARTS SPEKTRÁLIS PIPELINE  —  NYERS + INTEGRÁLT (SR × kA × IAM)")
    print("=" * 90)
    print(f"  RUN_MODE            : {RUN_MODE}")
    if RUN_MODE == "postprocess":
        print(f"  POSTPROCESS_MODE    : {POSTPROCESS_MODE}")
    if RUN_SUFFIX:
        print(f"  RUN_SUFFIX          : '{RUN_SUFFIX}'  "
              f"(kísérleti oszlopok: *_{RUN_SUFFIX})")
    else:
        print(f"  RUN_SUFFIX          : <nincs>  (default oszlopokba ír)")
    print(f"  SPECTRAL_TABLE      : {SPECTRAL_TABLE}")
    print(f"  INTEGRATED_TABLE    : {INTEGRATED_TABLE}")
    if DISABLE_PYMIESCATT:
        print(f"  PYMIESCATT ag       : KIKAPCSOLVA (cached_mie_lognormal monkey-patch)")
        print(f"                        -> tisztan empirikus Angstrom ag fut a hibrid modellben")
    else:
        print(f"  PYMIESCATT ag       : AKTIV (hibrid Mie + empirikus)")
    print(f"  Nyers WL tartomány  : {RAW_WLMIN:.0f}–{RAW_WLMAX:.0f} nm")
    print(f"  Integrálási WL      : {INT_WLMIN:.0f}–{INT_WLMAX:.0f} nm")
    print(f"  GHI azimut          : {GHI_AZIMUTH_DEG:.2f}° (tilt=0°)")
    print(f"  GTI1 tilt/azimut    : {GTI1_TILT_DEG:.2f}° / {GTI_AZIMUTH_DEG:.2f}°")
    print(f"  GTI2 tilt/azimut    : {GTI2_TILT_DEG:.2f}° / {GTI_AZIMUTH_DEG:.2f}°")
    print(f"  Nap minimum elev    : {SUN_MIN_ELEV_DEG}°")
    print("=" * 90)

    periods = _resolve_periods(RUN_MODE)
    if not periods:
        print("[ERROR] Nincs futtatandó időablak.")
        return 2
    print(f"  → Időablakok száma  : {len(periods)}")
    for i, (t0, t1) in enumerate(periods[:5], 1):
        print(f"      [{i}] {t0}  →  {t1}")
    if len(periods) > 5:
        print(f"      ... (+{len(periods) - 5} további)")

    conn = _get_conn()

    try:
        # tábla DDL (suffix-es oszlopok ADD COLUMN IF NOT EXISTS-szel)
        if RUN_MODE in ("clearsky", "allsky"):
            ensure_spectral_table(conn)
        ensure_integrated_table(conn)

        # SR/IAM/kA
        ctx = IntegrationContext.build()

        # POSTPROCESS
        if RUN_MODE == "postprocess":
            src = "SUFFIX" if RUN_SUFFIX else "DEFAULT"
            print(f"\n[POSTPROCESS] SMARTS NEM fut; a spektrum tábla "
                  f"{src} JSONB oszlopaiból újraszámolok, "
                  f"és a {('*_' + RUN_SUFFIX) if RUN_SUFFIX else 'default'} "
                  f"integrált oszlopokba írok.")
            written = _process_chunk_postprocess(conn, periods, ctx)
            print(f"\n✓ POSTPROCESS KÉSZ — integrált sor upsert: {written}")
            return 0

        # CLEARSKY / ALLSKY
        n_proc = n_spec = n_int = 0
        for start in range(0, len(periods), CHUNK_DAYS):
            chunk = periods[start: start + CHUNK_DAYS]
            np_, ns_, ni_ = _process_chunk_live(conn, chunk, ctx)
            n_proc += np_; n_spec += ns_; n_int += ni_

        print("\n" + "=" * 90)
        print(f"✓ PIPELINE KÉSZ ({RUN_MODE}"
              f"{', suffix=' + RUN_SUFFIX if RUN_SUFFIX else ''})")
        print(f"  Feldolgozott timestamp       : {n_proc}")
        print(f"  Spectral upsert-ek           : {n_spec}  →  {SPECTRAL_TABLE}")
        print(f"  Integrated upsert-ek         : {n_int}   →  {INTEGRATED_TABLE}")
        if RUN_SUFFIX:
            print(f"  Írt oszlopok                 : *_{RUN_SUFFIX}")
        print(f"  (SR×kA×IAM: kA = {ctx.kA:.6f}, "
              f"WL = {ctx.wl_min:.0f}–{ctx.wl_max:.0f} nm)")
        print("=" * 90)

        # ÚJ: per-periódus RMSE/MBE CSV kimenet
        try:
            _export_rmse_mbe_csv(conn, periods, RUN_MODE, RUN_SUFFIX)
        except Exception as e:
            print(f"[WARN] RMSE/MBE CSV export hiba: {e}")

        return 0

    except KeyboardInterrupt:
        print("\n[STOP] megszakítva")
        return 130
    except Exception as e:
        print(f"\n[FATAL] {type(e).__name__}: {e}")
        raise
    finally:
        try:
            conn.close()
        except Exception:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
