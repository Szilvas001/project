import psycopg2.extras

from const import TABLE_MINIMAL_SMARTS, LOGGER
from psycopg2.extras import execute_values
from const import TABLE_MINIMAL_SMARTS


def _py(v):
    """numpy/pandas scalar -> python natív, hogy psycopg2 ne írjon 'np.float64(...)'-t SQL-be."""
    if v is None:
        return None

    # pandas Timestamp -> datetime
    if hasattr(v, "to_pydatetime"):
        try:
            return v.to_pydatetime()
        except Exception:
            pass

    # numpy scalar -> python scalar
    if hasattr(v, "item") and callable(getattr(v, "item")):
        try:
            return v.item()
        except Exception:
            pass

    return v


def insert_dual_pipeline_batch(conn, rows):
    if not rows:
        return 0

    # minden értéket natívra konvertálunk
    clean_rows = [tuple(_py(x) for x in r) for r in rows]

    sql = f"""
        INSERT INTO {TABLE_MINIMAL_SMARTS} (
            timestamp,

            pymiescatt_tau550,
            pymiescatt_alpha1,
            pymiescatt_alpha2,
            pymiescatt_ssa,
            pymiescatt_gg,

            smarts_6a_ghi_raw,
            smarts_6a_ghi_srka,
            smarts_6a_ghi_final,

            smarts_6b_nox_ghi_raw,
            smarts_6b_nox_ghi_srka,
            smarts_6b_nox_ghi_final,

            pymiescatt_tau550_opt,
            pymiescatt_alpha1_opt,
            pymiescatt_alpha2_opt,
            pymiescatt_ssa_opt,
            pymiescatt_gg_opt,

            smarts_6a_ghi_raw_6a_variance_optimised,
            smarts_6a_ghi_srka_6a_variance_optimised,
            smarts_6a_ghi_final_6a_variance_optimised
        )
        VALUES %s
        ON CONFLICT (timestamp) DO UPDATE SET
            pymiescatt_tau550 = EXCLUDED.pymiescatt_tau550,
            pymiescatt_alpha1 = EXCLUDED.pymiescatt_alpha1,
            pymiescatt_alpha2 = EXCLUDED.pymiescatt_alpha2,
            pymiescatt_ssa = EXCLUDED.pymiescatt_ssa,
            pymiescatt_gg = EXCLUDED.pymiescatt_gg,

            smarts_6a_ghi_raw = EXCLUDED.smarts_6a_ghi_raw,
            smarts_6a_ghi_srka = EXCLUDED.smarts_6a_ghi_srka,
            smarts_6a_ghi_final = EXCLUDED.smarts_6a_ghi_final,

            smarts_6b_nox_ghi_raw = EXCLUDED.smarts_6b_nox_ghi_raw,
            smarts_6b_nox_ghi_srka = EXCLUDED.smarts_6b_nox_ghi_srka,
            smarts_6b_nox_ghi_final = EXCLUDED.smarts_6b_nox_ghi_final,

            pymiescatt_tau550_opt = EXCLUDED.pymiescatt_tau550_opt,
            pymiescatt_alpha1_opt = EXCLUDED.pymiescatt_alpha1_opt,
            pymiescatt_alpha2_opt = EXCLUDED.pymiescatt_alpha2_opt,
            pymiescatt_ssa_opt = EXCLUDED.pymiescatt_ssa_opt,
            pymiescatt_gg_opt = EXCLUDED.pymiescatt_gg_opt,

            smarts_6a_ghi_raw_6a_variance_optimised = EXCLUDED.smarts_6a_ghi_raw_6a_variance_optimised,
            smarts_6a_ghi_srka_6a_variance_optimised = EXCLUDED.smarts_6a_ghi_srka_6a_variance_optimised,
            smarts_6a_ghi_final_6a_variance_optimised = EXCLUDED.smarts_6a_ghi_final_6a_variance_optimised
    """

    with conn.cursor() as cur:
        psycopg2.extras.execute_values(cur, sql, clean_rows, page_size=500)
    conn.commit()

    LOGGER.info(f"DB batch insert: {len(clean_rows)} sor")
    return len(clean_rows)

def insert_smarts_finished_batch(conn, rows):
    """
    rows: list of tuples:
      (
        timestamp,
        smarts_ghi_finished,
        smarts_dni_finished,
        smarts_dhi_finished,
        smarts_beam, smarts_diffuse,                 # default = 12.25
        smarts_beam_1225, smarts_diffuse_1225,
        smarts_beam_1545, smarts_diffuse_1545
      )
    """
    if not rows:
        return 0

    sql = f"""
    INSERT INTO {TABLE_MINIMAL_SMARTS} (
        timestamp,
        smarts_ghi_finished,
        smarts_dni_finished,
        smarts_dhi_finished,
        smarts_beam,
        smarts_diffuse,
        smarts_beam_1225,
        smarts_diffuse_1225,
        smarts_beam_1545,
        smarts_diffuse_1545
    )
    VALUES %s
    ON CONFLICT (timestamp) DO UPDATE SET
        smarts_ghi_finished = EXCLUDED.smarts_ghi_finished,
        smarts_dni_finished = EXCLUDED.smarts_dni_finished,
        smarts_dhi_finished = EXCLUDED.smarts_dhi_finished,
        smarts_beam = EXCLUDED.smarts_beam,
        smarts_diffuse = EXCLUDED.smarts_diffuse,
        smarts_beam_1225 = EXCLUDED.smarts_beam_1225,
        smarts_diffuse_1225 = EXCLUDED.smarts_diffuse_1225,
        smarts_beam_1545 = EXCLUDED.smarts_beam_1545,
        smarts_diffuse_1545 = EXCLUDED.smarts_diffuse_1545;
    """

    clean_rows = [tuple(_py(x) for x in r) for r in rows]

    with conn.cursor() as cur:
        execute_values(cur, sql, clean_rows, page_size=500)
    conn.commit()
    return len(rows)


