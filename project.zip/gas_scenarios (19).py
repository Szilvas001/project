from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional, Dict

CURRENT_GAS_SCENARIO_KEY = "LAYERED_ALL_BG"
@dataclass
class GasScenario:
    key: str
    description: str
    base: str  # 'layered', 'combined', 'none'
    active_gases: Optional[List[str]] = None  # None = mind, [] = semmi (HNO2/NO3 default marad)
    add_background_back: bool = False         # csak 'layered' esetén értelmezett

# BACKGROUND_PPMV kulcsok → SMARTS gáznevekhez map
_BG_SMARTS_MAPPING = {
    "CH2O": "HCHO",
    "CH4": "CH4",
    "CO": "CO",
    "O3": "O3",
    # HNO2-höz is van háttér, de azt lent amúgy is konstansra állítjuk
}

GAS_SCENARIOS = {
    # 1) Referencia: CAMS layered integráció, háttér már KIVONVA (jelenlegi logika)
    "LAYERED_ALL_BG": GasScenario(
        key="LAYERED_ALL_BG",
        description="CAMS layered → Ap* (integral/1km − background), minden gáz",
        base="layered",
        active_gases=None,
        add_background_back=False,
    ),
    # 2) Ugyanez, csak a háttér visszaadva (no background subtraction)
    "LAYERED_ALL_noBG": GasScenario(
        key="LAYERED_ALL_noBG",
        description="CAMS layered → Ap* + background visszaadva (no background subtraction)",
        base="layered",
        active_gases=None,
        add_background_back=True,
    ),
    # 3) Csak CH2O a CAMS layered Ap-ből
    "LAYERED_ONLY_CH2O": GasScenario(
        key="LAYERED_ONLY_CH2O",
        description="CAMS layered → csak CH2O, a többi 0 (HNO2/NO3 default)",
        base="layered",
        active_gases=["CH2O"],
        add_background_back=False,
    ),
    # 4) Minden layered gáz, kivéve CH2O
    "LAYERED_NO_CH2O": GasScenario(
        key="LAYERED_NO_CH2O",
        description="CAMS layered → minden gáz CH2O kivételével",
        base="layered",
        active_gases=[g for g in ALL_SMARTS_GASES if g != "CH2O"],
        add_background_back=False,
    ),
    # 5) combined_gas µg/m³ + kg/m² alapján (régi fallback) minden gáz
    "COMBINED_ALL": GasScenario(
        key="COMBINED_ALL",
        description="combined_gas µg/m³ + kg/m² → minden gáz",
        base="combined",
        active_gases=None,
        add_background_back=False,
    ),
    # 6) combined_gas csak CH2O
    "COMBINED_ONLY_CH2O": GasScenario(
        key="COMBINED_ONLY_CH2O",
        description="combined_gas µg/m³ + kg/m² → csak CH2O, többi 0",
        base="combined",
        active_gases=["CH2O"],
        add_background_back=False,
    ),
    # 7) Nincs antropogén gáz (minden 0, kivéve HNO2/NO3 default)
    "NO_GAS": GasScenario(
        key="NO_GAS",
        description="Minden troposzférikus antropogén gáz kikapcsolva (HNO2/NO3 default)",
        base="none",
        active_gases=[],
        add_background_back=False,
    ),
    # 8) Oxidáns-only: O3 + NO2 + SO2 a CAMS layered-ből
    "LAYERED_OXIDANTS_ONLY": GasScenario(
        key="LAYERED_OXIDANTS_ONLY",
        description="CAMS layered → csak oxidánsok (O3, NO2, SO2)",
        base="layered",
        active_gases=["O3", "NO2", "SO2"],
        add_background_back=False,
    ),
}

SCENARIO_ORDER = [
    "LAYERED_ALL_BG",
    "LAYERED_ALL_noBG",
    "LAYERED_ONLY_CH2O",
    "LAYERED_NO_CH2O",
    "COMBINED_ALL",
    "COMBINED_ONLY_CH2O",
    "NO_GAS",
    "LAYERED_OXIDANTS_ONLY",
]

# aktuális futás szcenáriója (globális állapot a 6b buildhez)