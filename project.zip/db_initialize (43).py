import psycopg2
from getpass import getpass
from const import *

def _get_db_conn():
    """Azonos DB-hez csatlakozik, mint a forráslekérés."""
    global DB_PWD_CACHE
    if DB_PWD_CACHE is None:
        DB_PWD_CACHE = getpass(f"PostgreSQL jelszó ({DB_USER}@{DB_HOST}): ")
    return psycopg2.connect(
        host=DB_HOST, port=DB_PORT, dbname=DB_NAME, user=DB_USER, password=DB_PWD_CACHE
    )

def ensure_minimal_smarts_table(conn) -> None:
    """
    Tábla létrehozása/frissítése az új oszlopokkal.

    ÚJ OSZLOPOK:
    - pymiescatt_* : PyMieScatt AOD paraméterek
    - smarts_6a_*  : 6a futás (Moderate gázok + PyMieScatt AOD)
    - smarts_6b_nox_* : 6b futás (CAMS gázok + NOx NO2 + CAMS AOD)
    - pymiescatt_*_opt + smarts_6a_*_variance_optimised : zajtalanított (variance-optimised) ág
    """
    ddl = f"""
    CREATE TABLE IF NOT EXISTS {TABLE_MINIMAL_SMARTS} (
        timestamp          timestamptz PRIMARY KEY,

        -- ÚJ: PyMieScatt AOD paraméterek
        pymiescatt_tau550     double precision,
        pymiescatt_alpha1     double precision,
        pymiescatt_alpha2     double precision,
        pymiescatt_ssa        double precision,
        pymiescatt_gg         double precision,

        -- ÚJ: 6a futás (Moderate gázok + PyMieScatt AOD)
        smarts_6a_ghi_raw     double precision,
        smarts_6a_ghi_srka    double precision,
        smarts_6a_ghi_final   double precision,

        -- ÚJ: 6b futás (CAMS gázok + NOx NO2 + CAMS AOD)
        smarts_6b_nox_ghi_raw   double precision,
        smarts_6b_nox_ghi_srka  double precision,
        smarts_6b_nox_ghi_final double precision,

        -- ÚJ: PyMieScatt OPT (variance optimised)
        pymiescatt_tau550_opt     double precision,
        pymiescatt_alpha1_opt     double precision,
        pymiescatt_alpha2_opt     double precision,
        pymiescatt_ssa_opt        double precision,
        pymiescatt_gg_opt         double precision,

        -- ÚJ: 6a futás OPT (variance optimised)  -- külön oszlopok
        smarts_6a_ghi_raw_6a_variance_optimised   double precision,
        smarts_6a_ghi_srka_6a_variance_optimised  double precision,
        smarts_6a_ghi_final_6a_variance_optimised double precision
    );
    """
    alter = f"""
    ALTER TABLE {TABLE_MINIMAL_SMARTS}
        ADD COLUMN IF NOT EXISTS smarts_ghi_finished double precision,
        ADD COLUMN IF NOT EXISTS smarts_dni_finished double precision,
        ADD COLUMN IF NOT EXISTS smarts_dhi_finished double precision,

        -- ÚJ: string0 (12.25) tilt-re beam/diffuse
        ADD COLUMN IF NOT EXISTS smarts_beam double precision,
        ADD COLUMN IF NOT EXISTS smarts_diffuse double precision,
        ADD COLUMN IF NOT EXISTS smarts_beam_1225 double precision,
        ADD COLUMN IF NOT EXISTS smarts_diffuse_1225 double precision,

        -- ÚJ: string1 (15.45) tilt-re beam/diffuse
        ADD COLUMN IF NOT EXISTS smarts_beam_1545 double precision,
        ADD COLUMN IF NOT EXISTS smarts_diffuse_1545 double precision;
    """



    with conn.cursor() as cur:
        cur.execute(ddl)
        cur.execute(alter)
        conn.commit()

    print(f"✓ Tábla létrehozva/frissítve: {TABLE_MINIMAL_SMARTS} (PyMieScatt + OPT oszlopok)")
