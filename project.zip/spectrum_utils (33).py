from __future__ import annotations

from typing import Tuple
import numpy as np
import pandas as pd
import pvlib

from const import WLMIN, WLMAX
def _ghi_sr_weighted(spec_df: pd.DataFrame, sr_fn) -> float:
    sub = spec_df[(spec_df["wavelength_nm"] >= WLMIN) & (spec_df["wavelength_nm"] <= WLMAX)]
    if sub.shape[0] < 2: return np.nan
    wl = sub["wavelength_nm"].to_numpy(float)
    e  = sub["ghi_w_m2_per_nm"].to_numpy(float)
    sr = np.clip(sr_fn(wl), 0.0, 1.0)
    dlam = np.diff(wl)
    avg  = (e[:-1]*sr[:-1] + e[1:]*sr[1:]) / 2
    return float(np.sum(avg * dlam))
def _ghi_integral_raw(spec_df: pd.DataFrame) -> float:
    """Nyers SMARTS GHI (SR súlyozás NÉLKÜL), trapéz integrál WLMIN–WLMAX."""
    sub = spec_df[(spec_df["wavelength_nm"] >= WLMIN) & (spec_df["wavelength_nm"] <= WLMAX)]
    if sub.shape[0] < 2:
        return np.nan
    wl = sub["wavelength_nm"].to_numpy(float)
    e  = sub["ghi_w_m2_per_nm"].to_numpy(float)
    dlam = np.diff(wl)
    avg  = (e[:-1] + e[1:]) / 2.0
    return float(np.sum(avg * dlam))

def _am15_integral_sr(sr_fn) -> float:
    """
    ∫ AM1.5 (global) * SR(λ) dλ  [W/m^2]
    A WLMIN–WLMAX tartományban (pl. 350–1200 nm), a script PRINT_STEP_NM logikájához igazodva.
    """
    ref = pvlib.spectrum.get_reference_spectra(standard="ASTM G173-03")
    wl = ref.index.values.astype(float)
    # Mindig a GLOBAL görbét használjuk
    e = ref["global"].values.astype(float)

    # Csak a megadott tartományon integrálunk
    m = (wl >= WLMIN) & (wl <= WLMAX)
    wl = wl[m]
    e  = e[m]
    if wl.size < 2:
        return float("nan")

    sr = np.clip(sr_fn(wl), 0.0, 1.0)
    dlam = np.diff(wl)
    avg  = (e[:-1]*sr[:-1] + e[1:]*sr[1:]) / 2
    return float(np.sum(avg * dlam))  # W/m^2


def _am15_denorm_factor(sr_fn) -> Tuple[float, float]:
    """
    Visszaadja:
      f   = ∫ AM1.5G * SR dλ / 1000   (dimenziótlan normalizáló)
      kA  = 1 / f                      (denorm szorzó a SR-integrált → broadband)
    """
    integral = _am15_integral_sr(sr_fn)
    if not np.isfinite(integral) or integral <= 0:
        return float("nan"), float("nan")
    f = integral / 1000.0
    kA = 1.0 / f
    return f, kA

def _rmse(a: np.ndarray, b: np.ndarray) -> float:
    a = np.asarray(a, float); b = np.asarray(b, float)
    m = np.isfinite(a) & np.isfinite(b)
    if not m.any(): return float('nan')
    return float(np.sqrt(np.mean((a[m] - b[m])**2)))

def _integral_raw(spec_df: pd.DataFrame, col: str) -> float:
    if spec_df is None or spec_df.empty:
        return float("nan")
    if "wavelength_nm" not in spec_df.columns or col not in spec_df.columns:
        return float("nan")

    wl = pd.to_numeric(spec_df["wavelength_nm"], errors="coerce").to_numpy(dtype=float)
    y  = pd.to_numeric(spec_df[col], errors="coerce").to_numpy(dtype=float)

    m = np.isfinite(wl) & np.isfinite(y)
    if m.sum() < 3:
        return float("nan")

    wl = wl[m]
    y = y[m]
    idx = np.argsort(wl)
    wl = wl[idx]
    y = y[idx]

    return float(np.trapz(y, wl))


def _integral_sr_weighted(spec_df: pd.DataFrame, col: str, sr_fn) -> float:
    if spec_df is None or spec_df.empty:
        return float("nan")
    if "wavelength_nm" not in spec_df.columns or col not in spec_df.columns:
        return float("nan")

    wl = pd.to_numeric(spec_df["wavelength_nm"], errors="coerce").to_numpy(dtype=float)
    y  = pd.to_numeric(spec_df[col], errors="coerce").to_numpy(dtype=float)

    m = np.isfinite(wl) & np.isfinite(y)
    if m.sum() < 3:
        return float("nan")

    wl = wl[m]
    y = y[m]
    idx = np.argsort(wl)
    wl = wl[idx]
    y = y[idx]

    sr = np.asarray(sr_fn(wl), dtype=float)
    sr = np.where(np.isfinite(sr), sr, 0.0)

    return float(np.trapz(y * sr, wl))

