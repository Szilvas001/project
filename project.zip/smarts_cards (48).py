import numpy as np
import pandas as pd
import pvlib
from const import *
import helpers
from gas_layers import estimate_no2_from_nox
from typing import Optional, Tuple
import math
import numpy as np
import pandas as pd
import pvlib
from const import *
import helpers
import gas_layers as gl
MODERATE_POLLUTION_PPMV = gl.MODERATE_POLLUTION_PPMV
CAMS_AP_COLUMN_MAP = gl.CAMS_AP_COLUMN_MAP
estimate_no2_from_nox = gl.estimate_no2_from_nox

def build_smarts_params(row: pd.Series) -> dict:
    """
    SMARTS input generálás.
    
    Args:
        row: DataFrame sor (timestamp + meteorológia)
    """
    ts   = pd.to_datetime(row["timestamp"], utc=True)
    lat  = helpers._safe_float(row.get("latitude",  DEFAULT_LAT))
    lon  = helpers._safe_float(row.get("longitude", DEFAULT_LON))
    altk = helpers._safe_float(row.get("alt_km",    DEFAULT_ALT_KM))

    # Nyomás (hPa)
    spr = helpers._safe_float(row.get("sensor.tvl9_gw2000a_relative_pressure"))
    if not np.isfinite(spr):
        spr = 1013.25
    spr = helpers._clamp(spr, *SPR_VALID)

    # Hőmérséklet (°C) és RH (%)
    tair = helpers._safe_float(row.get("sensor.tvl9_gw2000a_outdoor_temperature"))
    rh   = helpers._safe_float(row.get("sensor.tvl9_gw2000a_humidity"))
    if not np.isfinite(tair):
        tair = 15.0
    if not np.isfinite(rh):
        rh = 50.0
    rh = helpers._clamp(rh, 0.0, 100.0)

    # Precipitable water (cm)
    w_cm = helpers._safe_float(row.get("Total_column_vertically_integrated_water_vapour"))
    if np.isfinite(w_cm):
        w_cm = w_cm / 10.0
    else:
        try:
            w_cm = float(pvlib.atmosphere.gueymard94_pw(tair, rh))
        except Exception:
            w_cm = 1.5

    # Ózon (atm·cm)
    o3atm = _o3_atmcm_auto(helpers._safe_float(row.get("GEMS_Total_column_ozone")))
    if not np.isfinite(o3atm):
        o3atm = 0.3

    # Aeroszol paraméterek - JAVÍTVA: 3 érték!
    alpha1, alpha2, tau550 = _compute_alpha_tau(row)
    ssa, gg = _derive_ssa_g(row)

    # Albedo (broadband)
    albedo_bb = _derive_albedo(row)

    # CO2 (ppmv)
    co2_ppmv = _co2_ppm_from_row(row)
    if not np.isfinite(co2_ppmv) or co2_ppmv <= 0:
        co2_ppmv = DEFAULT_CO2_PPM

    # AOI (deg)
    aoi_deg = helpers._compute_aoi(ts, lat, lon, altk, PANEL_TILT, PANEL_AZIMUTH)
    aoi_deg = float(np.clip(aoi_deg, 0.0, 90.0))

    return dict(
        timestamp=ts,
        latitude=lat,
        longitude=lon,
        alt_km=altk,
        spr_hpa=spr,
        tair_c=tair,
        rh_pct=rh,
        pw_cm=w_cm,
        o3_atm_cm=o3atm,
        alpha1=alpha1,     # ÚJ: ALPHA1 (340-500nm)
        alpha2=alpha2,     # ÚJ: ALPHA2 (500-1064nm)
        tau550=tau550,
        ssa=ssa,
        gg=gg,
        albedo_bb=albedo_bb,
        co2_ppm=co2_ppmv,
        aoi_deg=aoi_deg
    )

def _o3_atmcm_auto(v):
    v = helpers._safe_float(v, np.nan)
    if not np.isfinite(v): return np.nan
    if v > 10.0: return v / 1000.0
    if 0.05 <= v <= 1.5: return v
    return (v / 2.1415e-5) / 1000.0


def _co2_ppm_from_row(row: pd.Series) -> float:
    for col in ["sensor.tvl9_o_1pst_carbon_dioxide", "carbon_dioxide (ppm)", "co2_ppm"]:
        if col in row.index and pd.notna(row[col]):
            v = helpers._safe_float(row[col])
            if np.isfinite(v) and v > 0: return float(v)
    return DEFAULT_CO2_PPM


def _compute_alpha_tau(row: pd.Series) -> Tuple[float, float, float]:
    """
    ALPHA1, ALPHA2 és TAU550 kinyerése a sorból.
    
    Ha az ALPHA1/ALPHA2 már ki van számolva (loaders.load_cams_atm_data által), használjuk azokat.
    Egyébként fallback a régi logikára.
    
    Returns:
        (ALPHA1, ALPHA2, TAU550)
    """
    # --- Elsődleges: előre számolt értékek ---
    alpha1 = helpers._safe_float(row.get("ALPHA1"))
    alpha2 = helpers._safe_float(row.get("ALPHA2"))
    tau550 = helpers._safe_float(row.get("TAU550"))
    
    # Ha mind megvan, használjuk
    if np.isfinite(alpha1) and np.isfinite(alpha2) and np.isfinite(tau550) and tau550 > 0:
        return (
            helpers._clamp(alpha1, *ALPHA_CLAMP),
            helpers._clamp(alpha2, *ALPHA_CLAMP),
            helpers._clamp(tau550, *TAU550_CLAMP)
        )
    
    # --- Fallback: régi számítás ---
    # ALPHA1: 340nm és 500nm közötti
    tau340 = helpers._safe_float(row.get("Total_aerosol_optical_depth_at_340_nm"))
    tau500 = helpers._safe_float(row.get("Total_aerosol_optical_depth_at_500_nm"))
    tau1064 = helpers._safe_float(row.get("Total_aerosol_optical_depth_at_1064_nm"))
    
    if np.isfinite(tau340) and np.isfinite(tau500) and tau340 > 0 and tau500 > 0:
        alpha1 = -math.log(tau340 / tau500) / math.log(340.0 / 500.0)
    else:
        alpha1 = 1.3
    
    # ALPHA2: 500nm és 1064nm közötti
    if np.isfinite(tau500) and np.isfinite(tau1064) and tau500 > 0 and tau1064 > 0:
        alpha2 = -math.log(tau500 / tau1064) / math.log(500.0 / 1064.0)
    else:
        alpha2 = 1.3
    
    alpha1 = helpers._clamp(alpha1, *ALPHA_CLAMP)
    alpha2 = helpers._clamp(alpha2, *ALPHA_CLAMP)
    
    # TAU550 számítás
    tau550_val = helpers._safe_float(row.get("Total_Aerosol_Optical_Depth_at_550nm"))
    if np.isfinite(tau550_val) and tau550_val > 0:
        return alpha1, alpha2, helpers._clamp(tau550_val, *TAU550_CLAMP)
    
    # Ha nincs 550nm, skálázzuk 500→550 ALPHA2-vel
    if np.isfinite(tau500) and tau500 > 0:
        tau550_est = tau500 * (550.0 / 500.0) ** (-alpha2)
        return alpha1, alpha2, helpers._clamp(tau550_est, *TAU550_CLAMP)
    
    # Végső default
    return alpha1, alpha2, 0.10


def _derive_ssa_g(row: pd.Series) -> Tuple[float, float]:
    ssa = helpers._safe_float(row.get("Single_scattering_albedo_at_550_nm"))
    gg  = helpers._safe_float(row.get("Asymmetry_factor_at_550_nm"))
    if not np.isfinite(ssa): ssa = 0.90
    if not np.isfinite(gg):  gg  = 0.70
    return helpers._clamp(ssa, *SSA_CLAMP), helpers._clamp(gg, *GG_CLAMP)

def _derive_albedo(row: pd.Series) -> float:
    for c in ["Forecast_albedo", "Snow_albedo", "albedo"]:
        if c in row.index and pd.notna(row[c]):
            alb = helpers._safe_float(row[c])
            if np.isfinite(alb): return helpers._clamp(alb, *ALBEDO_CLAMP)
    return 0.20
def _compute_tday_24h_avg(df: pd.DataFrame, current_ts: pd.Timestamp, current_tair: float) -> float:
    """
    Visszaadja az utolsó 24 óra átlaghőmérsékletét.
    
    Args:
        df: Teljes DataFrame (timestamp + hőmérséklet oszlopokkal)
        current_ts: Aktuális timestamp
        current_tair: Aktuális hőmérséklet (fallback, ha nincs elég adat)
    
    Returns:
        float: 24 órás átlag hőmérséklet (°C)
    """
    # 24 órás ablak definiálása
    t_start = current_ts - pd.Timedelta(hours=24)
    
    # Hőmérséklet oszlop keresése
    temp_col = None
    for col in ['sensor.tvl9_gw2000a_outdoor_temperature', 'sensor.tvl9_o_1pst_temperature', 'tair_c']:
        if col in df.columns:
            temp_col = col
            break
    
    if temp_col is None:
        return current_tair  # Fallback: aktuális érték
    
    # Szűrés 24 órás ablakra
    mask = (pd.to_datetime(df['timestamp'], utc=True) >= t_start) & \
           (pd.to_datetime(df['timestamp'], utc=True) <= current_ts)
    
    temps = pd.to_numeric(df.loc[mask, temp_col], errors='coerce').dropna()
    
    if len(temps) < 2:
        return current_tair  # Fallback: nincs elég adat
    
    return float(temps.mean())


def build_smarts_input(row: pd.Series, df: pd.DataFrame) -> Optional[str]:
    """
    SMARTS input generálás IGAS=0, ILOAD=3 (Moderate Pollution) móddal.
    
    ✅ GÁZOK: IGAS=0, ILOAD=3 (előre definiált moderate pollution)
    ✅ AEROSZOL: USER mód (ALPHA1, ALPHA2, SSA, GG, TAU550)
    ✅ ALBEDO: FIX 0.2
    """
    ts = pd.to_datetime(row["timestamp"], utc=True, errors="coerce")
    if pd.isna(ts): 
        return None
    
    # ========== HELYSZÍN ==========
    lat = helpers._safe_float(row.get("latitude", DEFAULT_LAT))
    lon = helpers._safe_float(row.get("longitude", DEFAULT_LON))
    alt_km = helpers._safe_float(row.get("alt_km", DEFAULT_ALT_KM))
    
    # ========== METEOROLÓGIA ==========
    spr = helpers._safe_float(row.get("sensor.tvl9_gw2000a_relative_pressure"))
    if not np.isfinite(spr): 
        spr = 1013.25
    spr = helpers._clamp(spr, *SPR_VALID)
    
    tair = helpers._safe_float(row.get("sensor.tvl9_gw2000a_outdoor_temperature"))
    if not np.isfinite(tair):
        tair = helpers._safe_float(row.get("sensor.tvl9_o_1pst_temperature"))
    if not np.isfinite(tair):
        tair = 15.0
    
    rh = helpers._safe_float(row.get("sensor.tvl9_gw2000a_humidity"))
    if not np.isfinite(rh):
        rh = helpers._safe_float(row.get("sensor.tvl9_o_1pst_humidity"))
    if not np.isfinite(rh):
        rh = 50.0
    rh = helpers._clamp(rh, 0.0, 100.0)
    
    # ========== VÍZTARTALOM ==========
    w_cm = helpers._safe_float(row.get("Total_column_vertically_integrated_water_vapour"))
    if np.isfinite(w_cm): 
        w_cm = w_cm / 10.0
    else:
        try: 
            w_cm = float(pvlib.atmosphere.gueymard94_pw(tair, rh))
        except Exception: 
            w_cm = 1.5
    
    # ========== ÓZON ==========
    o3atm = _o3_atmcm_auto(helpers._safe_float(row.get("GEMS_Total_column_ozone")))
    if not np.isfinite(o3atm): 
        o3atm = 0.3
    
    # ========== AEROSZOL (USER MODE) - ALPHA1, ALPHA2 külön! ==========
    alpha1, alpha2, tau550 = _compute_alpha_tau(row)
    ssa, gg = _derive_ssa_g(row)
    
    # ========== CO2 ==========
    co2_ppm = _co2_ppm_from_row(row)
    
    # ========== NAPHELYZET ==========
    hdec = ts.hour + ts.minute/60.0 + ts.second/3600.0
    season = "SUMMER" if ts.month in (5,6,7,8) else "WINTER"
    
    # ========== SMARTS INPUT CARDS ==========
    L = []

    L.append(f"'GHI_ILOAD3_{ts.strftime('%Y%m%d_%H%M%S')}'")  # Card 1: COMNT
    L.append("1")                                              # Card 2: ISPR
    L.append(f"{spr:.2f}, {alt_km:.5f}, 0.0")                 # Card 2a: SPR, ALTIT, HEIGHT
    L.append("0")                                              # Card 3: IATMOS
    
    # TDAY: utolsó 24 óra átlaghőmérséklete
    tday = _compute_tday_24h_avg(df, ts, tair)
    L.append(f"{tair:.2f}, {rh:.1f}, {season}, {tday:.2f}")   # Card 3a: TAIR, RH, SEASON, TDAY
    
    L.append("0")                                              # Card 4: IH2O
    L.append(f"{w_cm:.5f}")                                    # Card 4a: W
    L.append("0")                                              # Card 5: IO3
    L.append(f"0, {o3atm:.6f}")                                # Card 5a: IALT, AbO3
    
    # ========== GÁZOK: IGAS=0, ILOAD=3 (Moderate Pollution) ==========
    L.append("0")                  # Card 6: IGAS
    L.append("3")                  # Card 6a: ILOAD = 3 (Moderate Pollution)
    # ❌ NINCS Card 6b (mert ILOAD ≠ 0)
    
    L.append(f"{co2_ppm:.1f}")                                 # Card 7: qCO2 (ppmv)
    L.append("0")                                              # Card 7a: ISPCTR (Gueymard 2004)
    
    # ✅ USER MÓD: ALPHA1, ALPHA2 külön!
    L.append("'USER'")                                         # Card 8: AEROS
    L.append(f"{alpha1:.4f}, {alpha2:.4f}, {ssa:.4f}, {gg:.4f}")  # Card 8a: ALPHA1, ALPHA2, OMEGL, GG
    
    # ✅ Card 9: TAU550
    L.append("5")                                              # Card 9: ITURB (TAU550 mód)
    L.append(f"{tau550:.6f}")                                  # Card 9a: TAU550

    # ✅ Card 10-10d: MINDEN ALBEDO = 0.2 (FIX)
    L.append("-1")                                             # Card 10: IALBDX (fixed broadband)
    L.append("0.15")                                            # Card 10a: RHOX (FIX 0.2)
    L.append("1")                                              # Card 10b: ITILT
    L.append(f"-1, {PANEL_TILT:.1f}, {PANEL_AZIMUTH:.1f}")     # Card 10c: IALBDG, TILT, WAZIM
    L.append("0.25")                                            # Card 10d: RHOG

    # Card 11–12: spektrális kimenet
    L.append(f"{WLMIN:.1f}, {WLMAX:.1f}, 1.0, 1366.1")         # WLMN, WLMX, SUNCOR, SOLARC
    L.append("2")                                              # IPRT
    L.append(f"{WLMIN:.1f}, {WLMAX:.1f}, {PRINT_STEP_NM:.1f}") # WPMN, WPMX, INTVL
    L.append("4")                                              # IOTOT
    L.append("4 2 3 5")                                        # IOUT (GHI, DNI, DHI, Dir horiz)

    # Card 13–16: opciók kikapcsolva
    L.append("0")  # ICIRC
    L.append("0")  # ISCAN
    L.append("0")  # ILLUM
    L.append("0")  # IUV

    # Card 17: IMASS
    L.append("3")
    # Card 17a: YEAR, MONTH, DAY, HDEC, LAT, LON, TIMEZONE
    L.append(f"{ts.year}, {ts.month}, {ts.day}, {hdec:.6f}, {lat:.6f}, {lon:.6f}, 0")

    L.append("")  # záró üres sor
    return "\n".join(L)


def build_smarts_input_new_aod(
    row, df_full, aod_params,
    panel_tilt_deg: float = PANEL_TILT,
    panel_azimuth_deg: float = PANEL_AZIMUTH,
    iout_codes: list[int] | None = None
):
    """
    ÚJ:
    - panel_tilt_deg paraméter (0°, 12.25°, 15.45°)
    - iout_codes paraméter:
        0°: [4,2,3,5]  => GHI, DNI, DHI, Direct horizontal
        tilt: [6,7]    => Direct tilted, Diffuse tilted
    """
    import numpy as np
    import pandas as pd
    import math

    if iout_codes is None:
        iout_codes = IOUT_0TILT_GHI_DNI_DHI

    ts = pd.to_datetime(row.get("timestamp"), utc=True, errors="coerce")
    if pd.isna(ts):
        return None

    # --- HELYSZÍN ---
    lat = helpers._safe_float(row.get("latitude", DEFAULT_LAT))
    lon = helpers._safe_float(row.get("longitude", DEFAULT_LON))
    alt_km = helpers._safe_float(row.get("alt_km", DEFAULT_ALT_KM))

    # --- METEOROLÓGIA ---
    spr = helpers._safe_float(row.get("sensor.tvl9_gw2000a_relative_pressure"))
    if not np.isfinite(spr):
        spr = 1013.25
    spr = helpers._clamp(spr, *SPR_VALID)

    tair = helpers._safe_float(row.get("sensor.tvl9_gw2000a_outdoor_temperature"))
    if not np.isfinite(tair):
        tair = helpers._safe_float(row.get("sensor.tvl9_o_1pst_temperature"))
    if not np.isfinite(tair):
        tair = 15.0

    rh = helpers._safe_float(row.get("sensor.tvl9_gw2000a_humidity"))
    if not np.isfinite(rh):
        rh = helpers._safe_float(row.get("sensor.tvl9_o_1pst_humidity"))
    if not np.isfinite(rh):
        rh = 50.0
    rh = helpers._clamp(rh, 0.0, 100.0)

    # --- PW (cm) ---
    w_cm = helpers._safe_float(row.get("Total_column_vertically_integrated_water_vapour"))
    if np.isfinite(w_cm):
        w_cm = w_cm / 10.0
    else:
        try:
            w_cm = float(pvlib.atmosphere.gueymard94_pw(tair, rh))
        except Exception:
            w_cm = 1.5

    # --- O3 (atm*cm) ---
    o3atm = _o3_atmcm_auto(helpers._safe_float(row.get("GEMS_Total_column_ozone")))
    if not np.isfinite(o3atm):
        o3atm = 0.3

    # --- AOD / aerosol paraméterek: aod_params-ból (ez a lényeg) ---
    # biztos clamp, fallback
    alpha1 = helpers._safe_float(aod_params.get("ALPHA1", row.get("ALPHA1", 1.30)))
    alpha2 = helpers._safe_float(aod_params.get("ALPHA2", row.get("ALPHA2", 1.30)))
    tau550 = helpers._safe_float(aod_params.get("TAU550", row.get("TAU550", 0.10)))
    ssa    = helpers._safe_float(aod_params.get("OMEGL", aod_params.get("SSA", row.get("OMEGL", 0.90))))
    gg     = helpers._safe_float(aod_params.get("GG", row.get("GG", 0.70)))

    if not np.isfinite(alpha1): alpha1 = 1.30
    if not np.isfinite(alpha2): alpha2 = 1.30
    if not np.isfinite(tau550): tau550 = 0.10
    if not np.isfinite(ssa):    ssa    = 0.90
    if not np.isfinite(gg):     gg     = 0.70

    alpha1 = helpers._clamp(alpha1, *ALPHA_CLAMP)
    alpha2 = helpers._clamp(alpha2, *ALPHA_CLAMP)
    tau550 = helpers._clamp(tau550, *TAU550_CLAMP)
    ssa    = helpers._clamp(ssa, *SSA_CLAMP)
    gg     = helpers._clamp(gg, *GG_CLAMP)

    # --- CO2 ---
    co2_ppm = _co2_ppm_from_row(row)
    if not np.isfinite(co2_ppm) or co2_ppm <= 0:
        co2_ppm = DEFAULT_CO2_PPM

    # --- NAPHELYZET ---
    hdec = ts.hour + ts.minute / 60.0 + ts.second / 3600.0
    season = "SUMMER" if ts.month in (3, 4, 5, 6, 7, 8) else "WINTER"

    # --- TDAY (24h átlag) ---
    try:
        tday = _compute_tday_24h_avg(df_full, ts, tair)
    except Exception:
        tday = tair

    # --- SMARTS INPUT ---
    L = []

    # Card 1: COMNT
    L.append(f"'NEW_AOD_{ts.strftime('%Y%m%d_%H%M%S')}'")

    # Card 2: ISPR
    L.append("1")
    # Card 2a: SPR, ALTIT, HEIGHT
    L.append(f"{spr:.2f}, {alt_km:.5f}, 0.0")

    # Card 3: IATMOS
    L.append("0")
    # Card 3a: TAIR, RH, SEASON, TDAY
    L.append(f"{tair:.2f}, {rh:.1f}, {season}, {tday:.2f}")

    # Card 4: IH2O + 4a
    L.append("0")
    L.append(f"{w_cm:.5f}")

    # Card 5: IO3 + 5a
    L.append("0")
    L.append(f"0, {o3atm:.6f}")

    # Card 6: IGAS + 6a: ILOAD=3 (Moderate pollution)
    L.append("0")
    L.append("3")

    # Card 7: CO2 + 7a
    L.append(f"{co2_ppm:.1f}")
    L.append("0")

    # Card 8: AEROS USER + 8a
    L.append("'USER'")
    L.append(f"{alpha1:.4f}, {alpha2:.4f}, {ssa:.4f}, {gg:.4f}")

    # Card 9: ITURB (TAU550 mód) + 9a
    L.append("5")
    L.append(f"{tau550:.6f}")

    # Card 10: albedo/tilt
    L.append("-1")  # IALBDX fixed broadband
    L.append("0.25")  # RHOX (nálad ez volt)
    L.append("1")   # ITILT
    L.append(f"-1, {float(panel_tilt_deg):.4f}, {float(panel_azimuth_deg):.4f}")  # IALBDG, TILT, WAZIM
    L.append("0.1")  # RHOG

    # Card 11–12: spektrum + IOUT
    L.append(f"{WLMIN:.1f}, {WLMAX:.1f}, 1.0, 1366.1")          # Card 11
    L.append("2")                                               # IPRT
    L.append(f"{WLMIN:.1f}, {WLMAX:.1f}, {PRINT_STEP_NM:.1f}")  # WPMN, WPMX, INTVL

    # IOTOT + IOUT lista
    L.append(str(int(len(iout_codes))))
    L.append(" ".join(str(int(x)) for x in iout_codes))

    # Card 13–16
    L.append("0")  # ICIRC
    L.append("0")  # ISCAN
    L.append("0")  # ILLUM
    L.append("0")  # IUV

    # Card 17: IMASS + 17a
    L.append("3")
    L.append(f"{ts.year}, {ts.month}, {ts.day}, {hdec:.6f}, {lat:.6f}, {lon:.6f}, 0")

    L.append("")
    return "\n".join(L)


def build_smarts_input_6b_with_nox_no2(row: pd.Series, df: pd.DataFrame) -> Optional[str]:
    """
    SMARTS input generálás IGAS=0, ILOAD=0 + Card 6b gázokkal.
    
    KÜLÖNBSÉG A SIMA 6b-től:
    - NO2 a NOx indexből becsülve (estimate_no2_from_nox)
    - Többi gáz CAMS-ből vagy Moderate konstansból
    
    Ez a "6b Card with NOx-based NO2" futás!
    """
    ts = pd.to_datetime(row["timestamp"], utc=True, errors="coerce")
    if pd.isna(ts):
        return None

    # Paraméterek (build_smarts_params-ból)
    params = build_smarts_params(row)
    lat      = params["latitude"]
    lon      = params["longitude"]
    alt_km   = params["alt_km"]
    spr      = params["spr_hpa"]
    tair     = params["tair_c"]
    rh       = params["rh_pct"]
    w_cm     = params["pw_cm"]
    o3atm    = params["o3_atm_cm"]
    alpha1   = params["alpha1"]
    alpha2   = params["alpha2"]
    tau550   = params["tau550"]
    ssa      = params["ssa"]
    gg       = params["gg"]
    co2_ppm  = params["co2_ppm"]

    hdec   = ts.hour + ts.minute / 60.0 + ts.second / 3600.0
    season = "SUMMER" if ts.month in (3, 4, 5, 6, 7, 8) else "WINTER"

    # ========== GÁZOK ÖSSZEÁLLÍTÁSA ==========
    # Alap: Moderate Pollution konstansok
    gases = MODERATE_POLLUTION_PPMV.copy()
    
    # CAMS gázok betöltése (ha vannak Ap* oszlopok)
    for smarts_gas, ap_col in CAMS_AP_COLUMN_MAP.items():
        if ap_col in row.index:
            val = helpers._safe_float(row[ap_col])
            if np.isfinite(val) and val > 0:
                gases[smarts_gas] = val
    
    # *** KULCS: NO2 NOx indexből! ***
    nox_index = helpers._safe_float(row.get('sensor.tvl9_o_1pst_nox_index', 1.0))
    pm25 = helpers._safe_float(row.get('sensor.tvl9_o_1pst_pm2_5'))
    
    # NO2 becslés
    gases["NO2"] = estimate_no2_from_nox(nox_index, pm25)

    # HNO2 és NO3 mindig konstans
    gases["HNO2"] = 0.002
    gases["NO3"]  = 5e-5

    # ========== SMARTS INPUT CARDS ==========
    L = []

    # Card 1: COMNT
    L.append(f"'GHI_6b_nox_no2_{ts.strftime('%Y%m%d_%H%M%S')}'")

    # Card 2: ISPR
    L.append("1")
    L.append(f"{spr:.2f}, {alt_km:.5f}, 0.0")

    # Card 3: IATMOS
    L.append("0")
    tday = _compute_tday_24h_avg(df, ts, tair)
    L.append(f"{tair:.2f}, {rh:.1f}, {season}, {tday:.2f}")

    # Card 4: IH2O
    L.append("0")
    L.append(f"{w_cm:.5f}")

    # Card 5: IO3
    L.append("0")
    L.append(f"0, {o3atm:.6f}")

    # Card 6: IGAS=0, ILOAD=0 + Card 6b
    L.append("0")
    L.append("0")
    L.append(
        f"{gases['CH2O']:.6e}, {gases['CH4']:.6e}, {gases['CO']:.6e}, {gases['HNO2']:.6e}, {gases['HNO3']:.6e}, "
        f"{gases['NO']:.6e}, {gases['NO2']:.6e}, {gases['NO3']:.6e}, {gases['O3']:.6e}, {gases['SO2']:.6e}"
    )

    # Card 7: qCO2
    L.append(f"{co2_ppm:.1f}")
    L.append("0")

    # Card 8: AEROS (USER mode)
    L.append("'USER'")
    L.append(f"{alpha1:.4f}, {alpha2:.4f}, {ssa:.4f}, {gg:.4f}")

    # Card 9: ITURB (TAU550)
    L.append("5")
    L.append(f"{tau550:.6f}")

    # Card 10: Albedo
    L.append("-1")
    L.append("0.2")
    L.append("1")
    L.append(f"-1, {PANEL_TILT:.1f}, {PANEL_AZIMUTH:.1f}")
    L.append("0.2")

    # Card 11-12: spektrum
    L.append(f"{WLMIN:.1f}, {WLMAX:.1f}, 1.0, 1366.1")
    L.append("2")
    L.append(f"{WLMIN:.1f}, {WLMAX:.1f}, {PRINT_STEP_NM:.1f}")
    L.append("4")
    L.append("4 2 3 5")

    # Card 13-16
    L.append("0")
    L.append("0")
    L.append("0")
    L.append("0")

    # Card 17
    L.append("3")
    L.append(f"{ts.year}, {ts.month}, {ts.day}, {hdec:.6f}, {lat:.6f}, {lon:.6f}, 0")

    L.append("")
    return "\n".join(L)