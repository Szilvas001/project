from __future__ import annotations

from typing import Optional, Dict
import numpy as np
import pandas as pd
from functools import lru_cache
from typing import Optional

import numpy as np
import pandas as pd
import PyMieScatt as pms

from const import *   # LOGGER innen jön
import helpers

__all__ = ["filter_pm_data_simple", "calculate_new_aod_params", "add_pymiescatt_variance_optimised_columns"]



# SciPy>=1.15 kompat shim (PyMieScatt trapz)
try:
    import scipy.integrate as _si
    if not hasattr(_si, "trapz"):
        _si.trapz = np.trapz
except Exception:
    pass

try:
    import PyMieScatt as pms
except Exception as e:
    raise


def filter_pm_data_simple(df: pd.DataFrame) -> pd.DataFrame:
    """
    PM adatok EGYSZERŰ szűrése - NINCS DOWNSAMPLING!
    Csak:
    - Negatív/0 értékek → NaN
    - Fizikai range clamp
    - Extrém outlier-ek (5σ) → mediánra
    - Rövid gap interpoláció (max 5 pont)
    """
    df = df.copy()

    pm_cols = {
        'pm0_3': 'sensor.tvl9_o_1pst_pm0_3',
        'pm1': 'sensor.tvl9_o_1pst_pm1',
        'pm2_5': 'sensor.tvl9_o_1pst_pm2_5',
        'pm10': 'sensor.tvl9_o_1pst_pm10',
    }

    PM_VALID_RANGES = {
        'pm0_3': (0.1, 100000.0),  # count
        'pm1': (0.1, 500.0),       # µg/m³
        'pm2_5': (0.1, 1000.0),    # µg/m³
        'pm10': (0.1, 2000.0),     # µg/m³
    }

    available_cols = {k: v for k, v in pm_cols.items() if v in df.columns}
    if not available_cols:
        return df

    original_len = len(df)
    print(f"[PM SIMPLE] Bemenet: {original_len} sor")

    for pm_key, col_name in available_cols.items():
        raw = pd.to_numeric(df[col_name], errors='coerce').copy()
        original_valid = raw.notna().sum()

        raw[raw <= 0] = np.nan

        min_val, max_val = PM_VALID_RANGES.get(pm_key, (0.1, 1000.0))
        raw[(raw < min_val) | (raw > max_val)] = np.nan

        if raw.notna().sum() > 50:
            rolling_median = raw.rolling(window=21, min_periods=5, center=True).median()
            rolling_std = raw.rolling(window=21, min_periods=5, center=True).std()
            z_score = np.abs((raw - rolling_median) / (rolling_std + 1e-6))
            extreme_outliers = z_score > 5.0
            outlier_count = int(extreme_outliers.sum())
            if outlier_count > 0:
                raw[extreme_outliers] = rolling_median[extreme_outliers]
                print(f"    [{pm_key}] {outlier_count} extrém outlier → medián")

        raw = raw.interpolate(method='linear', limit=5, limit_direction='both')

        df[col_name] = raw
        df[f"{col_name}_filtered"] = raw

        new_valid = raw.notna().sum()
        print(f"    [{pm_key}] Érvényes: {original_valid} → {new_valid}")

    # PM konzisztencia
    if 'sensor.tvl9_o_1pst_pm1' in df.columns and 'sensor.tvl9_o_1pst_pm2_5' in df.columns:
        mask = df['sensor.tvl9_o_1pst_pm1'] > df['sensor.tvl9_o_1pst_pm2_5'] * 1.2
        if mask.any():
            df.loc[mask, 'sensor.tvl9_o_1pst_pm1'] = df.loc[mask, 'sensor.tvl9_o_1pst_pm2_5'] * 0.9

    if 'sensor.tvl9_o_1pst_pm2_5' in df.columns and 'sensor.tvl9_o_1pst_pm10' in df.columns:
        mask = df['sensor.tvl9_o_1pst_pm2_5'] > df['sensor.tvl9_o_1pst_pm10'] * 1.2
        if mask.any():
            df.loc[mask, 'sensor.tvl9_o_1pst_pm2_5'] = df.loc[mask, 'sensor.tvl9_o_1pst_pm10'] * 0.9

    print(f"[PM SIMPLE] Kimenet: {len(df)} sor (VÁLTOZATLAN!)")
    return df




from functools import lru_cache
from typing import Optional
import numpy as np
import pandas as pd
import PyMieScatt as pms

# Assuming 'helpers' and 'LOGGER' are defined in your project
BLH_MIN_M = 50.0
EPS = 1e-10

# ====================================================================
# GLOBAL MIE SOLVER CACHE
# ====================================================================
@lru_cache(maxsize=200000)
def cached_mie_lognormal(
    m_real: float,
    m_imag: float,
    wavelength_nm: float,
    sigma_g: float,
    dg_wet_nm: float,
    n_total: float
):
    """
    Globally cached Mie solver for spherical aerosols.
    Rounds inputs slightly to maximize cache hits.
    """
    m_eff = complex(m_real, m_imag)
    try:
        return pms.Mie_Lognormal(
            m=m_eff,
            wavelength=wavelength_nm,
            geoStdDev=sigma_g,
            geoMean=dg_wet_nm,
            numberOfParticles=n_total
        )
    except Exception:
        return []

# ====================================================================
# MAIN FUSION ENGINE
# ====================================================================
def calculate_new_aod_params(
    row: pd.Series,
    cams_ratios_row: Optional[pd.Series],
    cams_upper_aod: dict,
    row_idx: int = -1
) -> dict:

    do_debug = (0 <= row_idx < 500) and (row_idx % 100 == 0)
    cams_upper_aod = cams_upper_aod or {}

    def _first_finite(*values, default=np.nan):
        for v in values:
            vv = helpers._safe_float(v, np.nan)
            if np.isfinite(vv):
                return float(vv)
        return float(default)

    # ====================================================================
    # A) THERMODYNAMIC BOUNDARY LAYER PHYSICS (1D Single Sensor)
    # ====================================================================
    # 1. Fetch exact meteorological mixed layer height
    blh_m = _first_finite(row.get("boundary_layer_height"), row.get("Boundary_layer_height"), row.get("blh_m"), default=1000.0)
    blh_m = float(np.clip(blh_m, BLH_MIN_M, 5000.0))

    # 2. Extract Local PM sensor
    local_pm = _first_finite(
        row.get("pm2_5"), row.get("pm25"), row.get("PM2_5"), row.get("PM25"),
        row.get("sensor.tvl9_pm_monitor_pm2_5"), row.get("sensor.tvl9_o_1pst_pm2_5"),
        default=5.0
    )

    # 3. Probabilistic Layer Assignment (Surface Layer vs Mixed Layer)
    # Without spatial data, we estimate mixing depth via local intensity.
    # Transition from Monin-Obukhov Surface Layer (10% BLH) up to full Mixed Layer.
    mixing_fraction = float(np.clip((local_pm - 5.0) / 15.0, 0.0, 1.0))

    surface_layer_m = blh_m * 0.10
    optical_thickness_m = surface_layer_m + (mixing_fraction * (blh_m - surface_layer_m))
    optical_thickness_km = optical_thickness_m / 1000.0

    # ====================================================================
    # B) UPPER ATMOSPHERE CHEMISTRY (CAMS RATIOS)
    # ====================================================================
    if cams_ratios_row is None:
        mass_bc, mass_om, mass_dust = 0.05, 0.60, 0.10
        mass_so4, mass_no3 = 0.175, 0.075
    else:
        try:
            bc_total = helpers._safe_float(cams_ratios_row.get("bc_total"), 3e-10)
            om_total = helpers._safe_float(cams_ratios_row.get("om_total"), 3e-10)
            dust_total = helpers._safe_float(cams_ratios_row.get("dust_total"), 3e-10)
            total_mass = bc_total + om_total + dust_total
            if np.isfinite(total_mass) and total_mass > 0:
                mass_bc = float(bc_total / total_mass)
                mass_om = float(om_total / total_mass)
                mass_dust = float(dust_total / total_mass)
            else:
                mass_bc, mass_om, mass_dust = 0.05, 0.60, 0.10
        except Exception:
            mass_bc, mass_om, mass_dust = 0.05, 0.60, 0.10

    remainder = max(0.0, 1.0 - mass_bc - mass_om - mass_dust)
    mass_so4 = remainder * 0.7
    mass_no3 = remainder * 0.3

    # ====================================================================
    # C) UPPER OPTICS (PURE CHEMICAL DERIVATION)
    # ====================================================================
    ext_bc = mass_bc * 10.0
    ext_om = mass_om * 4.0
    ext_dust = mass_dust * 0.6
    ext_inorg = (mass_so4 + mass_no3) * 5.0
    total_ext_weight = ext_bc + ext_om + ext_dust + ext_inorg

    if total_ext_weight > 0:
        upper_ssa = ((ext_bc * 0.20) + (ext_om * 0.95) + (ext_dust * 0.89) + (ext_inorg * 1.00)) / total_ext_weight
        scat_bc = ext_bc * 0.20 * 0.35
        scat_om = ext_om * 0.95 * 0.65
        scat_dust = ext_dust * 0.89 * 0.73
        scat_inorg = ext_inorg * 1.00 * 0.70
        total_scat_weight = upper_ssa * total_ext_weight
        upper_gg = (scat_bc + scat_om + scat_dust + scat_inorg) / total_scat_weight if total_scat_weight > 0 else 0.68
    else:
        upper_ssa, upper_gg = 0.95, 0.68

    upper_ssa = float(np.clip(upper_ssa, 0.5, 1.0))
    upper_gg = float(np.clip(upper_gg, 0.3, 0.95))

    # ====================================================================
    # E) LOCAL AEROSOL MICROPHYSICS
    # ====================================================================
    pm1_mass = _first_finite(row.get("pm1_0"), row.get("pm1"), row.get("sensor.tvl9_o_1pst_pm1_0"), default=np.nan)
    local_mass_bc = float(mass_bc)

    # Dynamic Black Carbon Override
    if np.isfinite(pm1_mass) and local_pm > 0:
        fine_ratio = float(np.clip(pm1_mass / local_pm, 0.0, 1.0))
        intensity_factor = float(np.clip((pm1_mass - 10.0) / 40.0, 0.0, 1.0))
        local_mass_bc = float(np.clip(mass_bc + (0.20 * intensity_factor * fine_ratio), mass_bc, 0.30))

    # Hygroscopic Growth (Kappa-Köhler Theory)
    rh_percent = helpers._safe_float(row.get("Relative_humidity"), 60.0)
    # Cap clear-sky RH at 95% to prevent mathematically infinite swelling
    rh_frac = float(np.clip(rh_percent, 1.0, 95.0)) / 100.0

    kappa_hygro = 0.30
    kappa_bulk = (1.0 - local_mass_bc) * kappa_hygro
    
    # Replaces the asymptotic power law with thermodynamic equilibrium
    g_h_effective = (1.0 + kappa_bulk * (rh_frac / (1.0 - rh_frac))) ** (1.0 / 3.0)
    
    dg_wet_nm = float(np.clip(80.0 * g_h_effective, 30.0, 1500.0))
    sigma_g = 1.60

    # Refractive Index (Mixed volume)
    m_real = 1.53 + (0.32 * local_mass_bc)
    m_imag = 0.005 + (0.71 * local_mass_bc)
    
    N_total = float(np.clip(helpers._safe_float(row.get("sensor.tvl9_pm_monitor_pm0_3_cnt"), 8000.0), 500.0, 500000.0))

    # Prepare rounded variables for the Mie Solver cache
    r_m_real = round(float(np.clip(m_real, 1.33, 1.85)), 3)
    r_m_imag = round(float(np.clip(m_imag, 0.0, 0.30)), 4)
    r_dg_wet = round(dg_wet_nm, 1)
    r_n_total = round(N_total, -1)

    # ====================================================================
    # F) THE HYBRID OPTICAL ROUTER (SPHERICAL VS FRACTAL)
    # ====================================================================
    # Background BC is ~0.05. Above 0.08, non-spherical fractal chains dominate.
    empirical_weight = float(np.clip((local_mass_bc - 0.08) / 0.07, 0.0, 1.0))

    # Spherical Physics (Mie Theory)
    res_550 = cached_mie_lognormal(r_m_real, r_m_imag, 550.0, sigma_g, r_dg_wet, r_n_total)
    mie_success = (len(res_550) >= 3 and np.isfinite(res_550[0]) and np.isfinite(res_550[1]))

    if mie_success:
        mie_ext = float(max(0.0, res_550[0]))
        mie_sca = float(max(0.0, res_550[1]))
        mie_g = float(np.clip(res_550[2], 0.3, 0.95))
        mie_ssa = float(np.clip((mie_sca / mie_ext) if mie_ext > 0 else 0.90, 0.4, 1.0))
    else:
        empirical_weight = 1.0
        mie_ext, mie_ssa, mie_g = 0.0, 0.0, 0.0

    # Fractal Physics (Empirical Parameterization)
    if empirical_weight > 0.0:
        emp_ext_eff = 4.5 + (2.0 * local_mass_bc)
        emp_ext = local_pm * emp_ext_eff if local_pm > 0 else 30.0
        emp_ssa = float(np.clip(0.98 - (0.78 * local_mass_bc), 0.40, 0.98))
        emp_g = 0.68
    else:
        emp_ext, emp_ssa, emp_g = 0.0, 0.0, 0.0

    # The Router Blend
    b_ext_550 = (mie_ext * (1.0 - empirical_weight)) + (emp_ext * empirical_weight)
    local_ssa_550 = (mie_ssa * (1.0 - empirical_weight)) + (emp_ssa * empirical_weight)
    local_g_550 = (mie_g * (1.0 - empirical_weight)) + (emp_g * empirical_weight)

    local_tau550 = float((b_ext_550 / 1000.0) * optical_thickness_km)

    # ====================================================================
    # G) UPPER SPECTRAL AOD (STRICT ÅNGSTRÖM POWER LAW)
    # ====================================================================
    a335 = helpers._safe_float(cams_upper_aod.get(335), np.nan)
    a532 = helpers._safe_float(cams_upper_aod.get(532), np.nan)
    a550 = helpers._safe_float(cams_upper_aod.get(550), np.nan)
    a1064 = helpers._safe_float(cams_upper_aod.get(1064), np.nan)

    # 1. Derive the upper Angstrom Exponent strictly from available data
    if np.isfinite(a532) and np.isfinite(a1064) and a532 > EPS and a1064 > EPS:
        alpha_upper = -np.log(a532 / a1064) / np.log(532.0 / 1064.0)
    else:
        alpha_upper = 1.3

    alpha_upper = float(np.clip(alpha_upper, 0.0, 2.5))

    # 2. Extrapolate missing wavelengths using the exact power law
    upper_tau550 = a550
    if not np.isfinite(upper_tau550):
        if np.isfinite(a532):
            upper_tau550 = a532 * ((550.0 / 532.0) ** (-alpha_upper))
        else:
            upper_tau550 = 0.03

    upper_aod_335 = a335
    if not np.isfinite(upper_aod_335):
        a355 = helpers._safe_float(cams_upper_aod.get(355), np.nan)
        if np.isfinite(a355) and a355 > EPS:
            upper_aod_335 = a355 * ((335.0 / 355.0) ** (-alpha_upper))
        elif np.isfinite(a532) and a532 > EPS:
            upper_aod_335 = a532 * ((335.0 / 532.0) ** (-alpha_upper))
        else:
            upper_aod_335 = 0.05

    upper_aod_532 = a532 if np.isfinite(a532) else 0.03
    upper_aod_1064 = a1064 if np.isfinite(a1064) else 0.01

    upper_tau550 = float(max(0.0, upper_tau550))

    # ====================================================================
    # H) FUSED TAU550
    # ====================================================================
    tau550 = float(local_tau550 + upper_tau550)

    # ====================================================================
    # I) FUSED ALPHA1/ALPHA2
    # ====================================================================
    res_335 = cached_mie_lognormal(r_m_real, r_m_imag, 335.0, sigma_g, r_dg_wet, r_n_total)
    res_532 = cached_mie_lognormal(r_m_real, r_m_imag, 532.0, sigma_g, r_dg_wet, r_n_total)
    res_1064 = cached_mie_lognormal(r_m_real, r_m_imag, 1064.0, sigma_g, r_dg_wet, r_n_total)

    fallback_alpha = float(np.clip(1.2 + (2.0 * local_mass_bc), 0.8, 1.8))

    def get_hybrid_aod(res, wave_nm):
        mie_ok = (len(res) > 0 and np.isfinite(res[0]))
        m_aod = (float(res[0]) / 1000.0) * optical_thickness_km if (mie_ok and empirical_weight < 1.0) else 0.0
        e_aod = local_tau550 * ((wave_nm / 550.0) ** (-fallback_alpha)) if empirical_weight > 0.0 else 0.0
        return (m_aod * (1.0 - empirical_weight)) + (e_aod * empirical_weight)

    local_aod_335 = get_hybrid_aod(res_335, 335.0)
    local_aod_532 = get_hybrid_aod(res_532, 532.0)
    local_aod_1064 = get_hybrid_aod(res_1064, 1064.0)

    fused_335 = float(max(EPS, local_aod_335 + upper_aod_335))
    fused_532 = float(max(EPS, local_aod_532 + upper_aod_532))
    fused_1064 = float(max(EPS, local_aod_1064 + upper_aod_1064))

    alpha1 = -np.log(fused_335 / fused_532) / np.log(335.0 / 532.0)
    alpha2 = -np.log(fused_532 / fused_1064) / np.log(532.0 / 1064.0)

    alpha1 = float(np.clip(alpha1, -0.5, 4.0))
    alpha2 = float(np.clip(alpha2, -0.5, 4.0))

    # ====================================================================
    # J) FUSED SSA / GG (STRICT OPTICAL MIXING)
    # ====================================================================
    if tau550 > EPS:
        fused_ssa = ((local_ssa_550 * local_tau550) + (upper_ssa * upper_tau550)) / tau550

        local_scat_depth = local_g_550 * local_ssa_550 * local_tau550
        upper_scat_depth = upper_gg * upper_ssa * upper_tau550
        denom = fused_ssa * tau550
        fused_gg = ((local_scat_depth + upper_scat_depth) / denom) if denom > EPS else local_g_550
    else:
        fused_ssa, fused_gg = 0.95, 0.68

    fused_ssa = float(np.clip(fused_ssa, 0.5, 1.0))
    fused_gg = float(np.clip(fused_gg, 0.3, 0.95))

    # ====================================================================
    # K) OUTPUT
    # ====================================================================
    out = {
        "TAU550": float(np.clip(tau550, 0.001, 3.0)),
        "ALPHA1": float(np.clip(alpha1, -0.5, 4.0)),
        "ALPHA2": float(np.clip(alpha2, -0.5, 4.0)),
        "OMEGL": float(np.clip(fused_ssa, 0.5, 1.0)),
        "GG": float(np.clip(fused_gg, 0.3, 0.95)),
    }

    if do_debug:
        LOGGER.info(
            f"[AOD {row_idx}] BLH={blh_m:.0f}m | opt_thick={optical_thickness_m:.0f}m | "
            f"local_tau={local_tau550:.4f} upper_tau={upper_tau550:.4f} fused_tau={out['TAU550']:.4f} | "
            f"local_ssa={local_ssa_550:.3f} upper_ssa={upper_ssa:.3f} fused_OMEGL={out['OMEGL']:.3f} | "
            f"emp_w={empirical_weight:.2f}"
        )

    return out
    
def add_pymiescatt_variance_optimised_columns(
    df: pd.DataFrame,
    logger,
    resample: str = "1min",
    trend_window: str = "10min",
    noise_window: str = "1min",
    out_prefix: str = "pymiescatt",
    strict_no_cams_fallback: bool = True,
):
    """
    Gyors + stabil:
      - PyMieScatt paramok percenkent (resample) -> sokkal kevesebb Mie futas
      - zajmertek PM0.3 residual RMS alapjan (noise_window)
      - noise-gated trend keveres (trend_window) -> 'variance optimised'

    Output oszlopok:
      {out_prefix}_tau550, _alpha1, _alpha2, _omegl, _gg
      {out_prefix}_tau550_opt, _alpha1_opt, _alpha2_opt, _omegl_opt, _gg_opt
      {out_prefix}_noise_rms
    """

    if df.empty:
        return df

    TS = "timestamp"

    PM03_F = "sensor.tvl9_o_1pst_pm0_3_filtered"
    PM03_R = "sensor.tvl9_o_1pst_pm0_3"
    PM10_F = "sensor.tvl9_o_1pst_pm10_filtered"
    PM10_R = "sensor.tvl9_o_1pst_pm10"
    PM25_F = "sensor.tvl9_o_1pst_pm2_5_filtered"
    PM25_R = "sensor.tvl9_o_1pst_pm2_5"
    PM1_F  = "sensor.tvl9_o_1pst_pm1_filtered"
    PM1_R  = "sensor.tvl9_o_1pst_pm1"
    RH     = "sensor.tvl9_gw2000a_humidity"
    NOX    = "sensor.tvl9_o_1pst_nox_index"
    BLH    = "Boundary_layer_height"

    TAU340 = "Total_aerosol_optical_depth_at_340_nm"
    TAU500 = "Total_aerosol_optical_depth_at_500_nm"
    TAU550 = "Total_aerosol_optical_depth_at_550_nm"   # lehet, hogy NINCS
    TAU1064= "Total_aerosol_optical_depth_at_1064_nm"

    # --- itt a lényeg: 550 NEM kötelező ---
    for c in [TS, RH, TAU340, TAU500, TAU1064]:
        if c not in df.columns:
            raise RuntimeError(f"Hiányzó oszlop a PyMieScatt batchhez: {c}")

    # zajhoz pm0.3 (filtered ha van, különben raw)
    pm03_col = PM03_F if PM03_F in df.columns else PM03_R
    if pm03_col not in df.columns:
        raise RuntimeError("Nincs PM0.3 oszlop (filtered vagy raw) - nem tudok zajt számolni.")

    d = df.copy()
    d[TS] = pd.to_datetime(d[TS], utc=True, errors="coerce")
    d = d.dropna(subset=[TS]).sort_values(TS)
    d = d.set_index(TS)

    # --- ha nincs CAMS 550: képezzük 500-ból (ugyanaz a logika, mint a scriptedben: 0.95) ---
    if TAU550 not in d.columns:
        d[TAU550] = 0.95 * pd.to_numeric(d[TAU500], errors="coerce")

    # -------- 1) NOISE METRIC: PM0.3 high-freq residual RMS --------
    pm = pd.to_numeric(d[pm03_col], errors="coerce")
    pm_trend = pm.rolling(trend_window, min_periods=3, center=True).median()
    pm_resid = pm - pm_trend
    noise_rms = pm_resid.rolling(noise_window, min_periods=3).std()
    noise_rms_min = noise_rms.resample(resample).mean()

    # -------- 2) RESAMPLE inputs (percenként) a Mie futáshoz --------
    agg = {}
    for c in [PM10_F, PM10_R, PM25_F, PM25_R, PM1_F, PM1_R, PM03_F, PM03_R, NOX, BLH,
              TAU340, TAU500, TAU550, TAU1064]:
        if c in d.columns:
            agg[c] = "median"
    agg[RH] = "mean"

    dm = d.resample(resample).agg(agg)
    dm = dm.dropna(subset=[RH])

    # ha resample után sincs 550 (pl. minden NaN volt), akkor is képezzük
    if TAU550 not in dm.columns:
        dm[TAU550] = 0.95 * pd.to_numeric(dm[TAU500], errors="coerce")

    # -------- 3) PyMieScatt paramok percenként --------
    rows = []
    last_good = None

    for ts, row in dm.iterrows():
        tau340 = float(row.get(TAU340, np.nan))
        tau500 = float(row.get(TAU500, np.nan))
        tau550 = float(row.get(TAU550, np.nan))
        tau1064= float(row.get(TAU1064, np.nan))

        # upper AOD becslés (30%)
        upper_aod = {
            340: 0.30 * tau340 if np.isfinite(tau340) else 0.05,
            500: 0.30 * tau500 if np.isfinite(tau500) else 0.04,
            550: 0.30 * tau550 if np.isfinite(tau550) else (0.30 * (0.95 * tau500) if np.isfinite(tau500) else 0.038),
            1064:0.30 * tau1064 if np.isfinite(tau1064) else 0.015,
        }

        row_for_mie = row.copy()
        if strict_no_cams_fallback:
            row_for_mie["ALPHA1"] = np.nan
            row_for_mie["ALPHA2"] = np.nan
            row_for_mie["TAU550"] = np.nan

        try:
            a = calculate_new_aod_params(row_for_mie, row_for_mie, upper_aod, row_idx=-1)
            last_good = a
        except Exception:
            if last_good is None:
                a = {"TAU550": 0.10, "ALPHA1": 1.30, "ALPHA2": 1.30, "OMEGL": 0.90, "GG": 0.70}
            else:
                a = last_good

        rows.append({
            TS: ts,
            f"{out_prefix}_tau550": float(a["TAU550"]),
            f"{out_prefix}_alpha1": float(a["ALPHA1"]),
            f"{out_prefix}_alpha2": float(a["ALPHA2"]),
            f"{out_prefix}_omegl":  float(a["OMEGL"]),
            f"{out_prefix}_gg":     float(a["GG"]),
        })

    pmie = pd.DataFrame(rows).set_index(TS).sort_index()
    pmie[f"{out_prefix}_noise_rms"] = noise_rms_min.reindex(pmie.index).ffill().bfill()

    # -------- 4) variance-optimised: noise-gated trend blending --------
    sigma = float(np.nanmedian(pmie[f"{out_prefix}_noise_rms"].to_numpy()))
    if not np.isfinite(sigma) or sigma <= 0:
        sigma = 1.0
    sigma *= 2.0

    w = 1.0 / (1.0 + (pmie[f"{out_prefix}_noise_rms"] / sigma) ** 2)

    def _opt(series: pd.Series):
        tr = series.rolling(trend_window, min_periods=3).median()
        return (w * series + (1.0 - w) * tr)

    pmie[f"{out_prefix}_tau550_opt"] = _opt(pmie[f"{out_prefix}_tau550"]).clip(0.001, 3.0)
    pmie[f"{out_prefix}_alpha1_opt"] = _opt(pmie[f"{out_prefix}_alpha1"]).clip(-0.5, 4.0)
    pmie[f"{out_prefix}_alpha2_opt"] = _opt(pmie[f"{out_prefix}_alpha2"]).clip(-0.5, 4.0)
    pmie[f"{out_prefix}_omegl_opt"]  = _opt(pmie[f"{out_prefix}_omegl"]).clip(0.60, 1.0)
    pmie[f"{out_prefix}_gg_opt"]     = _opt(pmie[f"{out_prefix}_gg"]).clip(0.0, 1.0)

    # -------- 5) visszamerge az eredeti df-re perc-bucket alapján --------
    df_out = df.copy()
    df_out[TS] = pd.to_datetime(df_out[TS], utc=True, errors="coerce")
    df_out["_ts_bucket"] = df_out[TS].dt.floor(resample)

    pmie2 = pmie.reset_index().rename(columns={TS: "_ts_bucket"})
    df_out = df_out.merge(pmie2, on="_ts_bucket", how="left").drop(columns=["_ts_bucket"])

    logger.info(
        f"[PyMieScatt VAR-OPT] resample={resample} trend={trend_window} noise={noise_window} rows(min)={len(pmie)}"
    )
    return df_out


#pm kezelés
#ssa,tau550-lower,upper,alpha1/2
#nrmse,sql ispymie,clearskyra generalni,isfallbeck
#s nélküli regresszio, s el, tiltek E szekcio