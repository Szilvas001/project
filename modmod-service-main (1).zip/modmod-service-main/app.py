import ast
import json

import pandas as pd
from flask import Flask, request, jsonify
from modmod import build_model_chain, DateRange
from modmod.database import operations


app = Flask(__name__)

@app.route('/modmod/calculate', methods=['POST'])
def run_model_chain_route():
    try:
        input_dict = ast.literal_eval(request.data.decode('utf-8'))
    except Exception as e:
        print(f"[ERROR] Failed to parse request body data: {e}")
        return jsonify({"error": f"Invalid request body data format: {e}"}), 400

    try:
        start_time = pd.Timestamp.now()

        try:
            start_date_str = input_dict['interval_start']
            end_date_str = input_dict['interval_end']
            start_date = pd.to_datetime(start_date_str, utc=True)
            end_date = pd.to_datetime(end_date_str, utc=True)
            date_range_obj = DateRange(start_date, end_date)
        except KeyError as e:
            error_msg = f"Missing required date key in request body: {e}"
            print(f"[ERROR] {error_msg}")
            return jsonify({"error": error_msg}), 400
        except Exception as e:
            error_msg = f"Failed to parse dates from request body: {e}"
            print(f"[ERROR] {error_msg}")
            return jsonify({"error": error_msg}), 400

        write_to_db_param = request.args.get('write_to_db', 'false')
        write_to_db = write_to_db_param.lower() in ('true', '1', 't', 'y', 'yes')
        print(f"[INFO] Write to DB flag (from URL param '{write_to_db_param}') set to: {write_to_db}")

        model_chain = build_model_chain(input_dict)
        model_chain.date_range = date_range_obj
        print(f"[INFO] Model chain: {model_chain}")

        required_inputs = list()
        outputs = list()
        for model in model_chain.models:
            outputs.extend([output_parameter.metric for output_parameter in model.output_parameters])
            for input_parameter in model.required_non_fixed_input_parameters:
                if input_parameter not in required_inputs:
                    required_inputs.append(input_parameter)

        required_inputs = [input_parameter for input_parameter in required_inputs if input_parameter not in outputs]
        required_fixed_inputs = {input_parameter.name: input_parameter.value for model in model_chain.models
                                 for input_parameter in model.input_parameters if input_parameter.value}

        print(f"[INFO] Required fixed inputs: {required_fixed_inputs}")
        accumulator = pd.DataFrame()

        first_model_is_data_loader = False
        first_model_name = "N/A"
        if model_chain.models:
             data_loader_model_names = ["HADataLoaderModel"]
             first_model_name = model_chain.models[0].__class__.__name__
             if first_model_name in data_loader_model_names:
                 first_model_is_data_loader = True

        print(f"[DEBUG app.py] Checking accumulator init logic:")
        print(f"[DEBUG app.py]   required_inputs empty? {not required_inputs}")
        print(f"[DEBUG app.py]   first_model_is_data_loader? {first_model_is_data_loader}")
        print(f"[DEBUG app.py]   First model actual name: '{first_model_name}'")

        if not required_inputs and not first_model_is_data_loader:
            print(f"[INFO - Branch 1] No database/API inputs required and first model is not a data loader. Initializing accumulator for single fixed timestamp: {start_date}")
            accumulator = pd.DataFrame(index=pd.DatetimeIndex([start_date], name='timestamp'))
        elif required_inputs and model_chain.input_table:
            print(f"[INFO - Branch 2] Loading required inputs {required_inputs} from table '{model_chain.input_table}' for {start_date} to {end_date}")
            accumulator = operations.load_required_inputs_from_db(required_inputs, start_date,
                                                                  end_date, model_chain.input_table)
            if not accumulator.empty:
                if 'timestamp' in accumulator.columns:
                    accumulator['timestamp'] = pd.to_datetime(accumulator['timestamp'], utc=True)
                    accumulator = accumulator.set_index('timestamp')
                elif isinstance(accumulator.index, pd.DatetimeIndex):
                    if accumulator.index.tz is None:
                        print("[INFO] Localizing DatetimeIndex to UTC.")
                        accumulator = accumulator.tz_localize('UTC')
                    elif accumulator.index.tz.zone != 'UTC':
                         print(f"[INFO] Converting DatetimeIndex from {accumulator.index.tz} to UTC.")
                         accumulator = accumulator.tz_convert('UTC')
                else:
                     print("[WARN] Loaded data has no 'timestamp' column or DatetimeIndex.")
                accumulator = accumulator[(accumulator.index >= start_date) & (accumulator.index <= end_date)]
                print(f"[INFO] Loaded and filtered accumulator shape: {accumulator.shape}")
            else:
                 print("[WARN] Loaded accumulator from DB is empty.")
                 accumulator = pd.DataFrame(index=pd.DatetimeIndex([], name='timestamp', tz='UTC'))
        else:
             print(f"[INFO - Branch 3] Accumulator initialized empty. Expecting a data loading model or subsequent process to populate.")
             accumulator = pd.DataFrame(index=pd.DatetimeIndex([], name='timestamp', tz='UTC'))

        initial_fixed_inputs = set(required_fixed_inputs.keys())

        for model in model_chain.models:
            accumulator = model.calculate(accumulator, model_chain.date_range)

        if 'timestamp' in initial_fixed_inputs:
            print("[INFO] 'timestamp' was a fixed input. Taking last row.")
            accumulator = accumulator.tail(1)

        if write_to_db and model_chain.output_table:
            print(f"[INFO] Writing results to output table: {model_chain.output_table}")
            operations.write_df_into_db(accumulator, model_chain.output_table)
        elif write_to_db and not model_chain.output_table:
            print("[WARN] write_to_db is True, but no output_table specified.")

        finish_time = pd.Timestamp.now()
        seconds_taken = (finish_time - start_time).total_seconds()
        print(f"[INFO] Execution took {seconds_taken:.4f} seconds")

        accumulator = accumulator.reset_index()
        if 'timestamp' in accumulator.columns:
           accumulator['timestamp'] = accumulator['timestamp'].dt.strftime('%Y-%m-%dT%H:%M:%SZ')
        else:
           print("[WARN] No 'timestamp' column found in the final accumulator before preparing JSON response.")
           accumulator['timestamp'] = None

        print(f"[INFO] Final accumulator for response: \n{accumulator.head()}")
        accumulator_dict = accumulator.to_dict(orient='records')
        return jsonify({"accumulator": accumulator_dict, "seconds_taken": seconds_taken})

    except ValueError as e:
        error_msg = f"Calculation error: {e}"
        print(f"[ERROR] {error_msg}")
        return jsonify({"error": error_msg}), 500
    except Exception as e:
        error_msg = f"An unexpected error occurred: {e}"
        print(f"[ERROR] {error_msg}")
        return jsonify({"error": error_msg}), 500
