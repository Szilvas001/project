import pandas as pd
import pvlib
from typing import List

from modmod.models.model_protocol import BaseCalculationModel


class AngleOfIncidenceModel(BaseCalculationModel):
    """
    Calculate the angle of incidence between solar rays and panel surface.
    """
    
    def __init__(self, name: str = "AngleOfIncidenceModel"):
        super().__init__(name)
    
    def get_required_inputs(self) -> List[str]:
        """Return list of required input column names."""
        return ['solar_zenith', 'solar_azimuth']
    
    def get_outputs(self) -> List[str]:
        """Return list of output column names."""
        return ['aoi']
    
    def calculate(self, df: pd.DataFrame, panel_tilt: float, panel_azimuth: float, 
                  **kwargs) -> pd.DataFrame:
        """Calculate angle of incidence.
        
        Args:
            df: Input dataframe with solar position data
            panel_tilt: Panel tilt angle in degrees
            panel_azimuth: Panel azimuth angle in degrees
            **kwargs: Additional parameters
            
        Returns:
            DataFrame with aoi (angle of incidence) column
        """
        result = df.copy()
        
        # Calculate angle of incidence using pvlib
        aoi = pvlib.irradiance.aoi(
            surface_tilt=panel_tilt,
            surface_azimuth=panel_azimuth,
            solar_zenith=df['solar_zenith'].values,
            solar_azimuth=df['solar_azimuth'].values
        )
        
        result['aoi'] = aoi
        
        return result
