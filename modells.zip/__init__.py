# ModMod Models - New Architecture

# Core model framework
from .model_protocol import BaseCalculationModel, ModelProtocol

# Active models (new system)
from .clear_sky_model import ClearSkyModel
from .unified_database_loader import UnifiedDatabaseLoader
from .solar_position_model import SolarPositionModel
from .angle_of_incidence_model import AngleOfIncidenceModel
from .average_model import AverageModel
from .revert_imt_iam_model import RevertImtIamModel
from .incident_angle_modifier_physical_model import IncidentAngleModifierPhysicalModel
from .incident_angle_modifier_ashrae_model import IncidentAngleModifierAshraeModel
from .incident_angle_modifier_martin_ruiz_model import IncidentAngleModifierMartinRuizModel
from .cell_temp_model import CellTempModel
from .dc_output_model import DcOutputModel

# Legacy models are in the deprecated/ folder
# Import them explicitly if needed: from .deprecated.model_name import ModelName

__all__ = [
    # New system
    "BaseCalculationModel",
    "ModelProtocol", 
    "ClearSkyModel",
    "UnifiedDatabaseLoader",
    "SolarPositionModel",
    "AngleOfIncidenceModel",
    "AverageModel",
    "RevertImtIamModel",
    "IncidentAngleModifierPhysicalModel",
    "IncidentAngleModifierAshraeModel",
    "IncidentAngleModifierMartinRuizModel",
    "CellTempModel",
    "DcOutputModel",
]