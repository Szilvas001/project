import numpy as np
import pandas as pd
from scipy.interpolate import PchipInterpolator
from typing import List

from modmod.models.model_protocol import BaseCalculationModel


class RevertImtIamModel(BaseCalculationModel):
    """
    Revert IMT IAM effects: undo the IAM effects on IMT reference cell irradiation.
    Calculates irradiation without IAM based on measured irradiation and angle of incidence.
    """
    
    def __init__(self, name: str = "RevertImtIamModel"):
        super().__init__(name)
    
    def get_required_inputs(self) -> List[str]:
        """Return list of required input column names."""
        return ['aoi', 'irradiance_with_imt_iam']
    
    def get_outputs(self) -> List[str]:
        """Return list of output column names."""
        return ['iam_reversed_irradiance_output', 'included_imt_iam_factor']
    
    def calculate(self, df: pd.DataFrame, **kwargs) -> pd.DataFrame:
        """Calculate IAM-corrected irradiance.
        
        Args:
            df: Input dataframe with aoi and irradiance_with_imt_iam columns
            **kwargs: Additional parameters
            
        Returns:
            DataFrame with iam_reversed_irradiance_output and included_imt_iam_factor columns
        """
        result = df.copy()
        
        # IMT IAM data from the original model
        aoi_deg = np.array([5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90])
        iam_percent = np.array([100, 100, 100, 100, 99.5, 99.3, 99, 99, 98.7, 98.4, 98, 96.7, 95.8, 93.8, 90.9, 85.7, 77.5, 0])
        iam_fraction = iam_percent / 100.0
        
        # Create PCHIP interpolation function
        iam_pchip_func = PchipInterpolator(aoi_deg, iam_fraction, extrapolate=True)
        
        # Calculate included IMT IAM factor
        aoi_values = df['aoi'].values
        
        # Clip AOI to physically reasonable range (0-90 degrees)
        aoi_values = np.clip(aoi_values, 0, 90)
        
        included_iam_factor = np.clip(iam_pchip_func(aoi_values), 0, 1)
        
        # Calculate IAM-corrected irradiance
        original_irradiance = df['irradiance_with_imt_iam']
        
        # Correct the IAM reversal formula
        # The IAM factor represents the fraction of irradiance that gets through
        # To reverse it, we divide by this factor
        # However, at extreme angles (AOI > 85°), the IAM factor becomes very small
        # causing unrealistic spikes. We limit the correction to reasonable values.
        
        # Apply a minimum IAM factor threshold to prevent extreme corrections
        # At AOI > 85°, the correction becomes unreliable anyway
        min_iam_threshold = 0.1  # 10% minimum transmission
        corrected_iam_factor = np.maximum(included_iam_factor, min_iam_threshold)
        
        corrected_irradiance = np.where(
            included_iam_factor == 0,
            original_irradiance,
            original_irradiance / corrected_iam_factor
        )
        
        result['included_imt_iam_factor'] = included_iam_factor
        result['iam_reversed_irradiance_output'] = corrected_irradiance
        
        return result
