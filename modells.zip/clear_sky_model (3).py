import numpy as np
import pandas as pd
import pvlib
import requests
from pvlib.irradiance import get_total_irradiance
from scipy.interpolate import interp1d
from sklearn.linear_model import LinearRegression
from .model_protocol import BaseCalculationModel
from pvlib.tools import cosd
import matplotlib.pyplot as plt


class ClearSkyModel(BaseCalculationModel):
    """
    Model to calculate clear sky irradiance and corresponding POA irradiance using SPCTRL2 model.
    """
    
    def __init__(self, name: str = "ClearSkyModel"):
        super().__init__(name)
    
    @classmethod
    def get_required_inputs(cls):
        """Required atmospheric and location inputs."""
        return ['pressure', 'wv', 'o3', 'ssa', 'asymmetry_factor_550', 'aod400', 'aod500', 'aod1064']
    
    @classmethod
    def get_outputs(cls):
        """Model outputs."""
        return ['clear_sky_poa_irradiance', 'relative_airmass', 'ang_alpha', 'ang_beta', 'aod500', 'apparent_zenith', 'aoi', 'dni', 'dhi']
    
    def calculate(self, df: pd.DataFrame, latitude: float, longitude: float, panel_tilt: float, 
                  panel_azimuth: float, altitude: float = 0, albedo: float = 0.25, 
                  apply_spectral_response: bool = True, **kwargs) -> pd.DataFrame:
        """Calculate clear sky irradiance using SPCTRL2 model.
        
        Framework handles validation, timestamp preparation, etc.
        Model developer only needs to implement the calculation logic.
        """
        
        # Validate AOD input data first
        self._validate_aod_data(df)
        
        # Ensure index is datetime and timezone-naive for pvlib
        timestamps = pd.to_datetime(df.index, format='mixed')
        if timestamps.tz is not None:
            timestamps = timestamps.tz_convert('UTC').tz_localize(None)
        
        
        # Use the existing irradiance_spctrl2 method
        result_df, intermediate_params = self.irradiance_spctrl2(
            timestamps, latitude, longitude, altitude, df, 
            panel_tilt, panel_azimuth, albedo, apply_spectral_response
        )
        
        # Debug: Check atmospheric data availability
        print(f"Atmospheric data shape: {df.shape}")
        print(f"Pressure column stats: min={df['pressure'].min()}, max={df['pressure'].max()}, null_count={df['pressure'].isnull().sum()}")
        print(f"Clear sky result shape: {result_df.shape}")
        print(f"Clear sky values: min={result_df['poa_global'].min()}, max={result_df['poa_global'].max()}, null_count={result_df['poa_global'].isnull().sum()}")
        print(f"Original df index type: {type(df.index)}, result_df index type: {type(result_df.index)}")
        print(f"Index alignment check: {df.index.equals(result_df.index)}")
        
        # Add result to original dataframe with proper index alignment
        result = df.copy()
        
        # Fix index alignment issue - ensure result_df has same index as df
        if not df.index.equals(result_df.index):
            print("Warning: Index mismatch detected, aligning indices...")
            # Align the result_df index with the original df index
            result_df = result_df.reindex(df.index, method='nearest')
        
        result['clear_sky_poa_irradiance'] = result_df['poa_global']
        
        # Add intermediate parameters to the result
        for param_name, param_values in intermediate_params.items():
            if isinstance(param_values, pd.Series):
                # Need to reindex Series to match the result dataframe index
                # Handle timezone mismatch between series index and result index
                if hasattr(result.index, 'tz') and result.index.tz is not None:
                    # Result has timezone, series doesn't - localize series index
                    if hasattr(param_values.index, 'tz') and param_values.index.tz is None:
                        param_values.index = param_values.index.tz_localize('UTC')
                
                reindexed = param_values.reindex(result.index)
                result[param_name] = reindexed.values
            else:
                # Numpy arrays are already aligned with df
                result[param_name] = param_values
        
        # Final validation check
        nan_count = result['clear_sky_poa_irradiance'].isnull().sum()
        if nan_count > 0:
            print(f"Warning: {nan_count} NaN values in clear_sky_poa_irradiance after assignment")
        
        return result
    
    def _validate_aod_data(self, df: pd.DataFrame):
        """Validate AOD input data for realistic values."""
        if 'aod469' in df.columns and 'aod550' in df.columns:
            aod469_stats = df['aod469'].describe()
            aod550_stats = df['aod550'].describe()
            
            print(f"AOD469 stats: min={aod469_stats['min']:.6f}, max={aod469_stats['max']:.6f}, mean={aod469_stats['mean']:.6f}")
            print(f"AOD550 stats: min={aod550_stats['min']:.6f}, max={aod550_stats['max']:.6f}, mean={aod550_stats['mean']:.6f}")
            
            # Check for problematic values
            if (df['aod469'] <= 0).any():
                print("Warning: Found zero or negative AOD469 values")
            if (df['aod550'] <= 0).any():
                print("Warning: Found zero or negative AOD550 values")
            if (df['aod469'] > 5).any():
                print("Warning: Found extremely high AOD469 values (>5)")
            if (df['aod550'] > 5).any():
                print("Warning: Found extremely high AOD550 values (>5)")
    
    @classmethod
    def calculate_alpha_beta(cls, aod_values, wavelengths_um):
        """
        Calculate Angstrom Alpha (α) and Beta (β) from AOD measurements.

        Parameters:
        - aod_values (list or array-like): AOD measurements at each wavelength.
        - wavelengths_nm (list or array-like): Corresponding wavelengths in nanometers.

        Returns:
        - alpha (float): Angstrom Alpha value.
        - beta (float): Angstrom Beta value.
        """
        try:
            # Convert inputs to numpy arrays for consistency
            aod_values = np.array(aod_values, dtype=float)
            wavelengths_um = np.array(wavelengths_um, dtype=float)

            # Validation checks
            if len(aod_values) != len(wavelengths_um):
                raise ValueError("Number of AOD values must match number of wavelengths.")
            if np.any(aod_values <= 0):
                raise ValueError("All AOD values must be positive.")

            # Log-transform the AOD values and wavelengths
            ln_aod = np.log(aod_values)
            ln_wavelength = np.log(wavelengths_um)

            # Reshape ln_wavelength for sklearn
            X = ln_wavelength.reshape(-1, 1)  # Independent variable
            Y = ln_aod  # Dependent variable

            # Initialize and fit the linear regression model
            model = LinearRegression()
            model.fit(X, Y)

            # Extract slope and intercept
            slope = model.coef_[0]
            intercept = model.intercept_

            # Calculate alpha and beta
            alpha = -slope
            beta = np.exp(intercept)

            return alpha, beta

        except Exception as e:
            print(f"Error calculating alpha and beta: {e}")
            return np.nan, np.nan

    @classmethod
    def calculate_wvf(cls, row):
        """
        Calculate the wavelength variation factor from SSA values at different wavelengths.
        
        Parameters:
        - row: pandas Series containing SSA values at different wavelengths
        
        Returns:
        - wvf: wavelength variation factor
        - k: coefficient
        """
        wavelengths_nm = [340, 355, 380, 400, 500, 645, 865, 1064, 1240, 1640, 2130]
        wavelengths_um = np.array(wavelengths_nm) / 1000.0
        log_wavelengths = np.log(wavelengths_um)

        # Extract SSA values
        ssa_values = [
            row[f'ssa{wl}'] for wl in wavelengths_nm
        ]
        
        # Compute the natural log of the SSA values
        log_ssa = np.log(ssa_values)
        
        # Perform linear regression
        slope, intercept = np.polyfit(log_wavelengths, log_ssa, 1)
        wvf = -slope
        k = np.exp(intercept)
        
        return wvf, k

    @classmethod
    def irradiance_spctrl2(cls, timestamps, latitude, longitude, altitude, df, panel_tilt, panel_azimuth, albedo, apply_spectral_response: bool = True):
        import numpy as np
        from scipy.interpolate import interp1d
        import pandas as pd
        import pvlib
        from pvlib.iam import marion_integrate

        solar_position = pvlib.solarposition.get_solarposition(
            time=timestamps,
            latitude=latitude,
            longitude=longitude,
            altitude=altitude
        )

        apparent_zenith = solar_position['apparent_zenith']
        airmass_relative = pvlib.atmosphere.get_relative_airmass(apparent_zenith)

        surface_tilt = panel_tilt
        surface_azimuth = panel_azimuth

        aoi = pvlib.irradiance.aoi(surface_tilt, surface_azimuth, apparent_zenith, solar_position['azimuth'])

        press = df["pressure"].values

        pw = df["wv"].values

        pw /= 10 # kg/m^2 -> cm

        ozone = df["o3"].values

        ozone *= 10 # In the CAMS data pull mechanism, there is a /= 10
        ozone *= 46.69 # Convert to atm * cm from kg/m^2

        ssa = df["ssa"].values
        asymmetry_factor = df["asymmetry_factor_550"].values

        aod400 = df["aod400"].values

        aod500 = df["aod500"].values

        aod1064 = df["aod1064"].values
        
        # Add small epsilon to prevent log(0) and division by 0
        epsilon = 1e-10
        aod400_safe = np.maximum(aod400, epsilon)
        aod500_safe = np.maximum(aod500, epsilon)
        aod1064_safe = np.maximum(aod1064, epsilon)
        
        # Calculate Angstrom alpha and beta
        ratio = aod400_safe / aod1064_safe
        ratio = np.maximum(ratio, epsilon)  # Prevent log(0)
        
        ang_alpha = -(np.log(ratio) / np.log(400 / 1064))
        ang_beta = aod1064_safe * (1.064 ** ang_alpha)
        
        # Validate and constrain alpha/beta to reasonable ranges
        ang_alpha = np.clip(ang_alpha, -2, 3)  # Typical range for alpha
        ang_beta = np.clip(ang_beta, 1e-6, 5)  # Typical range for beta
        
        print(f"Alpha range: min={ang_alpha.min():.4f}, max={ang_alpha.max():.4f}, mean={ang_alpha.mean():.4f}")
        print(f"Beta range: min={ang_beta.min():.6f}, max={ang_beta.max():.6f}, mean={ang_beta.mean():.6f}")

        # if timestamp hour > 13 then aod500 *= 5
        # aod500 = np.where(timestamps.hour >= 13, aod500 + 0.05, aod500)

        # Calculate WVF for each timestamp
        '''
        wvf_values = []
        for idx in range(len(accumulator)):
            wvf, _ = cls.calculate_wvf(accumulator.iloc[idx])
            wvf_values.append(wvf)
        
        wvf_array = np.array(wvf_values)
        '''

        spectral_response_data = {
            # Wavelength (nm): Normalized Spectral Response, from IMT datasheet  
            350: 0,
            400: 0.45,
            500: 0.60,
            600: 0.70,
            700: 0.80,
            800: 0.90,
            900: 0.97,
            915: 1,
            975: 1,
            1000: 0.95,
            1075: 0.60,
            1110: 0.36,
            1150: 0.10,
            1165: 0.04,
            1200: 0
        }

        ds_wavelengths = np.array(list(spectral_response_data.keys()))
        ds_sr = np.array(list(spectral_response_data.values()))
        sort_indices = np.argsort(ds_wavelengths)
        ds_wavelengths = ds_wavelengths[sort_indices]
        ds_sr = ds_sr[sort_indices]
        spline_interpolator = interp1d(ds_wavelengths, ds_sr, kind='cubic', bounds_error=False, fill_value=0.0)

        if apply_spectral_response:
            am15g = pvlib.spectrum.get_reference_spectra(standard='ASTM G173-03')  # Defaults to this standard

            # Get the spectral response (SR) at the same wavelengths as AM1.5G
            sr_values = spline_interpolator(am15g.index.values)
            sr_values = np.clip(sr_values, 0.0, 1.0)

            # Convert to arrays for integration
            wavelengths_std = am15g.index.values
            e_std = am15g['global'].values  # Use 'global' for AM1.5G tilted irradiance

            # Filter to responsive range
            mask_std = (wavelengths_std >= 350) & (wavelengths_std <= 1200)
            wavelengths_std_filtered = wavelengths_std[mask_std]
            e_std_filtered = e_std[mask_std]
            sr_filtered = sr_values[mask_std]

            # Trapezoidal integration for numerator: ∫ E_std(λ) * SR(λ) dλ
            delta_wavelengths_std = np.diff(wavelengths_std_filtered)
            average_e_sr = (e_std_filtered[:-1] * sr_filtered[:-1] + e_std_filtered[1:] * sr_filtered[1:]) / 2
            areas_std = average_e_sr * delta_wavelengths_std
            integral_e_sr = np.sum(areas_std)  # In W/m²
            
            # Compute f = integral_e_sr / 1000
            f = integral_e_sr / 1000  # Should be ~0.53-0.56 for c-Si; print it to verify

            print(f"f: {f}")

        distribution = pvlib.spectrum.spectrl2(
            apparent_zenith=apparent_zenith, 
            aerosol_asymmetry_factor=asymmetry_factor, 
            alpha=ang_alpha, 
            aoi=aoi,
            surface_tilt=surface_tilt, 
            ground_albedo=albedo, 
            surface_pressure=press * 100, # hPa to Pa
            relative_airmass=airmass_relative, 
            precipitable_water=pw, 
            ozone=ozone, 
            aerosol_turbidity_500nm=aod500, 
            scattering_albedo_400nm=ssa,
            wavelength_variation_factor=0.095
        )

        print(f"Calculating with aod500: {aod500}")

        df['alpha'] = ang_alpha
        df['beta'] = ang_beta

        # Define IAM from datasheet using a dictionary to avoid index ordering dependency
        iam_points = {
            0: 1.00,
            5: 1.00,
            10: 1.00,
            15: 1.00,
            20: 1.00,
            25: 0.995,
            30: 0.988,
            35: 0.986,
            40: 0.980,
            45: 0.976,
            50: 0.970,
            55: 0.960,
            60: 0.933,
            65: 0.921,
            70: 0.877,
            75: 0.819,
            80: 0.711,
            85: 0.546,
            90: 0.00,
        }

        aoi_degrees = np.array(sorted(iam_points.keys()))
        iam_values = np.array([iam_points[deg] for deg in aoi_degrees])

        iam_interpolator = interp1d(aoi_degrees, iam_values, kind='cubic', bounds_error=False, fill_value=(1.0, 0.0))

        def iam_datasheet(aoi_deg):
            aoi_deg = np.asarray(aoi_deg)
            aoi_deg = np.clip(aoi_deg, 0, 90)
            vals = iam_interpolator(aoi_deg)
            return np.clip(vals, 0.0, 1.0)

        use_advanced_iam = False  # Set to False to use simple global IAM based on AOI

        # Compute IAM for components (always compute, but apply conditionally)
        iam_direct = iam_datasheet(aoi)  # shape (N,)

        iam_sky = marion_integrate(iam_datasheet, surface_tilt, 'sky')  # scalar

        iam_ground = marion_integrate(iam_datasheet, surface_tilt, 'ground')  # scalar

        # Apply to spectral components
        wavelengths = distribution['wavelength']
        poa_direct = distribution['poa_direct']  # (122, N)
        poa_sky_diffuse = distribution['poa_sky_diffuse']  # (122, N)
        poa_ground_diffuse = distribution['poa_ground_diffuse']  # (122, N)

        if use_advanced_iam:
            iam_direct_broadcast = iam_direct[np.newaxis, :]  # (1, N)
            poa_direct_corrected = poa_direct * iam_direct_broadcast
            poa_sky_corrected = poa_sky_diffuse * iam_sky  # scalar * array
            poa_ground_corrected = poa_ground_diffuse * iam_ground
            poa_global_corrected = poa_direct_corrected + poa_sky_corrected + poa_ground_corrected
        else:
            # Simple: Apply single IAM based on AOI to total POA
            iam_global = iam_direct  # Use the direct AOI-based IAM for everything
            iam_global_broadcast = iam_global[np.newaxis, :]  # (1, N)
            poa_global_uncorrected = poa_direct + poa_sky_diffuse + poa_ground_diffuse
            poa_global_corrected = poa_global_uncorrected * iam_global_broadcast

        if apply_spectral_response:
            spectral_response_array = spline_interpolator(wavelengths)
            spectral_response_array = np.clip(spectral_response_array, 0.0, 1.0)
            spectral_response_array = spectral_response_array[:, np.newaxis]

            # Weight the corrected poa_global
            poa_global_weighted = poa_global_corrected * spectral_response_array  # Shape: (122, N)
            
            # 1. Filter wavelengths between 350 nm and 1200 nm
            mask = (wavelengths >= 350) & (wavelengths <= 1200)
            wavelengths_filtered = wavelengths[mask]  # Shape: (M,)
            poa_global_weighted_filtered = poa_global_weighted[mask, :]  # Shape: (M, N)
            
            # 2. Perform trapezoidal integration
            poa_global_weighted_filtered = np.nan_to_num(poa_global_weighted_filtered, nan=0.0)
            delta_wavelengths = np.diff(wavelengths_filtered)
            average_poa_weighted = (poa_global_weighted_filtered[:-1, :] + poa_global_weighted_filtered[1:, :]) / 2
            areas = average_poa_weighted * delta_wavelengths[:, np.newaxis]
            g_w = np.sum(areas, axis=0)  # Shape: (N,)  # This is G_w (weighted, in W/m²)
            
            # Normalize to get effective irradiance: G_eff = G_w / f
            poa_global_effective = g_w / f
        else:
            # Non-weighted: integrate corrected poa_global directly
            # Filter
            mask = (wavelengths >= 350) & (wavelengths <= 1200)
            wavelengths_filtered = wavelengths[mask]
            poa_global_filtered = poa_global_corrected[mask, :]
            poa_global_filtered = np.nan_to_num(poa_global_filtered, nan=0.0)
            delta_wavelengths = np.diff(wavelengths_filtered)
            average_poa = (poa_global_filtered[:-1, :] + poa_global_filtered[1:, :]) / 2
            areas = average_poa * delta_wavelengths[:, np.newaxis]
            poa_global_effective = np.sum(areas, axis=0)  # Broadband with IAM

        # Compute GHI using broadband DNI/DHI if available; otherwise integrate spectral DNI/DHI
        ghi_effective = None
        try:
            dni_val = distribution.get('dni', None)
            dhi_val = distribution.get('dhi', None)
            if dni_val is not None and dhi_val is not None:
                dni_arr = np.asarray(dni_val)
                dhi_arr = np.asarray(dhi_val)

                if dni_arr.ndim == 2:
                    # Spectral (wavelength x time): integrate to broadband
                    mask = (wavelengths >= 350) & (wavelengths <= 1200)
                    wavelengths_filtered = wavelengths[mask]
                    delta_wavelengths = np.diff(wavelengths_filtered)

                    dni_spec = np.nan_to_num(dni_arr[mask, :], nan=0.0)
                    dhi_spec = np.nan_to_num(dhi_arr[mask, :], nan=0.0)

                    if apply_spectral_response:
                        sr_filtered = spectral_response_array[mask]
                        dni_weighted = dni_spec * sr_filtered
                        dhi_weighted = dhi_spec * sr_filtered

                        avg_dni = (dni_weighted[:-1, :] + dni_weighted[1:, :]) / 2
                        avg_dhi = (dhi_weighted[:-1, :] + dhi_weighted[1:, :]) / 2

                        dni_areas = avg_dni * delta_wavelengths[:, np.newaxis]
                        dhi_areas = avg_dhi * delta_wavelengths[:, np.newaxis]

                        dni_eff = np.sum(dni_areas, axis=0) / f
                        dhi_eff = np.sum(dhi_areas, axis=0) / f
                    else:
                        avg_dni = (dni_spec[:-1, :] + dni_spec[1:, :]) / 2
                        avg_dhi = (dhi_spec[:-1, :] + dhi_spec[1:, :]) / 2

                        dni_areas = avg_dni * delta_wavelengths[:, np.newaxis]
                        dhi_areas = avg_dhi * delta_wavelengths[:, np.newaxis]

                        dni_eff = np.sum(dni_areas, axis=0)
                        dhi_eff = np.sum(dhi_areas, axis=0)

                    cosz = np.clip(cosd(apparent_zenith), 0, None)
                    cosz = np.asarray(cosz).reshape(-1)
                    ghi_effective = dni_eff * cosz + dhi_eff
                else:
                    # Broadband arrays aligned to time
                    dni_arr = dni_arr.reshape(-1)
                    dhi_arr = dhi_arr.reshape(-1)
                    cosz = np.clip(cosd(apparent_zenith), 0, None)
                    cosz = np.asarray(cosz).reshape(-1)

                    # Align lengths if needed via timestamp reindexing
                    if len(dni_arr) != len(cosz) or len(dni_arr) != len(df.index):
                        s = pd.Series(dni_arr * cosz[:len(dni_arr)] + dhi_arr[:len(dhi_arr)], index=timestamps[:len(dni_arr)])
                        s = s.reindex(df.index, method='nearest')
                        ghi_effective = s.values
                    else:
                        ghi_effective = dni_arr * cosz + dhi_arr
        except Exception as e:
            print(f"GHI computation warning: {e}")

        # Print comparison between computed GHI and POA global (do not return GHI)
        original_index = df.index
        if ghi_effective is not None:
            try:
                s_poa = pd.Series(poa_global_effective, index=original_index, name='POA_global')
                if len(ghi_effective) != len(original_index):
                    s_tmp = pd.Series(ghi_effective, index=timestamps[:len(ghi_effective)])
                    s_tmp = s_tmp.reindex(original_index, method='nearest')
                    s_ghi = s_tmp.rename('GHI')
                else:
                    s_ghi = pd.Series(ghi_effective, index=original_index, name='GHI')
                corr = s_poa.corr(s_ghi)
                print(f"GHI vs POA global correlation: {corr:.4f}")
                print("10:30 (hh:mm) comparison (W/m^2):")
                df_cmp = pd.concat([s_poa, s_ghi], axis=1)
                try:
                    if isinstance(df_cmp.index, pd.DatetimeIndex):
                        mask_1030 = (df_cmp.index.hour == 10) & (df_cmp.index.minute == 30)
                        df_1030 = df_cmp.loc[mask_1030]
                        if df_1030.empty:
                            print("No rows found at 10:30.")
                        else:
                            print(df_1030)
                    else:
                        print("Index is not a DatetimeIndex; cannot filter 10:30.")
                except Exception as e:
                    print(f"10:30 filtering failed: {e}")
            except Exception as e:
                print(f"GHI comparison print failed: {e}")

        # Create a DataFrame to store the effective poa_global values only
        spectral_irradiance = pd.DataFrame(
            {'poa_global': poa_global_effective},
            index=original_index  # Use original index instead of timestamps
        )
        
        # Collect intermediate parameters
        # Make sure to align them with the original index
        # airmass_relative and apparent_zenith are already Series with timestamps index
        # aoi is also a Series with timestamps index
        intermediate_params = {
            'relative_airmass': airmass_relative if isinstance(airmass_relative, pd.Series) else pd.Series(airmass_relative, index=timestamps),
            'ang_alpha': ang_alpha,  # This is a numpy array aligned with df
            'ang_beta': ang_beta,   # This is a numpy array aligned with df
            'aod500': aod500,       # This is a numpy array aligned with df
            'apparent_zenith': apparent_zenith if isinstance(apparent_zenith, pd.Series) else pd.Series(apparent_zenith, index=timestamps),
            'aoi': aoi if isinstance(aoi, pd.Series) else pd.Series(aoi, index=timestamps),
            'dni': dni_eff,
            'dhi': dhi_eff,
        }
        
        return spectral_irradiance, intermediate_params

    @classmethod
    def calc_solar_position(cls, timestamps):
        latitude, longitude = 47.523618, 19.012776
        altitude = 240

        solar_position = pvlib.solarposition.get_solarposition(
            time=timestamps,
            latitude=latitude,
            longitude=longitude,
            altitude=altitude
        )
        return solar_position

    @classmethod
    def calc_extraterrestrial_radiation(cls, timestamps):
        return pvlib.irradiance.get_extra_radiation(timestamps)

    @classmethod
    def calc_poa_irradiance(cls, solar_position, dni, ghi, dhi, panel_tilt, panel_azimuth, extra_radiation, albedo, models):
        poa_irradiances = {}
        for model in models:
            poa_irradiance = get_total_irradiance(
                surface_tilt=panel_tilt,
                surface_azimuth=panel_azimuth,
                dni=dni,
                ghi=ghi,
                dhi=dhi,
                solar_zenith=solar_position['apparent_zenith'],
                solar_azimuth=solar_position['azimuth'],
                model=model,
                albedo=albedo,
                dni_extra=extra_radiation
            )
            poa_irradiances[model] = poa_irradiance

        return poa_irradiances


