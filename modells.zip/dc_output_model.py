import pandas as pd
import pvlib
from typing import List

from modmod.models.model_protocol import BaseCalculationModel


class DcOutputModel(BaseCalculationModel):
    """
    Calculates the DC output of a PV system based on irradiance, cell temperature, and module specifications.
    """
    
    def __init__(self, name: str = "DcOutputModel"):
        super().__init__(name)
    
    def get_required_inputs(self) -> List[str]:
        """Return list of required input column names."""
        return ['irradiance', 'cell_temp']
    
    def get_outputs(self) -> List[str]:
        """Return list of output column names."""
        return ['dc_output']
    
    def calculate(self, df: pd.DataFrame, module_name: str, calc_type: str, module_no: int, **kwargs) -> pd.DataFrame:
        """Calculate DC output using single diode model.
        
        Args:
            df: Input dataframe with irradiance and cell_temp columns
            module_name: PV module name for SAM database lookup
            calc_type: Parameter calculation type (desoto or cec)
            module_no: Number of modules in string
            **kwargs: Additional parameters
            
        Returns:
            DataFrame with dc_output column
        """
        result = df.copy()
        
        module = self._select_module_from_cec(module_name)
        
        irrad = pd.to_numeric(df["irradiance"]).values
        cell_temp = pd.to_numeric(df["cell_temp"]).values
        
        dc_output = self._calculate_dc_singlediode_vectorized(irrad, cell_temp, module, calc_type)["p_mp"]
        dc_output.index = df.index
        
        result["dc_output"] = dc_output * module_no
        
        return result
    
    @staticmethod
    def _calc_params_desoto(irrad, cell_temp, module):
        """Calculate parameters using DeSoto model."""
        return pvlib.pvsystem.calcparams_desoto(
            irrad,
            cell_temp,
            module["alpha_sc"],
            module["a_ref"],
            module["I_L_ref"],
            module["I_o_ref"],
            module["R_sh_ref"],
            module["R_s"]
        )

    @staticmethod
    def _calc_params_cec(irrad, cell_temp, module):
        """Calculate parameters using CEC model."""
        return pvlib.pvsystem.calcparams_cec(
            irrad,
            cell_temp,
            module["alpha_sc"],
            module["a_ref"],
            module["I_L_ref"],
            module["I_o_ref"],
            module["R_sh_ref"],
            module["R_s"],
            module["Adjust"]
        )

    @classmethod
    def _calc_input_params_singlediode(cls, irrad, cell_temp, module, calc_type):
        """Calculate input parameters for single diode model."""
        calc_type_dict = {
            "desoto": cls._calc_params_desoto,
            "cec": cls._calc_params_cec,
        }
        if calc_type in calc_type_dict.keys():
            return calc_type_dict[calc_type](irrad, cell_temp, module)
        else:
            raise NotImplementedError(f"Input parameter calculation type {calc_type} not implemented! "
                                      f"Implemented ones are: {list(calc_type_dict.keys())}.")

    @staticmethod
    def _translate_sam_name_to_id(name: str) -> str:
        """Translate SAM module name to database ID."""
        from_translate = ' -.()[]:+/",'
        to_translate = "_" * len(from_translate)
        mapping = str.maketrans(from_translate, to_translate)
        return name.translate(mapping)

    @classmethod
    def _select_module_from_cec(cls, module_name: str) -> pd.DataFrame:
        """Select module from CEC database."""
        module_id = cls._translate_sam_name_to_id(module_name)
        try:
            sam_db_path = "sam_2023.12.17_export/CEC_Modules.csv"
            return pvlib.pvsystem.retrieve_sam(path=sam_db_path)[module_id]
        except KeyError:
            raise KeyError(f"Module with name {module_name} not found in SAM DB (located in {sam_db_path})!")

    @classmethod
    def _calculate_dc_singlediode_vectorized(cls, irrad, cell_temp, module, calc_type):
        """Calculate DC output using single diode model."""
        input_params = cls._calc_input_params_singlediode(irrad, cell_temp, module, calc_type)
        return pvlib.pvsystem.singlediode(*input_params)