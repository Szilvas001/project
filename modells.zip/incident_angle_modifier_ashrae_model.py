import pandas as pd
import pvlib
from typing import List

from modmod.models.model_protocol import BaseCalculationModel


class IncidentAngleModifierAshraeModel(BaseCalculationModel):
    """
    ASHRAE IAM model: Calculate Incident Angle Modifier using ASHRAE method.
    """
    
    def __init__(self, name: str = "IncidentAngleModifierAshraeModel"):
        super().__init__(name)
    
    def get_required_inputs(self) -> List[str]:
        """Return list of required input column names."""
        return ['aoi', 'irradiance_without_iam']
    
    def get_outputs(self) -> List[str]:
        """Return list of output column names."""
        return ['iam', 'irradiance_with_iam']
    
    def calculate(self, df: pd.DataFrame, iam_aoi_adjuster_b: float, **kwargs) -> pd.DataFrame:
        """Calculate ASHRAE IAM.
        
        Args:
            df: Input dataframe with aoi and irradiance_without_iam columns
            iam_aoi_adjuster_b: ASHRAE b parameter
            **kwargs: Additional parameters
            
        Returns:
            DataFrame with iam and irradiance_with_iam columns
        """
        result = df.copy()
        
        # Calculate IAM using pvlib ASHRAE model
        iam_values = pvlib.iam.ashrae(df['aoi'], b=iam_aoi_adjuster_b)
        
        # Apply IAM to irradiance
        irradiance_with_iam = df['irradiance_without_iam'] * iam_values
        
        result['iam'] = iam_values
        result['irradiance_with_iam'] = irradiance_with_iam
        
        return result
