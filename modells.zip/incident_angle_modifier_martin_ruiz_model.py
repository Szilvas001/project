import pandas as pd
import pvlib
from typing import List

from modmod.models.model_protocol import BaseCalculationModel


class IncidentAngleModifierMartinRuizModel(BaseCalculationModel):
    """
    Martin-Ruiz IAM model: Calculate Incident Angle Modifier using Martin-Ruiz method.
    """
    
    def __init__(self, name: str = "IncidentAngleModifierMartinRuizModel"):
        super().__init__(name)
    
    def get_required_inputs(self) -> List[str]:
        """Return list of required input column names."""
        return ['aoi', 'irradiance_without_iam']
    
    def get_outputs(self) -> List[str]:
        """Return list of output column names."""
        return ['iam', 'irradiance_with_iam']
    
    def calculate(self, df: pd.DataFrame, angular_losses_coeff_a_r: float, **kwargs) -> pd.DataFrame:
        """Calculate Martin-Ruiz IAM.
        
        Args:
            df: Input dataframe with aoi and irradiance_without_iam columns
            angular_losses_coeff_a_r: Martin-Ruiz a_r parameter
            **kwargs: Additional parameters
            
        Returns:
            DataFrame with iam and irradiance_with_iam columns
        """
        result = df.copy()
        
        # Calculate IAM using pvlib Martin-Ruiz model
        iam_values = pvlib.iam.martin_ruiz(df['aoi'], a_r=angular_losses_coeff_a_r)
        
        # Apply IAM to irradiance
        irradiance_with_iam = df['irradiance_without_iam'] * iam_values
        
        result['iam'] = iam_values
        result['irradiance_with_iam'] = irradiance_with_iam
        
        return result
