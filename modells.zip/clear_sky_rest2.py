from __future__ import annotations

import collections
import concurrent.futures as cf
import warnings
from typing import Dict, Tuple, Any

import numpy as np
import pandas as pd

import pvlib
from pvlib.irradiance import get_total_irradiance

# opcionális, ha később kellne (nem kötelező használni)
from sklearn.linear_model import LinearRegression  # noqa: F401

# A projektben adott ősosztály
from .model_protocol import BaseCalculationModel


# -----------------------------------------------------------------------------
# Általános konstansok és segédek
# -----------------------------------------------------------------------------

SOLAR_CONSTANT: float = 1361.0  # W/m^2 (modern érték)
SZA_LIM: float = 89.0           # fok – numerikai stabilitás (zenit határ)


def check_range(x: np.ndarray, name: str, low: float = 0.0, high: float = 1.0) -> None:
    """REST2 mellékértékek tartomány-ellenőrzése a [0,1] intervallumra."""
    if not isinstance(x, np.ndarray):
        return
    if np.any(x < low) or np.any(x > high):
        warnings.warn(f"{name}: érték kilóg a [{low}, {high}] tartományból – vágás alkalmazva.", RuntimeWarning)
        np.clip(x, low, high, out=x)


# -----------------------------------------------------------------------------
# REST2 (v9 compact) segédfüggvények – Anthony Lopez alapján, adaptálva
# -----------------------------------------------------------------------------

# -------------- [a teljes REST2 mag változatlan – kezdete] -------------------

def op_mass(p: np.ndarray, am: np.ndarray, cosz: np.ndarray, z: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Optikai tömegek (Rayleigh/gázok/víz/ózon útvonalak). p: hPa (mbar)."""
    masr = am * p / 1013.25
    masw = np.maximum(1.0, 1.0 / (cosz + 0.10648 * (z ** 0.11423) / (93.781 - z) ** 1.9203))
    maso = np.maximum(1.0, 1.0 / (cosz + 1.0651  * (z ** 0.6379)  / (101.8  - z) ** 2.2694))
    return masr, masw, maso


def trans_1(p: np.ndarray, am: np.ndarray, cosz: np.ndarray, z: np.ndarray,
            ozone: np.ndarray, w: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Sáv 1 (0.3–0.7 µm) transzmittanciák: Rayleigh, gáz, O3, NO2, víz."""
    masr, masw, maso = op_mass(p, am, cosz, z)
    transr1 = ((1.0 + 1.8169 * masr - 0.033454 * masr ** 2) / (1.0 + 2.063 * masr + 0.31978 * masr ** 2))
    transg1 = ((1.0 + 0.95885 * masr + 0.012871 * masr ** 2) / (1.0 + 0.96321 * masr + 0.015455 * masr ** 2))
    a1 = (ozone * (10.979 - 8.5421 * ozone) / (1.0 + 2.0115 * ozone + 40.189 * ozone ** 2))
    a2 = (ozone * (-0.027589 - 0.005138 * ozone) / (1.0 - 2.4857 * ozone + 13.942 * ozone ** 2))
    a3 = (ozone * (10.995 - 5.5001 * ozone) / (1.0 + 1.6784 * ozone + 42.406 * ozone ** 2))
    trano1 = (1.0 + a1 * maso + a2 * maso ** 2) / (1.0 + a3 * maso)
    trann1 = ((1.0 + 0.18307 * masw - 0.00024 * masw ** 2) / (1.0 + 0.18713 * masw))
    c1 = w * (0.065445 + 0.00029901 * w) / (1.0 + 1.2728 * w)
    c2 = w * (0.065687 + 0.0013218 * w) / (1.0 + 1.2008 * w)
    tranw1 = (1.0 + c1 * masw) / (1.0 + c2 * masw)
    return transr1, transg1, trano1, trann1, tranw1


def trans_2(p: np.ndarray, am: np.ndarray, cosz: np.ndarray, z: np.ndarray,
            w: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Sáv 2 (0.7–4 µm) transzmittanciák: Rayleigh, gáz, víz."""
    masr, masw, _ = op_mass(p, am, cosz, z)
    transr2 = (1.0 - 0.010394 * masr) / (1.0 - 0.00011042 * masr ** 2)
    trang2 = ((1.0 + 0.27284 * masr - 0.00063699 * masr ** 2) / (1.0 + 0.30306 * masr))
    c1 = w * ((19.566 - 1.6506 * w + 1.0672 * w ** 2) / (1.0 + 5.4248 * w + 1.6005 * w ** 2))
    c2 = w * ((0.50158 - 0.14732 * w + 0.047584 * w ** 2) / (1.0 + 1.1811 * w + 1.0699 * w ** 2))
    c3 = w * ((21.286 - 0.39232 * w + 1.2692 * w ** 2) / (1.0 + 4.8318 * w + 1.412 * w ** 2))
    c4 = w * ((0.70992 - 0.23155 * w + 0.096514 * w ** 2) / (1.0 + 0.44907 * w + 0.75425 * w ** 2))
    tranw2 = ((1.0 + c1 * masw + c2 * masw ** 2) / (1.0 + c3 * masw + c4 * masw ** 2))
    return transr2, trang2, tranw2


def band_1(alpha: np.ndarray, masa: np.ndarray, beta: np.ndarray) -> np.ndarray:
    """Sáv 1 jellemző hullámhossza (wvle1)."""
    wvlmin1 = 0.5158 - 0.008334 * alpha
    wvlmax1 = np.maximum(0.61, (0.6 + 0.95155 * alpha) / (1.0 + 1.3095 * alpha))
    i = np.where(alpha < 0)
    if i[0].size:
        wvlmin1[i] = 0.51
        wvlmax1[i] = 0.61
    cc0 = (0.50947 - 0.012555 * alpha + 0.0026455 * alpha ** 2 + 0.0044092 * alpha ** 3
           - 0.0022439 * alpha ** 4 + 0.0003123 * alpha ** 5)
    cc1 = (0.062836 + 0.049194 * alpha + 0.013976 * alpha ** 2 - 0.0114290 * alpha ** 3
           + 0.0053573 * alpha ** 4 + 0.0026402 * alpha ** 5)
    cc2 = (0.096418 + 0.072221 * alpha + 0.015505 * alpha ** 2 - 0.0216490 * alpha ** 3
           + 0.0119010 * alpha ** 4 + 0.0033763 * alpha ** 5)
    dd0 = 0.5
    dd1 = (0.065180 - 0.039075 * alpha + 0.11648 * alpha ** 2 + 0.048987 * alpha ** 3
           - 0.026766 * alpha ** 4 - 0.12573 * alpha ** 5 + 0.092131 * alpha ** 6)
    dd2 = (0.099191 - 0.083962 * alpha + 0.20562 * alpha ** 2 + 0.057377 * alpha ** 3
           - 0.049548 * alpha ** 4 - 0.17782 * alpha ** 5 + 0.13647 * alpha ** 6)
    y1 = masa * beta ** (0.3333 * alpha)
    z1 = masa * beta ** 0.5
    wvle1 = (cc0 + cc1 * y1) / (1.0 + cc2 * y1)
    j = np.where(masa * beta > 10)
    if j[0].size:
        wvle1[j] = (dd0 + dd1[j] * z1[j]) / (1.0 + dd2[j] * z1[j])
    wvle1 = np.minimum(wvle1, wvlmax1)
    wvle1 = np.maximum(wvle1, wvlmin1)
    return wvle1


def band_2(alpha: np.ndarray, masa: np.ndarray, beta: np.ndarray) -> np.ndarray:
    """Sáv 2 jellemző hullámhossza (wvle2)."""
    wvlmin2 = 1.0 - 0.02 * alpha
    wvlmax2 = 1.3 + 1.5317 * alpha - 0.55289 * alpha ** 2
    i = np.where(alpha < 0)
    if i[0].size:
        wvlmin2[i] = 1.0 + 0.4 * alpha[i]
        wvlmax2[i] = 1.3 + 0.25 * alpha[i]
    aa0 = (1.0677 - 0.05432 * alpha + 0.014351 * alpha ** 2 - 0.0097063 * alpha ** 3 + 0.0023655 * alpha ** 4)
    aa1 = (-0.20914 - 0.27218 * alpha + 0.83552 * alpha ** 2 - 0.85437 * alpha ** 3
           + 0.49305 * alpha ** 4 - 0.14965 * alpha ** 5 + 0.018964 * alpha ** 6)
    aa2 = (0.0010588 + 0.039597 * alpha + 0.006733 * alpha ** 2 + 0.070698 * alpha ** 3
           - 0.11284 * alpha ** 4 + 0.055096 * alpha ** 5 - 0.0086265 * alpha ** 6)
    aa3 = (-0.19432 - 0.29366 * alpha + 0.83474 * alpha ** 2 - 0.78019 * alpha ** 3
           + 0.37382 * alpha ** 4 - 0.089069 * alpha ** 5 + 0.0091113 * alpha ** 6)
    x2 = np.log(1.0 + (masa * beta))
    x22 = x2 * x2
    wvle2 = (aa0 + aa1 * x2 + aa2 * x22) / (1.0 + aa3 * x2)
    wvle2 = np.minimum(wvle2, wvlmax2)
    wvle2 = np.maximum(wvle2, wvlmin2)
    return wvle2


def aer_scat_trans(wvle: np.ndarray, piar: np.ndarray, alpha: np.ndarray,
                   beta: np.ndarray, masa: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Aeroszol szórás/abszorpció transzmittanciák és tau_as (ssa * tau_a)."""
    taua = beta / (wvle ** alpha)
    tauas = piar * taua
    amsbet = masa * taua
    tranas = np.exp(-masa * tauas)
    tranaa = np.exp(-amsbet * (1.0 - piar))
    return tranas, tranaa, tauas


def calc_eabs(tabs: np.ndarray, f: float, radius: np.ndarray) -> np.ndarray:
    """Aeroszol nélküli sávonkénti DNI (eq.3 része)."""
    return tabs * f * SOLAR_CONSTANT / (radius ** 2)


def calc_edni(transr: np.ndarray, tranas: np.ndarray, eabs: np.ndarray) -> np.ndarray:
    """Aeroszolos sávonkénti DNI (eq.3)."""
    return eabs * transr * tranas


def layer_props(transr: np.ndarray, tauas: np.ndarray, tranas: np.ndarray, tabs: np.ndarray,
                f: float, radius: np.ndarray, cosz: np.ndarray, albedo: np.ndarray,
                am: np.ndarray, fm: np.ndarray, g0: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Egy sáv “kétrétegű” modellje (abszorpció felül, szórás alul): sávonkénti
    edni, difúz, teljes difúz, és rsky.
    """
    eabs = calc_eabs(tabs, f, radius)
    edni = calc_edni(transr, tranas, eabs)

    taur = -np.log(np.maximum(transr, 1e-12)) / np.maximum(am, 1e-6)
    taut = taur + tauas

    frwd1 = ((0.5 + 1.8823 * cosz) / (1.0 + 1.7971 * cosz) * tauas + 0.5 * taur)
    amt = am * taut
    fn = (1.0 - 10.921 * amt - 11.741 * amt * amt) / (1.0 + 35.006 * amt)
    rsky = taut * (0.51754 + 0.15884 * taut) / (1.0 + 2.77 * taut)

    g1 = g0 * tauas / np.maximum(taut, 1e-12)
    fg = (-0.5 + 10.497 * g1 - 11.735 * g1 ** 2) / (1.0 + 401.0 * g1 ** 2)
    edif = frwd1 * np.exp(fn + fg + fm) * eabs
    edift = edif + albedo * rsky * (edni * cosz + edif) / np.maximum((1.0 - albedo * rsky), 1e-6)
    return edni, edif, edift, rsky


def rest2(p: np.ndarray, albedo: np.ndarray, ssa: np.ndarray, g: np.ndarray,
          z: np.ndarray, radius: np.ndarray, alpha: np.ndarray, beta: np.ndarray,
          ozone: np.ndarray, w: np.ndarray, sza_lim: float = SZA_LIM):
    """
    REST2 Clear Sky főfüggvény (v9 compact).
    Vissza: ghi, dni, dhi, Tddclr, Tduclr, Ruuclr, valamint sávonkénti GHI-k: E1_ghi, E2_ghi.
    """
    # SZA levágása
    z = np.where(z > sza_lim, sza_lim, z).astype(float)

    degrad = np.pi / 180.0
    f1c, f2c = 0.47244, 0.51951

    # Bemeneti korlátok
    alpha = np.clip(alpha, 0.0, 2.501)
    beta = np.clip(beta, 0.001, 2.2)
    albedo = np.clip(albedo, 0.05, 0.9)

    cosz = np.cos(z * degrad)

    g0 = g + 0.066 * (1.0 - alpha)
    piar1 = np.maximum(0.85, np.minimum(0.98, ssa + 0.03))
    piar2 = np.minimum(0.95, np.maximum(0.85, ssa - 0.02))
    piar1 = np.where(ssa <= 0, 0.95, piar1)
    piar2 = np.where(ssa <= 0, 0.90, piar2)
    ssa = np.where(ssa <= 0, 0.92, ssa)

    # SMARTS-kompatibilis optikai tömegek
    am = np.maximum(1.0, 1.0 / (cosz + 0.48353 * (z ** 0.095846) / (96.741 - z) ** 1.754))
    masa = np.maximum(1.0, 1.0 / (cosz + 0.16851 * (z ** 0.18198) / (95.318 - z) ** 1.9542))

    # Sávtranszmittanciák
    transr1, transg1, trano1, trann1, tranw1 = trans_1(p, am, cosz, z, ozone, w)
    transr2, trang2, tranw2 = trans_2(p, am, cosz, z, w)

    # Aeroszol függvények
    ambeta = masa * beta
    wvle1 = band_1(alpha, masa, beta)
    wvle2 = band_2(alpha, masa, beta)
    aodcor = ambeta * (0.015981 + 0.183 * ambeta) / (1.0 + 1.4142 * ambeta)

    tranas1, tranaa1, tauas1 = aer_scat_trans(wvle1, piar1, alpha, beta, masa)
    tranas2, tranaa2, tauas2 = aer_scat_trans(wvle2, piar2, alpha, beta, masa)

    tabs1 = transg1 * trann1 * tranw1 * trano1 * tranaa1
    tabs2 = trang2 * tranw2 * tranaa2

    fm = 0.15244 * (am - 1.0) / (1.0 + 2.2413 * am)

    edni1, edif1, edift1, rsky1 = layer_props(transr1, tauas1, tranas1, tabs1, f1c, radius, cosz, albedo, am, fm, g0)
    edni2, edif2, edift2, rsky2 = layer_props(transr2, tauas2, tranas2, tabs2, f2c, radius, cosz, albedo, am, fm, g0)

    # Sávonkénti GHI (eglob1/2): diffúz + direkt vízszintesre vetített
    eglob1 = edift1 + edni1 * cosz
    eglob2 = edift2 + edni2 * cosz

    # Összegek
    edif = edift1 + edift2
    edirn = (edni1 + edni2) * np.exp(aodcor)
    eglob = eglob1 + eglob2  # = edif + edirn * cosz

    # Transzmittanciák
    etdirn = SOLAR_CONSTANT / (np.maximum(radius, 1e-6) ** 2)
    Tddclr = np.divide(edirn, etdirn, out=np.zeros_like(edirn), where=etdirn > 0)
    Tduclr = np.divide(edif, (etdirn * np.maximum(cosz, 1e-6)), out=np.zeros_like(edif), where=(etdirn * np.maximum(cosz, 1e-6)) > 0)
    Ruuclr = (((edni1 * cosz + edif1) * rsky1 + (edni2 * cosz + edif2) * rsky2) /
              np.maximum(((edni1 * cosz + edif1) + (edni2 * cosz + edif2)), 1e-12))

    # Tartományellenőrzés
    check_range(Tddclr, 'Tddclr')
    check_range(Tduclr, 'Tduclr')
    check_range(Ruuclr, 'Ruuclr')

    RestData = collections.namedtuple('rest_data',
                                      ['ghi', 'dni', 'dhi', 'Tddclr', 'Tduclr', 'Ruuclr',
                                       'E1_ghi', 'E2_ghi'])
    return RestData(ghi=eglob, dni=edirn, dhi=edif, Tddclr=Tddclr, Tduclr=Tduclr, Ruuclr=Ruuclr,
                    E1_ghi=eglob1, E2_ghi=eglob2)


def rest2_parallel(p: np.ndarray, albedo: np.ndarray, ssa: np.ndarray, g: np.ndarray,
                   z: np.ndarray, radius: np.ndarray, alpha: np.ndarray, beta: np.ndarray,
                   ozone: np.ndarray, w: np.ndarray, sza_lim: float = SZA_LIM, n_workers: int = 8):
    """REST2 párhuzamos végrehajtás több darabban (idősor feldarabolása)."""
    n = len(z)
    n_workers = max(1, min(n_workers, n))
    splits = np.array_split(np.arange(n), n_workers)

    def _run(idx: np.ndarray):
        return rest2(p[idx], albedo[idx], ssa[idx], g[idx], z[idx], radius[idx],
                     alpha[idx], beta[idx], ozone[idx], w[idx], sza_lim=sza_lim)

    with cf.ThreadPoolExecutor(max_workers=len(splits)) as ex:
        parts = [ex.submit(_run, idx).result() for idx in splits]

    # Összefűzés
    ghi = np.concatenate([part.ghi for part in parts], axis=0)
    dni = np.concatenate([part.dni for part in parts], axis=0)
    dhi = np.concatenate([part.dhi for part in parts], axis=0)
    Tdd = np.concatenate([part.Tddclr for part in parts], axis=0)
    Tdu = np.concatenate([part.Tduclr for part in parts], axis=0)
    Ruu = np.concatenate([part.Ruuclr for part in parts], axis=0)
    E1 = np.concatenate([part.E1_ghi for part in parts], axis=0)
    E2 = np.concatenate([part.E2_ghi for part in parts], axis=0)

    RestData = collections.namedtuple('rest_data',
                                      ['ghi', 'dni', 'dhi', 'Tddclr', 'Tduclr', 'Ruuclr', 'E1_ghi', 'E2_ghi'])
    return RestData(ghi=ghi, dni=dni, dhi=dhi, Tddclr=Tdd, Tduclr=Tdu, Ruuclr=Ruu,
                    E1_ghi=E1, E2_ghi=E2)


def rest2_tddclr(p: np.ndarray, albedo: np.ndarray, ssa: np.ndarray, z: np.ndarray | float,
                 radius: np.ndarray, alpha: np.ndarray, beta: np.ndarray,
                 ozone: np.ndarray, w: np.ndarray, sza_lim: float = SZA_LIM) -> np.ndarray:
    """Csak Tddclr számítás adott SZA mellett."""
    if np.ndim(z) == 0:
        z = np.full_like(alpha, float(z))

    z = np.where(z > sza_lim, sza_lim, z).astype(float)
    degrad = np.pi / 180.0
    f1c, f2c = 0.47244, 0.51951

    alpha = np.clip(alpha, 0.0, 2.501)
    beta = np.clip(beta, 0.001, 2.2)
    albedo = np.clip(albedo, 0.05, 0.9)

    cosz = np.cos(z * degrad)
    piar1 = np.maximum(0.85, np.minimum(0.98, ssa + 0.03))
    piar2 = np.minimum(0.95, np.maximum(0.85, ssa - 0.02))
    piar1 = np.where(ssa <= 0, 0.95, piar1)
    piar2 = np.where(ssa <= 0, 0.90, piar2)
    ssa = np.where(ssa <= 0, 0.92, ssa)

    am = np.maximum(1.0, 1.0 / (cosz + 0.48353 * (z ** 0.095846) / (96.741 - z) ** 1.754))
    masa = np.maximum(1.0, 1.0 / (cosz + 0.16851 * (z ** 0.18198) / (95.318 - z) ** 1.9542))

    transr1, transg1, trano1, trann1, tranw1 = trans_1(p, am, cosz, z, ozone, w)
    transr2, trang2, tranw2 = trans_2(p, am, cosz, z, w)

    ambeta = masa * beta
    wvle1 = band_1(alpha, masa, beta)
    wvle2 = band_2(alpha, masa, beta)
    aodcor = ambeta * (0.015981 + 0.183 * ambeta) / (1.0 + 1.4142 * ambeta)

    tranas1, tranaa1, _ = aer_scat_trans(wvle1, piar1, alpha, beta, masa)
    tranas2, tranaa2, _ = aer_scat_trans(wvle2, piar2, alpha, beta, masa)

    tabs1 = transg1 * trann1 * tranw1 * trano1 * tranaa1
    tabs2 = trang2 * tranw2 * tranaa2

    edni1 = calc_edni(transr1, tranas1, calc_eabs(tabs1, f1c, radius))
    edni2 = calc_edni(transr2, tranas2, calc_eabs(tabs2, f2c, radius))

    edirn = (edni1 + edni2) * np.exp(aodcor)
    etdirn = SOLAR_CONSTANT / (np.maximum(radius, 1e-6) ** 2)
    Tddclr = np.divide(edirn, etdirn, out=np.zeros_like(edirn), where=etdirn > 0)

    check_range(Tddclr, 'Tddclr')
    return Tddclr


def rest2_tuuclr(p: np.ndarray, albedo: np.ndarray, ssa: np.ndarray, radius: np.ndarray,
                 alpha: np.ndarray, ozone: np.ndarray, w: np.ndarray,
                 parallel: bool = False,
                 diffuse_angles: Tuple[float, ...] = (84.2608, 78.4630, 72.5424, 66.4218, 60.0000,
                                                      53.1301, 45.5730, 36.8699, 25.8419, 0.00000)) -> np.ndarray:
    """Tuuclr becslése több SZA átlagolásából (FARMS eq. 5)."""
    Tdd_list = []

    def _one(angle: float) -> np.ndarray:
        return rest2_tddclr(p=p, albedo=albedo, ssa=ssa, z=angle,
                            radius=radius, alpha=alpha, beta=np.zeros_like(alpha),
                            ozone=ozone, w=w, sza_lim=SZA_LIM)

    if parallel:
        with cf.ThreadPoolExecutor(max_workers=len(diffuse_angles)) as ex:
            Tdd_list = [ex.submit(_one, ang).result() for ang in diffuse_angles]
    else:
        for ang in diffuse_angles:
            Tdd_list.append(_one(ang))

    scalar = 1.0 / len(diffuse_angles)
    for i, ang in enumerate(diffuse_angles):
        Tdd_list[i] = Tdd_list[i] * np.cos(np.deg2rad(ang)) * scalar
    Tuu = np.sum(np.array(Tdd_list), axis=0) * 2.0
    return Tuu

# -------------- [a teljes REST2 mag változatlan – vége] ----------------------


# -----------------------------------------------------------------------------
# Lánc-kompatibilis REST2 osztály – struktúra megőrzése + MMF + SZENZITIVITÁSOK
# -----------------------------------------------------------------------------

class ClearSkyModelRest(BaseCalculationModel):
    """
    Clear-sky broadband modell REST2 maggal.
    Struktúra és interfész megegyezik a korábbival, kiegészítve MMF és
    szenzitivitási derivált számítással (aod500, wv/PW).
    """

    SOLAR_CONSTANT = SOLAR_CONSTANT
    SZA_LIM = SZA_LIM

    def __init__(self, name: str = "ClearSkyModel"):
        super().__init__(name)

    # ---- Szükséges bemenetek/kimenetek ----
    @classmethod
    def get_required_inputs(cls):
        return ['pressure', 'wv', 'o3', 'ssa', 'asymmetry_factor_550',
                'aod400', 'aod500', 'aod1064']

    @classmethod
    def get_outputs(cls):
        # Kiegészítve az E1/E2 és a szenzitivitási oszlopokkal
        return ['clear_sky_poa_irradiance', 'clear_sky_ghi',
                'relative_airmass', 'ang_alpha', 'ang_beta', 'aod500',
                'apparent_zenith', 'aoi',
                'dni', 'dhi', 'Tddclr', 'Tduclr', 'Ruuclr',
                'E1_ghi', 'E2_ghi',
                'mmf', 'f1', 'f1_ref', 'k_mmf', 'poa_global_mmf',
                'dE1_daod500', 'dE2_daod500', 'dGHI_daod500', 'dPOA_daod500',
                'dE1_dpw', 'dE2_dpw', 'dGHI_dpw', 'dPOA_dpw']

    # -------------------- Publikus belépési pont --------------------

    def calculate(self, df: pd.DataFrame, latitude: float, longitude: float,
                  panel_tilt: float, panel_azimuth: float,
                  altitude: float = 0, albedo: float = 0.25,
                  apply_spectral_response: bool = False,  # REST2 broadband -> nem használjuk
                  mmf_k: float = 0.75,
                  mmf_sr1: float = 0.90,
                  mmf_sr2: float = 0.60,
                  mmf_f1_ref: float = 0.58,
                  mmf_clip: Tuple[float, float] = (0.8, 1.2),
                  # --- ÚJ: derivált beállítások ---
                  eps_aod500: float = 1e-3,
                  eps_wv: float = 0.1,
                  **kwargs) -> pd.DataFrame:
        """
        Broadband clear-sky REST2 számítás, majd Hay-Davies POA transzpozíció.
        Továbbá MMF (mismatch factor) és szenzitivitási deriváltak véges
        különbséggel (aod500, wv/PW).

        Paraméterek (MMF):
            mmf_k:    skálázó az E2 sávhoz (alap: 0.75)
            mmf_sr1:  átlagos SR az 0.29–0.70 µm sávban (alap: 0.90)
            mmf_sr2:  átlagos SR a 0.70–1.10 µm sávban (alap: 0.60)
            mmf_f1_ref: referencia f1 AM1.5G-hez (alap: 0.58)
            mmf_clip: MMF levágási tartomány (alap: [0.8, 1.2])

        Deriváltak (véges különbség):
            eps_aod500: abszolút kis lépés az aod500-hoz (alap: 1e-3)
            eps_wv:     abszolút kis lépés a wv-hez [kg/m^2] (alap: 0.1 ≙ 0.01 cm PW)
        """
        self._validate_inputs(df)

        # --- Időkezelés: mindenhol tz-aware UTC ---
        timestamps = pd.to_datetime(df.index, format='mixed')
        if getattr(timestamps, "tz", None) is None:
            timestamps = timestamps.tz_localize("UTC")
        else:
            timestamps = timestamps.tz_convert("UTC")

        if getattr(df.index, "tz", None) is None:
            df.index = pd.to_datetime(df.index, format='mixed').tz_localize("UTC")
        else:
            df.index = pd.to_datetime(df.index, format='mixed').tz_convert("UTC")

        # === Alapeset ===
        result_df, interm = self.irradiance_rest2(
            timestamps, latitude, longitude, altitude, df,
            panel_tilt, panel_azimuth, albedo
        )

        out = df.copy()
        if not out.index.equals(result_df.index):
            warnings.warn("Index mismatch detected, aligning by nearest.")
            result_df = result_df.reindex(out.index, method='nearest')

        # --- MMF számítás ---
        E1 = interm.get('E1_ghi')
        E2 = interm.get('E2_ghi')
        if isinstance(E1, pd.Series):
            E1v = E1.reindex(result_df.index, method='nearest').values
        else:
            E1v = np.asarray(E1, dtype=float)
        if isinstance(E2, pd.Series):
            E2v = E2.reindex(result_df.index, method='nearest').values
        else:
            E2v = np.asarray(E2, dtype=float)

        denom = E1v + mmf_k * E2v
        denom = np.where(denom <= 0, np.nan, denom)
        f1 = np.divide(E1v, denom)

        num_now = f1 * mmf_sr1 + (1.0 - f1) * mmf_sr2
        den_ref = mmf_f1_ref * mmf_sr1 + (1.0 - mmf_f1_ref) * mmf_sr2
        with np.errstate(invalid='ignore', divide='ignore'):
            mmf = np.divide(num_now, den_ref)
        lo, hi = mmf_clip
        mmf = np.clip(mmf, lo, hi)
        mmf = np.nan_to_num(mmf, nan=1.0)

        # Kimenetek (alap)
        out['clear_sky_poa_irradiance'] = result_df['poa_global'].values
        out['clear_sky_ghi'] = result_df['ghi'].values
        out['poa_global_mmf'] = out['clear_sky_poa_irradiance'].values * mmf

        # Köztes paraméterek illesztése – tz-biztonsággal
        for k, v in interm.items():
            if isinstance(v, pd.Series):
                if hasattr(out.index, 'tz') and out.index.tz is not None:
                    if hasattr(v.index, 'tz') and v.index.tz is None:
                        v.index = v.index.tz_localize('UTC')
                out[k] = v.reindex(out.index, method='nearest').values
            else:
                arr = np.asarray(v)
                if arr.ndim == 1 and len(arr) == len(out.index):
                    out[k] = arr
                else:
                    out[k] = np.full(len(out.index), np.nan)

        # MMF és komponensek
        out['mmf'] = mmf
        out['f1'] = np.nan_to_num(f1, nan=mmf_f1_ref)
        out['f1_ref'] = np.full(len(out.index), mmf_f1_ref)
        out['k_mmf'] = np.full(len(out.index), mmf_k)

        # === SZENZITIVITÁSOK (véges különbség) ===
        # 1) aod500-irányú lépés – FIGYELEM: a modell nem használja aod500-at,
        #    így a deriváltak várhatóan 0-k lesznek. Ettől még általános a kód.
        if eps_aod500 and eps_aod500 > 0:
            df_aod = df.copy()
            df_aod['aod500'] = df_aod['aod500'] + float(eps_aod500)
            res_aod, inter_aod = self.irradiance_rest2(
                timestamps, latitude, longitude, altitude, df_aod,
                panel_tilt, panel_azimuth, albedo
            )
            res_aod = res_aod.reindex(out.index, method='nearest')
            E1_aod = inter_aod['E1_ghi'].reindex(out.index, method='nearest').values
            E2_aod = inter_aod['E2_ghi'].reindex(out.index, method='nearest').values

            out['dE1_daod500'] = (E1_aod - E1v) / eps_aod500
            out['dE2_daod500'] = (E2_aod - E2v) / eps_aod500
            out['dGHI_daod500'] = (res_aod['ghi'].values - out['clear_sky_ghi'].values) / eps_aod500
            out['dPOA_daod500'] = (res_aod['poa_global'].values - out['clear_sky_poa_irradiance'].values) / eps_aod500
        else:
            out['dE1_daod500'] = 0.0
            out['dE2_daod500'] = 0.0
            out['dGHI_daod500'] = 0.0
            out['dPOA_daod500'] = 0.0

        # 2) wv/PW-irányú lépés
        if eps_wv and eps_wv > 0:
            df_pw = df.copy()
            df_pw['wv'] = df_pw['wv'] + float(eps_wv)
            res_pw, inter_pw = self.irradiance_rest2(
                timestamps, latitude, longitude, altitude, df_pw,
                panel_tilt, panel_azimuth, albedo
            )
            res_pw = res_pw.reindex(out.index, method='nearest')
            E1_pw = inter_pw['E1_ghi'].reindex(out.index, method='nearest').values
            E2_pw = inter_pw['E2_ghi'].reindex(out.index, method='nearest').values

            out['dE1_dpw'] = (E1_pw - E1v) / eps_wv
            out['dE2_dpw'] = (E2_pw - E2v) / eps_wv
            out['dGHI_dpw'] = (res_pw['ghi'].values - out['clear_sky_ghi'].values) / eps_wv
            out['dPOA_dpw'] = (res_pw['poa_global'].values - out['clear_sky_poa_irradiance'].values) / eps_wv
        else:
            out['dE1_dpw'] = 0.0
            out['dE2_dpw'] = 0.0
            out['dGHI_dpw'] = 0.0
            out['dPOA_dpw'] = 0.0

        if out['clear_sky_poa_irradiance'].isnull().any():
            warnings.warn("NaN found in clear_sky_poa_irradiance.")

        return out

    # -------------------- Validáció --------------------

    def _validate_inputs(self, df: pd.DataFrame, *args, **kwargs):
        req = ['aod400', 'aod500', 'aod1064', 'pressure', 'wv', 'o3', 'ssa', 'asymmetry_factor_550']
        for c in req:
            if c not in df.columns:
                raise ValueError(f"Missing required column: {c}")
        for c in ['aod400', 'aod500', 'aod1064', 'pressure', 'wv', 'o3', 'ssa', 'asymmetry_factor_550']:
            vals = pd.to_numeric(df[c], errors='coerce').astype(float)
            if vals.isnull().any():
                warnings.warn(f"Null/invalid in {c}, interpolating.")
                vals = vals.interpolate(limit_direction='both')
            if c.startswith('aod'):
                vals = np.clip(vals, 1e-6, 5.0)
            df[c] = vals

    # -------------------- Angström segédek --------------------


    @classmethod
    def _angstrom_from_many(cls, taus: np.ndarray, lams_um: np.ndarray):
        """
        Több hullámhosszra illesztett Angström-paraméterek idősoronként.
        ln(tau) = ln(beta) - alpha * ln(lambda)
        - taus: alak (N, K)  vagy (K,)
        - lams_um: alak (K,)
        Vissza: alpha (N,), beta (N,)  vagy ha 1D a bemenet, akkor skálárok.
        """
        taus = np.asarray(taus, dtype=float)
        lams = np.asarray(lams_um, dtype=float)
        taus = np.clip(taus, 1e-12, None)          # védőklipp

        x = np.log(lams)                            # (K,)

        if taus.ndim == 1:
            # egyetlen sor (K,)
            y = np.log(taus)                        # (K,)
            xm = x.mean()
            ym = y.mean()
            denom = np.sum((x - xm) ** 2)
            m = np.sum((x - xm) * (y - ym)) / denom
            c = ym - m * xm
            alpha = -m
            beta = np.exp(c)
        else:
            # több sor: (N, K)
            y = np.log(taus)                        # (N, K)
            xm = x.mean()
            denom = np.sum((x - xm) ** 2)          # skálár
            ym = y.mean(axis=1, keepdims=True)     # (N, 1)
            # soronkénti meredekség
            m = np.sum((x - xm) * (y - ym), axis=1) / denom   # (N,)
            c = (ym[:, 0]) - m * xm                            # (N,)
            alpha = -m
            beta = np.exp(c)

        # REST2 tartomány-klipp
        alpha = np.clip(alpha, 0.0, 2.5)
        beta  = np.clip(beta, 0.001, 2.2)
        return alpha, beta

    @classmethod
    def _angstrom_from_two(cls, tau1, tau2, lam1_um, lam2_um):
        """
        Két hullámhosszból: α = ln(τ1/τ2)/ln(λ2/λ1), β = τ1 * λ1^α
        """
        tau1 = np.asarray(tau1, dtype=float)
        tau2 = np.asarray(tau2, dtype=float)
        eps = 1e-12
        tau1 = np.maximum(tau1, eps)
        tau2 = np.maximum(tau2, eps)
        alpha = np.log(tau1 / tau2) / np.log(float(lam2_um) / float(lam1_um))
        beta = tau1 * (float(lam1_um) ** alpha)
        alpha = np.clip(alpha, 0.0, 2.5)     # REST2 ajánlott tartomány
        beta = np.clip(beta, 0.001, 2.2)     # REST2 ajánlott tartomány
        return alpha, beta

    @classmethod
    def _tau_from_alpha_beta(cls, alpha, beta, lam_um):
        return beta * (float(lam_um) ** (-alpha))

    # -------------------- REST2 mag + POA --------------------

    @classmethod
    def irradiance_rest2(cls, timestamps: pd.DatetimeIndex, latitude: float, longitude: float, altitude: float,
                         df: pd.DataFrame, panel_tilt: float, panel_azimuth: float, albedo: float):
        """
        REST2 két-sávos broadband számítás GHI/DNI/DHI-ra,
        majd Hay-Davies transzpozíció POA-ra. Tartalmaz Tddclr/Tduclr/Ruuclr is.
        E1/E2 GHI sávok (E1_ghi, E2_ghi) is visszatérnek az MMF-hez és szenzitivitásokhoz.
        """
        # Naphelyzet
        solpos = pvlib.solarposition.get_solarposition(
            time=timestamps, latitude=latitude, longitude=longitude, altitude=altitude
        )
        apparent_zenith = solpos['apparent_zenith'].clip(upper=cls.SZA_LIM)

        # Relative airmass
        airmass_rel = pvlib.atmosphere.get_relative_airmass(
            apparent_zenith, model='gueymard2003'
        )

        # Angström paraméterek (CAMS AOD 400/1064 nm alapján)
        aod400 = np.asarray(df['aod400'].values, dtype=float)
        aod1064 = np.asarray(df['aod1064'].values, dtype=float)
        aod500 = np.asarray(df['aod500'].values, dtype=float)  # visszaadjuk interm-ben

        # EDDIG:
        # alpha, beta = cls._angstrom_from_two(aod400, aod1064, 0.4, 1.064)

        # ÚJ: 3 pontos illesztés (400, 500, 1064 nm)
        alpha, beta = cls._angstrom_from_many(
            np.stack([aod400, aod500, aod1064], axis=-1),
            np.array([0.4, 0.5, 1.064], dtype=float)
        )

        # Légköri bemenetek
        p_hpa  = np.asarray(df['pressure'].values, dtype=float)               # hPa
        ssa    = np.asarray(df['ssa'].values, dtype=float)
        g_asym = np.asarray(df['asymmetry_factor_550'].values, dtype=float)

        # Precipitable water: kg/m^2 -> cm
        w_cm = np.asarray(df['wv'].values, dtype=float) / 10.0
        w_cm = np.clip(w_cm, 0.01, 10.0)

        # O3: kg/m^2 -> atm*cm
        o3_atmcm = np.asarray(df['o3'].values, dtype=float) * 10.0 * 46.69
        o3_atmcm = np.clip(o3_atmcm, 0.02, 1.8)

        # Extraterresztriális DNI és radius faktor
        i0 = pvlib.irradiance.get_extra_radiation(timestamps).values  # W/m^2
        radius = np.sqrt(np.maximum(cls.SOLAR_CONSTANT / np.maximum(i0, 1e-6), 1e-6))

        # Vektoros REST2 (nappali pontokra)
        z = np.asarray(apparent_zenith.values, dtype=float)
        sun_up = (90.0 - z) > 0.5

        n = len(z)
        ghi = np.zeros(n, dtype=float)
        dni = np.zeros(n, dtype=float)
        dhi = np.zeros(n, dtype=float)
        Tdd = np.zeros(n, dtype=float)
        Tdu = np.zeros(n, dtype=float)
        Ruu = np.zeros(n, dtype=float)
        E1_ghi = np.zeros(n, dtype=float)
        E2_ghi = np.zeros(n, dtype=float)

        if np.any(sun_up):
            res = rest2(
                p=p_hpa[sun_up],
                albedo=np.full(np.sum(sun_up), float(albedo)),
                ssa=ssa[sun_up],
                g=g_asym[sun_up],
                z=z[sun_up],
                radius=radius[sun_up],
                alpha=alpha[sun_up],
                beta=beta[sun_up],
                ozone=o3_atmcm[sun_up],
                w=w_cm[sun_up],
                sza_lim=cls.SZA_LIM
            )
            ghi[sun_up] = res.ghi
            dni[sun_up] = res.dni
            dhi[sun_up] = res.dhi
            Tdd[sun_up] = res.Tddclr
            Tdu[sun_up] = res.Tduclr
            Ruu[sun_up] = res.Ruuclr
            E1_ghi[sun_up] = res.E1_ghi
            E2_ghi[sun_up] = res.E2_ghi

        # AOI + POA (Hay-Davies)
        aoi = pvlib.irradiance.aoi(
            panel_tilt, panel_azimuth, apparent_zenith, solpos['azimuth']
        )
        poa = get_total_irradiance(
            surface_tilt=panel_tilt,
            surface_azimuth=panel_azimuth,
            dni=pd.Series(dni, index=timestamps),
            ghi=pd.Series(ghi, index=timestamps),
            dhi=pd.Series(dhi, index=timestamps),
            solar_zenith=apparent_zenith,
            solar_azimuth=solpos['azimuth'],
            model='haydavies',
            albedo=albedo,
            dni_extra=pd.Series(i0, index=timestamps)
        )

        # <<< LÉNYEG: a visszatérő DF indexe legyen a bemeneti df.index >>>
        original_index = df.index
        out = pd.DataFrame({
            'poa_global': poa['poa_global'].values,
            'ghi': ghi
        }, index=original_index)

        # Köztes paraméterek – timestamps indexen (a calculate() reindexeli)
        interm: Dict[str, Any] = {
            'relative_airmass': pd.Series(airmass_rel.values, index=timestamps, name='relative_airmass'),
            'ang_alpha': alpha,
            'ang_beta': beta,
            'aod500': aod500,
            'apparent_zenith': pd.Series(apparent_zenith.values, index=timestamps, name='apparent_zenith'),
            'aoi': pd.Series(aoi, index=timestamps, name='aoi'),
            'dni': dni,
            'dhi': dhi,
            'Tddclr': Tdd,
            'Tduclr': Tdu,
            'Ruuclr': Ruu,
            'E1_ghi': pd.Series(E1_ghi, index=timestamps, name='E1_ghi'),
            'E2_ghi': pd.Series(E2_ghi, index=timestamps, name='E2_ghi')
        }

        return out, interm

    # -------------------- Extra segédek (változatlan interfész) --------------------

    @classmethod
    def calc_solar_position(cls, timestamps):
        latitude, longitude = 47.523618, 19.012776
        altitude = 240
        return pvlib.solarposition.get_solarposition(
            time=timestamps, latitude=latitude, longitude=longitude, altitude=altitude
        )

    @classmethod
    def calc_extraterrestrial_radiation(cls, timestamps):
        return pvlib.irradiance.get_extra_radiation(timestamps)

    @classmethod
    def calc_poa_irradiance(cls, solar_position, dni, ghi, dhi,
                            panel_tilt, panel_azimuth, extra_radiation, albedo, models):
        poa_irradiances = {}
        for model in models:
            poa_irradiance = get_total_irradiance(
                surface_tilt=panel_tilt,
                surface_azimuth=panel_azimuth,
                dni=dni,
                ghi=ghi,
                dhi=dhi,
                solar_zenith=solar_position['apparent_zenith'],
                solar_azimuth=solar_position['azimuth'],
                model=model,
                albedo=albedo,
                dni_extra=extra_radiation
            )
            poa_irradiances[model] = poa_irradiance
        return poa_irradiances

