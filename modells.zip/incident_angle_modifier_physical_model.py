import pandas as pd
import pvlib
from typing import List

from modmod.models.model_protocol import BaseCalculationModel


class IncidentAngleModifierPhysicalModel(BaseCalculationModel):
    """
    Physical IAM model: Calculate Incident Angle Modifier using physical optics.
    Uses glazing thickness and other physical parameters.
    """
    
    def __init__(self, name: str = "IncidentAngleModifierPhysicalModel"):
        super().__init__(name)
    
    def get_required_inputs(self) -> List[str]:
        """Return list of required input column names."""
        return ['aoi', 'irradiance_without_iam']
    
    def get_outputs(self) -> List[str]:
        """Return list of output column names."""
        return ['iam', 'irradiance_with_iam']
    
    def calculate(self, df: pd.DataFrame, glazing_thickness_L: float, **kwargs) -> pd.DataFrame:
        """Calculate physical IAM.
        
        Args:
            df: Input dataframe with aoi and irradiance_without_iam columns
            glazing_thickness_L: Glazing thickness in meters
            **kwargs: Additional parameters
            
        Returns:
            DataFrame with iam and irradiance_with_iam columns
        """
        result = df.copy()
        
        # Calculate IAM using pvlib physical model
        iam_values = pvlib.iam.physical(df['aoi'], L=glazing_thickness_L)
        
        # Apply IAM to irradiance
        irradiance_with_iam = df['irradiance_without_iam'] * iam_values
        
        result['iam'] = iam_values
        result['irradiance_with_iam'] = irradiance_with_iam
        
        return result
