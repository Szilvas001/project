import pandas as pd
import pvlib
from typing import List

from modmod.models.model_protocol import BaseCalculationModel


class CellTempModel(BaseCalculationModel):
    """
    Calculates the cell temperature of a PV system based on module temperature, irradiance, and module specifications.
    """
    
    def __init__(self, name: str = "CellTempModel"):
        super().__init__(name)
    
    def get_required_inputs(self) -> List[str]:
        """Return list of required input column names."""
        return ['poa_irrad', 'module_temp']
    
    def get_outputs(self) -> List[str]:
        """Return list of output column names."""
        return ['cell_temp']
    
    def calculate(self, df: pd.DataFrame, mounting_key: str, **kwargs) -> pd.DataFrame:
        """Calculate cell temperature using Sandia model.
        
        Args:
            df: Input dataframe with ha_module_temp and ha_poa_irrad columns
            mounting_key: Sandia mounting key parameter
            **kwargs: Additional parameters
            
        Returns:
            DataFrame with cell_temp column
        """
        result = df.copy()
        
        module_temp = df["module_temp"].astype(float).values
        poa_irrad = df["poa_irrad"].astype(float).values
        
        cell_temp = self._calculate_cell_temp_sandia(module_temp, poa_irrad, mounting_key)
        
        result["cell_temp"] = cell_temp
        
        return result
    
    @staticmethod
    def _calculate_cell_temp_sandia(module_temp, poa_global, sandia_module_mounting_key):
        """Calculate cell temperature using Sandia model."""
        temp_model_params_sandia = pvlib.temperature.TEMPERATURE_MODEL_PARAMETERS["sapm"]
        if sandia_module_mounting_key in temp_model_params_sandia.keys():
            delta_t = temp_model_params_sandia[sandia_module_mounting_key]["deltaT"]
            return pvlib.temperature.sapm_cell_from_module(module_temp, poa_global, delta_t)
        else:
            raise KeyError(f"Key '{sandia_module_mounting_key}' is not present in {temp_model_params_sandia}!")
