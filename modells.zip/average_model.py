import pandas as pd
from typing import List

from modmod.models.model_protocol import BaseCalculationModel


class AverageModel(BaseCalculationModel):
    """
    Calculate the average of two input columns.
    """
    
    def __init__(self, name: str = "AverageModel"):
        super().__init__(name)
    
    def get_required_inputs(self) -> List[str]:
        """Return list of required input column names."""
        return ['avg_a_value', 'avg_b_value']
    
    def get_outputs(self) -> List[str]:
        """Return list of output column names."""
        return ['average_output']
    
    def calculate(self, df: pd.DataFrame, **kwargs) -> pd.DataFrame:
        """Calculate average of two columns.
        
        Args:
            df: Input dataframe with avg_a_value and avg_b_value columns
            **kwargs: Additional parameters
            
        Returns:
            DataFrame with average_output column
        """
        result = df.copy()
        
        # Calculate average of the two values
        result['average_output'] = df[['avg_a_value', 'avg_b_value']].mean(axis=1)
        
        return result
