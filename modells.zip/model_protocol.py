"""Protocol definition for standardized model interface."""
from typing import Protocol, Dict, Any, Optional, List
import pandas as pd
from abc import ABC, abstractmethod


class ModelProtocol(Protocol):
    """Protocol that all models must implement."""
    
    name: str
    
    def validate_inputs(self, df: pd.DataFrame, parameters: Dict[str, Any]) -> None:
        """Validate that required inputs are present and valid.
        
        Args:
            df: Input dataframe
            parameters: Model parameters
            
        Raises:
            ValueError: If validation fails
        """
        ...
    
    def calculate(self, df: pd.DataFrame, parameters: Dict[str, Any]) -> pd.DataFrame:
        """Perform the model calculation.
        
        Args:
            df: Input dataframe
            parameters: Model parameters
            
        Returns:
            DataFrame with calculation results
        """
        ...
    
    def get_required_inputs(self) -> List[str]:
        """Get list of required input column names."""
        ...
    
    def get_outputs(self) -> List[str]:
        """Get list of output column names produced by this model."""
        ...


class BaseCalculationModel(ABC):
    """Abstract base class for calculation models with framework-handled validation."""
    
    def __init__(self, name: str):
        self.name = name
    
    @abstractmethod
    def calculate(self, df: pd.DataFrame, **parameters) -> pd.DataFrame:
        """Perform calculation - the only method models need to implement.
        
        Args:
            df: Input dataframe with required columns
            **parameters: All parameters passed as keyword arguments
            
        Returns:
            DataFrame with calculation results
        """
        pass
    
    @classmethod
    def get_required_inputs(cls) -> List[str]:
        """Get required inputs - can be overridden by subclasses."""
        return []
    
    @classmethod
    def get_outputs(cls) -> List[str]:
        """Get outputs - can be overridden by subclasses."""
        return []
    
    def execute(self, df: pd.DataFrame, parameters: Optional[Dict[str, Any]] = None) -> pd.DataFrame:
        """Execute the model with framework-handled validation.
        
        Args:
            df: Input dataframe
            parameters: Model parameters
            
        Returns:
            DataFrame with results
        """
        parameters = parameters or {}
        
        # Framework handles validation
        self._validate_inputs(df, parameters)
        
        # Prepare dataframe (ensure timestamp index, etc.)
        prepared_df = self._prepare_dataframe(df)
        
        # Call the model's calculate method with parameters as kwargs
        result = self.calculate(prepared_df, **parameters)
        
        # Framework validates outputs
        self._validate_outputs(result)
        
        return result
    
    def _validate_inputs(self, df: pd.DataFrame, parameters: Dict[str, Any]) -> None:
        """Framework-handled input validation."""
        # Check required columns
        required_cols = self.get_required_inputs()
        missing_cols = [col for col in required_cols if col not in df.columns]
        if missing_cols:
            raise ValueError(f"Model {self.name} missing required columns: {missing_cols}")
        
        # Check for empty dataframe
        if df.empty and required_cols:
            raise ValueError(f"Model {self.name} received empty dataframe")
    
    def _prepare_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """Framework-handled dataframe preparation."""
        result = df.copy()
        
        # Ensure timestamp is index if present
        if 'timestamp' in result.columns:
            result = result.set_index('timestamp')
        
        # Ensure index is datetime if it looks like timestamps
        if not pd.api.types.is_datetime64_any_dtype(result.index):
            try:
                result.index = pd.to_datetime(result.index)
            except:
                pass  # Not a timestamp index, that's okay
        
        return result
    
    def _validate_outputs(self, result: pd.DataFrame) -> None:
        """Framework-handled output validation."""
        expected_outputs = self.get_outputs()
        if expected_outputs:
            missing_outputs = set(expected_outputs) - set(result.columns)
            if missing_outputs:
                raise ValueError(f"Model {self.name} did not produce expected outputs: {missing_outputs}")