#!/bin/bash
set -euo pipefail

echo "=== CAMS Engine Deployment ==="

# 1. Create GitLab SSH key secret (for cloning private repo)
if ! oc get secret gitlab-ssh-key &>/dev/null; then
    echo "Creating GitLab SSH key secret..."
    echo "You need a deploy key or SSH key with read access to the repo."
    echo "  oc create secret generic gitlab-ssh-key \\"
    echo "    --from-file=ssh-privatekey=~/.ssh/id_ed25519 \\"
    echo "    --type=kubernetes.io/ssh-auth"
    echo ""
    read -p "Press Enter after creating the secret, or Ctrl+C to abort..."
fi

# 2. Create webhook secret
if ! oc get secret cams-engine-webhook-secret &>/dev/null; then
    echo "Creating webhook secret..."
    oc create secret generic cams-engine-webhook-secret \
        --from-literal=WebHookSecretKey="$(openssl rand -hex 20)"
fi

# 3. Create ecmwf datastores config secret
if ! oc get secret ecmwfdatastoresrc-secret &>/dev/null; then
    echo "Creating ecmwfdatastoresrc secret..."
    oc create secret generic ecmwfdatastoresrc-secret \
        --from-file=.ecmwfdatastoresrc=../.ecmwfdatastoresrc
fi

# 4. Apply build config + image stream
echo "Applying build configuration..."
oc apply -f deployment/buildconfig.yaml

# 5. Start initial build
echo "Starting build..."
oc start-build cams-engine --follow

# 6. Apply cronjob
echo "Applying CronJob..."
oc apply -f deployment/cronjob.yaml

# 7. Print webhook URL for GitLab setup
echo ""
echo "=== Deployment complete ==="
echo ""
echo "NEXT STEP: Configure GitLab webhook"
echo "  1. Go to: https://gitlab.ulx.hu/ulx-em/cams-data-pull/-/hooks"
echo "  2. Get the webhook URL:"
WEBHOOK_URL=$(oc describe bc cams-engine | grep -A1 "GitLab" | grep URL | awk '{print $NF}' 2>/dev/null || echo "<run 'oc describe bc cams-engine' to find it>")
echo "     URL: ${WEBHOOK_URL}"
WEBHOOK_SECRET=$(oc get secret cams-engine-webhook-secret -o jsonpath='{.data.WebHookSecretKey}' 2>/dev/null | base64 -d || echo "<check secret>")
echo "     Secret Token: ${WEBHOOK_SECRET}"
echo "  3. Check 'Push events' trigger"
echo "  4. Uncheck 'Enable SSL verification' if using self-signed certs"
echo ""
echo "After this, every git push will automatically rebuild and deploy."
echo "CronJob schedule: $(oc get cronjob cams-engine -o jsonpath='{.spec.schedule}' 2>/dev/null || echo '15 10,22 * * *')"
