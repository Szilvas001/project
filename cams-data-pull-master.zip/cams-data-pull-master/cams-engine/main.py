#!/usr/bin/env python3
"""CAMS Engine — config-driven forecast pull with automatic backfill."""

import logging
import os
import smtplib
import tempfile
import traceback
from datetime import datetime, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import yaml
from dotenv import load_dotenv

from engine import backfill, db, grib_processor
from engine.client import get_client

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

def load_config(path="config.yaml"):
    with open(path) as f:
        return yaml.safe_load(f)


def parse_range(spec):
    """Parse '0-36' into ['0','1',...,'36'] or '0,3,6' into ['0','3','6']."""
    if "-" in spec and "," not in spec:
        start, end = spec.split("-")
        return [str(i) for i in range(int(start), int(end) + 1)]
    return [s.strip() for s in spec.split(",")]


def determine_forecast(schedule):
    """Pick the most recent forecast (date, time) based on the UTC clock.

    Returns (forecast_date_str, forecast_time_str).
    """
    now = datetime.utcnow()
    current_hour = now.hour

    # Try schedule entries from latest to earliest availability
    for time_str, avail_hour in sorted(schedule.items(), key=lambda x: x[1], reverse=True):
        if current_hour >= avail_hour:
            return now.strftime("%Y-%m-%d"), time_str

    # Before any availability today → yesterday's latest forecast
    latest_time = max(schedule, key=schedule.get)
    return (now - timedelta(days=1)).strftime("%Y-%m-%d"), latest_time


# ---------------------------------------------------------------------------
# Request building
# ---------------------------------------------------------------------------

def build_request(dataset_config, config, forecast_date, forecast_time):
    """Build a CAMS API request dict from config."""
    target = config["target"]
    lat = target["lat"]
    lon = target["lon"]
    margin = target["area_margin"]

    request = {
        "variable": dataset_config["variables"],
        "date": [f"{forecast_date}/{forecast_date}"],
        "time": [forecast_time],
        "leadtime_hour": parse_range(dataset_config["leadtime_hours"]),
        "type": ["forecast"],
        "data_format": "grib",
        "area": [lat + margin, lon - margin, lat - margin, lon + margin],
    }

    if "model_levels" in dataset_config:
        request["model_level"] = parse_range(dataset_config["model_levels"])

    return request


# ---------------------------------------------------------------------------
# Core pipeline: fetch → parse → insert
# ---------------------------------------------------------------------------

def fetch_and_insert(client, dataset_config, config, forecast_date, forecast_time):
    """Download one forecast, parse the GRIB, and insert into the DB.

    Returns a log message string.
    """
    name = dataset_config["name"]
    table = dataset_config["target_table"]
    pk = dataset_config["primary_key"]

    request = build_request(dataset_config, config, forecast_date, forecast_time)
    log.info("[%s] Fetching %s %s ...", name, forecast_date, forecast_time)

    # Download
    tmp = tempfile.NamedTemporaryFile(suffix=".grib", delete=False)
    tmp.close()
    try:
        remote = client.submit(dataset_config["dataset"], request)
        remote.download(tmp.name)
        log.info("[%s] Downloaded GRIB to %s", name, tmp.name)

        # Parse
        target = config["target"]
        df_long = grib_processor.parse_grib_file(
            tmp.name, target["lat"], target["lon"],
        )
        df_wide = grib_processor.pivot_and_clean(df_long, dataset_config)

        # Insert
        conn = db.get_connection()
        cur = conn.cursor()
        try:
            db.ensure_table(cur, table, df_wide, pk)
            db.ensure_columns(cur, table, df_wide)
            conn.commit()

            inserted = db.insert_data(cur, table, df_wide, pk)
            conn.commit()
        finally:
            cur.close()
            conn.close()

        msg = f"[{name}] {forecast_date} {forecast_time}: {inserted} rows inserted"
        log.info(msg)
        return msg

    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Phases
# ---------------------------------------------------------------------------

def phase_live_pull(config, client, forecast_date, forecast_time):
    """Phase 1: pull today's forecast for every dataset."""
    results = []
    for ds in config["datasets"]:
        try:
            msg = fetch_and_insert(client, ds, config, forecast_date, forecast_time)
            results.append(msg)
        except Exception as e:
            err = f"[{ds['name']}] LIVE PULL FAILED: {e}"
            log.error(err)
            log.debug(traceback.format_exc())
            results.append(err)
    return results


def phase_backfill(config, client):
    """Phase 2: detect and fill gaps for every dataset with backfill config."""
    results = []
    for ds in config["datasets"]:
        if "backfill" not in ds:
            continue

        try:
            conn = db.get_connection()
            cur = conn.cursor()
            if not db._table_exists(cur, ds["target_table"]):
                cur.close()
                conn.close()
                results.append(f"[{ds['name']}] BACKFILL: table does not exist yet, skipping")
                continue
            missing = backfill.find_missing_forecasts(cur, ds, config["schedule"])
            cur.close()
            conn.close()
        except Exception as e:
            results.append(f"[{ds['name']}] BACKFILL GAP DETECTION FAILED: {e}")
            log.error(results[-1])
            continue

        if not missing:
            results.append(f"[{ds['name']}] BACKFILL: 0 gaps")
            continue

        for d, h in missing:
            date_str = d.strftime("%Y-%m-%d") if hasattr(d, "strftime") else str(d)
            time_str = f"{h:02d}:00"
            try:
                msg = fetch_and_insert(client, ds, config, date_str, time_str)
                results.append(f"[BACKFILL] {msg}")
            except Exception as e:
                err = f"[BACKFILL] [{ds['name']}] {date_str} {time_str} FAILED: {e}"
                log.error(err)
                results.append(err)

    return results


def phase_views(config):
    """Phase 3: create or update consumption views."""
    results = []
    views = config.get("views", [])
    if not views:
        return results

    try:
        conn = db.get_connection()
        cur = conn.cursor()
        db.ensure_views(cur, views, config["schedule"])
        conn.commit()
        cur.close()
        conn.close()
        results.append(f"Views updated: {', '.join(v['name'] for v in views)}")
    except Exception as e:
        err = f"VIEW UPDATE FAILED: {e}"
        log.error(err)
        results.append(err)

    return results


# ---------------------------------------------------------------------------
# Email
# ---------------------------------------------------------------------------

def send_summary_email(config, results):
    """Send an HTML summary email."""
    smtp_server = os.getenv("SMTP_SERVER")
    smtp_port = int(os.getenv("SMTP_PORT", "25"))
    smtp_user = os.getenv("SMTP_USER")
    smtp_password = os.getenv("SMTP_PASSWORD")
    recipient = config["email"]["recipient"]

    if not all([smtp_server, smtp_user, smtp_password]):
        log.warning("SMTP not configured, skipping email.")
        return

    now = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
    log_text = "\n".join(results)

    body = f"""\
<html><body>
<p>CAMS Engine run at {now}</p>
<pre>{log_text}</pre>
<p>Best regards,<br>CAMS Engine</p>
</body></html>"""

    msg = MIMEMultipart("alternative")
    msg["From"] = smtp_user
    msg["To"] = recipient
    msg["Subject"] = f"CAMS Engine — {now}"
    msg.attach(MIMEText(body, "html"))

    try:
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(smtp_user, smtp_password)
            server.send_message(msg)
        log.info("Summary email sent to %s", recipient)
    except Exception as e:
        log.error("Failed to send email: %s", e)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    config = load_config()
    forecast_date, forecast_time = determine_forecast(config["schedule"])
    log.info("Forecast target: %s %s", forecast_date, forecast_time)

    client = get_client()
    log.info("ECMWF datastores client initialized.")

    results = []

    # Phase 1: live pull
    results.extend(phase_live_pull(config, client, forecast_date, forecast_time))

    # Phase 2: backfill
    results.extend(phase_backfill(config, client))

    # Phase 3: views
    results.extend(phase_views(config))

    # Phase 4: email
    send_summary_email(config, results)

    log.info("Done. %d result lines.", len(results))
    for r in results:
        log.info("  %s", r)


if __name__ == "__main__":
    main()
