import logging
from datetime import date, timedelta

log = logging.getLogger(__name__)


def find_missing_forecasts(cur, dataset_config, schedule):
    """Detect gaps and return missing (date, hour) pairs to backfill.

    Compares the expected set of (date, reference_hour) pairs — every day
    from ``start_date`` to yesterday, for each forecast time in the
    schedule — against what already exists in the target table.

    Returns at most ``max_per_run`` gaps, oldest first.
    """
    table = dataset_config["target_table"]
    backfill = dataset_config["backfill"]
    start = date.fromisoformat(backfill["start_date"])
    max_per_run = backfill.get("max_per_run", 4)
    yesterday = date.today() - timedelta(days=1)

    # Get existing (date, hour) pairs from DB
    cur.execute(
        f'SELECT DISTINCT reference_time::date AS d, '
        f'       EXTRACT(HOUR FROM reference_time)::int AS h '
        f'FROM "{table}" '
        f'WHERE reference_time >= %s',
        (start,),
    )
    existing = {(row[0], row[1]) for row in cur.fetchall()}

    # Build expected set
    expected = set()
    d = start
    while d <= yesterday:
        for time_str in schedule:
            hour = int(time_str.split(":")[0])
            expected.add((d, hour))
        d += timedelta(days=1)

    missing = sorted(expected - existing)

    log.info(
        "[%s] Backfill: %d expected, %d exist, %d missing, processing up to %d.",
        dataset_config["name"],
        len(expected),
        len(existing),
        len(missing),
        max_per_run,
    )

    return missing[:max_per_run]
