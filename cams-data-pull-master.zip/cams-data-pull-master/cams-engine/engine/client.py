import os
import shutil
import logging

from ecmwf.datastores import Client

log = logging.getLogger(__name__)


def get_client():
    """Initialize the ECMWF datastores client.

    Looks for .ecmwfdatastoresrc in standard locations and copies it to
    the home directory if needed (the client expects ~/.ecmwfdatastoresrc).
    """
    config_locations = [
        "/.ecmwfdatastoresrc",                              # K8s mount
        os.path.join(os.getcwd(), ".ecmwfdatastoresrc"),    # project dir
        os.path.expanduser("~/.ecmwfdatastoresrc"),         # home dir
    ]

    home_config = os.path.expanduser("~/.ecmwfdatastoresrc")

    for path in config_locations:
        if os.path.exists(path):
            if path != home_config:
                shutil.copy2(path, home_config)
                log.info("Copied %s to %s", path, home_config)
            else:
                log.info("Using config from %s", path)
            break
    else:
        log.warning(".ecmwfdatastoresrc not found in standard locations")

    return Client()
