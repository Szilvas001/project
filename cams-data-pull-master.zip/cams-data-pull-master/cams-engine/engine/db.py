import logging
import os

import psycopg2
from psycopg2.extras import execute_values

log = logging.getLogger(__name__)


def get_connection():
    """Create a PostgreSQL connection from environment variables."""
    return psycopg2.connect(
        host=os.getenv("DB_HOST"),
        port=os.getenv("DB_PORT", "5432"),
        dbname=os.getenv("DB_NAME"),
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASSWORD"),
    )


def _col_type(col, df):
    """Determine the PostgreSQL column type for a DataFrame column."""
    if col in ("reference_time", "valid_time"):
        return "TIMESTAMP NOT NULL"
    if col == "forecast_hours":
        return "BIGINT NOT NULL"
    # Detect array columns (cells contain lists)
    first_val = df[col].dropna().iloc[0] if not df[col].dropna().empty else None
    if isinstance(first_val, (list, tuple)):
        return "DOUBLE PRECISION[]"
    return "DOUBLE PRECISION"


def ensure_table(cur, table, df, pk):
    """CREATE TABLE IF NOT EXISTS based on the DataFrame schema."""
    col_defs = []
    for col in df.columns:
        col_defs.append(f'"{col}" {_col_type(col, df)}')

    pk_str = ", ".join(f'"{c}"' for c in pk)
    sql = (
        f'CREATE TABLE IF NOT EXISTS "{table}" (\n'
        f'    {", ".join(col_defs)},\n'
        f"    PRIMARY KEY ({pk_str})\n"
        f");"
    )
    cur.execute(sql)
    log.info("Table '%s' ensured.", table)


def ensure_columns(cur, table, df):
    """Add any DataFrame columns that are missing from the table."""
    cur.execute(
        "SELECT column_name FROM information_schema.columns WHERE table_name = %s",
        (table,),
    )
    existing = {row[0] for row in cur.fetchall()}

    for col in df.columns:
        if col not in existing:
            pg_type = _col_type(col, df)
            log.info("Adding column '%s' (%s) to '%s'.", col, pg_type, table)
            cur.execute(
                f'ALTER TABLE "{table}" ADD COLUMN "{col}" {pg_type};'
            )


def insert_data(cur, table, df, pk):
    """Bulk-insert rows with ON CONFLICT DO NOTHING.

    Returns the number of rows inserted.
    """
    cols = list(df.columns)
    cols_str = ", ".join(f'"{c}"' for c in cols)
    pk_str = ", ".join(f'"{c}"' for c in pk)

    sql = (
        f'INSERT INTO "{table}" ({cols_str}) '
        f"VALUES %s "
        f"ON CONFLICT ({pk_str}) DO NOTHING"
    )

    data = [tuple(row) for row in df.itertuples(index=False, name=None)]
    # psycopg2 needs list values as-is (it auto-adapts Python lists to PG arrays)
    execute_values(cur, sql, data, page_size=1000)

    inserted = cur.rowcount
    skipped = len(data) - inserted
    log.info(
        "Insert into '%s': %d inserted, %d skipped (already exist).",
        table, inserted, skipped,
    )
    return inserted


def _table_exists(cur, table):
    """Check whether a table exists in the current schema."""
    cur.execute(
        "SELECT EXISTS ("
        "  SELECT 1 FROM information_schema.tables WHERE table_name = %s"
        ")",
        (table,),
    )
    return cur.fetchone()[0]


def ensure_views(cur, views_config, schedule):
    """Create or replace best-forecast views defined in config.

    Each view computes valid_time from (reference_time + forecast_hours),
    determines when the forecast became available using the schedule, and
    picks one forecast per valid_time according to the view's strategy:

    - "latest_causal" (default): only forecasts available before valid_time,
      prefer the most recently issued one.  Good for surface data with long
      lead times (e.g. 0-36 h) where the forecast arrives well before the
      valid time it describes.

    - "earliest": no causal filter; prefer the earliest-available forecast
      per valid_time.  Use this when lead times are short (e.g. 0-12 h) so
      most valid times have already passed by the time the forecast is
      published.  A newer run will never silently replace data that was
      already the best known at inference time.
    """
    for view in views_config:
        name = view["name"]
        source = view["source_table"]
        strategy = view.get("strategy", "latest_causal")

        if not _table_exists(cur, source):
            log.warning(
                "Skipping view '%s': source table '%s' does not exist yet.",
                name, source,
            )
            continue

        # Fetch parameter columns (everything except reference_time, forecast_hours)
        cur.execute(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_name = %s ORDER BY ordinal_position",
            (source,),
        )
        all_cols = [row[0] for row in cur.fetchall()]
        param_cols = [c for c in all_cols if c not in ("reference_time", "forecast_hours")]

        if not param_cols:
            log.warning("Skipping view '%s': no parameter columns found.", name)
            continue

        # Build CASE expression for available_at
        cases = []
        for time_str, avail_hour in schedule.items():
            hour = int(time_str.split(":")[0])
            offset = avail_hour - hour
            cases.append(
                f"WHEN EXTRACT(HOUR FROM reference_time) = {hour} "
                f"THEN reference_time + interval '{offset} hours'"
            )
        case_sql = "CASE " + " ".join(cases) + " END"

        param_sql = ", ".join(f'"{c}"' for c in param_cols)

        if strategy == "earliest":
            order_sql = "ORDER BY available_at ASC"
            where_sql = ""
        else:
            order_sql = "ORDER BY available_at DESC"
            where_sql = "WHERE available_at <= valid_time"

        view_sql = f"""
        CREATE OR REPLACE VIEW "{name}" AS
        WITH all_forecasts AS (
            SELECT
                reference_time + (forecast_hours * interval '1 hour') AS valid_time,
                {case_sql} AS available_at,
                {param_sql}
            FROM "{source}"
        ),
        valid_forecasts AS (
            SELECT *,
                ROW_NUMBER() OVER (
                    PARTITION BY valid_time
                    {order_sql}
                ) AS rn
            FROM all_forecasts
            {where_sql}
        )
        SELECT valid_time, {param_sql}
        FROM valid_forecasts
        WHERE rn = 1;
        """

        cur.execute(view_sql)
        log.info("View '%s' created/updated on '%s' (strategy: %s).", name, source, strategy)
