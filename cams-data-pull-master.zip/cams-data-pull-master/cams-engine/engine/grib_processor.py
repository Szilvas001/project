import logging

import numpy as np
import pandas as pd
import pygrib

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Interpolation
# ---------------------------------------------------------------------------

def bilinear_interpolate(lats_2d, lons_2d, values_2d, target_lat, target_lon):
    """Bilinear interpolation on a 2D grid to a single target point.

    Handles descending latitude order (common in GRIB) and numpy masked arrays.
    """
    lats_1d = np.sort(np.unique(lats_2d))
    lons_1d = np.sort(np.unique(lons_2d))

    j = np.searchsorted(lats_1d, target_lat) - 1
    i = np.searchsorted(lons_1d, target_lon) - 1

    j = max(0, min(j, len(lats_1d) - 2))
    i = max(0, min(i, len(lons_1d) - 2))

    lat0, lat1 = lats_1d[j], lats_1d[j + 1]
    lon0, lon1 = lons_1d[i], lons_1d[i + 1]

    vals = (
        np.ma.filled(values_2d, fill_value=np.nan)
        if isinstance(values_2d, np.ma.MaskedArray)
        else values_2d
    )
    flat_lats = lats_2d.ravel()
    flat_lons = lons_2d.ravel()
    flat_vals = vals.ravel()

    def grid_val(lat, lon):
        idx = np.argmin((flat_lats - lat) ** 2 + (flat_lons - lon) ** 2)
        return flat_vals[idx]

    q11 = grid_val(lat0, lon0)
    q21 = grid_val(lat0, lon1)
    q12 = grid_val(lat1, lon0)
    q22 = grid_val(lat1, lon1)

    dlat = lat1 - lat0
    dlon = lon1 - lon0
    if dlat == 0 or dlon == 0:
        return float(grid_val(target_lat, target_lon))

    t = (target_lat - lat0) / dlat
    u = (target_lon - lon0) / dlon

    value = (
        q11 * (1 - t) * (1 - u)
        + q21 * (1 - t) * u
        + q12 * t * (1 - u)
        + q22 * t * u
    )
    return float(value)


# ---------------------------------------------------------------------------
# Parameter name cleaning
# ---------------------------------------------------------------------------

def clean_parameter_name(name):
    """Lowercase, replace spaces/hyphens with underscores, collapse duplicates."""
    cleaned = str(name).lower().replace(" ", "_").replace("-", "_")
    while "__" in cleaned:
        cleaned = cleaned.replace("__", "_")
    return cleaned.strip("_")


# ---------------------------------------------------------------------------
# GRIB parsing
# ---------------------------------------------------------------------------

def _extract_parameter_name(grb):
    """Extract a meaningful parameter name from a GRIB message."""
    parts = str(grb).split(":")
    parameter_raw = parts[1].strip() if len(parts) > 1 else None

    if not parameter_raw or parameter_raw.isdigit():
        for attr in ("cfVarName", "shortName", "name", "parameterName"):
            val = getattr(grb, attr, None)
            if val is not None and str(val).strip() and str(val) != "unknown":
                parameter_raw = str(val).strip()
                break

    if parameter_raw is None:
        parameter_raw = str(grb.parameterName)

    return clean_parameter_name(parameter_raw)


def _extract_forecast_hours(grb):
    """Extract forecast lead time in hours from a GRIB message."""
    parts = str(grb).split(":")
    try:
        return int(parts[6].split()[2])
    except Exception:
        pass
    try:
        return int(grb.forecastTime)
    except Exception:
        pass
    return int(str(grb.stepRange).split("-")[-1])


def _extract_value(grb, target_lat, target_lon):
    """Extract a scalar value, interpolating if the grid has multiple points."""
    raw_values = grb.values

    if hasattr(raw_values, "shape") and raw_values.size > 1:
        lats, lons = grb.latlons()
        return bilinear_interpolate(lats, lons, raw_values, target_lat, target_lon)

    if hasattr(raw_values, "ravel"):
        arr = (
            np.ma.filled(raw_values, fill_value=np.nan)
            if isinstance(raw_values, np.ma.MaskedArray)
            else raw_values
        )
        return float(arr.ravel()[0])

    return float(raw_values)


def parse_grib_file(path, target_lat, target_lon):
    """Parse a GRIB file into a long-format DataFrame.

    Each row contains: reference_time, forecast_hours, parameter, level, value.
    """
    records = []
    grbs = pygrib.open(path)

    for grb in grbs:
        try:
            reference_time = pd.Timestamp(
                year=grb.year, month=grb.month, day=grb.day,
                hour=grb.hour, minute=grb.minute, second=grb.second,
            )
            records.append({
                "reference_time": reference_time,
                "forecast_hours": _extract_forecast_hours(grb),
                "parameter": _extract_parameter_name(grb),
                "level": int(getattr(grb, "level", 0)),
                "value": _extract_value(grb, target_lat, target_lon),
            })
        except Exception as e:
            log.warning("Could not parse message in %s: %s", path, e)

    grbs.close()

    if not records:
        raise ValueError(f"No GRIB messages parsed from {path}")

    df = pd.DataFrame(records)
    log.info("Parsed %d messages from %s", len(df), path)
    return df


# ---------------------------------------------------------------------------
# Pivot to wide format
# ---------------------------------------------------------------------------

def pivot_and_clean(df, dataset_config):
    """Pivot a long-format DataFrame to wide format.

    For model-level data (model_levels in config), each parameter becomes a
    single column containing a Python list of values ordered by level
    (1..max_level).  For surface data, columns are just the parameter name.

    Unit adjustments from config are applied before pivoting.
    """
    # Apply unit adjustments
    for param, adjustment in dataset_config.get("unit_adjustments", {}).items():
        mask = df["parameter"] == param
        if mask.any() and adjustment == "divide_by_10":
            df.loc[mask, "value"] /= 10
            log.info("Applied unit adjustment for %s: %s", param, adjustment)

    has_levels = "model_levels" in dataset_config

    if has_levels:
        # Group values into arrays ordered by level
        log.info(
            "Multi-level data: %d levels, packing into arrays.",
            df["level"].nunique(),
        )

        def _pack_array(group):
            return list(group.sort_values("level")["value"].values)

        grouped = (
            df.groupby(["reference_time", "forecast_hours", "parameter"])
            .apply(_pack_array, include_groups=False)
            .reset_index(name="values_array")
        )

        pivoted = grouped.pivot_table(
            index=["reference_time", "forecast_hours"],
            columns="parameter",
            values="values_array",
            aggfunc="first",
        )
        pivoted.reset_index(inplace=True)
        pivoted.columns.name = None
    else:
        df["param_col"] = df["parameter"]
        pivoted = df.pivot_table(
            index=["reference_time", "forecast_hours"],
            columns="param_col",
            values="value",
            aggfunc="first",
        )
        pivoted.reset_index(inplace=True)
        pivoted.columns.name = None

    pivoted.sort_values(["reference_time", "forecast_hours"], inplace=True)

    log.info(
        "Pivoted to %d rows x %d columns.",
        len(pivoted), len(pivoted.columns),
    )
    return pivoted
