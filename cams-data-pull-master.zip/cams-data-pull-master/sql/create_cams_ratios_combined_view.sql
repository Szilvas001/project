-- Combined view merging legacy cams_ratios with new cams_ratios_raw data.
-- cams_ratios provides historical data; cams_ratios_raw covers everything after
-- the last timestamp in cams_ratios.
-- For the raw table, picks the closest forecast (smallest forecast_hours)
-- per valid_time and extracts the single-level value from the array columns.

CREATE OR REPLACE VIEW cams_ratios_combined AS
WITH raw_deduped AS (
    SELECT DISTINCT ON (reference_time + (forecast_hours * INTERVAL '1 hour'))
        reference_time + (forecast_hours * INTERVAL '1 hour')       AS timestamp,
        "dust_aerosol_(0.03_0.55_um)_mixing_ratio"[1]               AS dust_0_03_0_55_um_kg_kg,
        "dust_aerosol_(0.55_0.9_um)_mixing_ratio"[1]                AS dust_0_55_0_9_um_kg_kg,
        "dust_aerosol_(0.9_20_um)_mixing_ratio"[1]                  AS dust_0_9_20_um_kg_kg,
        hydrophilic_organic_matter_aerosol_mixing_ratio[1]          AS om_hydrophilic_kg_kg,
        hydrophobic_organic_matter_aerosol_mixing_ratio[1]          AS om_hydrophobic_kg_kg,
        hydrophilic_black_carbon_aerosol_mixing_ratio[1]            AS bc_hydrophilic_kg_kg,
        hydrophobic_black_carbon_aerosol_mixing_ratio[1]            AS bc_hydrophobic_kg_kg
    FROM cams_ratios_raw
    ORDER BY reference_time + (forecast_hours * INTERVAL '1 hour'), forecast_hours ASC
)
SELECT
    timestamp,
    dust_0_03_0_55_um_kg_kg,
    dust_0_55_0_9_um_kg_kg,
    dust_0_9_20_um_kg_kg,
    om_hydrophilic_kg_kg,
    om_hydrophobic_kg_kg,
    bc_hydrophilic_kg_kg,
    bc_hydrophobic_kg_kg
FROM cams_ratios
UNION ALL
SELECT *
FROM raw_deduped
WHERE timestamp > (SELECT MAX(timestamp) FROM cams_ratios);
