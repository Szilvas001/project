# Async version that reads MJPEG frames from an RTSP
# stream and publishes them to Kafka using aiokafka.
# -------------------------------------------------

import asyncio
import cv2
import time
import logging
from aiokafka import AIOKafkaProducer
from dotenv import load_dotenv
import config

def run_setup():
    setup_logging()
    load_dotenv()


def setup_logging():
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    )


def get_current_timestamp() -> float:
    """
    Return the local system time.
    """
    return time.time()


def encode_frame_jpg(frame) -> bytes:
    """
    Encode a BGR OpenCV frame as JPEG bytes.
    """
    ret, buf = cv2.imencode('.jpg', frame)
    if not ret:
        raise RuntimeError("Failed to encode frame as JPEG")
    return buf.tobytes()

async def produce_frames():
    # Initialise async Kafka producer
    rtsp_url = config.get_rtsp_url()
    producer = AIOKafkaProducer(
        bootstrap_servers=config.get_kafka_broker_addr(),
        compression_type='gzip',          # optional, reduces bandwidth
        max_request_size=10 * 1024 * 1024 # allow up‑to 10 MiB frames
    )
    await producer.start()
    try:
        # Open RTSP stream (still using OpenCV, which is blocking)
        cap = cv2.VideoCapture(rtsp_url, cv2.CAP_FFMPEG)
        if not cap.isOpened():
            raise RuntimeError(f"Cannot open RTSP stream: {rtsp_url}")

        logger.info("Streaming started – press Ctrl+C to stop.")
        loop = asyncio.get_running_loop()

        while True:
            # Read frame in a thread pool to avoid blocking the event loop
            ret, frame = await loop.run_in_executor(None, cap.read)
            if not ret:
                await asyncio.sleep(0.05)  # brief pause on hiccup
                continue

            payload = encode_frame_jpg(frame)
            frame_ts = get_current_timestamp()
            key = str(frame_ts).encode('utf-8')

            # Send asynchronously; `await` yields control while the broker
            # processes the request.
            await producer.send_and_wait(topic=config.get_kafka_topic(), key=key, value=payload)

    finally:
        await producer.stop()
        cap.release()

if __name__ == "__main__":
    run_setup()
    logger = logging.getLogger(__name__)
    try:
        asyncio.run(produce_frames())
    except KeyboardInterrupt:
        print("\nStopped by user")
