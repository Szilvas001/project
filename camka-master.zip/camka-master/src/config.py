import os

def get_kafka_broker_addr() -> list[str]:
    return os.getenv("KAFKA_ADDRESS", "localhost:9092").split(",")


def get_kafka_topic() -> str:
    return os.getenv("KAFKA_TOPIC", "camka-frames")


def get_rtsp_url() -> str:
    return os.getenv("RTSP_URL", "localhost:554")
