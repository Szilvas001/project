#!/usr/bin/with-contenv bashio
# shellcheck shell=bash
set -e

# Load/create config
KAFKA_ADDRESS=$(bashio::config 'kafka_address')
KAFKA_TOPIC=$(bashio::config 'kafka_topic')
RTSP_URL=$(bashio::config 'rtsp_url')

source /usr/src/.venv/bin/activate

exec env KAFKA_ADDRESS="$KAFKA_ADDRESS" KAFKA_TOPIC="$KAFKA_TOPIC" RTSP_URL="$RTSP_URL" python3 /usr/src/rtsp_to_kafka.py
