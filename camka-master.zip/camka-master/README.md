# CamKa

### Stream camera feed to Apache Kafka for reliable image preservation and offline processing purposes.

A service that consumes frames from an RTSP stream and sends them individually to a Kafka topic.

## Setup

### Running locally:

#### Set up local dev env:

Create and enter a Python virtual env (venv) for installing the project's dependencies in an isolated environment:
> If you are using Python tools that already handle setting up isolated dev environments, skip the steps below.

```sh
python -m venv .venv
source .venv/bin/activate
```

Install the dependencies into this virtual environment:

```
pip install -r requirements.txt
```

#### Specify your configuration using environment variables:

The service needs some configuration parameters to operate. The following are required at this point:

```
RTSP_URL=rtsp://<user>:<password>@<host>:<port>[/<optional path>]
KAFKA_BROKERS=<kafka_bootstrap_1>[,optional_kafka_bootstrap_2,...]>
KAFKA_TOPIC=<kafka_topic_to_send_frames_to>
```

You can specify these temporarily in the command line when running the service, or by writing them in a `.env` file located in the root folder of the project.

#### Run the service:

After you have specified the configuration parameters, you can run the service like this (assuming you are in the previously mentioned dev environment and you have installed the dependencies):

```sh
python rtsp_to_kafka.py
```

This will launch CamKa which will then continuously consume the configured RTSP stream and send each incoming frame to the configured Kafka topic using the configured Kafka bootstrap server(s).
