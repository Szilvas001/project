"""Adatbázis réteg – PostgreSQL kapcsolat, tábla kezelés, insertek."""

import logging
import os

import pandas as pd
import psycopg2
import psycopg2.extras
from psycopg2 import sql

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Kapcsolat
# ---------------------------------------------------------------------------

def get_connection():
    """Visszaad egy psycopg2 kapcsolatot.

    Környezeti változók:
        DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD
    Vagy egyetlen DATABASE_URL string (postgres://user:pass@host/db).
    """
    database_url = os.getenv("DATABASE_URL")
    if database_url:
        return psycopg2.connect(database_url)

    return psycopg2.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=int(os.getenv("DB_PORT", "5432")),
        dbname=os.getenv("DB_NAME", "cams"),
        user=os.getenv("DB_USER", "cams"),
        password=os.getenv("DB_PASSWORD", ""),
    )


# ---------------------------------------------------------------------------
# Séma kezelés
# ---------------------------------------------------------------------------

# Pandas dtype → PostgreSQL típus leképezés
_PG_TYPES = {
    "int64": "BIGINT",
    "int32": "INTEGER",
    "float64": "DOUBLE PRECISION",
    "float32": "REAL",
    "bool": "BOOLEAN",
    "object": "TEXT",
    "datetime64[ns, UTC]": "TIMESTAMPTZ",
    "datetime64[ns]": "TIMESTAMP",
}


def _pg_type(series: pd.Series) -> str:
    return _PG_TYPES.get(str(series.dtype), "TEXT")


def _table_exists(cur, table: str) -> bool:
    cur.execute(
        "SELECT 1 FROM information_schema.tables WHERE table_name = %s", (table,)
    )
    return cur.fetchone() is not None


def ensure_table(cur, table: str, df: pd.DataFrame, primary_key: list[str]) -> None:
    """Létrehozza a táblát, ha még nem létezik."""
    if _table_exists(cur, table):
        return

    col_defs = [
        sql.SQL("{} {}").format(sql.Identifier(col), sql.SQL(_pg_type(df[col])))
        for col in df.columns
    ]
    pk_cols = sql.SQL(", ").join(sql.Identifier(k) for k in primary_key)

    stmt = sql.SQL(
        "CREATE TABLE IF NOT EXISTS {tbl} ({cols}, PRIMARY KEY ({pk}))"
    ).format(
        tbl=sql.Identifier(table),
        cols=sql.SQL(", ").join(col_defs),
        pk=pk_cols,
    )
    cur.execute(stmt)
    log.info("Tábla létrehozva: %s", table)


def ensure_columns(cur, table: str, df: pd.DataFrame) -> None:
    """Hozzáadja a hiányzó oszlopokat (ALTER TABLE ADD COLUMN IF NOT EXISTS)."""
    cur.execute(
        "SELECT column_name FROM information_schema.columns WHERE table_name = %s",
        (table,),
    )
    existing = {row[0] for row in cur.fetchall()}

    for col in df.columns:
        if col not in existing:
            cur.execute(
                sql.SQL("ALTER TABLE {} ADD COLUMN IF NOT EXISTS {} {}").format(
                    sql.Identifier(table),
                    sql.Identifier(col),
                    sql.SQL(_pg_type(df[col])),
                )
            )
            log.info("Új oszlop: %s.%s", table, col)


# ---------------------------------------------------------------------------
# Insert
# ---------------------------------------------------------------------------

def insert_data(cur, table: str, df: pd.DataFrame, primary_key: list[str]) -> int:
    """Upsert: conflict esetén frissíti a nem-PK oszlopokat.

    Visszaadja a ténylegesen módosított sorok számát.
    """
    if df.empty:
        return 0

    cols = list(df.columns)
    non_pk = [c for c in cols if c not in primary_key]

    col_ids = sql.SQL(", ").join(sql.Identifier(c) for c in cols)
    placeholders = sql.SQL(", ").join(sql.Placeholder() * len(cols))
    pk_ids = sql.SQL(", ").join(sql.Identifier(k) for k in primary_key)

    if non_pk:
        update_clause = sql.SQL(", ").join(
            sql.SQL("{} = EXCLUDED.{}").format(sql.Identifier(c), sql.Identifier(c))
            for c in non_pk
        )
        conflict_action = sql.SQL("DO UPDATE SET ") + update_clause
    else:
        conflict_action = sql.SQL("DO NOTHING")

    stmt = sql.SQL(
        "INSERT INTO {tbl} ({cols}) VALUES ({vals}) ON CONFLICT ({pk}) {action}"
    ).format(
        tbl=sql.Identifier(table),
        cols=col_ids,
        vals=placeholders,
        pk=pk_ids,
        action=conflict_action,
    )

    records = [
        tuple(
            v.isoformat() if isinstance(v, pd.Timestamp) else (None if pd.isna(v) else v)
            for v in row
        )
        for row in df.itertuples(index=False, name=None)
    ]

    psycopg2.extras.execute_batch(cur, stmt, records, page_size=500)
    return len(records)
