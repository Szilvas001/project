"""CAMS API client – vékony wrapper az ECMWF cdsapi köré."""

import logging
import os

import cdsapi

log = logging.getLogger(__name__)


def get_client() -> cdsapi.Client:
    """Visszaad egy kész cdsapi.Client példányt.

    Hitelesítés sorrendje:
      1. CADS_URL + CADS_KEY környezeti változók  (Docker / CI)
      2. ~/.cdsapirc fájl                          (helyi fejlesztés)

    A ~/.cdsapirc formátuma:
        url: https://ads.atmosphere.copernicus.eu/api
        key: <UID>:<API-KEY>
    """
    url = os.getenv("CADS_URL")
    key = os.getenv("CADS_KEY")

    if url and key:
        log.info("CADS hitelesítés: környezeti változókból.")
        return cdsapi.Client(url=url, key=key, quiet=True, progress=False)

    log.info("CADS hitelesítés: ~/.cdsapirc fájlból.")
    return cdsapi.Client(quiet=True, progress=False)
