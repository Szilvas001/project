"""Backfill – hiányzó előrejelzési napok detektálása és visszatöltése."""

import logging
from datetime import date, timedelta

import psycopg2

log = logging.getLogger(__name__)


def _expected_dates(start_date: date, schedule: dict) -> list[tuple[date, int]]:
    """Összes (dátum, UTC_óra) pár a start_date-től a tegnapi napig."""
    hours = sorted(int(t.split(":")[0]) for t in schedule)
    today = date.today()
    result = []
    d = start_date
    while d < today:
        for h in hours:
            result.append((d, h))
        d += timedelta(days=1)
    return result


def find_missing_forecasts(
    cur,
    dataset_config: dict,
    schedule: dict,
) -> list[tuple[date, int]]:
    """Visszaadja a DB-ből hiányzó (dátum, UTC_óra) párokat.

    Args:
        cur: aktív psycopg2 cursor
        dataset_config: a config.yaml datasets[] egyik eleme
        schedule: a config.yaml schedule szekciója

    Returns:
        Rendezett lista: [(date, hour), ...]
    """
    backfill_cfg = dataset_config.get("backfill", {})
    if not backfill_cfg:
        return []

    start_str = backfill_cfg.get("start_date", "")
    if not start_str:
        return []

    try:
        start = date.fromisoformat(start_str)
    except ValueError:
        log.error("Hibás backfill.start_date formátum: %s", start_str)
        return []

    max_per_run = int(backfill_cfg.get("max_per_run", 50))
    table = dataset_config["target_table"]

    # Meglévő (dátum, óra) párok a DB-ből
    try:
        cur.execute(
            f"SELECT DISTINCT DATE(reference_time AT TIME ZONE 'UTC'), "
            f"EXTRACT(HOUR FROM reference_time AT TIME ZONE 'UTC')::int "
            f"FROM {table}"
        )
        existing = {(row[0], row[1]) for row in cur.fetchall()}
    except psycopg2.Error as exc:
        log.warning("Nem sikerült lekérni a meglévő sorokat (%s): %s", table, exc)
        existing = set()

    all_expected = _expected_dates(start, schedule)
    missing = [(d, h) for d, h in all_expected if (d, h) not in existing]

    if missing:
        log.info("[%s] %d hiányzó időpont, max %d kerül feldolgozásra.",
                 dataset_config["name"], len(missing), max_per_run)

    return missing[:max_per_run]
