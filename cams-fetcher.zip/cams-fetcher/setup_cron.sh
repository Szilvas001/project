#!/usr/bin/env bash
# setup_cron.sh – beállítja a CAMS Fetcher cron job-jait
#
# Futtatás: bash setup_cron.sh
# Eltávolítás: bash setup_cron.sh --remove

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="$SCRIPT_DIR/logs"
CRON_TAG="# cams-fetcher"

mkdir -p "$LOG_DIR"

remove_cron() {
    crontab -l 2>/dev/null | grep -v "$CRON_TAG" | crontab -
    echo "CAMS Fetcher cron job-ok eltávolítva."
    exit 0
}

[[ "${1:-}" == "--remove" ]] && remove_cron

# ---------------------------------------------------------------------------
# Ütemezés:
#   - 10:15 UTC  →  00Z futam (elérhető ~10:00 UTC körül)
#   - 22:15 UTC  →  12Z futam (elérhető ~22:00 UTC körül)
# ---------------------------------------------------------------------------

CRON_JOB_1="15 10 * * * cd $SCRIPT_DIR && docker compose run --rm fetcher >> $LOG_DIR/cams-\$(date +\%Y-\%m-\%d).log 2>&1 $CRON_TAG"
CRON_JOB_2="15 22 * * * cd $SCRIPT_DIR && docker compose run --rm fetcher >> $LOG_DIR/cams-\$(date +\%Y-\%m-\%d).log 2>&1 $CRON_TAG"

# Meglévő CAMS sorok törlése, majd újak hozzáadása
(
    crontab -l 2>/dev/null | grep -v "$CRON_TAG"
    echo "$CRON_JOB_1"
    echo "$CRON_JOB_2"
) | crontab -

echo "✓ Cron job-ok beállítva:"
echo "  10:15 UTC – 00Z futam"
echo "  22:15 UTC – 12Z futam"
echo ""
echo "Logok helye: $LOG_DIR/"
echo ""
echo "Ellenőrzés: crontab -l"
echo "Eltávolítás: bash setup_cron.sh --remove"
