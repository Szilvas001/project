# CAMS Fetcher

Config-vezérelt légköri adatleszedő az ECMWF Copernicus Atmosphere Monitoring Service
(CAMS) API-jából. Bármilyen koordinátára működik, PostgreSQL-be ment.

## Előfeltételek

- Docker + Docker Compose
- Ingyenes [Copernicus ADS fiók](https://ads.atmosphere.copernicus.eu/) és API kulcs

---

## Gyors indítás

### 1. API kulcs megszerzése

1. Regisztrálj: https://ads.atmosphere.copernicus.eu/
2. Profil → API key → másold ki az URL-t és a kulcsot
3. Fogadd el a CAMS adatkészlet licencét:
   https://ads.atmosphere.copernicus.eu/datasets/cams-global-atmospheric-composition-forecasts

### 2. Konfiguráció

Szerkeszd a `config.yaml`-t:

```yaml
target:
  name: "Pécs"
  lat: 46.0727
  lon: 18.2323
  area_margin: 0.5
```

Bármilyen koordináta megadható.

### 3. Környezeti változók

Hozz létre egy `.env` fájlt a projektgyökérben:

```env
CADS_URL=https://ads.atmosphere.copernicus.eu/api
CADS_KEY=<a-te-api-kulcsod>
```

Vagy használd a `~/.cdsapirc` fájlt (lásd lent).

### 4. Futtatás Docker Compose-zal

```bash
# Első indítás (DB + fetcher)
docker compose up --build

# Csak a leszedő (ha a DB már fut)
docker compose run --rm fetcher

# Dry-run (nem ír DB-be, csak logol)
docker compose run --rm fetcher python main.py --dry-run
```

---

## Helyi futtatás (Docker nélkül)

```bash
# Függőségek
pip install -r requirements.txt

# ~/.cdsapirc fájl (ha nem env változókat használsz)
# url: https://ads.atmosphere.copernicus.eu/api
# key: <UID>:<API-KEY>

# PostgreSQL indítása (pl. lokálisan)
export DB_HOST=localhost DB_NAME=cams DB_USER=cams DB_PASSWORD=secret

python main.py
python main.py --config other_city.yaml
python main.py --dry-run
```

---

## Ütemezés (cron) – ajánlott futtatási mód

### Automatikus beállítás

```bash
bash setup_cron.sh
```

Ez beállítja a cron job-okat és létrehozza a `logs/` mappát.
Eltávolítás: `bash setup_cron.sh --remove`

### Manuális beállítás

```bash
crontab -e
```

```cron
# CAMS Fetcher – naponta kétszer (UTC)
15 10 * * * cd /opt/cams-fetcher && docker compose run --rm fetcher >> /opt/cams-fetcher/logs/cams-$(date +\%Y-\%m-\%d).log 2>&1
15 22 * * * cd /opt/cams-fetcher && docker compose run --rm fetcher >> /opt/cams-fetcher/logs/cams-$(date +\%Y-\%m-\%d).log 2>&1
```

### Log rotáció (opcionális)

```bash
sudo cp cams-fetcher-logrotate /etc/logrotate.d/cams-fetcher
```

### Cron időzítés magyarázata

| Cron idő (UTC) | Miért? |
|----------------|--------|
| 10:15 UTC | A 00Z futam ~10:00 UTC körül válik elérhetővé |
| 22:15 UTC | A 12Z futam ~22:00 UTC körül válik elérhetővé |

Az időzítés a `config.yaml` `schedule` szekciójában módosítható.

---

## Több város

Minden városhoz külön config fájl:

```bash
python main.py --config cities/london.yaml
python main.py --config cities/berlin.yaml
```

---

## Adatbázis séma

A táblákat a program automatikusan hozza létre az első futáskor.
Például `config.yaml` alapértelmezett beállításokkal:

```
cams_surface
  ├── reference_time  TIMESTAMPTZ  (PK)
  ├── forecast_hours  INTEGER      (PK)
  ├── total_column_ozone         DOUBLE PRECISION
  ├── total_column_water_vapour  DOUBLE PRECISION
  ├── total_aerosol_optical_depth_550nm  DOUBLE PRECISION
  └── boundary_layer_height      DOUBLE PRECISION
```

---

## Elérhető változók

Teljes lista az ECMWF dokumentációban:
https://ads.atmosphere.copernicus.eu/datasets/cams-global-atmospheric-composition-forecasts

---

## Hibakeresés

| Hiba | Megoldás |
|------|----------|
| `401 Unauthorized` | Ellenőrizd a CADS_KEY-t és hogy elfogadtad-e a licencet |
| `pygrib` import hiba | `apt install libeccodes-dev` (vagy Docker-ben automatikusan megvan) |
| `psycopg2` kapcsolati hiba | Ellenőrizd a DB_* env változókat |
