#!/usr/bin/env python3
"""CAMS Fetcher – config-vezérelt légköri adatleszedő.

Futtatás:
    python main.py                          # normál mód
    python main.py --config my_config.yaml  # egyéni config
    python main.py --dry-run                # csak logol, nem ír DB-be
"""

import argparse
import logging
import os
import smtplib
import sys
import tempfile
import traceback
from datetime import datetime, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import yaml
from dotenv import load_dotenv

from app import backfill, db, grib_processor
from app.client import get_client

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Segédfüggvények
# ---------------------------------------------------------------------------

def load_config(path: str = "config.yaml") -> dict:
    with open(path) as f:
        return yaml.safe_load(f)


def parse_leadtime(spec: str) -> list[str]:
    """'0-36' → ['0','1',...,'36']  |  '0,3,6' → ['0','3','6']"""
    spec = str(spec).strip()
    if "-" in spec and "," not in spec:
        start, end = spec.split("-")
        return [str(i) for i in range(int(start), int(end) + 1)]
    return [s.strip() for s in spec.split(",")]


def determine_forecast(schedule: dict) -> tuple[str, str]:
    """A jelenlegi UTC idő alapján meghatározza a legfrissebb elérhető futamot.

    Visszatér: (dátum_str, idő_str)  pl. ('2026-04-27', '00:00')
    """
    now = datetime.utcnow()
    for time_str, avail_hour in sorted(schedule.items(), key=lambda x: x[1], reverse=True):
        if now.hour >= int(avail_hour):
            return now.strftime("%Y-%m-%d"), time_str
    # Még egyik sem elérhető ma → tegnap legkésőbbi
    latest = max(schedule, key=schedule.get)
    return (now - timedelta(days=1)).strftime("%Y-%m-%d"), latest


# ---------------------------------------------------------------------------
# API kérés összeállítása
# ---------------------------------------------------------------------------

def build_request(ds_cfg: dict, cfg: dict, forecast_date: str, forecast_time: str) -> dict:
    t = cfg["target"]
    lat, lon, margin = t["lat"], t["lon"], t["area_margin"]

    req = {
        "variable": ds_cfg["variables"],
        "date": [f"{forecast_date}/{forecast_date}"],
        "time": [forecast_time],
        "leadtime_hour": parse_leadtime(ds_cfg["leadtime_hours"]),
        "type": ["forecast"],
        "data_format": "grib",
        # [N, W, S, E]
        "area": [lat + margin, lon - margin, lat - margin, lon + margin],
    }

    if "model_levels" in ds_cfg:
        req["model_level"] = parse_leadtime(ds_cfg["model_levels"])

    return req


# ---------------------------------------------------------------------------
# Fő pipeline: letöltés → parse → DB
# ---------------------------------------------------------------------------

def fetch_and_insert(
    client,
    ds_cfg: dict,
    cfg: dict,
    forecast_date: str,
    forecast_time: str,
    dry_run: bool = False,
) -> str:
    name = ds_cfg["name"]
    table = ds_cfg["target_table"]
    pk = ds_cfg["primary_key"]
    target = cfg["target"]

    req = build_request(ds_cfg, cfg, forecast_date, forecast_time)
    log.info("[%s] Letöltés: %s %s", name, forecast_date, forecast_time)

    tmp = tempfile.NamedTemporaryFile(suffix=".grib", delete=False)
    tmp.close()
    try:
        result = client.retrieve(ds_cfg["dataset"], req)
        result.download(tmp.name)
        log.info("[%s] GRIB mentve: %s", name, tmp.name)

        df_long = grib_processor.parse_grib_file(tmp.name, target["lat"], target["lon"])
        df_wide = grib_processor.pivot_and_clean(df_long, ds_cfg)

        if dry_run:
            msg = f"[DRY-RUN] [{name}] {forecast_date} {forecast_time}: {len(df_wide)} sor (nem írva)"
            log.info(msg)
            return msg

        conn = db.get_connection()
        cur = conn.cursor()
        try:
            db.ensure_table(cur, table, df_wide, pk)
            db.ensure_columns(cur, table, df_wide)
            conn.commit()
            inserted = db.insert_data(cur, table, df_wide, pk)
            conn.commit()
        finally:
            cur.close()
            conn.close()

        msg = f"[{name}] {forecast_date} {forecast_time}: {inserted} sor"
        log.info(msg)
        return msg

    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Fázisok
# ---------------------------------------------------------------------------

def phase_live(cfg: dict, client, forecast_date: str, forecast_time: str, dry_run: bool) -> list[str]:
    results = []
    for ds in cfg["datasets"]:
        try:
            results.append(fetch_and_insert(client, ds, cfg, forecast_date, forecast_time, dry_run))
        except Exception as e:
            err = f"[{ds['name']}] HIBA (live): {e}"
            log.error(err)
            log.debug(traceback.format_exc())
            results.append(err)
    return results


def phase_backfill(cfg: dict, client, dry_run: bool) -> list[str]:
    results = []
    backfill_cfg = cfg.get("backfill", {})
    if not backfill_cfg.get("enabled", False):
        return results

    for ds in cfg["datasets"]:
        if "backfill" not in ds:
            continue
        try:
            conn = db.get_connection()
            cur = conn.cursor()
            missing = backfill.find_missing_forecasts(cur, ds, cfg["schedule"])
            cur.close()
            conn.close()
        except Exception as e:
            results.append(f"[{ds['name']}] BACKFILL GAP DETEKTÁLÁS HIBA: {e}")
            continue

        if not missing:
            results.append(f"[{ds['name']}] backfill: 0 hiányzó")
            continue

        for d, h in missing:
            date_str = d.strftime("%Y-%m-%d") if hasattr(d, "strftime") else str(d)
            time_str = f"{h:02d}:00"
            try:
                msg = fetch_and_insert(client, ds, cfg, date_str, time_str, dry_run)
                results.append(f"[BACKFILL] {msg}")
            except Exception as e:
                err = f"[BACKFILL] [{ds['name']}] {date_str} {time_str} HIBA: {e}"
                log.error(err)
                results.append(err)

    return results


# ---------------------------------------------------------------------------
# Email
# ---------------------------------------------------------------------------

def send_email(cfg: dict, results: list[str]) -> None:
    email_cfg = cfg.get("email", {})
    if not email_cfg.get("enabled", False):
        return

    smtp_server = os.getenv("SMTP_SERVER")
    smtp_port = int(os.getenv("SMTP_PORT", "587"))
    smtp_user = os.getenv("SMTP_USER")
    smtp_password = os.getenv("SMTP_PASSWORD")
    recipient = email_cfg.get("recipient", "")

    if not all([smtp_server, smtp_user, smtp_password, recipient]):
        log.warning("SMTP nincs teljesen konfigurálva, email kihagyva.")
        return

    now_str = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
    body = (
        f"<html><body><p>CAMS Fetcher – {now_str}</p>"
        f"<pre>{'chr(10)'.join(results)}</pre></body></html>"
    )
    msg = MIMEMultipart("alternative")
    msg["From"] = smtp_user
    msg["To"] = recipient
    msg["Subject"] = f"CAMS Fetcher – {now_str}"
    msg.attach(MIMEText(body, "html"))

    try:
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(smtp_user, smtp_password)
            server.send_message(msg)
        log.info("Email elküldve: %s", recipient)
    except Exception as e:
        log.error("Email küldési hiba: %s", e)


# ---------------------------------------------------------------------------
# CLI + belépési pont
# ---------------------------------------------------------------------------

def parse_args():
    parser = argparse.ArgumentParser(description="CAMS Fetcher")
    parser.add_argument("--config", default="config.yaml", help="Config fájl elérési útja")
    parser.add_argument("--dry-run", action="store_true", help="Nem ír az adatbázisba")
    return parser.parse_args()


def main():
    args = parse_args()
    cfg = load_config(args.config)

    forecast_date, forecast_time = determine_forecast(cfg["schedule"])
    log.info("Célpont: %s | Koordináta: %.4f, %.4f | Futam: %s %s",
             cfg["target"].get("name", "–"),
             cfg["target"]["lat"], cfg["target"]["lon"],
             forecast_date, forecast_time)

    client = get_client()
    log.info("ECMWF CADS kliens inicializálva.")

    results = []
    results.extend(phase_live(cfg, client, forecast_date, forecast_time, args.dry_run))
    results.extend(phase_backfill(cfg, client, args.dry_run))
    send_email(cfg, results)

    log.info("Kész. %d eredménysor.", len(results))
    for r in results:
        log.info("  %s", r)

    # Ha bármilyen HIBA volt, nem-nulla kilépési kóddal térünk vissza
    if any("HIBA" in r or "FAILED" in r for r in results):
        sys.exit(1)


if __name__ == "__main__":
    main()
