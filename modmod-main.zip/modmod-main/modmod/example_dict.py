pvlib_calc_test = {
    "modules": [
        {
            "model": "ha_data_loader",
            "inputs": {},
            "outputs": {
                "sensor.calculated_effective_poa_irradiance_tvl9": {
                    "metric": "sensor.calculated_effective_poa_irradiance_tvl9",
                    "transformations": []
                },
                "sensor.calculated_incident_angle_modifier_ashrae_tvl9": {
                    "metric": "sensor.calculated_incident_angle_modifier_ashrae_tvl9",
                    "transformations": []
                },
                "sensor.tvl9_gw2000a_absolute_pressure": {
                    "metric": "sensor.tvl9_gw2000a_absolute_pressure",
                    "transformations": []
                },
                "sensor.tvl9_gw2000a_outdoor_temperature": {
                    "metric": "sensor.tvl9_gw2000a_outdoor_temperature",
                    "transformations": []
                },
                "sensor.tvl9_gw2000a_humidity": {
                    "metric": "sensor.tvl9_gw2000a_humidity",
                    "transformations": []
                },
                "sensor.tvl9_rt1_mid_poa_irradiance": {
                    "metric": "sensor.tvl9_rt1_mid_poa_irradiance",
                    "transformations": []
                },
                "sensor.tvl9_rt1_mid_module_temp": {
                    "metric": "sensor.tvl9_rt1_mid_module_temp",
                    "transformations": []
                },
                "input_text.pv_module_name": {
                    "metric": "input_text.pv_module_name",
                    "transformations": []
                }
            },
        },
        {
            "model": "solar_position_model",
            "inputs": {
                "ha_pressure_pa": {
                    "metric": "sensor.tvl9_gw2000a_absolute_pressure",
                    "transformations": []
                },
                "ha_temperature": {
                    "metric": "sensor.tvl9_gw2000a_outdoor_temperature",
                    "transformations": []
                },
                "latitude": {
                    "value": 47.523533
                },
                "longitude": {
                    "value": 19.012432
                },
                "altitude": {
                    "value": 240
                },
            },
            "outputs": {
                "solar_azimuth": {
                    "metric": "solar_azimuth",
                },
                "solar_zenith": {
                    "metric": "solar_zenith",
                }
            }
        },
        {
            "model": "relative_airmass_model",
            "inputs": {
                "solar_zenith": {
                    "metric": "solar_zenith",
                    "transformations": []
                }
            },
            "outputs": {
                "relative_airmass": {
                    "metric": "relative_airmass",
                }
            }
        },
        {
            "model": "absolute_airmass_model",
            "inputs": {
                "relative_airmass": {
                    "metric": "relative_airmass",
                    "transformations": []
                },
                "ha_pressure_pa": {
                    "metric": "sensor.tvl9_gw2000a_absolute_pressure",
                    "transformations": []
                }
            },
            "outputs": {
                "absolute_airmass": {
                    "metric": "absolute_airmass",
                },
            }
        },
        {
            "model": "precipitable_water_model",
            "inputs": {
                "ha_temperature": {
                    "metric": "sensor.tvl9_gw2000a_outdoor_temperature",
                    "transformations": []
                },
                "humidity": {
                    "metric": "sensor.tvl9_gw2000a_humidity",
                    "transformations": []
                }
            },
            "outputs": {
                "precipitable_water": {
                    "metric": "precipitable_water",
                }
            }
        },
        {
            "model": "spectral_factor_model",
            "inputs": {
                "precipitable_water": {
                    "metric": "precipitable_water",
                    "transformations": []
                },
                "absolute_airmass": {
                    "metric": "absolute_airmass",
                    "transformations": []
                },
                "module_type": {
                    "value": "monosi"
                }
            },
            "outputs": {
                "spectral_factor": {
                    "metric": "spectral_factor",
                }
            }
        },
        {
            "model": "incident_angle_modifier_model",
            "inputs": {
                "ha_iam": {
                    "metric": "sensor.calculated_incident_angle_modifier_ashrae_tvl9",
                    "transformations": []
                },
            },
            "outputs": {
                "iam": {
                    "metric": "iam",
                }
            }
        },
        {
            "model": "cell_temp_model",
            "inputs": {
                "mounting_key": {
                    "value": "open_rack_glass_polymer"
                },
                "ha_poa_irrad": {
                    "metric": "sensor.tvl9_rt1_mid_poa_irradiance",
                    "transformations": []
                },
                "ha_module_temp": {
                    "metric": "sensor.tvl9_rt1_mid_module_temp",
                    "transformations": []
                }
            },
            "outputs": {
                "cell_temp": {
                    "metric": "cell_temp",
                }
            }
        },
        {
            "model": "angle_of_incidence_model",
            "inputs": {
                "panel_tilt": {
                    "value": 12.0
                },
                "panel_azimuth": {
                    "value": 183.0
                },
                "ha_pressure_pa": {
                    "metric": "sensor.tvl9_gw2000a_absolute_pressure",
                    "transformations": []
                },
                "ha_temperature": {
                    "metric": "sensor.tvl9_gw2000a_outdoor_temperature",
                    "transformations": []
                },
                "latitude": {
                    "value": 47.523618
                },
                "longitude": {
                    "value": 19.012776
                },
                "altitude": {
                    "value": 240
                },
            },
            "outputs": {
                "aoi": {
                    "metric": "aoi",
                }
            }
        },
        {
            "model": "poa_effective_irradiance_model",
            "inputs": {
                "ha_poa_irrad": {
                    "metric": "sensor.tvl9_rt1_mid_poa_irradiance",
                    "transformations": []
                },
                "spectral_factor": {
                    "metric": "spectral_factor",
                    "transformations": [] 
                },
                "iam": {
                    "metric": "iam",
                    "transformations": []
                }
            },
            "outputs": {
                "poa_effective_irradiance": {
                    "metric": "poa_effective_irradiance",
                },
            }
        },

        {
            "model": "dc_output_model",
            "inputs": {
                "irradiance": {
                    "metric": "poa_effective_irradiance",
                    "transformations": []
                },
                "cell_temp": {
                    "metric": "cell_temp",
                    "transformations": []
                },
                "module_name": {
                    "value": "Trina Solar TSM-400DE09.08",
                },
                "calc_type": {
                    "value": "cec"
                },
                "module_no": {
                    "value": 14
                }
            },
            "outputs": {
                "dc_output": {
                    "metric": "dc_output",
                }
            }
        },
    ],
    "input_table": "normalized_dataset_12deg",
    "output_table": "dc_output_edge_12deg",
    "interval_start": "2025-04-14 00:00:00.000+00",
    "interval_end": "2025-04-16 00:00:00.000+00",
}

ha_data_loader_test = {
    "modules": [
        {
            "model": "ha_data_loader",
            "inputs": {},
            "outputs": {
                "sensor.tvl9_gw2000a_wind_speed": {
                    "metric": "sensor.tvl9_gw2000a_wind_speed",
                    "transformations": [],
                },
            }
        },
        {
            "model": "temporary_loading_model",
            "inputs": {
                "fixed_input": {
                    "value": 9
                },
                "cell_temp": {
                    "metric": "sensor.random_cell_temp",
                    "transformations": []
                },
                "irradiance": {
                    "metric": "sensor.random_irradiance",
                    "transformations": [
                        {
                            "model": "test_transform",
                            "parameters": [
                                {
                                    "test_param": 1000,
                                }
                            ],
                        },
                    ]
                }
            },
            "outputs": {
                "temporary_output": {
                    "metric": "temporary_output",
                }
            }
        }
    ],
    "input_table": "pvlib_test_1",
    "output_table": "modmod_test_1",
    "interval_start": "2024-08-08 06:30:00.000+00",
    "interval_end": "2024-08-08 09:30:00.000+00",
}

live_with_historical_data_test = {
    "modules": [
        {
            "model": "ha_data_loader",
            "inputs": {},
            "outputs": {
                "sensor.tvl9_rt1_mid_poa_irradiance": {
                    "metric": "sensor.tvl9_rt1_mid_poa_irradiance",
                },
            }
        },
        {
            "model": "dc_output_model",
            "inputs": {
                "irradiance": {
                    "value": 500.0,
                },
                "cell_temp": {
                    "value": 30.0,
                },
                "module_name": {
                    "value": "Trina Solar TSM-400DE09.08",
                },
                "calc_type": {
                    "value": "cec"
                },
                "module_no": {
                    "value": "6"
                },
                "timestamp": {
                    "value": "2024-08-13 08:34:00.000+00",
                }
            },
            "outputs": {
                "dc_output": {
                    "metric": "dc_output",
                }
            }
        },
        {
            "model": "ac_output_model",
            "inputs": {
                "dc_output": {
                    "metric": "dc_output",
                    "transformations": []
                },
                "inverter_dc_input_limit": {
                    "value": 12955
                },
            },
            "outputs": {
                "ac_output": {
                    "metric": "ac_output",
                }
            }
        },
    ],
    "input_table": "pvlib_test_1",
    "output_table": "modmod_test_2",
    "interval_start": "2024-08-13 07:25:00.000+00",
    "interval_end": "2024-08-13 07:55:00.000+00",
}

live_without_historical_data_test = {
    "modules": [
        {
            "model": "dc_output_model",
            "inputs": {
                "irradiance": {
                    "value": 500.0,
                },
                "cell_temp": {
                    "value": 30.0,
                },
                "module_name": {
                    "value": "Trina Solar TSM-400DE09.08",
                },
                "calc_type": {
                    "value": "cec"
                },
                "module_no": {
                    "value": "6"
                },
                "timestamp": {
                    "value": "2024-08-13 08:34:00.000+00",
                }
            },
            "outputs": {
                "dc_output": {
                    "metric": "dc_output",
                }
            }
        },
        {
            "model": "ac_output_model",
            "inputs": {
                "dc_output": {
                    "metric": "dc_output",
                    "transformations": []
                },
                "inverter_dc_input_limit": {
                    "value": 12955
                },
            },
            "outputs": {
                "ac_output": {
                    "metric": "ac_output",
                }
            }
        },
    ],
    "input_table": "pvlib_test_1",
    "output_table": "modmod_test_2",
}

consumer_test = {
    "modules": [
        {
            "model": "consumer_test_model",
            "inputs": {
                "momentary_generation": {
                    "value": 3800,
                },
                "momentary_consumption": {
                    "value": 900,
                },
                "timestamp": {
                    "value": "2024-08-15 14:34:00.000+00",
                }
            },
            "outputs": {
                "turn_on_signal": {
                    "metric": "turn_on_signal",
                }
            }
        }
    ],
    "input_table": "pvlib_test_1",
    "output_table": "modmod_test_consumer",
}

cloud_coverage_test = {
    "modules": [
        {
            "model": "cloud_cover_pulling_model",
            "inputs": {},
            "outputs": {
                "cloud_cover_low": {
                    "metric": "cloud_cover_low",
                },
                "cloud_cover_medium": {
                    "metric": "cloud_cover_medium",
                },
                "cloud_cover_high": {
                    "metric": "cloud_cover_high",
                },
                "cloud_cover_effective": {
                    "metric": "cloud_cover_effective",
                }
            }
        },
    ],
    "input_table": "pvlib_test_1",
    "output_table": "pulled_cloud_coverage_meteomatics",
    "interval_start": "2024-04-01 06:00:00.000+00",
    "interval_end": "2024-10-01 07:25:00.000+00",
}

openmeteo_pull_test = {
    "modules": [
        {
            "model": "cloud_cover_pulling_openmeteo_model",
            "inputs": {},
            "outputs": {
                "cloud_cover_low": {
                    "metric": "cloud_cover_low",
                },
                "cloud_cover_medium": {
                    "metric": "cloud_cover_medium",
                },
                "cloud_cover_high": {
                    "metric": "cloud_cover_high",
                },
                "cloud_cover_total": {
                    "metric": "cloud_cover_total",
                },
                "current_cloud_cover": {
                    "metric": "current_cloud_cover",
                }
            }
        }
    ],
    "input_table": "pvlib_test_1",
    "output_table": "cloud_cover_openmeteo",
    "interval_start": "2024-09-17 10:30:00.000+00",
    "interval_end": "2024-09-19 12:00:00.000+00",
}

openmeteo_irradiance_pull_test = {
    "modules": [
        {
            "model": "irradiance_pulling_openmeteo_model",
            "inputs": {},
            "outputs": {
                "shortwave_radiation": {
                    "metric": "shortwave_radiation",
                },
                "diffuse_radiation": {
                    "metric": "diffuse_radiation",
                },
                "direct_normal_irradiance": {
                    "metric": "direct_normal_irradiance",
                },
                "data_timestamp": {
                    "metric": "data_timestamp",
                },
            }
        }
    ],
    "input_table": "pvlib_test_1",
    "output_table": "pulled_irradiance_openmeteo_new"
}

measured_irradiance_test = {
    "modules": [
        {
            "model": "ha_data_loader",
            "inputs": {},
            "outputs": {
                "sensor.tvl9_rt1_mid_poa_irradiance": {
                    "metric": "sensor.tvl9_rt1_mid_poa_irradiance",
                    "transformations": []
                },
                "sensor.tvl9_rt1_edge_poa_irradiance": {
                    "metric": "sensor.tvl9_rt1_edge_poa_irradiance",
                    "transformations": []
                },
            },
        }
    ],
    "input_table": "pvlib_test_1",
    "output_table": "measured_irradiance_to_compare",
    "interval_start": "2024-09-17 10:30:00.000+00",
    "interval_end": "2024-09-20 10:00:05.000+00",
}

irradiance_comparison_test = {
    "modules": [
        {
            "model": "test_openmeteo_irradiance_model",
            "inputs": {
                "ghi": {
                    "metric": "shortwave_radiation",
                    "transformations": []
                },
                "dni": {
                    "metric": "direct_normal_irradiance",
                    "transformations": []
                },
                "dhi": {
                    "metric": "diffuse_radiation",
                    "transformations": []
                },
                "gti": {
                    "metric": "global_tilted_irradiance",
                    "transformations": []
                }
            },
            "outputs": {
                "poa_global_ghi": {
                    "metric": "poa_global_ghi",
                },
                "poa_global_gti": {
                    "metric": "poa_global_gti",
                }
            },
        },
        {
            "model": "clear_sky_model",
            "inputs": {
                "panel_tilt": {
                    "value": 10.0
                },
                "panel_azimuth": {
                    "value": 183.0
                },
            },
            "outputs": {
                "clear_sky_ghi": {
                    "metric": "clear_sky_ghi",
                },
                "clear_sky_dni": {
                    "metric": "clear_sky_dni",
                },
                "clear_sky_dhi": {
                    "metric": "clear_sky_dhi",
                },
                "clear_sky_poa_irradiance": {
                    "metric": "clear_sky_poa_irradiance",
                },
            },
        }
    ],
    "input_table": "pulled_irradiance_openmeteo",
    "output_table": "clear_sky_asd",
    "interval_start": "2024-08-25 10:30:00.000+00",
    "interval_end": "2024-08-27 18:00:00.000+00",
}

openmeteo_3month_pull_test = {
    "modules": [
        {
            "model": "openmeteo_pulling_model",
            "inputs": {},
            "outputs": {
                "openmeteo_ghi": {
                    "metric": "openmeteo_ghi",
                },
                "openmeteo_dhi": {
                    "metric": "openmeteo_dhi",
                },
                "openmeteo_dni": {
                    "metric": "openmeteo_dni",
                },
                "poa_irradiance": {
                    "metric": "poa_irradiance",
                }
            }
        }
    ],
    "input_table": "pvlib_test_1",
    "output_table": "pulled_irradiance_openmeteo_3month_17deg_poa",
    "interval_start": "2024-06-28 00:00:00.000+00",
    "interval_end": "2024-09-25 08:40:00.000+00",
}

ha_irradiance_pull_test = {
    "modules": [
        {
            "model": "clear_sky_model",
            "inputs": {
                "sensor_tvl9_rt1_mid_poa_irradiance": {
                    "metric": "sensor_tvl9_rt1_mid_poa_irradiance",
                    "transformations": []
                },
                "panel_tilt": {
                    "value": 10.0
                },
                "panel_azimuth": {
                    "value": 183.0
                },
                "latitude": {
                    "value": 47.523618,
                },
                "longitude": {
                    "value": 19.012776,
                },
                "altitude": {
                    "value": 240,
                },
                "albedo": {
                    "value": 0.6,
                },
                "model": {
                    "value": "bird"
                }
            },
            "outputs": {
                "clear_sky_poa_irradiance": {
                    "metric": "clear_sky_poa_irradiance",
                },
            },
        }
    ],
    "input_table": "ha_irradiance_data",
    "output_table": "clear_sky_comparison_ha_test",
    "interval_start": "2024-10-02 08:00:00.000+00",
    "interval_end": "2024-10-02 10:00:00.000+00",
}

ha_to_db_test = {
    "modules": [
        {
            "model": "ha_data_loader",
            "inputs": {},
            "outputs": {
                "sensor.tvl9_imt_11_irrad": {
                    "metric": "sensor.tvl9_imt_11_irrad",
                    "transformations": [],
                },
            }
        },
    ],
    "input_table": "pvlib_test_1",
    "output_table": "ha_irradiance_data_imt11",
    "interval_start": "2025-06-15 00:00:00.000+00",
    "interval_end": "2025-07-01 00:00:00.000+00",
}

imt_dc_calc_test = {
  "modules": [
    {
      "model": "ha_data_loader",
      "inputs": {},
      "outputs": {
        "sensor.tvl9_imt_11_irrad": {
          "metric": "sensor.tvl9_imt_11_irrad",
          "transformations": []
        },
        "sensor.tvl9_imt_12_irrad": {
          "metric": "sensor.tvl9_imt_12_irrad",
          "transformations": []
        },
        "sensor.tvl9_rt1_mid_module_temp": {
          "metric": "sensor.tvl9_rt1_mid_module_temp",
          "transformations": []
        },
        "sensor.tvl9_rt1_edge_module_temp": {
          "metric": "sensor.tvl9_rt1_edge_module_temp",
          "transformations": []
        },
        "input_text.pv_module_name": {
          "metric": "input_text.pv_module_name",
          "transformations": []
        },
        "sensor.tvl9_gw2000a_absolute_pressure": {
            "metric": "sensor.tvl9_gw2000a_absolute_pressure"
        },
        "sensor.tvl9_gw2000a_outdoor_temperature": {
            "metric": "sensor.tvl9_gw2000a_outdoor_temperature"
        },
        "sensor.tvl9_mid_dc_power_output_calculation_singlediode_cec": {
          "metric": "sensor.tvl9_mid_dc_power_output_calculation_singlediode_cec",
          "transformations": []
        },
        "sensor.tvl9_fronius_mppt_module_0_dc_power": {
          "metric": "sensor.tvl9_fronius_mppt_module_0_dc_power",
          "transformations": []
        }
      }
    },
    {
        "model": "solar_position_model",
        "inputs": {
            "ha_pressure_pa": {
                "metric": "sensor.tvl9_gw2000a_absolute_pressure",
                "transformations": []
            },
            "ha_temperature": {
                "metric": "sensor.tvl9_gw2000a_outdoor_temperature",
                "transformations": []
            },
            "latitude": {
                "value": 47.523533
            },
            "longitude": {
                "value": 19.012432
            },
            "altitude": {
                "value": 240
            },
        },
        "outputs": {
            "solar_azimuth": {
                "metric": "solar_azimuth",
            },
            "solar_zenith": {
                "metric": "solar_zenith",
            }
        }
    },
    {
        "model": "angle_of_incidence_model",
        "inputs": {
            "panel_tilt": {
                "value": 12.0
            },
            "panel_azimuth": {
                "value": 183.0
            },
            "ha_pressure_pa": {
                "metric": "sensor.tvl9_gw2000a_absolute_pressure",
                "transformations": []
            },
            "ha_temperature": {
                "metric": "sensor.tvl9_gw2000a_outdoor_temperature",
                "transformations": []
            },
            "latitude": {
                # why was this different?
                # "value": 47.523618
                "value": 47.523533
            },
            "longitude": {
                # why was this different?
                # "value": 19.012776
                "value": 19.012432
            },
            "altitude": {
                "value": 240
            },
        },
        "outputs": {
            "aoi": {
                "metric": "mid_aoi",
            }
        }
    },
    {
        "model": "revert_imt_iam_model",
        "inputs": {
            "aoi": {
                "metric": "mid_aoi"
            },
            "irradiance_with_imt_iam": {
                "metric": "sensor.tvl9_imt_12_irrad"
            }
        },
        "outputs": {
            "iam_reversed_irradiance_output": {
                "metric": "iam_reversed_mid_irradiance_output"
            },
            "included_imt_iam_factor": {
                "metric": "included_mid_imt_iam_factor"
            }
        }
    },
    {
        "model": "incident_angle_modifier_physical_model",
        "inputs": {
            "aoi": {
                "metric": "mid_aoi"
            },
            "irradiance_without_iam": {
                "metric": "iam_reversed_mid_irradiance_output"
            },
            "glazing_thickness_L": {
                "value": 0.0036
            }
        },
        "outputs": {
            "iam": {
                "metric": "iam_physical"
            },
            "irradiance_with_iam": {
                "metric": "irradiance_with_iam_physical"
            }
        }
    },
    {
        "model": "incident_angle_modifier_ashrae_model",
        "inputs": {
            "aoi": {
                "metric": "mid_aoi"
            },
            "irradiance_without_iam": {
                "metric": "iam_reversed_mid_irradiance_output"
            },
            "iam_aoi_adjuster_b": {
                "value": 0.05
            }
        },
        "outputs": {
            "iam": {
                "metric": "iam_ashrae"
            },
            "irradiance_with_iam": {
                "metric": "irradiance_with_iam_ashrae"
            }
        }
    },
    {
        "model": "incident_angle_modifier_martin_ruiz_model",
        "inputs": {
            "aoi": {
                "metric": "mid_aoi"
            },
            "irradiance_without_iam": {
                "metric": "iam_reversed_mid_irradiance_output"
            },
            "angular_losses_coeff_a_r": {
                "value": 0.16
            }
        },
        "outputs": {
            "iam": {
                "metric": "iam_martin_ruiz"
            },
            "irradiance_with_iam": {
                "metric": "irradiance_with_iam_martin_ruiz"
            }
        }
    },
    {
        "model": "cell_temp_model",
        "inputs": {
            "mounting_key": {
                "value": "open_rack_glass_polymer"
            },
            "ha_poa_irrad": {
                "metric": "sensor.tvl9_imt_12_irrad",
                "transformations": []
            },
            "ha_module_temp": {
                "metric": "sensor.tvl9_rt1_mid_module_temp",
                "transformations": []
            }
        },
        "outputs": {
            "cell_temp": {
                "metric": "cell_temp_mid",
            }
        }
    },
    {
        "model": "cell_temp_model",
        "inputs": {
            "mounting_key": {
                "value": "open_rack_glass_polymer"
            },
            "ha_poa_irrad": {
                "metric": "sensor.tvl9_imt_11_irrad",
                "transformations": []
            },
            "ha_module_temp": {
                "metric": "sensor.tvl9_rt1_edge_module_temp",
                "transformations": []
            }
        },
        "outputs": {
            "cell_temp": {
                "metric": "cell_temp_edge",
            }
        }
    },
    {
        "model": "average_model",
        "inputs": {
            "avg_a_value": {
                "metric": "cell_temp_edge",
                "transformations": []
            },
            "avg_b_value": {
                "metric": "cell_temp_mid",
                "transformations": []
            }
        },
        "outputs": {
            "average_output": {
                "metric": "cell_temp_average",
            }
        }
    },
    {
      "model": "dc_output_model",
      "inputs": {
        "irradiance": {
          "metric": "sensor.tvl9_imt_12_irrad"
        },
        "cell_temp": {
          "metric": "cell_temp_average"
        },
        "module_name": {
          "value": "Trina Solar TSM-400DE09.08"
        },
        "calc_type": {
          "value": "cec"
        },
        "module_no": {
          "value": "14"
        }
      },
      "outputs": {
        "dc_output": {
          "metric": "dc_output"
        }
      }
    },
    {
      "model": "dc_output_model",
      "inputs": {
        "irradiance": {
          "metric": "irradiance_with_iam_physical"
        },
        "cell_temp": {
          "metric": "cell_temp_average"
        },
        "module_name": {
          "value": "Trina Solar TSM-400DE09.08"
        },
        "calc_type": {
          "value": "cec"
        },
        "module_no": {
          "value": "14"
        }
      },
      "outputs": {
        "dc_output": {
          "metric": "dc_output_iam_physical"
        }
      }
    },
    {
      "model": "dc_output_model",
      "inputs": {
        "irradiance": {
          "metric": "irradiance_with_iam_ashrae"
        },
        "cell_temp": {
          "metric": "cell_temp_average"
        },
        "module_name": {
          "value": "Trina Solar TSM-400DE09.08"
        },
        "calc_type": {
          "value": "cec"
        },
        "module_no": {
          "value": "14"
        }
      },
      "outputs": {
        "dc_output": {
          "metric": "dc_output_iam_ashrae"
        }
      }
    },
    {
      "model": "dc_output_model",
      "inputs": {
        "irradiance": {
          "metric": "irradiance_with_iam_martin_ruiz"
        },
        "cell_temp": {
          "metric": "cell_temp_average"
        },
        "module_name": {
          "value": "Trina Solar TSM-400DE09.08"
        },
        "calc_type": {
          "value": "cec"
        },
        "module_no": {
          "value": "14"
        }
      },
      "outputs": {
        "dc_output": {
          "metric": "dc_output_iam_martin_ruiz"
        }
      }
    }
  ],
  "input_table": "",
  "output_table": "mid_imt12_sensors_irrad_dc_output_calc_20250426",
  "interval_start": "2025-04-26 05:25:00.000+02",
  "interval_end": "2025-04-26 19:50:00.000+02"
}


integral_test = {
    "modules": [
        {
            "model": "clear_sky_model",
            "inputs": {

                "panel_tilt": {
                    "value": 12.26
                },
                "panel_azimuth": {
                    "value": 183.0
                },
                "latitude": {
                    "value": 47.523618,
                },
                "longitude": {
                    "value": 19.012776,
                },
                "altitude": {
                    "value": 240,
                },
                "albedo": {
                    "value": 0.25,
                },
                "aod380": {
                    "value": 0
                },
                "aod500": {
                    "value": 0
                },
                "asymmetry_factor": {
                    "metric": "asymmetry_factor",
                    "transformations": []
                },
                "ssa": {
                    "metric": "ssa",
                    "transformations": []
                },
                "wv": {
                    "metric": "wv",
                    "transformations": []
                },
                "o3": {
                    "metric": "o3",
                    "transformations": []
                },
                "aod469": {
                    "metric": "aod469",
                    "transformations": []
                },
                "aod550": {
                    "metric": "aod550",
                    "transformations": []
                },
                "pressure": {
                    "metric": "pressure",
                    "transformations": []
                },
                "model": {
                    "value": "spctrl2"
                }
            },
            "outputs": {
                "clear_sky_poa_irradiance": {
                    "metric": "clear_sky_poa_irradiance",
                }
            },
        },
    ],
    "input_table": "levente_input",
    "output_table": "clearsky_simulation_fixed_pressure_fixed_o3",
    "interval_start": "2025-04-27 00:00:00.000+00",
    "interval_end": "2025-04-28 00:00:00.000+00",
}

meteomatics_pull_test = {
    "modules": [
        {
            "model": "meteomatics_data_loader_model",
            "inputs": {},
            "outputs": {
                "low_cloud_cover_p": {
                    "metric": "low_cloud_cover_p",
                },
                "high_cloud_cover_p": {
                    "metric": "high_cloud_cover_p",
                },
                "total_cloud_cover_p": {
                    "metric": "total_cloud_cover_p",
                },
                "effective_cloud_cover_p": {
                    "metric": "effective_cloud_cover_p",
                },
                "medium_cloud_cover_p": {
                    "metric": "medium_cloud_cover_p",
                },
                "wind_dir_1200m_d": {
                    "metric": "wind_dir_1200m_d",
                },
                "wind_speed_1200m_ms": {
                    "metric": "wind_speed_1200m_ms",
                },
                "total_aod_550nm_idx": {
                    "metric": "total_aod_550nm_idx",
                },
            }
        },
    ],
    "input_table": "pvlib_test_1",
    "output_table": "pulled_data_meteomatics_weather",
    "interval_start": "2024-10-07 18:35:00.000+00",
    "interval_end": "2024-10-22 08:25:00.000+00",
}

meteomatics_pull_test_weather = {
    "modules": [
        {
            "model": "meteomatics_data_loader_model",
            "inputs": {},
            "outputs": {
                "global_rad_W": {
                    "metric": "global_rad_W",
                },
                "global_rad_tilt_10_orientation_183_W": {
                    "metric": "global_rad_tilt_10_orientation_183_W",
                },
            }
        },
    ],
    "input_table": "pvlib_test_1",
    "output_table": "pulled_data_meteomatics_weather_experiment",
    "interval_start": "2024-04-17 06:00:00.000+00",
    "interval_end": "2024-10-16 18:30:00.000+00",
}

meteomatics_pull_test_weather = {
    "modules": [
        {
            "model": "clear_sky_model",
            "inputs": {

            },
            "outputs": {
                "global_rad_W": {
                    "metric": "global_rad_W",
                },
                "global_rad_tilt_10_orientation_183_W": {
                    "metric": "global_rad_tilt_10_orientation_183_W",
                },
            }
        },
        {
            "model": "meteomatics_data_loader_model",
            "inputs": {},
            "outputs": {
                "global_rad_W": {
                    "metric": "global_rad_W",
                },
                "global_rad_tilt_10_orientation_183_W": {
                    "metric": "global_rad_tilt_10_orientation_183_W",
                },
            }
        },
        {
            "model": "meteomatics_data_loader_model",
            "inputs": {},
            "outputs": {
                "global_rad_W": {
                    "metric": "global_rad_W",
                },
                "global_rad_tilt_10_orientation_183_W": {
                    "metric": "global_rad_tilt_10_orientation_183_W",
                },
            }
        },
    ],
    "input_table": "pvlib_test_1",
    "output_table": "pulled_data_meteomatics_weather_experiment",
    "interval_start": "2024-04-17 06:00:00.000+00",
    "interval_end": "2024-10-16 18:30:00.000+00",
}

poa_from_direct = {
    "modules": [
        {
            "model": "poa_from_direct_model",
            "inputs": {
                "panel_tilt": {
                    "value": 10.0
                },
                "panel_azimuth": {
                    "value": 183.0
                },
                "latitude": {
                    "value": 47.523618,
                },
                "longitude": {
                    "value": 19.012776,
                },
                "altitude": {
                    "value": 240,
                },
                "albedo": {
                    "value": 0.55,
                },
                "diffuse_rad_w": {
                    "metric": "diffuse_rad_w",
                },
                "direct_rad_w": {
                    "metric": "direct_rad_w",
                },
            },
            "outputs": {
                "poa_irradiance": {
                    "metric": "poa_irradiance",
                }
            }
        },
    ],
    "input_table": "pulled_data_meteomatics_chunk_3",
    "output_table": "meteomatics_poa_irradiance",
    "interval_start": "2024-07-02 06:00:00.000+00",
    "interval_end": "2024-10-12 18:30:00.000+00",
}

integral_test_2 = {
    "modules": [
        {
            "model": "clear_sky_model",
            "inputs": {
                "sensor_tvl9_rt1_mid_poa_irradiance": {
                    "metric": "sensor_tvl9_rt1_mid_poa_irradiance",
                    "transformations": []
                },
                "panel_tilt": {
                    "value": 10.0
                },
                "panel_azimuth": {
                    "value": 183.0
                },
                "latitude": {
                    "value": 47.523618,
                },
                "longitude": {
                    "value": 19.012776,
                },
                "altitude": {
                    "value": 240,
                },
                "albedo": {
                    "value": 0.55,
                },
                "aod469": {
                    "metric": "aod469",
                    "transformations": []
                },
                "aod550": {
                    "metric": "aod550",
                    "transformations": []
                },
                "aod670": {
                    "metric": "aod670",
                    "transformations": []
                },
                "aod865": {
                    "metric": "aod865",
                    "transformations": []
                },
                "aod1240": {
                    "metric": "aod1240",
                    "transformations": []
                },
                "wv": {
                    "metric": "wv",
                    "transformations": []
                },
                "o3": {
                    "metric": "o3",
                    "transformations": []
                },
                "no2": {
                    "metric": "no2",
                    "transformations": []
                },
                "model": {
                    "value": "rest2"
                }
            },
            "outputs": {
                "clear_sky_poa_irradiance": {
                    "metric": "clear_sky_poa_irradiance",
                },
                "alpha": {
                    "metric": "alpha"
                },
                "beta": {
                    "metric": "beta"
                }
            },
        },
        {
            "model": "interval_integral_model",
            "inputs": {
                "measured_irradiance": {
                    "metric": "sensor_tvl9_rt1_mid_poa_irradiance",
                    "transformations": []
                },
                "clear_sky_irradiance": {
                    "metric": "clear_sky_poa_irradiance",
                    "transformations": []
                },
                "interval": {
                    "value": "now"
                }
            },
            "outputs": {
                "clear_sky_integral": {
                    "metric": "clear_sky_integral",
                },
                "measured_integral": {
                    "metric": "measured_integral",
                }
            },
        }
    ],
    "input_table": "ha_meteomatics_with_aod",
    "output_table": "clear_sky_integral_test_rest2",
    "interval_start": "2024-07-15 08:00:00.000+00",
    "interval_end": "2024-10-07 18:00:00.000+00",
}

model_chain = {
    "modules": [
        {
            "model": "clear_sky_model",
            "inputs": {
                "panel_tilt": {
                    "value": 10.0
                },
                "panel_azimuth": {
                    "value": 183.0
                },
                "model": {
                    "value": "rest2"
                }
            },
            "outputs": {
                "clear_sky_poa_irradiance": {
                    "metric": "clear_sky_poa_irradiance",
                },
            },
        },
        {
            "model": "dc_generation_model",
            "inputs": {
                "clear_sky_poa_irradiance": {
                    "metric": "clear_sky_poa_irradiance",
                    "transformations": []
                },
            },
            "outputs": {
                "total_dc_generation": {
                    "metric": "total_dc_generation",
                },
            },
        }
    ],
    "input_table": "input_table_for_this_chain",
    "output_table": "optionally_save_results_to_here",
    "interval_start": "2024-10-15 08:00:00.000+00",
    "interval_end": "2024-10-17 18:00:00.000+00",
}
