from typing import List, Dict, Any

import pandas as pd

from modmod.transformation_strategies import *


class DataTransform:
    def __init__(self, model: str, parameters: List[Dict[str, Any]]):
        self.model = model
        self.parameters = parameters
        self.strategy = self._get_strategy()

    def _get_strategy(self) -> TransformationStrategy:
        strategies = {
            "moving_average_transform": MovingAverageTransform,
            "time_offset_transform": TimeOffsetTransform,
            "test_transform": TestTransform,
        }
        if self.model not in strategies:
            raise ValueError(f"Unknown transformation model: {self.model}")
        return strategies[self.model](self.parameters)

    def apply(self, data: pd.Series) -> pd.Series:
        return self.strategy.apply(data)
