import os
import re
from pathlib import Path

from .file_operations import check_existing_file, update_init_file, remove_from_init_file, update_init_file_for_rename


def create_model_file(model_name):
    if not model_name.endswith('_model'):
        model_name += '_model'

    class_name = ''.join(word.capitalize() for word in model_name.split('_'))
    file_name = f"{model_name}.py"
    file_path = Path('modmod/models') / file_name

    check_existing_file(file_path)

    content = f"""import pandas as pd

from modmod.models import CalculationModel


class {class_name}(CalculationModel):
    \"""
    Replace this docstring with a description of {class_name}
    \"""
    
    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        # TODO: Implement your calculation logic here
        return accumulator
"""

    os.makedirs(file_path.parent, exist_ok=True)
    with open(file_path, 'w') as f:
        f.write(content)

    print(f"[INFO] Created new model file: {file_path}")


def update_model_map(model_name):
    if not model_name.endswith('_model'):
        model_name += '_model'

    map_file_path = Path('modmod/calculation_model_helper.py')
    class_name = ''.join(word.capitalize() for word in model_name.split('_'))

    with open(map_file_path, 'r') as f:
        content = f.read()

    map_pattern = r'model_map\s*=\s*\{[^}]*\}'
    map_match = re.search(map_pattern, content, re.DOTALL)

    if map_match:
        map_str = map_match.group(0)
        last_entry_indent = re.search(r'^(\s+)"', map_str, re.MULTILINE)
        indent = last_entry_indent.group(1) if last_entry_indent else '    '

        new_entry = f'{indent}"{model_name}": {class_name},'

        map_lines = map_str.split('\n')

        map_lines.insert(-1, new_entry)

        updated_map = '\n'.join(map_lines)

        updated_content = content.replace(map_str, updated_map)

        with open(map_file_path, 'w') as f:
            f.write(updated_content)

        print(f"[INFO] Updated model map in {map_file_path}")
    else:
        print("[ERROR] Could not find model_map in calculation_model_helper.py")


def create_new_model(model_name):
    try:
        create_model_file(model_name)
        update_model_map(model_name)
        update_init_file(model_name, 'models')
    except FileExistsError as e:
        print(f"[ERROR] {e}")
        print(f"[INFO] Model creation aborted.")


def remove_model_file(model_name):
    if not model_name.endswith('_model'):
        model_name += '_model'

    file_name = f"{model_name}.py"
    file_path = Path('modmod/models') / file_name

    if not file_path.exists():
        raise FileNotFoundError(f"Model file {file_path} does not exist.")

    os.remove(file_path)
    print(f"[INFO] Removed model file: {file_path}")


def remove_from_model_map(model_name):
    if not model_name.endswith('_model'):
        model_name += '_model'

    map_file_path = Path('modmod/calculation_model_helper.py')

    with open(map_file_path, 'r') as f:
        content = f.read()

    map_pattern = r'model_map\s*=\s*\{[^}]*\}'
    map_match = re.search(map_pattern, content, re.DOTALL)

    if map_match:
        map_str = map_match.group(0)
        map_lines = map_str.split('\n')

        updated_lines = [line for line in map_lines if model_name not in line]
        updated_map = '\n'.join(updated_lines)

        updated_content = content.replace(map_str, updated_map)

        with open(map_file_path, 'w') as f:
            f.write(updated_content)

        print(f"[INFO] Removed {model_name} from model map in {map_file_path}")
    else:
        print("[ERROR] Could not find model_map in calculation_model_helper.py")


def remove_model(model_name):
    try:
        remove_model_file(model_name)
        remove_from_model_map(model_name)
        remove_from_init_file(model_name, 'models')
        print(f"[INFO] Successfully removed model: {model_name}")
    except FileNotFoundError as e:
        print(f"[ERROR] {e}")
        print("[INFO] Model removal aborted.")


def rename_model_file(old_name, new_name):
    if not old_name.endswith('_model'):
        old_name += '_model'
    if not new_name.endswith('_model'):
        new_name += '_model'

    old_file_path = Path('modmod/models') / f"{old_name}.py"
    new_file_path = Path('modmod/models') / f"{new_name}.py"

    if not old_file_path.exists():
        raise FileNotFoundError(f"Model file {old_file_path} does not exist.")
    if new_file_path.exists():
        raise FileExistsError(f"A file already exists at {new_file_path}. Please choose a different name.")

    os.rename(old_file_path, new_file_path)
    print(f"[INFO] Renamed model file from {old_file_path} to {new_file_path}")

    # Update the content of the file
    with open(new_file_path, 'r') as f:
        content = f.read()

    old_class_name = ''.join(word.capitalize() for word in old_name.split('_'))
    new_class_name = ''.join(word.capitalize() for word in new_name.split('_'))
    updated_content = content.replace(old_class_name, new_class_name)

    with open(new_file_path, 'w') as f:
        f.write(updated_content)


def update_model_map_for_rename(old_name, new_name):
    if not old_name.endswith('_model'):
        old_name += '_model'
    if not new_name.endswith('_model'):
        new_name += '_model'

    map_file_path = Path('modmod/calculation_model_helper.py')

    with open(map_file_path, 'r') as f:
        content = f.read()

    old_class_name = ''.join(word.capitalize() for word in old_name.split('_'))
    new_class_name = ''.join(word.capitalize() for word in new_name.split('_'))

    updated_content = content.replace(f'"{old_name}": {old_class_name}', f'"{new_name}": {new_class_name}')

    with open(map_file_path, 'w') as f:
        f.write(updated_content)

    print(f"[INFO] Updated model map in {map_file_path}")


def rename_model(old_name, new_name):
    try:
        rename_model_file(old_name, new_name)
        update_model_map_for_rename(old_name, new_name)
        update_init_file_for_rename(old_name, new_name, 'models')
        print(f"[INFO] Successfully renamed model from {old_name} to {new_name}")
    except (FileNotFoundError, FileExistsError) as e:
        print(f"[ERROR] {e}")
        print("[INFO] Model renaming aborted.")
