import os
import re
from pathlib import Path

from .file_operations import check_existing_file, update_init_file, remove_from_init_file, update_init_file_for_rename


def create_transformation_file(transformation_name):
    if not transformation_name.endswith('_transform'):
        transformation_name += '_transform'

    class_name = ''.join(word.capitalize() for word in transformation_name.split('_'))
    file_name = f"{transformation_name}.py"
    file_path = Path('modmod/transformation_strategies') / file_name

    check_existing_file(file_path)

    content = f"""import pandas as pd

from modmod.transformation_strategies import TransformationStrategy


class {class_name}(TransformationStrategy):
    def apply(self, data: pd.Series) -> pd.Series:
        print("Applying {transformation_name} transformation")
        # TODO: Implement your transformation logic here
        return data
"""

    os.makedirs(file_path.parent, exist_ok=True)
    with open(file_path, 'w') as f:
        f.write(content)

    print(f"[INFO] Created new transformation file: {file_path}")


def update_transformation_map(transformation_name):
    if not transformation_name.endswith('_transform'):
        transformation_name += '_transform'

    map_file_path = Path('modmod/data_transform.py')
    class_name = ''.join(word.capitalize() for word in transformation_name.split('_'))

    with open(map_file_path, 'r') as f:
        content = f.read()

    strategies_pattern = r'strategies\s*=\s*\{[^}]*\}'
    strategies_match = re.search(strategies_pattern, content, re.DOTALL)

    if strategies_match:
        strategies_str = strategies_match.group(0)
        strategies_lines = strategies_str.split('\n')

        last_element = strategies_lines[-2].strip()  # -2 because -1 is the closing brace
        if not last_element.endswith(','):
            strategies_lines[-2] = strategies_lines[-2] + ','

        last_entry_indent = re.search(r'^(\s+)"', strategies_str, re.MULTILINE)
        indent = last_entry_indent.group(1) if last_entry_indent else '        '

        new_entry = f'{indent}"{transformation_name}": {class_name},'

        strategies_lines.insert(-1, new_entry)

        updated_strategies = '\n'.join(strategies_lines)

        updated_content = content.replace(strategies_str, updated_strategies)

        with open(map_file_path, 'w') as f:
            f.write(updated_content)

        print(f"[INFO] Updated transformation map in {map_file_path}")
    else:
        print("[ERROR] Could not find strategies dictionary in data_transform.py")


def create_new_transformation(transformation_name):
    try:
        create_transformation_file(transformation_name)
        update_transformation_map(transformation_name)
        update_init_file(transformation_name, 'transformation_strategies')
    except FileExistsError as e:
        print(f"[ERROR] {e}")
        print("[INFO] Transformation creation aborted.")


def remove_transformation_file(transformation_name):
    if not transformation_name.endswith('_transform'):
        transformation_name += '_transform'

    file_name = f"{transformation_name}.py"
    file_path = Path('modmod/transformation_strategies') / file_name

    if not file_path.exists():
        raise FileNotFoundError(f"Transformation file {file_path} does not exist.")

    os.remove(file_path)
    print(f"[INFO] Removed transformation file: {file_path}")


def remove_from_transformation_map(transformation_name):
    if not transformation_name.endswith('_transform'):
        transformation_name += '_transform'

    map_file_path = Path('modmod/data_transform.py')

    with open(map_file_path, 'r') as f:
        content = f.read()

    strategies_pattern = r'strategies\s*=\s*\{[^}]*\}'
    strategies_match = re.search(strategies_pattern, content, re.DOTALL)

    if strategies_match:
        strategies_str = strategies_match.group(0)
        strategies_lines = strategies_str.split('\n')

        updated_lines = [line for line in strategies_lines if transformation_name not in line]
        updated_strategies = '\n'.join(updated_lines)

        updated_content = content.replace(strategies_str, updated_strategies)

        with open(map_file_path, 'w') as f:
            f.write(updated_content)

        print(f"[INFO] Removed {transformation_name} from transformation map in {map_file_path}")
    else:
        print("[ERROR] Could not find strategies dictionary in data_transform.py")


def remove_transformation(transformation_name):
    try:
        remove_transformation_file(transformation_name)
        remove_from_transformation_map(transformation_name)
        remove_from_init_file(transformation_name, 'transformation_strategies')
        print(f"[INFO] Successfully removed transformation: {transformation_name}")
    except FileNotFoundError as e:
        print(f"[ERROR] {e}")
        print("[INFO] Transformation removal aborted.")


def rename_transformation_file(old_name, new_name):
    if not old_name.endswith('_transform'):
        old_name += '_transform'
    if not new_name.endswith('_transform'):
        new_name += '_transform'

    old_file_path = Path('modmod/transformation_strategies') / f"{old_name}.py"
    new_file_path = Path('modmod/transformation_strategies') / f"{new_name}.py"

    if not old_file_path.exists():
        raise FileNotFoundError(f"Transformation file {old_file_path} does not exist.")
    if new_file_path.exists():
        raise FileExistsError(f"A file already exists at {new_file_path}. Please choose a different name.")

    os.rename(old_file_path, new_file_path)
    print(f"[INFO] Renamed transformation file from {old_file_path} to {new_file_path}")

    # Update the content of the file
    with open(new_file_path, 'r') as f:
        content = f.read()

    old_class_name = ''.join(word.capitalize() for word in old_name.split('_'))
    new_class_name = ''.join(word.capitalize() for word in new_name.split('_'))
    updated_content = content.replace(old_class_name, new_class_name)

    with open(new_file_path, 'w') as f:
        f.write(updated_content)


def update_transformation_map_for_rename(old_name, new_name):
    if not old_name.endswith('_transform'):
        old_name += '_transform'
    if not new_name.endswith('_transform'):
        new_name += '_transform'

    map_file_path = Path('modmod/data_transform.py')

    with open(map_file_path, 'r') as f:
        content = f.read()

    old_class_name = ''.join(word.capitalize() for word in old_name.split('_'))
    new_class_name = ''.join(word.capitalize() for word in new_name.split('_'))

    old_key = old_name.replace('_transform', '')
    new_key = new_name.replace('_transform', '')

    updated_content = content.replace(f'"{old_key}": {old_class_name}', f'"{new_key}": {new_class_name}')

    with open(map_file_path, 'w') as f:
        f.write(updated_content)

    print(f"[INFO] Updated transformation map in {map_file_path}")


def rename_transformation(old_name, new_name):
    try:
        rename_transformation_file(old_name, new_name)
        update_transformation_map_for_rename(old_name, new_name)
        update_init_file_for_rename(old_name, new_name, 'transformation_strategies')
        print(f"[INFO] Successfully renamed transformation from {old_name} to {new_name}")
    except (FileNotFoundError, FileExistsError) as e:
        print(f"[ERROR] {e}")
        print("[INFO] Transformation renaming aborted.")
