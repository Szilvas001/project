import re
from pathlib import Path


def check_existing_file(file_path):
    if file_path.exists():
        raise FileExistsError(f"A file already exists at {file_path}. Please choose a different name.")


def update_init_file(component_name, component_type):
    if component_type == 'models':
        if not component_name.endswith('_model'):
            component_name += '_model'
    elif component_type == 'transformation_strategies':
        if not component_name.endswith('_transform'):
            component_name += '_transform'

    init_file_path = Path(f'modmod/{component_type}') / '__init__.py'
    class_name = ''.join(word.capitalize() for word in component_name.split('_'))

    with open(init_file_path, 'r') as f:
        content = f.readlines()

    import_statement = f"from .{component_name} import {class_name}\n"
    if import_statement not in content:
        # Find the index of the last import statement
        last_import_index = -1
        for i, line in enumerate(content):
            if re.match(r'^(from|import)\s', line):
                last_import_index = i

        # Insert the new import statement after the last import
        if last_import_index != -1:
            content.insert(last_import_index + 1, import_statement)
        else:
            # If no imports found, insert at the beginning of the file
            content.insert(0, import_statement)

    all_start = next(i for i, line in enumerate(content) if line.startswith('__all__'))
    all_end = next(i for i, line in enumerate(content[all_start:], all_start) if line.strip() == ']')

    all_content = content[all_start:all_end + 1]
    if f'"{class_name}"' not in ''.join(all_content):
        all_content.insert(-1, f'    "{class_name}",\n')

    content[all_start:all_end + 1] = all_content

    with open(init_file_path, 'w') as f:
        f.writelines(content)

    print(f"[INFO] Updated {init_file_path}")


def remove_from_init_file(component_name, component_type):
    if component_type == 'models':
        if not component_name.endswith('_model'):
            component_name += '_model'
    elif component_type == 'transformation_strategies':
        if not component_name.endswith('_transform'):
            component_name += '_transform'

    init_file_path = Path(f'modmod/{component_type}') / '__init__.py'
    class_name = ''.join(word.capitalize() for word in component_name.split('_'))

    with open(init_file_path, 'r') as f:
        content = f.readlines()

    # Remove import statement
    content = [line for line in content if f"from .{component_name} import {class_name}" not in line]

    # Remove from __all__
    all_start = next(i for i, line in enumerate(content) if line.startswith('__all__'))
    all_end = next(i for i, line in enumerate(content[all_start:], all_start) if line.strip() == ']')

    all_content = content[all_start:all_end + 1]
    all_content = [line for line in all_content if class_name not in line]

    content[all_start:all_end + 1] = all_content

    with open(init_file_path, 'w') as f:
        f.writelines(content)

    print(f"[INFO] Removed {component_name} from {init_file_path}")


def update_init_file_for_rename(old_name, new_name, component_type):
    if component_type == 'models':
        if not old_name.endswith('_model'):
            old_name += '_model'
        if not new_name.endswith('_model'):
            new_name += '_model'
    elif component_type == 'transformation_strategies':
        if not old_name.endswith('_transform'):
            old_name += '_transform'
        if not new_name.endswith('_transform'):
            new_name += '_transform'

    init_file_path = Path(f'modmod/{component_type}') / '__init__.py'
    old_class_name = ''.join(word.capitalize() for word in old_name.split('_'))
    new_class_name = ''.join(word.capitalize() for word in new_name.split('_'))

    with open(init_file_path, 'r') as f:
        content = f.read()

    # Update import statement
    old_import = f"from .{old_name} import {old_class_name}"
    new_import = f"from .{new_name} import {new_class_name}"
    updated_content = content.replace(old_import, new_import)

    # Update __all__ list
    updated_content = updated_content.replace(f'"{old_class_name}"', f'"{new_class_name}"')

    with open(init_file_path, 'w') as f:
        f.write(updated_content)

    print(f"[INFO] Updated {init_file_path}")
