import argparse

from .model_operations import create_new_model, remove_model, rename_model
from .transformation_operations import create_new_transformation, remove_transformation, rename_transformation


def main():
    parser = argparse.ArgumentParser(description="ModMod CLI tool")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # New command
    new_parser = subparsers.add_parser('new', aliases=['n'], help="Create new components")
    new_subparsers = new_parser.add_subparsers(dest="component", help="Component to create")

    model_parser = new_subparsers.add_parser('model', aliases=['m'], help="Create a new model")
    model_parser.add_argument("name", help="Name of the new model (without '_model' suffix)")

    transformation_parser = new_subparsers.add_parser('transformation', aliases=['t'],
                                                      help="Create a new transformation")
    transformation_parser.add_argument("name",
                                       help="Name of the new transformation (with or without '_transform' suffix)")

    # Remove command
    remove_parser = subparsers.add_parser('delete', aliases=['d'], help="Delete existing components")
    remove_subparsers = remove_parser.add_subparsers(dest="component", help="Component to delete")

    remove_model_parser = remove_subparsers.add_parser('model', aliases=['m'], help="Delete an existing model")
    remove_model_parser.add_argument("name", help="Name of the model to delete (with or without '_model' suffix)")

    remove_transformation_parser = remove_subparsers.add_parser('transformation', aliases=['t'],
                                                                help="Delete an existing transformation")
    remove_transformation_parser.add_argument("name",
                                              help="Name of the transformation to remove (with or without '_transform' suffix)")

    # Rename command
    rename_parser = subparsers.add_parser('rename', aliases=['r'], help="Rename existing components")
    rename_subparsers = rename_parser.add_subparsers(dest="component", help="Component to rename")

    rename_model_parser = rename_subparsers.add_parser('model', aliases=['m'], help="Rename an existing model")
    rename_model_parser.add_argument("old_name", help="Current name of the model (without '_model' suffix)")
    rename_model_parser.add_argument("new_name", help="New name for the model (without '_model' suffix)")

    rename_transformation_parser = rename_subparsers.add_parser('transformation', aliases=['t'],
                                                                help="Rename an existing transformation")
    rename_transformation_parser.add_argument("old_name",
                                              help="Current name of the transformation (with or without '_transform' suffix)")
    rename_transformation_parser.add_argument("new_name",
                                              help="New name for the transformation (with or without '_transform' suffix)")

    args = parser.parse_args()

    if args.command in ['new', 'n']:
        if args.component in ['model', 'm']:
            create_new_model(args.name)
        elif args.component in ['transformation', 't']:
            create_new_transformation(args.name)
        else:
            new_parser.print_help()
    elif args.command in ['delete', 'd']:
        if args.component in ['model', 'm']:
            remove_model(args.name)
        elif args.component in ['transformation', 't']:
            remove_transformation(args.name)
        else:
            remove_parser.print_help()
    elif args.command in ['rename', 'r']:
        if args.component in ['model', 'm']:
            rename_model(args.old_name, args.new_name)
        elif args.component in ['transformation', 't']:
            rename_transformation(args.old_name, args.new_name)
        else:
            rename_parser.print_help()
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
