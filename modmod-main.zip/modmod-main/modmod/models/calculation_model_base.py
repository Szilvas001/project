from abc import ABC, abstractmethod
from datetime import datetime
from typing import List, Dict, Any

import pandas as pd

from modmod.date_range import DateRange
from modmod.parameter import InputParameter, OutputParameter


class CalculationModel(ABC):
    def __init__(self, input_parameters: List[InputParameter], output_parameters: List[OutputParameter]):
        self.input_parameters = input_parameters
        self.output_parameters = output_parameters

    @property
    def required_non_fixed_input_parameters(self) -> List[str]:
        return [p.metric for p in self.input_parameters if p.metric]

    @property
    def required_input_parameters(self) -> List[str]:
        return [p.metric for p in self.input_parameters]

    @property
    def required_fixed_input_parameters(self) -> Dict[str, Any]:
        return {p.name: p.value for p in self.input_parameters if p.value}

    @abstractmethod
    def execute(self, input_df: pd.DataFrame, date_range: DateRange) -> pd.DataFrame:
        pass

    @property
    def required_output_parameters(self) -> List[str]:
        return [p.metric for p in self.output_parameters]

    def calculate(self, accumulator: pd.DataFrame, date_range: DateRange) -> pd.DataFrame:
        start_time = datetime.now()
        accumulator_copy = accumulator.copy()

        for input_parameter in self.input_parameters:
            if input_parameter.metric:
                # Check if metric column exists in the original accumulator before renaming in copy
                if input_parameter.metric in accumulator.columns: # Check original accumulator
                    # Ensure the column is copied before renaming if not already present
                    if input_parameter.metric not in accumulator_copy.columns:
                         accumulator_copy[input_parameter.metric] = accumulator[input_parameter.metric]

                    accumulator_copy.rename(columns={input_parameter.metric: input_parameter.name}, inplace=True)

                    if input_parameter.transformations:
                        # Apply transformation only if the column exists after potential rename
                        if input_parameter.name in accumulator_copy.columns:
                             accumulator_copy[input_parameter.name] = input_parameter.transform(
                                 accumulator_copy[input_parameter.name])
                        else:
                             print(f"[WARN] Column '{input_parameter.name}' (from metric '{input_parameter.metric}') not found for transformation in {self.__class__.__name__}.")

            elif input_parameter.value:
                # Add fixed value. accumulator_copy now guaranteed to have an index if it started empty.
                # If it started non-empty, this assigns the value to the existing index.
                accumulator_copy[input_parameter.name] = input_parameter.value

            # If we want the fixed parameters to be written to the output, uncomment the following lines
            # if input_parameter.value:
            #     accumulator[input_parameter.name] = accumulator_copy[input_parameter.name]

        print(f"[DEBUG] accumulator_copy before execute: \n{accumulator_copy.head()}")
        new_accumulator = self.execute(accumulator_copy, date_range)
        print(f"[DEBUG] new_accumulator returned by execute: \n{new_accumulator.head()}")
        if self.required_output_parameters:
            for output_parameter in self.output_parameters:
                # Use output_parameter.name which should be the column name in new_accumulator
                if output_parameter.name not in new_accumulator.columns:
                    raise ValueError(
                        f"{self.__class__.__name__} did not write output parameter name '{output_parameter.name}' (metric: '{output_parameter.metric}') into its result DataFrame")
        # Merge results back into the original accumulator using the metric name
        for output_parameter in self.output_parameters:
            # Ensure the column exists in the result before trying to assign it
            if output_parameter.name in new_accumulator.columns:
                 accumulator[output_parameter.metric] = new_accumulator[output_parameter.name]
            else:
                 # This case is already checked above, but being defensive
                 print(f"[ERROR] Output column '{output_parameter.name}' missing in result from {self.__class__.__name__}")

        if self.__class__.__name__ == "IntervalIntegralModel":
            accumulator = new_accumulator

        end_time = datetime.now()
        total_time = end_time - start_time
        print(f"[LOG] Model {self.__class__.__name__} executed in {total_time.seconds} seconds")

        return accumulator
