import pandas as pd
import pvlib

from modmod.models import CalculationModel


class AbsoluteAirmassModel(CalculationModel):
    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        relative_airmass = pd.to_numeric(accumulator["relative_airmass"], errors='raise').values
        pressure_hpa = pd.to_numeric(accumulator["ha_pressure_pa"], errors='raise')
        pressure_pa = (pressure_hpa * 100).values
        accumulator["absolute_airmass"] = pvlib.atmosphere.get_absolute_airmass(
            airmass_relative=relative_airmass, pressure=pressure_pa
        )
        return accumulator
