from datetime import datetime

import pandas as pd
import requests

from modmod.models import CalculationModel


class CloudCoverPullingOpenmeteoModel(CalculationModel):
    """
    A model to pull cloud cover data from the OpenMeteo API and process it.
    """

    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        datetime_now = pd.Timestamp.now()
        current_date = datetime_now.strftime('%Y-%m-%d')
        formatted_datetime = datetime_now.strftime("%Y-%m-%dT%H:%M:%S.%f%z")

        openmeteo_api_url = f"https://api.open-meteo.com/v1/forecast?latitude=47.4707972&longitude=19.0615991&current=cloud_cover&hourly=cloud_cover,cloud_cover_low,cloud_cover_mid,cloud_cover_high&timezone=Europe%2FBerlin&start_date={current_date}&end_date={current_date}"
        response = requests.get(openmeteo_api_url)
        data = response.json()

        print(f"[INFO] OpenMeteo API response: {data}")

        current_cloud_cover = data['current']['cloud_cover']

        current_time = datetime.fromisoformat(data['current']['time'])
        forecast_times = [datetime.fromisoformat(t) for t in data['hourly']['time']]
        closest_time = min(forecast_times, key=lambda d: abs(d - current_time))
        closest_time_index = forecast_times.index(closest_time)

        cloud_cover_low = data['hourly']['cloud_cover_low'][closest_time_index]
        cloud_cover_medium = data['hourly']['cloud_cover_mid'][closest_time_index]
        cloud_cover_high = data['hourly']['cloud_cover_high'][closest_time_index]
        cloud_cover_total = data['hourly']['cloud_cover'][closest_time_index]

        new_accumulator = pd.DataFrame(
            data=[[current_cloud_cover, cloud_cover_low, cloud_cover_medium, cloud_cover_high, cloud_cover_total]],
            index=[formatted_datetime],
            columns=["current_cloud_cover", "cloud_cover_low", "cloud_cover_medium", "cloud_cover_high",
                     "cloud_cover_total"]
        )

        accumulator = pd.concat([accumulator, new_accumulator])
        return accumulator
