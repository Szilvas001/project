import pandas as pd

from modmod.models import CalculationModel


class OpenweathermapPullingModel(CalculationModel):
    """
    Replace this docstring with a description of OpenweathermapPullingModel
    """
    
    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        # TODO: Implement your calculation logic here
        return accumulator
