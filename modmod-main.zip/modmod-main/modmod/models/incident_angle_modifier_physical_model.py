import pandas as pd
import pvlib

from modmod.models import CalculationModel


"""
Physical IAM model: Calculate IAM using AOI and model-specific parameters.

Inputs:
  - aoi
  - irradiance_without_iam
  - glazing_thickness_L
  # TODO
  # - effective_index_of_refraction_n
  # - glazing_extinction_coefficient_K
  # - effective_index_of_refraction_anti_reflective_n_ar
Outputs:
  - iam
  - irradiance_with_iam
"""
class IncidentAngleModifierPhysicalModel(CalculationModel):
    @classmethod
    def calc_iam(cls, accumulator) -> pd.Series:
        return pvlib.iam.physical(accumulator["aoi"], L=accumulator["glazing_thickness_L"])

    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        iams = self.calc_iam(accumulator)
        accumulator["iam"] = iams
        accumulator["irradiance_with_iam"] = accumulator["irradiance_without_iam"] * iams

        return accumulator
