import numpy as np
import pandas as pd
import pvlib

from modmod.models import CalculationModel


class AngleOfIncidenceModel(CalculationModel):
    """
    Calculates the angle of incidence
    """

    @classmethod
    def calc_aoi(cls, accumulator) -> np.ndarray:
        solar_zenith = accumulator["solar_zenith"].values
        solar_azimuth = accumulator["solar_azimuth"].values
        panel_tilt = accumulator["panel_tilt"].iloc[0]
        panel_azimuth = accumulator["panel_azimuth"].iloc[0]

        return pvlib.irradiance.aoi(
            surface_tilt=panel_tilt,
            surface_azimuth=panel_azimuth,
            solar_zenith=solar_zenith,
            solar_azimuth=solar_azimuth
        )

    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        accumulator["aoi"] = self.calc_aoi(accumulator)

        return accumulator
