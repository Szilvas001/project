import pandas as pd
import pvlib

from modmod.models import CalculationModel


"""
Ashrae IAM model: Calculate IAM using AOI and model-specific parameters.

Inputs:
  - aoi
  - irradiance_without_iam
  - iam_aoi_adjuster_b
Outputs:
  - iam
  - irradiance_with_iam
"""
class IncidentAngleModifierAshraeModel(CalculationModel):
    @classmethod
    def calc_iam(cls, accumulator) -> pd.Series:
        return pvlib.iam.ashrae(accumulator["aoi"], b=accumulator["iam_aoi_adjuster_b"])

    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        iams = self.calc_iam(accumulator)
        accumulator["iam"] = iams
        accumulator["irradiance_with_iam"] = accumulator["irradiance_without_iam"] * iams

        return accumulator
