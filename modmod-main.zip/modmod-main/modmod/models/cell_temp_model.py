import numpy as np
import pandas as pd
import pvlib

from modmod.models import CalculationModel


class CellTempModel(CalculationModel):
    """
    Calculates the cell temperature of a PV system based on module temperature, irradiance, and module specifications.
    """

    @classmethod
    def calculate_cell_temp_sandia(cls, module_temp: np.ndarray, poa_global: np.ndarray,
                                   sandia_module_mounting_key: str):
        temp_model_params_sandia = pvlib.temperature.TEMPERATURE_MODEL_PARAMETERS["sapm"]
        if sandia_module_mounting_key in temp_model_params_sandia.keys():
            delta_t = temp_model_params_sandia[sandia_module_mounting_key]["deltaT"]
            return pvlib.temperature.sapm_cell_from_module(module_temp, poa_global, delta_t)
        else:
            raise KeyError(f"Key '{sandia_module_mounting_key}' is not present in {temp_model_params_sandia}!")

    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        module_temp = accumulator["ha_module_temp"].astype(float).values
        poa_irrad = accumulator["ha_poa_irrad"].astype(float).values
        mounting_key = accumulator["mounting_key"].iloc[0]

        cell_temp = self.calculate_cell_temp_sandia(module_temp, poa_irrad, mounting_key)

        accumulator["cell_temp"] = cell_temp

        return accumulator
