import pandas as pd
import pvlib

from modmod.models import CalculationModel


class SolarPositionModel(CalculationModel):
    @classmethod
    def calc_solarpos(cls, dates: pd.DatetimeIndex, accumulator, apparent: bool = True) -> pd.DataFrame:
        if not apparent:
            return pvlib.solarposition.get_solarposition(
                time=dates,
                latitude=accumulator['latitude'].iloc[0],
                longitude=accumulator['longitude'].iloc[0],
                temperature=accumulator['ha_temperature'].astype(float).values
            )
        else:
            return pvlib.solarposition.get_solarposition(
                time=dates,
                latitude=accumulator['latitude'].iloc[0],
                longitude=accumulator['longitude'].iloc[0],
                altitude=accumulator['altitude'].iloc[0],
                pressure=accumulator['ha_pressure_pa'].astype(float).values,
                temperature=accumulator['ha_temperature'].astype(float).values
            )

    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        df_solarpos = self.calc_solarpos(accumulator.index, accumulator)
        accumulator["solar_zenith"] = df_solarpos["zenith"].values
        accumulator["solar_azimuth"] = df_solarpos["azimuth"].values
        return accumulator
