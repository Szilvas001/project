import pandas as pd

from modmod.models import CalculationModel


class IntervalIntegralModel(CalculationModel):
    """
    A model to calculate interval integrals for measured and clear sky irradiance for multiple models.
    """

    @classmethod
    def execute(cls, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        print(f"Integrals on accumulator: \n{accumulator}")

        # Ensure timestamp is the index
        if 'timestamp' in accumulator.columns:
            accumulator.set_index('timestamp', inplace=True)

        # Get the interval from the first row
        interval = accumulator['interval'].iloc[0]

        # Dictionary to map intervals to hours
        interval_to_hours = {
            '15min': 0.25,
            '30min': 0.5,
            '1h': 1,
            '4h': 4,
            '8h': 8,
            '24h': 24
        }

        # Get the number of hours for the interval
        if interval != 'now':
            hours = interval_to_hours.get(interval)
            if hours is None:
                raise ValueError(f"Unsupported interval: {interval}")
            print(f"Interval: {interval}, hours: {hours}")
        else:
            # For 'now', we set hours to 1 (or adjust based on your needs)
            hours = 1
            print("Interval is 'now', skipping resampling but generating integral fields with current values")

        # Handling multiple models by splitting the string and iterating through each
        models = accumulator['model'].iloc[0].split(',')

        if interval != 'now':
            # Resample the data
            resampled = accumulator.resample(interval, closed='right', label='right').agg({
                'measured_irradiance': 'mean',
                'interval': 'last'
            })

            # Calculate measured integral (same for all models)
            resampled['measured_integral'] = resampled['measured_irradiance'] * hours

            # Calculate integrals for each clear sky model
            for model in models:
                model = model.strip()
                clear_sky_irradiance_col = f'clear_sky_poa_irradiance_{model}'

                if clear_sky_irradiance_col not in accumulator.columns:
                    raise ValueError(f"Missing clear sky irradiance column for model: {model}")

                # Add the clear sky irradiance to the resampling
                resampled[clear_sky_irradiance_col] = accumulator[clear_sky_irradiance_col].resample(
                    interval, closed='right', label='right').mean()

                # Calculate the integral for clear sky irradiance for each model
                resampled[f'clear_sky_integral_{model}'] = resampled[clear_sky_irradiance_col] * hours

            print(f"Resampled accumulator with integrals: \n{resampled}")

            return resampled
        else:
            # For 'now', calculate the integral fields without resampling
            accumulator['measured_integral'] = accumulator['measured_irradiance'] * hours

            for model in models:
                model = model.strip()
                clear_sky_irradiance_col = f'clear_sky_poa_irradiance_{model}'

                if clear_sky_irradiance_col not in accumulator.columns:
                    raise ValueError(f"Missing clear sky irradiance column for model: {model}")

                # Calculate the integral for clear sky irradiance for each model
                accumulator[f'clear_sky_integral_{model}'] = accumulator[clear_sky_irradiance_col] * hours

            print(f"Accumulator with integrals (without resampling): \n{accumulator}")

            return accumulator
