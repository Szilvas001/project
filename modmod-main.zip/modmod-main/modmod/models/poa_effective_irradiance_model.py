from datetime import datetime
from zoneinfo import ZoneInfo

import pandas as pd
import pvlib

from modmod.models import CalculationModel
from modmod.utils import InputHelper
from modmod.weather_api import OpenMeteoAPI


class PoaEffectiveIrradianceModel(CalculationModel):
    @classmethod
    def calc_spectral_factor(cls, precp_water: float, abs_airmass: float) -> float:
        return pvlib.spectrum.spectral_factor_firstsolar(
            precipitable_water=precp_water,
            airmass_absolute=abs_airmass,
            module_type="monosi"
        )[0]

    @classmethod
    def calc_absolute_airmass(cls, rel_airmass: float, weather_api: OpenMeteoAPI) -> float:
        pressure, _ = weather_api.get_most_recent_current_surface_pressure_with_timestamp(call_api=True)
        return pvlib.atmosphere.get_absolute_airmass(
            airmass_relative=rel_airmass, pressure=pressure
        )

    @classmethod
    def calc_relative_airmass(cls, zenith: float) -> float:
        return pvlib.atmosphere.get_relative_airmass(zenith)

    @classmethod
    def calc_apparent_zenith(cls, weatherApi: OpenMeteoAPI) -> float:
        date = datetime.now(tz=ZoneInfo('Europe/Budapest'))
        return InputHelper.calc_solarpos(date, weatherApi, apparent=True).loc[date, "apparent_zenith"]

    @classmethod
    def calc_precp_water(cls, weatherApi: OpenMeteoAPI) -> float:
        air_temp, date = weatherApi.get_most_recent_current_temp_with_timestamp(call_api=True)
        rel_humidity, date = weatherApi.get_most_recent_current_rel_humidity_with_timestamp(call_api=True)
        return pvlib.atmosphere.gueymard94_pw(air_temp, rel_humidity)

    @classmethod
    def calc_spectral_factor_from_weather(cls, weather_api: OpenMeteoAPI) -> float:
        precp_water = cls.calc_precp_water(weather_api)

        apparent_zenith = cls.calc_apparent_zenith(weather_api)

        relative_airmass = cls.calc_relative_airmass(apparent_zenith)
        absolute_airmass = cls.calc_absolute_airmass(relative_airmass, weather_api)

        return cls.calc_spectral_factor(precp_water, absolute_airmass)

    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        poa_irrad_value = accumulator["ha_poa_irrad"].astype(float).values

        iam_ashrae = accumulator["iam"].astype(float).values

        spectral_factor = accumulator["spectral_factor"].values

        effective_poa_irrad = poa_irrad_value * spectral_factor * iam_ashrae

        accumulator["poa_effective_irradiance"] = effective_poa_irrad

        return accumulator
