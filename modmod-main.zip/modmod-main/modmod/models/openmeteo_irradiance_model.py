import pandas as pd
import requests

from modmod.models import CalculationModel


class OpenmeteoIrradianceModel(CalculationModel):
    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        # Parse the date strings to datetime objects with UTC timezone
        start_date_dt = pd.to_datetime(date_range.start_date, utc=True)
        end_date_dt = pd.to_datetime(date_range.end_date, utc=True)

        # Convert datetime objects to 'YYYY-MM-DD' strings for the API
        start_date_str = start_date_dt.strftime('%Y-%m-%d')
        end_date_str = end_date_dt.strftime('%Y-%m-%d')

        tilt = pd.to_numeric(accumulator['tilt'].iloc[0])

        url = "https://api.open-meteo.com/v1/forecast"
        params = {
            "latitude": "47.523618",
            "longitude": "19.012776",
            "hourly": "shortwave_radiation_instant,diffuse_radiation_instant,"
                      "direct_normal_irradiance_instant,global_tilted_irradiance_instant",
            "start_date": start_date_str,
            "end_date": end_date_str,
            "tilt": tilt,
            "azimuth": "3",
            "timezone": "UTC"
        }
        response = requests.get(url, params=params)

        if response.status_code == 200:
            data = response.json()
        else:
            print(f"Error {response.status_code}: {response.text}")
            return accumulator  # Return the original accumulator if API call fails

        openmeteo_df = pd.DataFrame(data['hourly'])
        openmeteo_df['time'] = pd.to_datetime(openmeteo_df['time'], utc=True)
        openmeteo_df.set_index('time', inplace=True)
        openmeteo_df = openmeteo_df.sort_index().reset_index()

        openmeteo_df.rename(columns={
            'shortwave_radiation_instant': 'openmeteo_ghi',
            'diffuse_radiation_instant': 'openmeteo_dhi',
            'direct_normal_irradiance_instant': 'openmeteo_dni',
            'global_tilted_irradiance_instant': 'openmeteo_poa_irradiance'
        }, inplace=True)

        accumulator = accumulator.reset_index()
        accumulator['timestamp'] = pd.to_datetime(accumulator['timestamp'], utc=True)
        accumulator = accumulator.sort_values('timestamp')

        merged_df = pd.merge_asof(
            accumulator,
            openmeteo_df,
            left_on='timestamp',
            right_on='time',
            direction='nearest',
            tolerance=pd.Timedelta('1h')
        ).drop(columns=['time'])
        merged_df = merged_df.set_index('timestamp')

        merged_df[['openmeteo_ghi', 'openmeteo_dni',
                   'openmeteo_dhi', 'openmeteo_poa_irradiance']] = \
            merged_df[['openmeteo_ghi', 'openmeteo_dni',
                       'openmeteo_dhi', 'openmeteo_poa_irradiance']].ffill()

        return merged_df
