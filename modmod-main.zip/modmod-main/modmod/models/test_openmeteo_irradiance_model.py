import pandas as pd
from pvlib import location, irradiance

from modmod.models import CalculationModel


class TestOpenmeteoIrradianceModel(CalculationModel):
    """
    This model calculates the plane-of-array irradiance using pvlib based on the irradiance data
    provided in the accumulator DataFrame.
    """

    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        latitude = 47.523618
        longitude = 19.012776
        tz = 'UTC'

        tilt = 10
        surface_azimuth = 183

        site_location = location.Location(latitude, longitude, tz=tz)

        accumulator['timestamp'] = pd.to_datetime(accumulator['timestamp'])

        if accumulator['timestamp'].dt.tz is None:
            accumulator['timestamp'] = accumulator['timestamp'].dt.tz_localize(tz)
        else:
            accumulator['timestamp'] = accumulator['timestamp'].dt.tz_convert(tz)

        accumulator.set_index('timestamp', inplace=True)

        required_columns = ['ghi', 'dni', 'dhi']
        missing_columns = [col for col in required_columns if col not in accumulator.columns]
        if missing_columns:
            raise ValueError(f"Missing required irradiance data columns: {missing_columns}")

        accumulator[required_columns] = accumulator[required_columns].fillna(0)

        times = accumulator.index
        solpos = site_location.get_solarposition(times)

        ghi_values = ["ghi"]

        for ghi_value in ghi_values:
            poa_irrad = irradiance.get_total_irradiance(
                surface_tilt=tilt,
                surface_azimuth=surface_azimuth,
                dni=accumulator['dni'],
                ghi=accumulator[ghi_value],
                dhi=accumulator['dhi'],
                solar_zenith=solpos['apparent_zenith'],
                solar_azimuth=solpos['azimuth'],
                model='klucher'
            )

            accumulator[f'poa_global_{ghi_value}'] = poa_irrad['poa_global']

        accumulator.reset_index(inplace=True)

        return accumulator
