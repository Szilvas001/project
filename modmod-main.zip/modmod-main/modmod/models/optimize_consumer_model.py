import pandas as pd

from modmod.models import CalculationModel


class OptimizeConsumerModel(CalculationModel):
    def execute(self, accumulator: pd.DataFrame) -> pd.DataFrame:
        print("OptimizeConsumerModel: accumulator fields:", accumulator.columns)
        return accumulator
