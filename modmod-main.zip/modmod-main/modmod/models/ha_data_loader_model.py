# Aligns data the following way:
# Since timestamps are not guaranteed to be the same across all entities, this will return a dataframe
# with the union of all timestamps, assuming that if there is no data for a given entity at a given
# timestamp, the previous value should be used.
import os
from datetime import datetime

import pandas as pd
import requests

from modmod import DateRange
from modmod.models import CalculationModel


def align_dataframes(dataframes):
    if not dataframes:
        return pd.DataFrame()

    result = dataframes[0]

    for df in dataframes[1:]:
        combined_index = result.index.union(df.index)
        result = result.reindex(combined_index)
        df = df.reindex(combined_index)
        result = result.ffill()
        df = df.ffill()
        result = pd.concat([result, df], axis=1)

    print(f"Result columns: {result.columns}")
    # Ensure the index is a DateTimeIndex for time-based rolling
    if not isinstance(result.index, pd.DatetimeIndex):
        raise ValueError("DataFrame index must be a DateTimeIndex for time-based rolling.")

    # Sort the index to ensure proper rolling calculations
    result = result.sort_index()

    # Replace 'unknown' with NaN and convert columns to numeric
    result = result.apply(pd.to_numeric, errors='coerce')

    # Define the rolling window.
    rolling_window = '5T'

    # Apply rolling average and fill NaN values
    result = result.fillna(result.rolling(rolling_window, min_periods=1).mean())

    return result


class HADataLoaderModel(CalculationModel):
    def execute(self, accumulator: pd.DataFrame, date_range: DateRange) -> pd.DataFrame:
        run_start_total = datetime.now()
        ha_api_url = os.getenv("HA_API_URL")
        auth_token = os.getenv("AUTH_TOKEN")
        try:
            ha_api_timeout = int(os.getenv("HA_API_TIMEOUT", "60"))
        except ValueError:
            print("[WARN] Invalid HA_API_TIMEOUT value, defaulting to 60 seconds.")
            ha_api_timeout = 60

        output_metrics = [p.metric for p in self.output_parameters]

        # --- START DATE FORMATTING FIX ---
        try:
            start_ts = pd.to_datetime(date_range.start_date, utc=True)
            end_ts = pd.to_datetime(date_range.end_date, utc=True)
            start_date_str = start_ts.strftime('%Y-%m-%dT%H:%M:%SZ')
            end_date_str = end_ts.strftime('%Y-%m-%dT%H:%M:%SZ')
        except Exception as e:
            print(f"[ERROR] Failed to format dates for HA API URL: {e}")
            return accumulator
        # --- END DATE FORMATTING FIX ---

        headers = {
            "Authorization": f"Bearer {auth_token}"
        }

        all_time_series_data = []
        all_constant_data = {}

        for metric in output_metrics:
            run_start_metric = datetime.now()
            url = f"{ha_api_url}/history/period/{start_date_str}?end_time={end_date_str}&minimal_response&no_attributes&filter_entity_id={metric}"
            print(f"HADataLoaderModel requesting data for entity: {metric}, URL: {url}")

            try:
                response = requests.get(url, headers=headers, verify=True, timeout=ha_api_timeout)
                run_end_metric = datetime.now()
                print(f"[LOG] Response for {metric} received in {(run_end_metric - run_start_metric).seconds} seconds")

                print(f"[DEBUG] HA API Raw Response Status for {metric}: {response.status_code}")
                # print(f"[DEBUG] HA API Raw Response Text for {metric} (first 500 chars): {response.text[:500]}...") # Optional: for deep debugging

                if not response.ok:
                    print(f"[ERROR] HA API request for {metric} failed with status {response.status_code}: {response.text[:200]}")
                    continue # Skip to the next metric

                response_data_for_metric_outer = response.json()
                
                if not response_data_for_metric_outer or not isinstance(response_data_for_metric_outer, list) or not response_data_for_metric_outer[0]:
                    print(f"[WARN] No data or unexpected format received for metric {metric}. Response: {response_data_for_metric_outer}")
                    continue

                # The API returns a list containing one list of states for a single entity filter
                entity_states = response_data_for_metric_outer[0]

            except requests.exceptions.Timeout:
                print(f"[ERROR] HA API request for {metric} timed out.")
                continue
            except requests.exceptions.RequestException as e:
                print(f"[ERROR] HA API request for {metric} failed: {e}")
                continue
            except requests.exceptions.JSONDecodeError as e:
                print(f"[ERROR] Failed to decode HA API JSON response for {metric}: {e}")
                # print(f"[ERROR] Raw response text for {metric} that failed parsing: {response.text}") # Optional
                continue
            
            # Process the successfully fetched data for this metric
            if entity_states:
                first_state = entity_states[0]
                print(f"[DEBUG] Processing data for {metric}, first state: {first_state}")
                if isinstance(first_state, dict) and 'entity_id' in first_state:
                    entity_id = first_state['entity_id'] # Should be same as metric
                    if len(entity_states) == 1:
                        all_constant_data[entity_id] = first_state['state']
                        print(f"[DEBUG] {entity_id} identified as constant: {first_state['state']}")
                    else:
                        entity_data_list = []
                        for state in entity_states:
                            if isinstance(state, dict):
                                entity_data_list.append({
                                    'timestamp': pd.to_datetime(state['last_changed'], utc=True, errors="coerce"),
                                    'state': state['state']
                                })
                        
                        entity_df = pd.DataFrame(entity_data_list)
                        entity_df.dropna(subset=['timestamp'], inplace=True)

                        if not entity_df.empty:
                            entity_df.set_index('timestamp', inplace=True)
                            entity_df.columns = [entity_id]
                            all_time_series_data.append(entity_df)
                            print(f"[DEBUG] Time-series data added for {entity_id}, shape: {entity_df.shape}")
                        else:
                            print(f"[WARN] No valid time-series data after processing for {entity_id}")
                else:
                    print(f"[WARN] Skipping invalid/unexpected entity_state entry format for {metric}: {first_state}")
            else:
                print(f"[LOG] No entity states returned for metric {metric}")


        if not all_time_series_data and not all_constant_data:
            print("[LOG] No data successfully fetched from API for any metric.")
            return accumulator

        # Align time-series data
        if all_time_series_data:
            result = align_dataframes(all_time_series_data) # align_dataframes handles multiple DFs
            print(f"[LOG] Aligned time-series data shape: {result.shape if not result.empty else 'empty'}")
            if not result.empty:
                 result = result.astype(float, errors='ignore') # Try to convert to float, ignore if not possible
        else:
            result = pd.DataFrame()
            print("[LOG] No time-series data to align.")

        # Add constant data
        if all_constant_data:
            print(f"[DEBUG] Adding constant data: {all_constant_data}")
            for entity_id, value in all_constant_data.items():
                # Try to convert constant value to numeric if possible
                try:
                    numeric_value = pd.to_numeric(value)
                except ValueError:
                    numeric_value = value # Keep as string if not numeric

                if result.empty:
                    # If only constant data, create a DataFrame. Use a common or arbitrary index like the first timestamp of range
                    # Or, if no time-series data at all, we might need a strategy for the index (e.g. date_range.start_date)
                    # For now, let's assume if result is empty and we have constants, they apply across the range
                    # This part might need refinement based on how constants should be represented if no time-series exist
                    # A simple approach: create a single row DF. This might not align well if accumulator has an index.
                    # Using the start_ts as a placeholder index.
                    print(f"[DEBUG] Result is empty. Creating new DF for constant {entity_id} with value {numeric_value} at index {start_ts}")
                    result = pd.DataFrame({entity_id: [numeric_value]}, index=[start_ts])
                else:
                    # If result DataFrame exists (from time-series data), add/overwrite constant column
                    print(f"[DEBUG] Adding constant column {entity_id} with value {numeric_value} to existing result DF")
                    result[entity_id] = numeric_value 
                    # Constants should ideally be forward-filled if they apply over time
                    # However, align_dataframes already does ffill.
                    # If a constant is added AFTER align_dataframes, it will be a single value repeated.
                    # If align_dataframes produced an index, this will fill that column.
                    # If the constant's entity_id was ALREADY a column from time-series (unlikely here), it's overwritten.
                    # This seems fine - if it's constant, it should overwrite any (potentially sparse) time-series for that entity.
        else:
            print("[LOG] No constant data to add.")

        if result.empty:
            print("[LOG] Result DataFrame is empty after processing all metrics.")
            return accumulator
            
        # --- Start of new debug logs ---
        print("\n[DEBUG] HA Data (result) before merge attempt:")
        print(result.head())
        print(result.tail())
        print(f"[DEBUG] HA Data (result) shape: {result.shape}")
        # --- Specific Timestamp Check ---
        target_ts_str = '2025-03-19 12:00:04.846218+00:00'
        target_ts = pd.to_datetime(target_ts_str)
        if target_ts in result.index:
            print(f"\n[DEBUG] HA Data (result) value at {target_ts_str}:\n{result.loc[target_ts]}")
        else:
            print(f"\n[DEBUG] Target timestamp {target_ts_str} not found in HA Data (result) index.")
        # --- End of new debug logs ---

        if accumulator.empty:
            print("[DEBUG] Accumulator is empty, using HA data directly.")
            accumulator = result
        else:
            print("\n[DEBUG] Accumulator before merge:")
            print(accumulator.head())
            print(accumulator.tail())
            print(f"[DEBUG] Accumulator shape before merge: {accumulator.shape}")
            # --- Specific Timestamp Check ---
            if target_ts in accumulator.index:
                 print(f"\n[DEBUG] Accumulator value before merge at {target_ts_str}:\n{accumulator.loc[target_ts]}")
            else:
                 print(f"\n[DEBUG] Target timestamp {target_ts_str} not found in Accumulator index before merge.")
            # --- End Specific Timestamp Check ---

            print("\n[DEBUG] HA Data (result) being merged:")
            print(result.head())
            print(result.tail())
            print(f"[DEBUG] HA Data (result) shape for merge: {result.shape}")

            # Merge/Align HA data onto accumulator's index
            # Reindex HA data to match accumulator's index, forward-filling
            # Use a tolerance to limit how far back ffill looks (e.g., 5 minutes)
            ha_aligned = result.reindex(accumulator.index, method='ffill', tolerance=pd.Timedelta('5min'))
            # Back-fill any remaining NaNs at the beginning
            ha_aligned = ha_aligned.bfill()

            print("\n[DEBUG] HA Data after aligning to accumulator index (ha_aligned):")
            print(ha_aligned.head())
            print(ha_aligned.tail())
            print(f"[DEBUG] ha_aligned shape: {ha_aligned.shape}")
            # --- Specific Timestamp Check ---
            if target_ts in ha_aligned.index:
                 print(f"\n[DEBUG] ha_aligned value at {target_ts_str}:\n{ha_aligned.loc[target_ts]}")
            else:
                 print(f"\n[DEBUG] Target timestamp {target_ts_str} not found in ha_aligned index.")
            # --- End Specific Timestamp Check ---

            # Merge the aligned HA data into the accumulator
            # Use combine_first to prioritize accumulator's existing data if any overlap (shouldn't be any)
            # Then update with ha_aligned, filling NaNs in accumulator
            accumulator = accumulator.combine_first(ha_aligned)
            # Ensure all columns from ha_aligned are present, adding if necessary
            for col in ha_aligned.columns:
                if col not in accumulator.columns:
                    accumulator[col] = ha_aligned[col]
                else:
                    # Update only where accumulator originally had NaN
                    accumulator[col] = accumulator[col].fillna(ha_aligned[col])


            print("\n[DEBUG] Accumulator after merging HA data:")
            print(accumulator.head())
            print(accumulator.tail())
            print(f"[DEBUG] Accumulator shape after merge: {accumulator.shape}")
            # --- Specific Timestamp Check ---
            if target_ts in accumulator.index:
                 print(f"\n[DEBUG] Accumulator value after merge at {target_ts_str}:\n{accumulator.loc[target_ts]}")
            else:
                 print(f"\n[DEBUG] Target timestamp {target_ts_str} not found in Accumulator index after merge.")
            # --- End Specific Timestamp Check ---

        # Convert accumulator columns to numeric where possible, coercing errors
        for col in accumulator.columns:
             if accumulator[col].dtype == 'object': # Only attempt conversion on object columns
                 accumulator[col] = pd.to_numeric(accumulator[col], errors='coerce')

        accumulator.replace('unknown', pd.NA, inplace=True)
        accumulator.replace('unavailable', pd.NA, inplace=True)
        # We might still need a final ffill for safety, but let's see the logs first
        # accumulator = accumulator.ffill()

        # Fill NaN values in constant columns (ensure they are added if result was empty initially)
        for entity_id, value in all_constant_data.items():
            if entity_id not in accumulator.columns:
                 accumulator[entity_id] = value # Add column if missing
            # Try converting constant value to numeric if possible, otherwise keep as is
            try:
                numeric_value = pd.to_numeric(value)
                accumulator[entity_id] = accumulator[entity_id].fillna(numeric_value) 
            except ValueError:
                accumulator[entity_id] = accumulator[entity_id].fillna(value) # Fill with original string value
            accumulator[entity_id] = accumulator[entity_id].ffill() # Forward fill constants

        print("[LOG] HADataLoaderModel processing completed")
        return accumulator
