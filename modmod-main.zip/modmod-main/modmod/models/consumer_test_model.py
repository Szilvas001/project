import os

import pandas as pd
import requests

from modmod.models import CalculationModel


class ConsumerTestModel(CalculationModel):
    """
    Replace this docstring with a description of ConsumerTestModel
    """

    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        momentary_generation = pd.to_numeric(accumulator["momentary_generation"]).iloc[0]
        momentary_consumption = pd.to_numeric(accumulator["momentary_consumption"]).iloc[0]

        momentary_delta = momentary_generation - momentary_consumption

        meteomatics_api_url = os.getenv(
            "METEOMATICS_API_URL") + "2024-08-28T17:40:00.000+02:00--2024-08-28T17:45:00.000+02:00:PT5M/total_cloud_cover:p,low_cloud_cover:p,high_cloud_cover:p,medium_cloud_cover:p/47.4978789,19.0402383/json?model=mix"

        request = requests.get(meteomatics_api_url, auth=("ulx_gero_kristof", "O8rr8I8ipD"))
        response = request.json()

        print(f"Response from Meteomatics API: {response}")

        turn_on_signal = min((momentary_delta // 1800), 3)
        accumulator["turn_on_signal"] = turn_on_signal

        return accumulator
