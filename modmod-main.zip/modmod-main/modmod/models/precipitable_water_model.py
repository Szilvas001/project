import pandas as pd
import pvlib

from modmod.models import CalculationModel


class PrecipitableWaterModel(CalculationModel):
    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        temperature = pd.to_numeric(accumulator["ha_temperature"]).values
        humidity = pd.to_numeric(accumulator["humidity"]).values
        precipitable_water = pvlib.atmosphere.gueymard94_pw(temperature, humidity)
        accumulator["precipitable_water"] = precipitable_water
        return accumulator
