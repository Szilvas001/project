import numpy as np
import pandas as pd
import pvlib
import requests
from pvlib.irradiance import get_total_irradiance
from scipy.interpolate import interp1d
from sklearn.linear_model import LinearRegression
from modmod.models import CalculationModel
from pvlib.tools import cosd
import matplotlib.pyplot as plt


class ClearSkyModel(CalculationModel):
    """
    Model to calculate clear sky irradiance and corresponding POA irradiance using different clear sky models.
    """
    @classmethod
    def calculate_alpha_beta(cls, aod_values, wavelengths_um):
        """
        Calculate Angstrom Alpha (α) and Beta (β) from AOD measurements.

        Parameters:
        - aod_values (list or array-like): AOD measurements at each wavelength.
        - wavelengths_nm (list or array-like): Corresponding wavelengths in nanometers.

        Returns:
        - alpha (float): Angstrom Alpha value.
        - beta (float): Angstrom Beta value.
        """
        try:
            # Convert inputs to numpy arrays for consistency
            aod_values = np.array(aod_values, dtype=float)
            wavelengths_um = np.array(wavelengths_um, dtype=float)

            # Validation checks
            if len(aod_values) != len(wavelengths_um):
                raise ValueError("Number of AOD values must match number of wavelengths.")
            if np.any(aod_values <= 0):
                raise ValueError("All AOD values must be positive.")

            # Log-transform the AOD values and wavelengths
            ln_aod = np.log(aod_values)
            ln_wavelength = np.log(wavelengths_um)

            # Reshape ln_wavelength for sklearn
            X = ln_wavelength.reshape(-1, 1)  # Independent variable
            Y = ln_aod  # Dependent variable

            # Initialize and fit the linear regression model
            model = LinearRegression()
            model.fit(X, Y)

            # Extract slope and intercept
            slope = model.coef_[0]
            intercept = model.intercept_

            # Calculate alpha and beta
            alpha = -slope
            beta = np.exp(intercept)

            return alpha, beta

        except Exception as e:
            print(f"Error calculating alpha and beta: {e}")
            return np.nan, np.nan

    @classmethod
    def calculate_wvf(cls, row):
        """
        Calculate the wavelength variation factor from SSA values at different wavelengths.
        
        Parameters:
        - row: pandas Series containing SSA values at different wavelengths
        
        Returns:
        - wvf: wavelength variation factor
        - k: coefficient
        """
        wavelengths_nm = [340, 355, 380, 400, 500, 645, 865, 1064, 1240, 1640, 2130]
        wavelengths_um = np.array(wavelengths_nm) / 1000.0
        log_wavelengths = np.log(wavelengths_um)

        # Extract SSA values
        ssa_values = [
            row[f'ssa{wl}'] for wl in wavelengths_nm
        ]
        
        # Compute the natural log of the SSA values
        log_ssa = np.log(ssa_values)
        
        # Perform linear regression
        slope, intercept = np.polyfit(log_wavelengths, log_ssa, 1)
        wvf = -slope
        k = np.exp(intercept)
        
        return wvf, k

    @classmethod
    def irradiance_spctrl2(cls, timestamps, latitude, longitude, altitude, accumulator, apply_spectral_response: bool = True):
        solar_position = pvlib.solarposition.get_solarposition(
            time=timestamps,
            latitude=latitude,
            longitude=longitude,
            altitude=altitude
        )

        apparent_zenith = solar_position['apparent_zenith']
        airmass_relative = pvlib.atmosphere.get_relative_airmass(apparent_zenith)

        surface_tilt = accumulator["panel_tilt"].iloc[0]
        surface_azimuth = accumulator["panel_azimuth"].iloc[0]

        aoi = pvlib.irradiance.aoi(surface_tilt, surface_azimuth, apparent_zenith, solar_position['azimuth'])

        albedo = accumulator["albedo"].iloc[0]

        press = accumulator["pressure"].values

        pw = accumulator["wv"].values
        ozone = accumulator["o3"].values

        ssa = accumulator["ssa"].values
        asymmetry_factor = accumulator["asymmetry_factor"].values

        aod469 = accumulator["aod469"].values

        ang_alpha = -(np.log(accumulator["aod469"] / accumulator["aod550"]) / np.log(469 / 550))
        ang_beta = np.exp(np.log(accumulator["aod550"]) + ang_alpha * np.log(0.550))

        # Convert to aod500
        aod500 = pvlib.atmosphere.angstrom_aod_at_lambda(aod469, 469, ang_alpha, 500)

        # Calculate WVF for each timestamp
        '''
        wvf_values = []
        for idx in range(len(accumulator)):
            wvf, _ = cls.calculate_wvf(accumulator.iloc[idx])
            wvf_values.append(wvf)
        
        wvf_array = np.array(wvf_values)
        '''


        spectral_response_data = {
            # Wavelength (nm): Normalized Spectral Response (%) from IMT datasheet  
            350: 0,
            400: 0.45,
            500: 0.60,
            600: 0.70,
            700: 0.80,
            800: 0.90,
            900: 0.97,
            915: 1,
            975: 1,
            1000: 0.95,
            1075: 0.60,
            1110: 0.36,
            1150: 0.10,
            1165: 0.04,
            1200: 0
        }

        ds_wavelengths = np.array(list(spectral_response_data.keys()))
        ds_sr = np.array(list(spectral_response_data.values()))
        sort_indices = np.argsort(ds_wavelengths)
        ds_wavelengths = ds_wavelengths[sort_indices]
        ds_sr = ds_sr[sort_indices]
        spline_interpolator = interp1d(ds_wavelengths, ds_sr, kind='cubic', bounds_error=False, fill_value=0.0)

        am15g = pvlib.spectrum.get_reference_spectra(standard='ASTM G173-03')  # Defaults to this standard

        # Get the spectral response (SR) at the same wavelengths as AM1.5G
        sr_values = spline_interpolator(am15g.index.values)

        # Convert to arrays for integration
        wavelengths_std = am15g.index.values
        e_std = am15g['global'].values  # Use 'global' for AM1.5G tilted irradiance

        # Filter to responsive range
        mask_std = (wavelengths_std >= 350) & (wavelengths_std <= 1200)
        wavelengths_std_filtered = wavelengths_std[mask_std]
        e_std_filtered = e_std[mask_std]
        sr_filtered = sr_values[mask_std]

        # Trapezoidal integration for numerator: ∫ E_std(λ) * SR(λ) dλ
        delta_wavelengths_std = np.diff(wavelengths_std_filtered)
        average_e_sr = (e_std_filtered[:-1] * sr_filtered[:-1] + e_std_filtered[1:] * sr_filtered[1:]) / 2
        areas_std = average_e_sr * delta_wavelengths_std
        integral_e_sr = np.sum(areas_std)  # In W/m²

        # Compute f = integral_e_sr / 1000
        f = integral_e_sr / 1000  # Should be ~0.53-0.56 for c-Si; print it to verify

        print(f"f: {f}")

        distribution = pvlib.spectrum.spectrl2(
            apparent_zenith=apparent_zenith, 
            aerosol_asymmetry_factor=asymmetry_factor, 
            alpha=ang_alpha, 
            aoi=aoi,
            surface_tilt=surface_tilt, 
            ground_albedo=albedo, 
            surface_pressure=press * 100, # hPa to Pa
            relative_airmass=airmass_relative, 
            precipitable_water=pw, 
            ozone=ozone, 
            aerosol_turbidity_500nm=aod500, 
            scattering_albedo_400nm=ssa,
            wavelength_variation_factor=0.095
        )

        print(f"Calculating with aod500: {aod500}")

        accumulator['alpha'] = ang_alpha
        accumulator['beta'] = ang_beta

        wavelengths = distribution['wavelength']
        poa_global = distribution['poa_global']

        spectral_response_array = spline_interpolator(wavelengths)
        spectral_response_array = spectral_response_array[:, np.newaxis]

        # 1. Filter wavelengths between 350 nm and 1200 nm
        mask = (wavelengths >= 350) & (wavelengths <= 1200)
        wavelengths_filtered = wavelengths[mask]  # Shape: (M,)

        poa_global_weighted = poa_global * spectral_response_array  # Shape: (122, N)
        
        poa_global_weighted_filtered = poa_global_weighted[mask, :]  # Shape: (M, N)
        
        # 2. Perform trapezoidal integration
        poa_global_weighted_filtered = np.nan_to_num(poa_global_weighted_filtered, nan=0.0)
        delta_wavelengths = np.diff(wavelengths_filtered)
        average_poa_weighted = (poa_global_weighted_filtered[:-1, :] + poa_global_weighted_filtered[1:, :]) / 2
        areas = average_poa_weighted * delta_wavelengths[:, np.newaxis]
        g_w = np.sum(areas, axis=0)  # Shape: (N,)  # This is G_w (weighted, in W/m²)
        
        # Normalize to get effective irradiance: G_eff = G_w / f
        poa_global_effective = g_w / f
        
        # Create a DataFrame to store the effective poa_global values
        spectral_irradiance = pd.DataFrame(
            {'poa_global': poa_global_effective},
            index=timestamps
        )
        return spectral_irradiance

    @classmethod
    def calc_solar_position(cls, timestamps):
        latitude, longitude = 47.523618, 19.012776
        altitude = 240

        solar_position = pvlib.solarposition.get_solarposition(
            time=timestamps,
            latitude=latitude,
            longitude=longitude,
            altitude=altitude
        )
        return solar_position

    @classmethod
    def calc_extraterrestrial_radiation(cls, timestamps):
        return pvlib.irradiance.get_extra_radiation(timestamps)

    @classmethod
    def calc_poa_irradiance(cls, solar_position, dni, ghi, dhi, panel_tilt, panel_azimuth, extra_radiation, albedo, models):
        poa_irradiances = {}
        for model in models:
            poa_irradiance = get_total_irradiance(
                surface_tilt=panel_tilt,
                surface_azimuth=panel_azimuth,
                dni=dni,
                ghi=ghi,
                dhi=dhi,
                solar_zenith=solar_position['apparent_zenith'],
                solar_azimuth=solar_position['azimuth'],
                model=model,
                albedo=albedo,
                dni_extra=extra_radiation
            )
            poa_irradiances[model] = poa_irradiance

        return poa_irradiances

    @classmethod
    def init_default_params(cls, accumulator):
        default_values = {
            "albedo": 0.2,
            "precipitable_water": 0.02,
            "ozone": 0.3,
            "aod380": None,
            "aod500": None,
            "aod700": None,
            "linke_turbidity": None,
            "press": None,
            "ang_alpha": 1.14,
            "ang_beta": 0.12,
            "Dayth": accumulator.index.dayofyear,
            "Year": accumulator.index.year,
        }

        params = {
            key: accumulator[key].iloc[0] if key in accumulator.columns and accumulator[key].iloc[0] !=
                                             accumulator[key].iloc[1] else default
            for key, default in default_values.items()
        }

        print(f"[INFO] Default parameters: \n{params}")

        return params

    @classmethod
    def execute(cls, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        # TODO: Fix parameter configuration from the accumulator
        timestamps = accumulator.index

        latitude = accumulator['latitude'].iloc[0]
        longitude = accumulator['longitude'].iloc[0]
        altitude = accumulator['altitude'].iloc[0]

        models = accumulator['model'].iloc[0].split(',')

        clear_sky_models = {
            "spctrl2": cls.irradiance_spctrl2,
        }

        # Iterate through each model and accumulate results
        for model in models:
            model = model.strip()
            if model not in clear_sky_models:
                raise ValueError(
                    f"Unsupported model: {model}. Supported models are: {', '.join(clear_sky_models.keys())}")

            # Calculate irradiance WITH spectral response (effective irradiance)
            effective_irradiance_df = clear_sky_models[model](
                timestamps, latitude, longitude, altitude, accumulator, apply_spectral_response=True
            )
            effective_irradiance = effective_irradiance_df['poa_global']


            # Set the final output to be the effective irradiance by default
            accumulator[f'clear_sky_poa_irradiance'] = effective_irradiance

        return accumulator
