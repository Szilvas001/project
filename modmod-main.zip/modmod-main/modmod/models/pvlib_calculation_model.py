import pandas as pd

from modmod.models import CalculationModel


class PVLibCalculationModel(CalculationModel):
    def execute(self, accumulator: pd.DataFrame) -> pd.DataFrame:
        print("PVLibCalculationModel: accumulator:", accumulator)
        accumulator["calculated_ac"] = accumulator["wind"] * accumulator["irradiance"] * 0.82326
        accumulator["calculated_dc"] = accumulator["wind"] * accumulator["irradiance"]
        print("PVLibCalculationModel: accumulator after calculation:", accumulator)
        return accumulator
