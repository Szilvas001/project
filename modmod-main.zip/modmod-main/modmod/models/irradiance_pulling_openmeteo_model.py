from datetime import datetime

import pandas as pd
import requests

from modmod.models import CalculationModel


class IrradiancePullingOpenmeteoModel(CalculationModel):
    """
    A model to pull irradiance data from the OpenMeteo API and process it.
    """

    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        datetime_now = pd.Timestamp.now()
        current_date = datetime_now.strftime('%Y-%m-%d')
        formatted_datetime = datetime_now.strftime("%Y-%m-%dT%H:%M:%S.%f%z")

        latitude = 47.523618
        longitude = 19.012776
        variables = 'shortwave_radiation,diffuse_radiation,direct_normal_irradiance'

        openmeteo_api_url = (
            f"https://api.open-meteo.com/v1/forecast?"
            f"latitude={latitude}&longitude={longitude}&minutely_15={variables}"
            f"&start_date={current_date}&end_date={current_date}"
        )

        response = requests.get(openmeteo_api_url)
        data = response.json()

        if 'minutely_15' not in data:
            print("[ERROR] No minutely_15 data available.")
            return accumulator

        forecast_times_str = data['minutely_15']['time']
        forecast_times = [datetime.fromisoformat(t) for t in forecast_times_str]

        closest_time = min(forecast_times, key=lambda d: abs(d - datetime_now))
        closest_time_index = forecast_times.index(closest_time)

        shortwave_radiation = data['minutely_15']['shortwave_radiation'][closest_time_index]
        diffuse_radiation = data['minutely_15']['diffuse_radiation'][closest_time_index]
        direct_normal_irradiance = data['minutely_15']['direct_normal_irradiance'][closest_time_index]

        new_accumulator = pd.DataFrame(
            data=[[shortwave_radiation, diffuse_radiation, direct_normal_irradiance, closest_time]],
            index=[formatted_datetime],
            columns=["shortwave_radiation", "diffuse_radiation", "direct_normal_irradiance", "data_timestamp"]
        )

        accumulator = pd.concat([accumulator, new_accumulator])
        return accumulator
