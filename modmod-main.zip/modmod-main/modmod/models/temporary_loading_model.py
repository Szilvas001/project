import pandas as pd

from modmod.models import CalculationModel


class TemporaryLoadingModel(CalculationModel):
    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        accumulator["temporary_output"] = accumulator["cell_temp"] * accumulator["fixed_input"]
        return accumulator
