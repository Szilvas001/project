import pandas as pd
import pvlib

from modmod.models import CalculationModel


class RelativeAirmassModel(CalculationModel):
    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        zenith = accumulator["solar_zenith"].values
        print(f"NaN values in accumulator: {accumulator.isna().sum()}")
        accumulator["relative_airmass"] = pvlib.atmosphere.get_relative_airmass(zenith)
        print(f"NaN values in accumulator after relative_airmass: {accumulator.isna().sum()}")
        return accumulator
