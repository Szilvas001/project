import pandas as pd
import requests
from requests.auth import HTTPBasicAuth

from modmod.models import CalculationModel


class MeteomaticsDataLoaderModel(CalculationModel):
    """
    This model fetches data from the Meteomatics API for a set of predefined parameters, date range, and location.
    The parameters are extracted from a predefined URL.
    """

    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        # Format the start and end dates
        start_date = str(date_range.start_date).replace(" ", "T").replace("+00", "Z")
        end_date = str(date_range.end_date).replace(" ", "T").replace("+00", "Z")

        # Here's the URL you provided
        provided_url = (
            "https://api.meteomatics.com/2024-10-07T16:30:00.000+00:00--2024-10-22T06:25:00.000+00:00:PT5M/low_cloud_cover:p,high_cloud_cover:p,total_cloud_cover:p,effective_cloud_cover:p,medium_cloud_cover:p,t_240m:C,wind_dir_1200m:d,wind_speed_1200m:ms,total_aod_550nm:idx/47.523618,19.012776/json?model=mix"
        )

        # Extract the parameters from the provided URL
        # Split the URL to get the parameters part
        try:
            # Find the part of the URL after the date range
            parameters_section = provided_url.split(':PT5M/')[1]
            parameters_str = parameters_section.split('/')[0]
        except IndexError:
            print("Error parsing the parameters from the provided URL.")
            return accumulator

            # Construct the API URL using the extracted parameters
        url = f"https://api.meteomatics.com/{start_date}--{end_date}:PT5M/{parameters_str}/47.523618,19.012776/json"

        # Additional request parameters
        params = {
            "model": "mix"
        }

        username = "ulx_gero_kristof"
        password = "O8rr8I8ipD"

        # Send the GET request to the Meteomatics API
        response = requests.get(url, params=params, auth=HTTPBasicAuth(username, password))

        # Check if the request was successful
        if response.status_code == 200:
            # Parse the JSON response into a dictionary
            data = response.json()

            # Initialize a dictionary to store the data
            data_dict = {}

            # Iterate over each parameter's data in the response
            for parameter_data in data['data']:
                # Replace ':' with '_' in the parameter name
                parameter = parameter_data['parameter'].replace(':', '_')
                parameter = parameter.replace('-', '')

                # Initialize lists to store timestamps and values
                timestamps = []
                values = []

                # Extract data for each coordinate and timestamp
                for coord_data in parameter_data['coordinates']:
                    for date_data in coord_data['dates']:
                        timestamp = date_data['date']
                        value = date_data['value']
                        timestamps.append(timestamp)
                        values.append(value)

                # Add the timestamps to the data dictionary once
                if 'timestamp' not in data_dict:
                    data_dict['timestamp'] = pd.to_datetime(timestamps)

                # Add the parameter values to the data dictionary
                data_dict[parameter] = values

            # Create a DataFrame from the data dictionary
            df = pd.DataFrame(data_dict)

            # Set 'timestamp' as the index
            df.set_index('timestamp', inplace=True)

            # Concatenate the new data with the accumulator DataFrame
            accumulator = pd.concat([accumulator, df])

            print(f"Data loaded from Meteomatics: \n{accumulator}")

        else:
            # Print error information if the request failed
            print(f"Error: {response.status_code}")
            print(response.text)

        # Return the updated accumulator DataFrame
        return accumulator
