import random

import pandas as pd

from modmod.models import CalculationModel


class SimulateConsumersModel(CalculationModel):
    def execute(self, accumulator: pd.DataFrame) -> pd.DataFrame:
        print("SimulateConsumersModel: accumulator:", accumulator)
        accumulator["consumption"] = accumulator.apply(lambda row: random.uniform(5000, 10000), axis=1)
        return accumulator
