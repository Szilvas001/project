import pandas as pd
import pvlib
import requests
from pvlib.irradiance import get_total_irradiance

from modmod.models import CalculationModel


class OpenmeteoPullingModel(CalculationModel):
    """
    Model to pull 15-minute irradiance data from the Open-Meteo API, calculate POA irradiance using pvlib,
    and update the accumulator DataFrame.
    """

    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        # Define location coordinates and altitude
        latitude = 47.523618
        longitude = 19.012776
        altitude = 240  # in meters

        # Define PV system parameters
        panel_tilt = 17  # degrees
        panel_azimuth = 183  # degrees
        albedo = 0.6  # Ground reflectance

        # Convert date_range to datetime
        start_date_dt = pd.to_datetime(date_range.start_date, utc=True)
        end_date_dt = pd.to_datetime(date_range.end_date, utc=True)

        # Convert datetime objects to 'YYYY-MM-DD' strings for the API
        start_date_str = start_date_dt.strftime('%Y-%m-%d')
        end_date_str = end_date_dt.strftime('%Y-%m-%d')

        # Construct the API URL and parameters
        url = "https://api.open-meteo.com/v1/forecast"
        params = {
            "latitude": latitude,
            "longitude": longitude,
            "minutely_15": "shortwave_radiation,diffuse_radiation,direct_normal_irradiance",
            "start_date": start_date_str,
            "end_date": end_date_str,
            "timezone": "UTC"
        }

        # Make the API request
        response = requests.get(url, params=params)
        if response.status_code != 200:
            raise Exception(f"Request failed with status code {response.status_code}: {response.text}")

        # Parse the JSON response
        data = response.json()
        minutely_data = data.get('minutely_15', {})

        if not minutely_data:
            raise Exception("No 'minutely_15' data found in the response.")

        # Create a DataFrame from the minutely data
        df = pd.DataFrame(minutely_data)

        if 'time' not in df.columns:
            raise Exception("No 'time' column found in the 'minutely_15' data.")

        # Convert 'time' to datetime and set as index
        df['time'] = pd.to_datetime(df['time'], utc=True)
        df.set_index('time', inplace=True)
        df['latitude'] = latitude
        df['longitude'] = longitude

        # Rename columns to standard names
        df.rename(columns={
            'shortwave_radiation': 'openmeteo_ghi',
            'diffuse_radiation': 'openmeteo_dhi',
            'direct_normal_irradiance': 'openmeteo_dni'
        }, inplace=True)

        # Prepare the accumulator DataFrame
        if accumulator.empty:
            # Initialize accumulator with fetched data
            accumulator = df.reset_index()
            accumulator.rename(columns={'time': 'timestamp'}, inplace=True)
            # Add PV system parameters as constant columns
            accumulator['panel_tilt'] = panel_tilt
            accumulator['panel_azimuth'] = panel_azimuth
        else:
            # Ensure 'timestamp' column exists and is in datetime format
            if 'timestamp' not in accumulator.columns:
                accumulator.reset_index(inplace=True)
                accumulator.rename(columns={'index': 'timestamp'}, inplace=True)
            else:
                accumulator.reset_index(inplace=True)

            accumulator['timestamp'] = pd.to_datetime(accumulator['timestamp'], utc=True)

            # Prepare df for merging
            df.reset_index(inplace=True)
            df.rename(columns={'time': 'timestamp'}, inplace=True)

            # Merge the dataframes on 'timestamp' with a tolerance of 15 minutes
            merged_df = pd.merge_asof(
                accumulator.sort_values('timestamp'),
                df.sort_values('timestamp'),
                on='timestamp',
                direction='nearest',
                tolerance=pd.Timedelta('15min')
            )

            # Forward fill missing irradiance values
            irradiance_cols = ['openmeteo_ghi', 'openmeteo_dhi', 'openmeteo_dni']
            merged_df[irradiance_cols] = merged_df[irradiance_cols].ffill()

            # If 'panel_tilt' and 'panel_azimuth' are not present, add them
            if 'panel_tilt' not in merged_df.columns:
                merged_df['panel_tilt'] = panel_tilt
            if 'panel_azimuth' not in merged_df.columns:
                merged_df['panel_azimuth'] = panel_azimuth

            accumulator = merged_df

        # Set 'timestamp' as index
        accumulator.set_index('timestamp', inplace=True)

        # Calculate POA Irradiance using pvlib
        accumulator = self.calculate_poa(accumulator, latitude, longitude, altitude, panel_tilt, panel_azimuth, albedo)

        return accumulator

    @staticmethod
    def calculate_poa(df: pd.DataFrame, latitude: float, longitude: float, altitude: float,
                      panel_tilt: float, panel_azimuth: float, albedo: float) -> pd.DataFrame:
        """
        Calculate Plane of Array (POA) irradiance using pvlib.

        Parameters:
            df (pd.DataFrame): DataFrame containing 'openmeteo_ghi', 'openmeteo_dhi', 'openmeteo_dni'.
            latitude (float): Latitude of the location.
            longitude (float): Longitude of the location.
            altitude (float): Altitude of the location in meters.
            panel_tilt (float): Tilt angle of the PV panel in degrees.
            panel_azimuth (float): Azimuth angle of the PV panel in degrees.
            albedo (float): Ground reflectance.

        Returns:
            pd.DataFrame: DataFrame with an additional 'poa_irradiance' column.
        """
        # Create a pvlib Location object
        location = pvlib.location.Location(latitude, longitude, altitude=altitude, tz='UTC')

        # Ensure the DataFrame is sorted by timestamp
        df = df.sort_index()

        # Calculate solar position
        solar_position = location.get_solarposition(df.index)

        # Extract necessary angles
        apparent_zenith = solar_position['apparent_zenith']
        azimuth = solar_position['azimuth']

        # Calculate POA irradiance using the Hay-Davies model
        poa_components = get_total_irradiance(
            surface_tilt=panel_tilt,
            surface_azimuth=panel_azimuth,
            dni=df['openmeteo_dni'],
            ghi=df['openmeteo_ghi'],
            dhi=df['openmeteo_dhi'],
            solar_zenith=apparent_zenith,
            solar_azimuth=azimuth,
            albedo=albedo,
            model='klucher'
        )

        # Add POA irradiance to the DataFrame
        df['poa_irradiance'] = poa_components['poa_global']

        df['poa_irradiance'] = df['poa_irradiance'].clip(lower=0)

        return df
