import pandas as pd

from modmod.models import CalculationModel


class IncidentAngleModifierModel(CalculationModel):

    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        accumulator["iam"] = accumulator["ha_iam"].astype(float).values
        return accumulator
