import pandas as pd
import pvlib

from modmod.models import CalculationModel


class AverageModel(CalculationModel):
    @classmethod
    def calc_average(cls, accumulator) -> pd.Series:
        return accumulator[["avg_a_value", "avg_b_value"]].mean(axis=1)

    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        averages = self.calc_average(accumulator)
        accumulator["average_output"] = averages

        return accumulator
