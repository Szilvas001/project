import numpy as np
import pandas as pd
from scipy.interpolate import PchipInterpolator
import pvlib

from modmod.models import CalculationModel

"""
Revert IMT IAM model: undo the effects of IAM on IMT reference cell irradiation, calculate irradiation without IAM

Inputs:
  - aoi
  - irradiance_with_imt_iam
Outputs:
  - iam_reversed_irradiance_output
"""
class RevertImtIamModel(CalculationModel):
    @classmethod
    def calculate_included_imt_iam(cls, accumulator: pd.DataFrame) -> pd.Series:
        # Incidence Angle Modifier (IAM) Data
        aoi_deg = np.array([5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90])
        iam_percent = np.array([100, 100, 100, 100, 99.5, 99.3, 99, 99, 98.7, 98.4, 98, 96.7, 95.8, 93.8, 90.9, 85.7, 77.5, 0])
        iam_fraction = iam_percent / 100.0

        # --- Create PCHIP Interpolation Function ---
        # PchipInterpolator preserves monotonicity between points.
        iam_pchip_func = PchipInterpolator(aoi_deg, iam_fraction, extrapolate=True) # Extrapolate needed for values outside range

        aoi = accumulator["aoi"].values

        return np.clip(iam_pchip_func(aoi), 0, 1)


    @classmethod
    def calculate_iam_corrected_irradiance(cls, row):
        original_irradiance = row["irradiance_with_imt_iam"]
        included_imt_iam_factor = row["included_imt_iam_factor"]

        result_column_name = "iam_reversed_irradiance_output"

        if included_imt_iam_factor == 0:
            result_value = original_irradiance
        else:
            result_value = original_irradiance / (included_imt_iam_factor * 100) * 100

        return pd.Series([result_value], index=[result_column_name])


    @classmethod
    def revert_imt_iam(cls, accumulator: pd.DataFrame) -> pd.Series:
        return accumulator.apply(cls.calculate_iam_corrected_irradiance, axis=1)


    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        accumulator["included_imt_iam_factor"] = self.calculate_included_imt_iam(accumulator)
        accumulator["iam_reversed_irradiance_output"] = self.revert_imt_iam(accumulator)["iam_reversed_irradiance_output"]

        return accumulator
