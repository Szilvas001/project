import pandas as pd
import pvlib

from modmod.models import CalculationModel


class DcOutputModel(CalculationModel):
    """
    Calculates the DC output of a PV system based on irradiance, cell temperature, and module specifications.
    """

    @classmethod
    def calc_params_desoto(cls, irrad, cell_temp, module):
        return pvlib.pvsystem.calcparams_desoto(
            irrad,
            cell_temp,
            module["alpha_sc"],
            module["a_ref"],
            module["I_L_ref"],
            module["I_o_ref"],
            module["R_sh_ref"],
            module["R_s"]
        )

    @classmethod
    def calc_params_cec(cls, irrad, cell_temp, module):
        return pvlib.pvsystem.calcparams_cec(
            irrad,
            cell_temp,
            module["alpha_sc"],
            module["a_ref"],
            module["I_L_ref"],
            module["I_o_ref"],
            module["R_sh_ref"],
            module["R_s"],
            module["Adjust"]
        )

    @classmethod
    def calc_input_params_singlediode(cls, irrad, cell_temp, module, calc_type):
        calc_type_dict = {
            "desoto": cls.calc_params_desoto,
            "cec": cls.calc_params_cec,
        }
        if calc_type in calc_type_dict.keys():
            return calc_type_dict[calc_type](irrad, cell_temp, module)
        else:
            raise NotImplementedError(f"Input parameter calculation type {calc_type} not implemented! "
                                      f"Implemented ones are: {list(calc_type_dict.keys())}.")

    @classmethod
    def translate_sam_name_to_id(cls, name: str) -> str:
        from_translate = ' -.()[]:+/",'
        to_translate = "_" * len(from_translate)
        mapping = str.maketrans(from_translate, to_translate)
        return name.translate(mapping)

    @classmethod
    def select_module_from_cec(cls, module_name: str) -> pd.DataFrame:
        module_id = cls.translate_sam_name_to_id(module_name)
        try:
            sam_db_path = "sam_2023.12.17_export/CEC_Modules.csv"
            return pvlib.pvsystem.retrieve_sam(path=sam_db_path)[module_id]
        except KeyError:
            raise KeyError(f"Module with name {module_name} not found in SAM DB (located in {sam_db_path})!")

    @classmethod
    def calculate_dc_singlediode_vectorized(cls, irrad, cell_temp, module, calc_type):
        input_params = cls.calc_input_params_singlediode(irrad, cell_temp, module, calc_type)
        return pvlib.pvsystem.singlediode(*input_params)

    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        print(f"[DEBUG] accumulator: \n{accumulator}")
        module = self.select_module_from_cec(accumulator["module_name"].iloc[0])

        calc_type = accumulator["calc_type"].iloc[0]
        module_no = accumulator["module_no"].iloc[0]

        irrad = pd.to_numeric(accumulator["irradiance"]).values
        cell_temp = pd.to_numeric(accumulator["cell_temp"]).values
        module_no = pd.to_numeric(accumulator["module_no"]).values

        dc_output = self.calculate_dc_singlediode_vectorized(irrad, cell_temp, module, calc_type)["p_mp"]

        dc_output.index = accumulator.index

        print(f"Types are {type(dc_output)} and {type(module_no)}")

        accumulator["dc_output"] = dc_output * module_no

        return accumulator
