import os

import pandas as pd
import requests

from modmod.models import CalculationModel


class CloudCoverPullingModel(CalculationModel):
    """
    Replace this docstring with a description of CloudCoverPullingModel
    """

    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        if date_range.start_date is None and date_range.end_date is None:
            datetime_now = pd.Timestamp.now().strftime("%Y-%m-%dT%H:%M:%S.%f%z")

            meteomatics_api_url = os.getenv(
                "METEOMATICS_API_URL") + f"{datetime_now}+02:00--{datetime_now}+02:00:PT5M/low_cloud_cover:p,medium_cloud_cover:p,high_cloud_cover:p,effective_cloud_cover:p/47.4707972,19.0615991/json?model=mix"

            request = requests.get(meteomatics_api_url, auth=("ulx_gero_kristof", "O8rr8I8ipD"))

            print(f"Sent request to {meteomatics_api_url}")
            response = request.json()

            cloud_cover_low = response["data"][0]["coordinates"][0]["dates"][0]["value"]
            cloud_cover_medium = response["data"][1]["coordinates"][0]["dates"][0]["value"]
            cloud_cover_high = response["data"][2]["coordinates"][0]["dates"][0]["value"]
            cloud_cover_effective = response["data"][3]["coordinates"][0]["dates"][0]["value"]

            date = response["data"][0]["coordinates"][0]["dates"][0]["date"]
            new_accumulator = pd.DataFrame(
                data=[[cloud_cover_low, cloud_cover_medium, cloud_cover_high, cloud_cover_effective]],
                index=[date],
                columns=["cloud_cover_low", "cloud_cover_medium", "cloud_cover_high", "cloud_cover_effective"]
            )
            accumulator = pd.concat([accumulator, new_accumulator])
        else:
            print(f"Date range: {date_range.start_date} - {date_range.end_date}")
            start_dt = pd.to_datetime(date_range.start_date, utc=True)
            end_dt = pd.to_datetime(date_range.end_date, utc=True)

            datetime_start = start_dt.strftime("%Y-%m-%dT%H:%M:%S.%f%z")
            datetime_end = end_dt.strftime("%Y-%m-%dT%H:%M:%S.%f%z")

            meteomatics_api_url = os.getenv(
                "METEOMATICS_API_URL") + f"{datetime_start}--{datetime_end}:PT5M/low_cloud_cover:p,medium_cloud_cover:p,high_cloud_cover:p,effective_cloud_cover:p/47.4707972,19.0615991/json?model=mix"

            request = requests.get(meteomatics_api_url, auth=("ulx_gero_kristof", "O8rr8I8ipD"))

            print(f"Sent request to {meteomatics_api_url}")
            response = request.json()

            # Process the Meteomatics API response
            data_dict = {
                'datetime': [],
                'cloud_cover_low': [],
                'cloud_cover_medium': [],
                'cloud_cover_high': [],
                'cloud_cover_effective': []
            }

            for param in response['data']:
                param_name = param['parameter'].split(':')[0].replace('_cloud_cover', '')
                column_name = f'cloud_cover_{param_name}'

                for date_value in param['coordinates'][0]['dates']:
                    if param_name == 'low':  # Only add datetime once per time point
                        data_dict['datetime'].append(date_value['date'])
                    data_dict[column_name].append(date_value['value'])

            df = pd.DataFrame(data_dict)
            df['timestamp'] = pd.to_datetime(df['datetime'])
            df = df.set_index('timestamp')

            # Reorder columns to match the expected output
            column_order = ['cloud_cover_low', 'cloud_cover_medium', 'cloud_cover_high', 'cloud_cover_effective']
            df = df[column_order]

            # Concatenate the new data with the existing accumulator
            accumulator = pd.concat([accumulator, df])

        return accumulator
