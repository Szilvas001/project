import pandas as pd
import pvlib

from modmod.models import CalculationModel


class SpectralFactorModel(CalculationModel):
    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        # Return a default spectral factor of 1.0 (no spectral correction)
        accumulator["spectral_factor"] = 1.0
        return accumulator
