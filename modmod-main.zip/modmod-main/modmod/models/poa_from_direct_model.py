import numpy as np
import pandas as pd
import pvlib
from pvlib import solarposition
from pvlib.irradiance import get_total_irradiance

from modmod.models import CalculationModel


class PoaFromDirectModel(CalculationModel):
    """
    This model calculates the Plane of Array (POA) irradiance using the direct and diffuse irradiance values
    provided in the accumulator. The POA irradiance is derived based on the tilt angle, azimuth angle, and the incident angle
    of solar radiation.

    Attributes:
        None
    """

    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        accumulator.reset_index(inplace=True, drop=True)
        accumulator.set_index('timestamp', inplace=True)
        timestamps = accumulator.index

        latitude = accumulator['latitude'].iloc[0]
        longitude = accumulator['longitude'].iloc[0]
        altitude = accumulator['altitude'].iloc[0]

        solar_position = pvlib.solarposition.get_solarposition(
            time=timestamps,
            latitude=latitude,
            longitude=longitude,
            altitude=altitude
        )

        # Extract relevant parameters from the accumulator
        dni = accumulator["direct_rad_w"]  # Direct Normal Irradiance (DNI)
        dhi = accumulator["diffuse_rad_w"]  # Diffuse Horizontal Irradiance (DHI)

        ghi = dhi + dni * np.cos(np.radians(solar_position['apparent_zenith']))

        panel_tilt = accumulator["panel_tilt"].iloc[0]  # Tilt angle of the PV panel in degrees
        panel_azimuth = accumulator["panel_azimuth"].iloc[0]  # Azimuth angle of the PV panel in degrees
        latitude = accumulator["latitude"].iloc[0]  # Latitude of the location in degrees
        longitude = accumulator["longitude"].iloc[0]  # Longitude of the location in degrees
        altitude = accumulator["altitude"].iloc[0]  # Altitude of the location in meters
        albedo = accumulator.get("albedo", 0.2)  # Default albedo if not available

        total_irradiance = get_total_irradiance(
            surface_tilt=panel_tilt,
            surface_azimuth=panel_azimuth,
            dni=dni,
            ghi=ghi,
            dhi=dhi,
            solar_zenith=solar_position['apparent_zenith'],
            solar_azimuth=solar_position['azimuth'],
            model='klucher',
            albedo=albedo,
        )

        poa_irradiance = total_irradiance['poa_global']

        accumulator['poa_irradiance'] = poa_irradiance

        accumulator.reset_index(inplace=True)

        return accumulator
