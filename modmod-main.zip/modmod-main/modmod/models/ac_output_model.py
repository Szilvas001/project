import pandas as pd
import pvlib

from modmod.models import CalculationModel


class AcOutputModel(CalculationModel):
    """
    Calculates the AC output of a PV system based on DC output and the inverter's specifications.
    """

    @classmethod
    def translate_sam_name_to_id(cls, name: str) -> str:
        from_translate = ' -.()[]:+/",'
        to_translate = "_" * len(from_translate)
        mapping = str.maketrans(from_translate, to_translate)
        return name.translate(mapping)

    @classmethod
    def select_inverter_from_cec(cls, inverter_name: str) -> pd.DataFrame:
        inverter_id = cls.translate_sam_name_to_id(inverter_name)
        try:
            sam_db_path = "sam_2023.12.17_export/CEC_Inverters.csv"
            return pvlib.pvsystem.retrieve_sam(path=sam_db_path)[inverter_id]
        except KeyError:
            raise KeyError(f"Inverter with name {inverter_name} not found in SAM DB (located in {sam_db_path})!")

    @classmethod
    def calculate_ac_pvwatts(cls, dc_power: float, inverter: pd.DataFrame) -> float:
        inverter_dc_input_limit = inverter["Pdco"]
        return pvlib.inverter.pvwatts(pdc=dc_power, pdc0=inverter_dc_input_limit)

    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        inverter = self.select_inverter_from_cec("Fronius International GmbH: Fronius Symo 12.5-3 480 [480V]")

        accumulator["ac_output"] = accumulator.apply(
            lambda row: self.calculate_ac_pvwatts(row["dc_output"], inverter), axis=1
        )

        return accumulator
