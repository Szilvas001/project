import pandas as pd
import pvlib

from modmod.models import CalculationModel


"""
Martin Ruiz IAM model: Calculate IAM using AOI and model-specific parameters.

Inputs:
  - aoi
  - irradiance_without_iam
  - angular_losses_coeff_a_r
Outputs:
  - iam
  - irradiance_with_iam
"""
class IncidentAngleModifierMartinRuizModel(CalculationModel):
    @classmethod
    def calc_iam(cls, accumulator) -> pd.Series:
        return pvlib.iam.martin_ruiz(accumulator["aoi"], a_r=accumulator["angular_losses_coeff_a_r"])

    def execute(self, accumulator: pd.DataFrame, date_range) -> pd.DataFrame:
        iams = self.calc_iam(accumulator)
        accumulator["iam"] = iams
        accumulator["irradiance_with_iam"] = accumulator["irradiance_without_iam"] * iams

        return accumulator
