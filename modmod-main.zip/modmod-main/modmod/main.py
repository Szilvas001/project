import pandas as pd
import os
import sys
from pathlib import Path
from dotenv import load_dotenv
from dateutil import parser

# Find and load the .env file from the project root
project_root = Path(__file__).parent.parent.absolute()
env_path = project_root / '.env'
if env_path.exists():
    print(f"Loading environment variables from {env_path}")
    load_dotenv(dotenv_path=env_path)
else:
    print(f"Warning: .env file not found at {env_path}")
    # Try to load from current directory as fallback
    load_dotenv()

# Print environment variables for debugging
print(f"DB_HOST: {os.getenv('DB_HOST')}")
print(f"DB_PORT: {os.getenv('DB_PORT')}")
print(f"DB_USER: {os.getenv('DB_USER')}")
print(f"DB_NAME: {os.getenv('DB_NAME')}")

os.environ['DB_NAME'] = 'kristof'
print(f"Before override - DB_NAME: {os.getenv('DB_NAME')}")
os.environ['DB_NAME'] = 'kristof'
print(f"After override - DB_NAME: {os.getenv('DB_NAME')}")

# Fallback for .env loading (keep as is)
if not os.getenv('DB_HOST'):
    print("Warning: .env file not found or DB variables not set, trying parent directory...")
    load_dotenv(dotenv_path=project_root.parent / '.env')
    # Re-check env variables after attempting load from parent
    print(f"After parent load attempt - DB_HOST: {os.getenv('DB_HOST')}")

# Add project root to Python path
# sys.path.insert(0, str(project_root))

from modmod.database import operations
from modmod.model_chain import build_model_chain
from modmod.models import clear_sky_model
# --- START REMOVAL --- 
# from modmod.irrad_to_dc import pvlib_calc_test # Example import, remove from package
# --- END REMOVAL ---
from modmod.date_range import DateRange # Import DateRange

def run_model_chain(input_dict, write_to_db=True):
    try:
        start_time = pd.Timestamp.now()

        # Parse dates robustly and ensure they are UTC
        try:
            start_date_str = input_dict['interval_start']
            end_date_str = input_dict['interval_end']
            start_date = pd.to_datetime(start_date_str, utc=True)
            end_date = pd.to_datetime(end_date_str, utc=True)
            # Create a DateRange object with parsed datetimes
            # We might need to adjust build_model_chain if it expects strings
            # For now, let's create it here and pass it, assuming build_model_chain can accept it
            # or that build_model_chain uses these fields from the input_dict directly.
            # Let's assume build_model_chain accesses input_dict directly for now.
            # We will update the input_dict for clarity and potential use by build_model_chain
            input_dict['interval_start_dt'] = start_date
            input_dict['interval_end_dt'] = end_date
            date_range_obj = DateRange(start_date, end_date)
        except KeyError as e:
            print(f"[ERROR] Missing required date key in input_dict: {e}")
            return None
        except Exception as e:
            print(f"[ERROR] Failed to parse dates: {e}")
            return None

        model_chain = build_model_chain(input_dict)
        # Ensure model_chain uses the parsed DateRange object
        model_chain.date_range = date_range_obj

        # Get required inputs (excluding fixed ones)
        required_inputs = list()
        outputs = list()
        for model in model_chain.models:
            outputs.extend([output_parameter.metric for output_parameter in model.output_parameters])
            for input_parameter in model.required_non_fixed_input_parameters:
                if input_parameter not in required_inputs:
                    required_inputs.append(input_parameter)

        required_inputs = [input_parameter for input_parameter in required_inputs if input_parameter not in outputs]
        required_fixed_inputs = {input_parameter.name: input_parameter.value for model in model_chain.models
                                 for input_parameter in model.input_parameters if input_parameter.value}

        accumulator = pd.DataFrame()

        # --- START FINAL INITIALIZATION LOGIC ---
        # Check if the chain starts with a known data loader model
        first_model_is_data_loader = False
        if model_chain.models:
             # Add other data loading model class names here if needed
             data_loader_model_names = ["HADataLoaderModel"] 
             first_model_name = model_chain.models[0].__class__.__name__
             if first_model_name in data_loader_model_names:
                 first_model_is_data_loader = True

        # ---- START DEBUG PRINTS ----
        print(f"[DEBUG main.py] Checking accumulator init logic:")
        print(f"[DEBUG main.py]   required_inputs empty? {not required_inputs}")
        print(f"[DEBUG main.py]   first_model_is_data_loader? {first_model_is_data_loader}")
        print(f"[DEBUG main.py]   First model actual name: '{first_model_name}'") # Print actual name found
        # ---- END DEBUG PRINTS ----

        if not required_inputs and not first_model_is_data_loader:
            # Case 1: No DB/API inputs needed AND first model doesn't load data -> Fixed value calc
            print(f"[INFO - Branch 1] No database/API inputs required and first model is not a data loader. Initializing accumulator for single fixed timestamp: {start_date}") # Modified log
            accumulator = pd.DataFrame(index=pd.DatetimeIndex([start_date], name='timestamp'))
        elif required_inputs and model_chain.input_table:
            # Case 2: DB inputs are required AND table specified -> Load from DB
            print(f"[INFO - Branch 2] Loading required inputs {required_inputs} from table '{model_chain.input_table}'") # Modified log
            accumulator = operations.load_required_inputs_from_db(required_inputs, start_date_str,
                                                                  end_date_str, model_chain.input_table)
            # Ensure index is DatetimeIndex and UTC after loading
            if not accumulator.empty:
                if 'timestamp' in accumulator.columns:
                    accumulator['timestamp'] = pd.to_datetime(accumulator['timestamp'], utc=True)
                    accumulator = accumulator.set_index('timestamp')
                elif isinstance(accumulator.index, pd.DatetimeIndex):
                    if accumulator.index.tz is None:
                        accumulator = accumulator.tz_localize('UTC')
                    else:
                        accumulator = accumulator.tz_convert('UTC')
                else:
                     print("[WARN] Loaded data has no 'timestamp' column or DatetimeIndex.")
            else:
                 print("[WARN] Loaded accumulator from DB is empty.")
        else:
            # Case 3: Other scenarios (e.g., first model IS a data loader, or DB inputs needed but no table)
            # -> Initialize accumulator empty, expect a model to populate it.
             print(f"[INFO - Branch 3] Accumulator initialized empty. Expecting a data loading model or subsequent process to populate.") # Modified log
        # --- END FINAL INITIALIZATION LOGIC ---

        for model in model_chain.models:
            accumulator = model.calculate(accumulator, model_chain.date_range)

        if 'timestamp' in required_fixed_inputs:
            accumulator = accumulator.tail(1)

        if write_to_db:
            operations.write_df_into_db(accumulator, model_chain.output_table)

        finish_time = pd.Timestamp.now()
        seconds_taken = str((finish_time - start_time).total_seconds())
        print(f"[INFO] Execution took {seconds_taken} seconds")

        return accumulator

    except ValueError as e:
        print(f"[ERROR] {e}")
        return None


if __name__ == "__main__":
    from example_dict import integral_test
    df = run_model_chain(integral_test, write_to_db=True)
    print(df[df.index >= '2025-04-27 10:30:00+00:00'])
