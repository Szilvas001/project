from abc import ABC, abstractmethod
from typing import List, Dict, Any

import pandas as pd


class TransformationStrategy(ABC):
    def __init__(self, parameters: List[Dict[str, Any]]):
        self.parameters = parameters

    @abstractmethod
    def apply(self, data: pd.Series) -> pd.Series:
        pass
