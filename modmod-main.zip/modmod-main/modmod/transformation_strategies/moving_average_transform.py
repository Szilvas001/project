import pandas as pd

from modmod.transformation_strategies import TransformationStrategy


class MovingAverageTransform(TransformationStrategy):
    def apply(self, data: pd.Series) -> pd.Series:
        print("Applying moving average transformation")
        return data
