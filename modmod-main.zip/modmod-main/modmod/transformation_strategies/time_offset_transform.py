import pandas as pd

from modmod.transformation_strategies import TransformationStrategy


class TimeOffsetTransform(TransformationStrategy):
    def apply(self, data: pd.Series) -> pd.Series:
        print("Applying time offset transformation")
        return data
