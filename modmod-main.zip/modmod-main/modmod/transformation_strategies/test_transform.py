import pandas as pd

from modmod.transformation_strategies import TransformationStrategy


class TestTransform(TransformationStrategy):
    def apply(self, data: pd.Series) -> pd.Series:
        print("Applying test transformation: ", self.parameters)
        data *= float(self.parameters[0]["test_param"])
        return data
