

pvlib_calc_test = {
    "modules": [
        {
            "model": "ha_data_loader",
            "inputs": {},
            "outputs": {
                "sensor.calculated_effective_poa_irradiance_tvl9": {
                    "metric": "sensor.calculated_effective_poa_irradiance_tvl9",
                    "transformations": []
                },
                "sensor.calculated_incident_angle_modifier_ashrae_tvl9": {
                    "metric": "sensor.calculated_incident_angle_modifier_ashrae_tvl9",
                    "transformations": []
                },
                "sensor.tvl9_gw2000a_absolute_pressure": {
                    "metric": "sensor.tvl9_gw2000a_absolute_pressure",
                    "transformations": []
                },
                "sensor.tvl9_gw2000a_outdoor_temperature": {
                    "metric": "sensor.tvl9_gw2000a_outdoor_temperature",
                    "transformations": []
                },
                "sensor.tvl9_gw2000a_humidity": {
                    "metric": "sensor.tvl9_gw2000a_humidity",
                    "transformations": []
                },
                "sensor.tvl9_rt1_mid_poa_irradiance": {
                    "metric": "sensor.tvl9_rt1_mid_poa_irradiance",
                    "transformations": []
                },
                "sensor.tvl9_rt1_mid_module_temp": {
                    "metric": "sensor.tvl9_rt1_mid_module_temp",
                    "transformations": []
                },
                "input_text.pv_module_name": {
                    "metric": "input_text.pv_module_name",
                    "transformations": []
                }
            },
        },
        {
            "model": "solar_position_model",
            "inputs": {
                "ha_pressure_pa": {
                    "metric": "sensor.tvl9_gw2000a_absolute_pressure",
                    "transformations": []
                },
                "ha_temperature": {
                    "metric": "sensor.tvl9_gw2000a_outdoor_temperature",
                    "transformations": []
                },
                "latitude": {
                    "value": 47.523533
                },
                "longitude": {
                    "value": 19.012432
                },
                "altitude": {
                    "value": 240
                },
            },
            "outputs": {
                "solar_azimuth": {
                    "metric": "solar_azimuth",
                },
                "solar_zenith": {
                    "metric": "solar_zenith",
                }
            }
        },
        {
            "model": "relative_airmass_model",
            "inputs": {
                "solar_zenith": {
                    "metric": "solar_zenith",
                    "transformations": []
                }
            },
            "outputs": {
                "relative_airmass": {
                    "metric": "relative_airmass",
                }
            }
        },
        {
            "model": "absolute_airmass_model",
            "inputs": {
                "relative_airmass": {
                    "metric": "relative_airmass",
                    "transformations": []
                },
                "ha_pressure_pa": {
                    "metric": "sensor.tvl9_gw2000a_absolute_pressure",
                    "transformations": []
                }
            },
            "outputs": {
                "absolute_airmass": {
                    "metric": "absolute_airmass",
                },
            }
        },
        {
            "model": "precipitable_water_model",
            "inputs": {
                "ha_temperature": {
                    "metric": "sensor.tvl9_gw2000a_outdoor_temperature",
                    "transformations": []
                },
                "humidity": {
                    "metric": "sensor.tvl9_gw2000a_humidity",
                    "transformations": []
                }
            },
            "outputs": {
                "precipitable_water": {
                    "metric": "precipitable_water",
                }
            }
        },
        {
            "model": "spectral_factor_model",
            "inputs": {
                "precipitable_water": {
                    "metric": "precipitable_water",
                    "transformations": []
                },
                "absolute_airmass": {
                    "metric": "absolute_airmass",
                    "transformations": []
                },
                "module_type": {
                    "value": "monosi"
                }
            },
            "outputs": {
                "spectral_factor": {
                    "metric": "spectral_factor",
                }
            }
        },
        {
            "model": "incident_angle_modifier_model",
            "inputs": {
                "ha_iam": {
                    "metric": "sensor.calculated_incident_angle_modifier_ashrae_tvl9",
                    "transformations": []
                },
            },
            "outputs": {
                "iam": {
                    "metric": "iam",
                }
            }
        },
        {
            "model": "cell_temp_model",
            "inputs": {
                "mounting_key": {
                    "value": "open_rack_glass_polymer"
                },
                "ha_poa_irrad": {
                    "metric": "sensor.tvl9_rt1_mid_poa_irradiance",
                    "transformations": []
                },
                "ha_module_temp": {
                    "metric": "sensor.tvl9_rt1_mid_module_temp",
                    "transformations": []
                }
            },
            "outputs": {
                "cell_temp": {
                    "metric": "cell_temp",
                }
            }
        },
        {
            "model": "angle_of_incidence_model",
            "inputs": {
                "panel_tilt": {
                    "value": 12.0
                },
                "panel_azimuth": {
                    "value": 183.0
                },
                "ha_pressure_pa": {
                    "metric": "sensor.tvl9_gw2000a_absolute_pressure",
                    "transformations": []
                },
                "ha_temperature": {
                    "metric": "sensor.tvl9_gw2000a_outdoor_temperature",
                    "transformations": []
                },
                "latitude": {
                    "value": 47.523618
                },
                "longitude": {
                    "value": 19.012776
                },
                "altitude": {
                    "value": 240
                },
            },
            "outputs": {
                "aoi": {
                    "metric": "aoi",
                }
            }
        },
        {
            "model": "poa_effective_irradiance_model",
            "inputs": {
                "ha_poa_irrad": {
                    "metric": "sensor.tvl9_rt1_mid_poa_irradiance",
                    "transformations": []
                },
                "spectral_factor": {
                    "metric": "spectral_factor",
                    "transformations": []
                },
                "iam": {
                    "metric": "iam",
                    "transformations": []
                }
            },
            "outputs": {
                "poa_effective_irradiance": {
                    "metric": "poa_effective_irradiance",
                },
            }
        },

        {
            "model": "dc_output_model",
            "inputs": {
                "irradiance": {
                    "metric": "poa_effective_irradiance",
                    "transformations": []
                },
                "cell_temp": {
                    "metric": "cell_temp",
                    "transformations": []
                },
                "module_name": {
                    "value": "Trina Solar TSM-400DE09.08",
                },
                "calc_type": {
                    "value": "cec"
                },
                "module_no": {
                    "value": 14
                }
            },
            "outputs": {
                "dc_output": {
                    "metric": "dc_output",
                }
            }
        },
    ],
    "input_table": "normalized_dataset_12deg",
    "output_table": "dc_output_edge_12deg",
    "interval_start": "2025-04-14 00:00:00.000+00",
    "interval_end": "2025-04-16 00:00:00.000+00",
}