import pytest

from modmod.example_dict import live_without_historical_data_test, live_with_historical_data_test, ha_data_loader_test, \
    pvlib_calc_test, consumer_test
from modmod.main import run_model_chain


@pytest.mark.parametrize("input_dict", [pvlib_calc_test, ha_data_loader_test, live_without_historical_data_test,
                                        live_with_historical_data_test, consumer_test])
def test_model_chain(input_dict):
    result = run_model_chain(input_dict, write_to_db=False)

    # Check if the result is not None (no error occurred)
    assert result is not None, f"Model chain failed for input dictionary: {input_dict}"

    # Check if the accumulator is not empty
    assert not result.empty, f"Accumulator is empty for input dictionary: {input_dict}"

    # Check if all values in the accumulator are valid (non-NaN)
    assert not result.isnull().values.any(), f"Accumulator contains NaN values for input dictionary: {input_dict}"


if __name__ == "__main__":
    pytest.main([__file__])
