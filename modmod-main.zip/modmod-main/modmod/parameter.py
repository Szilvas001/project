from typing import Any, List, Dict

from modmod.data_transform import DataTransform


class InputParameter:
    def __init__(self, name: str, metric: str, transformations: List[DataTransform], value: Any):
        self.name = name
        self.metric = metric
        self.transformations = transformations
        self.value = value

    def transform(self, data):
        for transform in self.transformations:
            data = transform.apply(data)
        return data


class OutputParameter:
    def __init__(self, name: str, metric: str):
        self.name = name
        self.metric = metric


class ParameterProcessor:
    @staticmethod
    def process_input(name: str, config: Dict[str, Any]) -> InputParameter:
        if "metric" in config:
            metric = config["metric"]
            transformations = [DataTransform(**transform) for transform in config.get("transformations", [])]
            value = None
        else:
            metric = None
            transformations = []
            value = config["value"]

        return InputParameter(name, metric, transformations, value)

    @staticmethod
    def process_output(name: str, config: Dict[str, str]) -> OutputParameter:
        return OutputParameter(name, config["metric"])
