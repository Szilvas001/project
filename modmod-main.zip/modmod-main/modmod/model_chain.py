from typing import List, Dict, Any

from modmod import DateRange
from modmod.calculation_model_helper import create_model
from modmod.models import CalculationModel


class ModelChain:
    def __init__(self, models: [CalculationModel], date_range, input_table, output_table):
        self.models = models
        self.date_range = date_range
        self.input_table = input_table
        self.output_table = output_table


def build_model_chain(data: List[Dict[str, Any]]) -> ModelChain:
    interval_start = None
    interval_end = None
    if 'interval_start' in data:
        interval_start = data['interval_start']
    if 'interval_end' in data:
        interval_end = data['interval_end']

    date_range = DateRange(interval_start, interval_end)

    input_table = data['input_table']
    output_table = data['output_table']

    models = [create_model(module) for module in data["modules"]]

    return ModelChain(models, date_range, input_table, output_table)
