from datetime import datetime
from zoneinfo import ZoneInfo

import openmeteo_requests
import requests_cache
from openmeteo_sdk import WeatherApiResponse
from retry_requests import retry


class OpenMeteoAPI():

    def __init__(self, lat: float, long: float, tz: str):
        self.lat = lat
        self.long = long
        self.tz = tz

        # Setup the Open-Meteo API client with cache and retry on error
        self.cache_session = requests_cache.CachedSession('.cache', expire_after=300, backend="memory")
        self.retry_session = retry(self.cache_session, retries=5, backoff_factor=0.2)
        self.openmeteo = openmeteo_requests.Client(session=self.retry_session)
        self.most_recent_response = None

    def call_weather_api(self) -> WeatherApiResponse.WeatherApiResponse:
        # Make sure all required weather variables are listed here
        # The order of variables in hourly or daily is important to assign them correctly below
        url = "https://api.open-meteo.com/v1/forecast"
        params = {
            "latitude": self.lat,
            "longitude": self.long,
            "current": ["temperature_2m", "relative_humidity_2m", "surface_pressure"],
            "timezone": self.tz,
            "forecast_days": 1
        }
        responses = self.openmeteo.weather_api(url, params=params)

        # Process first location. Add a for-loop for multiple locations or weather calculation_models
        self.most_recent_response = responses[0]
        return responses[0]

    def call_api_fetch_current_temp_with_timestamp(self) -> tuple[float, datetime]:
        return get_current_temp_with_timestamp(self.call_weather_api(), self.get_tz())

    def get_most_recent_current_temp_with_timestamp(self, call_api: bool = False) -> tuple[float, datetime]:
        if (call_api or self.most_recent_response is None):
            return self.call_api_fetch_current_temp_with_timestamp()
        else:
            return get_current_temp_with_timestamp(self.most_recent_response, self.get_tz())

    def call_api_fetch_current_surface_pressure_with_timestamp(self) -> tuple[float, datetime]:
        return get_current_surface_pressure_with_timestamp(self.call_weather_api(), self.get_tz())

    def get_most_recent_current_surface_pressure_with_timestamp(self, call_api: bool = False) -> tuple[float, datetime]:
        if (call_api or self.most_recent_response is None):
            return self.call_api_fetch_current_surface_pressure_with_timestamp()
        else:
            return get_current_surface_pressure_with_timestamp(self.most_recent_response, self.get_tz())

    def call_api_fetch_current_rel_humidity_with_timestamp(self) -> tuple[float, datetime]:
        return get_current_rel_humidity_with_timestamp(self.call_weather_api(), self.get_tz())

    def get_most_recent_current_rel_humidity_with_timestamp(self, call_api: bool = False) -> tuple[float, datetime]:
        if (call_api or self.most_recent_response is None):
            return self.call_api_fetch_current_rel_humidity_with_timestamp()
        else:
            return get_current_rel_humidity_with_timestamp(self.most_recent_response, self.get_tz())

    def get_tz(self) -> ZoneInfo:
        return ZoneInfo(self.tz)


def print_response_details(response: WeatherApiResponse.WeatherApiResponse):
    print(f"Coordinates {response.Latitude()}°N {response.Longitude()}°E")
    print(f"Elevation {response.Elevation()} m asl")
    print(f"Timezone {response.Timezone()} {response.TimezoneAbbreviation()}")
    print(f"Timezone difference to GMT+0 {response.UtcOffsetSeconds()} s")


def get_current_temp_with_timestamp(response: WeatherApiResponse.WeatherApiResponse, tz: ZoneInfo) -> tuple[
    float, datetime]:
    # Current values. The order of variables needs to be the same as requested.
    current = response.Current()
    current_temperature_2m = current.Variables(0).Value()
    return (
        current_temperature_2m,
        datetime.fromtimestamp(current.Time(), tz=tz),
    )


def get_current_rel_humidity_with_timestamp(response: WeatherApiResponse.WeatherApiResponse, tz: ZoneInfo) -> tuple[
    float, datetime]:
    # Current values. The order of variables needs to be the same as requested.
    current = response.Current()
    rel_humidity_2m = current.Variables(1).Value()
    return (
        rel_humidity_2m,
        datetime.fromtimestamp(current.Time(), tz=tz),
    )


def get_current_surface_pressure_with_timestamp(response: WeatherApiResponse.WeatherApiResponse, tz: ZoneInfo) -> tuple[
    float, datetime]:
    # Current values. The order of variables needs to be the same as requested.
    current = response.Current()
    # OpenMeteo supplies pressure values in hPa, so we convert it to Pa
    surface_pressure = current.Variables(2).Value() * 100
    return (
        surface_pressure,
        datetime.fromtimestamp(current.Time(), tz=tz),
    )
