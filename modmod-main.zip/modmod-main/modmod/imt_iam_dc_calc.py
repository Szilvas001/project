from datetime import datetime
from zoneinfo import ZoneInfo
from chains.common import StringMetadata, StringType, DateFormat, format_datetime

def get_imt_dc_calc_wind_data_modmod_chain(string_type: StringType, date_start: datetime, date_end: datetime) -> dict:
    concise_date_start = format_datetime(date_start, DateFormat.DATE)
    concise_date_end = format_datetime(date_end, DateFormat.DATE)

    long_date_start = format_datetime(date_start, DateFormat.MICROSEC_TZ)
    long_date_end = format_datetime(date_end, DateFormat.MICROSEC_TZ)

    other_string_type = StringType.MID if string_type == StringType.EDGE else StringType.EDGE

    string_metadata_this_type = StringMetadata(string_type)
    string_metadata_other_type = StringMetadata(other_string_type)

    return {
      "modules": [
        {
          "model": "ha_data_loader",
          "inputs": {},
          "outputs": {
            "sensor.tvl9_imt_11_irrad": {
              "metric": "sensor.tvl9_imt_11_irrad",
              "transformations": []
            },
            "sensor.tvl9_imt_12_irrad": {
              "metric": "sensor.tvl9_imt_12_irrad",
              "transformations": []
            },
            "sensor.tvl9_rt1_mid_module_temp": {
              "metric": "sensor.tvl9_rt1_mid_module_temp",
              "transformations": []
            },
            "sensor.tvl9_rt1_edge_module_temp": {
              "metric": "sensor.tvl9_rt1_edge_module_temp",
              "transformations": []
            },
            "input_text.pv_module_name": {
              "metric": "input_text.pv_module_name",
              "transformations": []
            },
            "sensor.tvl9_gw2000a_absolute_pressure": {
                "metric": "sensor.tvl9_gw2000a_absolute_pressure"
            },
            "sensor.tvl9_gw2000a_outdoor_temperature": {
                "metric": "sensor.tvl9_gw2000a_outdoor_temperature"
            },
            f"sensor.tvl9_{string_metadata_this_type.type}_dc_power_output_calculation_singlediode_cec": {
              "metric": f"sensor.tvl9_{string_metadata_this_type.type}_dc_power_output_calculation_singlediode_cec",
              "transformations": []
            },
            "sensor.tvl9_gw2000a_wind_speed": {
              "metric": "sensor.tvl9_gw2000a_wind_speed",
              "transformations": []
            },
            "sensor.tvl9_gw2000a_wind_direction": {
              "metric": "sensor.tvl9_gw2000a_wind_direction",
              "transformations": []
            },
            f"sensor.tvl9_fronius_mppt_module_{string_metadata_this_type.mppt_id}_dc_power": {
              "metric": f"sensor.tvl9_fronius_mppt_module_{string_metadata_this_type.mppt_id}_dc_power",
              "transformations": []
            }
          }
        },
        {
            "model": "solar_position_model",
            "inputs": {
                "ha_pressure_pa": {
                    "metric": "sensor.tvl9_gw2000a_absolute_pressure",
                    "transformations": []
                },
                "ha_temperature": {
                    "metric": "sensor.tvl9_gw2000a_outdoor_temperature",
                    "transformations": []
                },
                "latitude": {
                    "value": 47.523533
                },
                "longitude": {
                    "value": 19.012432
                },
                "altitude": {
                    "value": 240
                },
            },
            "outputs": {
                "solar_azimuth": {
                    "metric": "solar_azimuth",
                },
                "solar_zenith": {
                    "metric": "solar_zenith",
                }
            }
        },
        {
            "model": "angle_of_incidence_model",
            "inputs": {
                "panel_tilt": {
                    "value": 12.33
                },
                "panel_azimuth": {
                    "value": 183.0
                },
                "ha_pressure_pa": {
                    "metric": "sensor.tvl9_gw2000a_absolute_pressure",
                    "transformations": []
                },
                "ha_temperature": {
                    "metric": "sensor.tvl9_gw2000a_outdoor_temperature",
                    "transformations": []
                },
                "latitude": {
                    # why was this different?
                    # "value": 47.523618
                    "value": 47.523533
                },
                "longitude": {
                    # why was this different?
                    # "value": 19.012776
                    "value": 19.012432
                },
                "altitude": {
                    "value": 240
                },
            },
            "outputs": {
                "aoi": {
                    "metric": f"{string_metadata_this_type.type}_aoi",
                }
            }
        },
        {
            "model": "revert_imt_iam_model",
            "inputs": {
                "aoi": {
                    "metric": f"{string_metadata_this_type.type}_aoi"
                },
                "irradiance_with_imt_iam": {
                    "metric": f"sensor.tvl9_imt_{string_metadata_this_type.imt_no}_irrad"
                }
            },
            "outputs": {
                "iam_reversed_irradiance_output": {
                    "metric": f"iam_reversed_{string_metadata_this_type.type}_irradiance_output"
                },
                "included_imt_iam_factor": {
                    "metric": f"included_{string_metadata_this_type.type}_imt_iam_factor"
                }
            }
        },
        {
            "model": "incident_angle_modifier_physical_model",
            "inputs": {
                "aoi": {
                    "metric": f"{string_metadata_this_type.type}_aoi"
                },
                "irradiance_without_iam": {
                    "metric": f"iam_reversed_{string_metadata_this_type.type}_irradiance_output"
                },
                "glazing_thickness_L": {
                    "value": 0.0036
                }
            },
            "outputs": {
                "iam": {
                    "metric": "iam_physical"
                },
                "irradiance_with_iam": {
                    "metric": "irradiance_with_iam_physical"
                }
            }
        },
        {
            "model": "incident_angle_modifier_ashrae_model",
            "inputs": {
                "aoi": {
                    "metric": f"{string_metadata_this_type.type}_aoi"
                },
                "irradiance_without_iam": {
                    "metric": f"iam_reversed_{string_metadata_this_type.type}_irradiance_output"
                },
                "iam_aoi_adjuster_b": {
                    "value": 0.05
                }
            },
            "outputs": {
                "iam": {
                    "metric": "iam_ashrae"
                },
                "irradiance_with_iam": {
                    "metric": "irradiance_with_iam_ashrae"
                }
            }
        },
        {
            "model": "incident_angle_modifier_martin_ruiz_model",
            "inputs": {
                "aoi": {
                    "metric": f"{string_metadata_this_type.type}_aoi"
                },
                "irradiance_without_iam": {
                    "metric": f"iam_reversed_{string_metadata_this_type.type}_irradiance_output"
                },
                "angular_losses_coeff_a_r": {
                    "value": 0.16
                }
            },
            "outputs": {
                "iam": {
                    "metric": "iam_martin_ruiz"
                },
                "irradiance_with_iam": {
                    "metric": "irradiance_with_iam_martin_ruiz"
                }
            }
        },
        {
            "model": "cell_temp_model",
            "inputs": {
                "mounting_key": {
                    "value": "open_rack_glass_polymer"
                },
                "ha_poa_irrad": {
                    "metric": f"sensor.tvl9_imt_{string_metadata_this_type.imt_no}_irrad",
                    "transformations": []
                },
                "ha_module_temp": {
                    "metric": f"sensor.tvl9_rt1_{string_metadata_this_type.type}_module_temp",
                    "transformations": []
                }
            },
            "outputs": {
                "cell_temp": {
                    "metric": f"cell_temp_{string_metadata_this_type.type}",
                }
            }
        },
        {
            "model": "cell_temp_model",
            "inputs": {
                "mounting_key": {
                    "value": "open_rack_glass_polymer"
                },
                "ha_poa_irrad": {
                    "metric": f"sensor.tvl9_imt_{string_metadata_other_type.imt_no}_irrad",
                    "transformations": []
                },
                "ha_module_temp": {
                    "metric": f"sensor.tvl9_rt1_{string_metadata_other_type.type}_module_temp",
                    "transformations": []
                }
            },
            "outputs": {
                "cell_temp": {
                    "metric": f"cell_temp_{string_metadata_other_type.type}",
                }
            }
        },
        {
            "model": "average_model",
            "inputs": {
                "avg_a_value": {
                    "metric": f"cell_temp_{string_metadata_other_type.type}",
                    "transformations": []
                },
                "avg_b_value": {
                    "metric": f"cell_temp_{string_metadata_this_type.type}",
                    "transformations": []
                }
            },
            "outputs": {
                "average_output": {
                    "metric": "cell_temp_average",
                }
            }
        },
        {
          "model": "dc_output_model",
          "inputs": {
            "irradiance": {
              "metric": f"sensor.tvl9_imt_{string_metadata_this_type.imt_no}_irrad"
            },
            "cell_temp": {
              "metric": "cell_temp_average"
            },
            "module_name": {
              "value": "Trina Solar TSM-400DE09.08"
            },
            "calc_type": {
              "value": "cec"
            },
            "module_no": {
              "value": f"{string_metadata_this_type.module_no}"
            }
          },
          "outputs": {
            "dc_output": {
              "metric": f"{string_metadata_this_type.type}_dc_output"
            }
          }
        },
        {
          "model": "dc_output_model",
          "inputs": {
            "irradiance": {
              "metric": "irradiance_with_iam_physical"
            },
            "cell_temp": {
              "metric": "cell_temp_average"
            },
            "module_name": {
              "value": "Trina Solar TSM-400DE09.08"
            },
            "calc_type": {
              "value": "cec"
            },
            "module_no": {
              "value": f"{string_metadata_this_type.module_no}"
            }
          },
          "outputs": {
            "dc_output": {
              "metric": f"{string_metadata_this_type.type}_dc_output_iam_physical"
            }
          }
        },
        {
          "model": "dc_output_model",
          "inputs": {
            "irradiance": {
              "metric": "irradiance_with_iam_ashrae"
            },
            "cell_temp": {
              "metric": "cell_temp_average"
            },
            "module_name": {
              "value": "Trina Solar TSM-400DE09.08"
            },
            "calc_type": {
              "value": "cec"
            },
            "module_no": {
              "value": f"{string_metadata_this_type.module_no}"
            }
          },
          "outputs": {
            "dc_output": {
              "metric": f"{string_metadata_this_type.type}_dc_output_iam_ashrae"
            }
          }
        },
        {
          "model": "dc_output_model",
          "inputs": {
            "irradiance": {
              "metric": "irradiance_with_iam_martin_ruiz"
            },
            "cell_temp": {
              "metric": "cell_temp_average"
            },
            "module_name": {
              "value": "Trina Solar TSM-400DE09.08"
            },
            "calc_type": {
              "value": "cec"
            },
            "module_no": {
              "value": f"{string_metadata_this_type.module_no}"
            }
          },
          "outputs": {
            "dc_output": {
              "metric": f"{string_metadata_this_type.type}_dc_output_iam_martin_ruiz"
            }
          }
        }
      ],
      "input_table": "",
      "output_table": f"wind_data_{string_metadata_this_type.type}_imt{string_metadata_this_type.imt_no}_sensors_irrad_dc_output_calc_{concise_date_start}_{concise_date_end}",
      "interval_start": f"{long_date_start}",
      "interval_end": f"{long_date_end}"
    }


def get_mid_edge_imt_dc_wind_data_chains_for_date(date_start: datetime, date_end: datetime) -> dict[str, dict]:
    result = []
    for string_type in [StringType.MID, StringType.EDGE]:
        result.append(get_imt_dc_calc_wind_data_modmod_chain(
            string_type=string_type,
            date_start=date_start,
            date_end=date_end,
        ))

    return result[0], result[1]


mid_imt12_0426_0428 = get_imt_dc_calc_wind_data_modmod_chain(
    string_type=StringType.MID,
    date_start=datetime(2025, 4, 26, 5, 25, 0, 0, ZoneInfo('Europe/Budapest')),
    date_end=datetime(2025, 4, 28, 19, 50, 0, 0, ZoneInfo('Europe/Budapest'))
)

edge_imt11_0426_0428 = get_imt_dc_calc_wind_data_modmod_chain(
    string_type=StringType.EDGE,
    date_start=datetime(2025, 4, 26, 5, 25, 0, 0, ZoneInfo('Europe/Budapest')),
    date_end=datetime(2025, 4, 28, 19, 50, 0, 0, ZoneInfo('Europe/Budapest'))
)

mid_imt12_0427_0509, edge_imt11_0427_0509 = get_mid_edge_imt_dc_wind_data_chains_for_date(
    date_start=datetime(2025, 4, 27, 5, 5, 20, 0, ZoneInfo('Europe/Budapest')),
    date_end=datetime(2025, 5, 9, 10, 5, 13, 0, ZoneInfo('Europe/Budapest'))
)
