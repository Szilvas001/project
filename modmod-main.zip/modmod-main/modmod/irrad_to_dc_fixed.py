pvlib_calc_test = {
  "modules": [
    {
      "model": "dc_output_model",
      "inputs": {
        "irradiance": {
          "value": "735"
        },
        "cell_temp": {
          "value": "28"
        },
        "module_name": {
          "value": "Trina Solar TSM-400DE09.08"
        },
        "calc_type": {
          "value": "cec"
        },
        "module_no": {
          "value": "14"
        }
      },
      "outputs": {
        "dc_output": {
          "metric": "dc_output"
        }
      }
  }
  ],
  "input_table": "normalized_dataset_12deg",
  "output_table": "asdasdasd",
  "interval_start": "2025-04-14 00:00:00.000+00",
  "interval_end": "2025-04-16 00:00:00.000+00",
}