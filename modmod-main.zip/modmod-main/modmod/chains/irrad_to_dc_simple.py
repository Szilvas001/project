from datetime import datetime
from zoneinfo import ZoneInfo
from chains.common import StringMetadata, StringType, DateFormat, format_datetime

def create_irrad_to_dc_chain(string_type: StringType, date_start: datetime, date_end: datetime) -> dict:
    concise_date_start = format_datetime(date_start, DateFormat.DATE)
    concise_date_end = format_datetime(date_end, DateFormat.DATE)

    long_date_start = format_datetime(date_start, DateFormat.MICROSEC_TZ)
    long_date_end = format_datetime(date_end, DateFormat.MICROSEC_TZ)

    other_string_type = StringType.MID if string_type == StringType.EDGE else StringType.EDGE

    string_metadata_this_type = StringMetadata(string_type)
    string_metadata_other_type = StringMetadata(other_string_type)

    return {
      "modules": [
        {
          "model": "ha_data_loader",
          "inputs": {},
          "outputs": {
            f"sensor.tvl9_imt_{string_metadata_this_type.imt_no}_irrad": {
              "metric": f"sensor.tvl9_imt_{string_metadata_this_type.imt_no}_irrad",
              "transformations": []
            },
            f"sensor.tvl9_imt_{string_metadata_other_type.imt_no}_irrad": {
              "metric": f"sensor.tvl9_imt_{string_metadata_other_type.imt_no}_irrad",
              "transformations": []
            },
            f"sensor.tvl9_rt1_{string_metadata_this_type.type}_module_temp": {
              "metric": f"sensor.tvl9_rt1_{string_metadata_this_type.type}_module_temp",
              "transformations": []
            },
            f"sensor.tvl9_rt1_{string_metadata_other_type.type}_module_temp": {
              "metric": f"sensor.tvl9_rt1_{string_metadata_other_type.type}_module_temp",
              "transformations": []
            },
            f"sensor.tvl9_fronius_mppt_module_{string_metadata_this_type.mppt_id}_dc_power": {
              "metric": f"sensor.tvl9_fronius_mppt_module_{string_metadata_this_type.mppt_id}_dc_power",
              "transformations": []
            }
          }
        },
        {
            "model": "cell_temp_model",
            "inputs": {
                "mounting_key": {
                    "value": "open_rack_glass_polymer"
                },
                "ha_poa_irrad": {
                    "metric": f"sensor.tvl9_imt_{string_metadata_this_type.imt_no}_irrad",
                    "transformations": []
                },
                "ha_module_temp": {
                    "metric": f"sensor.tvl9_rt1_{string_metadata_this_type.type}_module_temp",
                    "transformations": []
                }
            },
            "outputs": {
                "cell_temp": {
                    "metric": f"cell_temp_{string_metadata_this_type.type}",
                }
            }
        },
        {
            "model": "cell_temp_model",
            "inputs": {
                "mounting_key": {
                    "value": "open_rack_glass_polymer"
                },
                "ha_poa_irrad": {
                    "metric": f"sensor.tvl9_imt_{string_metadata_other_type.imt_no}_irrad",
                    "transformations": []
                },
                "ha_module_temp": {
                    "metric": f"sensor.tvl9_rt1_{string_metadata_other_type.type}_module_temp",
                    "transformations": []
                }
            },
            "outputs": {
                "cell_temp": {
                    "metric": f"cell_temp_{string_metadata_other_type.type}",
                }
            }
        },
        {
            "model": "average_model",
            "inputs": {
                "avg_a_value": {
                    "metric": f"cell_temp_{string_metadata_other_type.type}",
                    "transformations": []
                },
                "avg_b_value": {
                    "metric": f"cell_temp_{string_metadata_this_type.type}",
                    "transformations": []
                }
            },
            "outputs": {
                "average_output": {
                    "metric": "cell_temp_average",
                }
            }
        },
        {
          "model": "dc_output_model",
          "inputs": {
            "irradiance": {
              "metric": f"sensor.tvl9_imt_{string_metadata_this_type.imt_no}_irrad"
            },
            "cell_temp": {
              "metric": "cell_temp_average"
            },
            "module_name": {
              "value": "Trina Solar TSM-400DE09.08"
            },
            "calc_type": {
              "value": "cec"
            },
            "module_no": {
              "value": f"{string_metadata_this_type.module_no}"
            }
          },
          "outputs": {
            "dc_output": {
              "metric": f"{string_metadata_this_type.type}_dc_output"
            }
          }
        },
        {
          "model": "dc_output_model",
          "inputs": {
            "irradiance": {
              "metric": f"sensor.tvl9_imt_{string_metadata_other_type.imt_no}_irrad"
            },
            "cell_temp": {
              "metric": "cell_temp_average"
            },
            "module_name": {
              "value": "Trina Solar TSM-400DE09.08"
            },
            "calc_type": {
              "value": "cec"
            },
            "module_no": {
              "value": f"{string_metadata_other_type.module_no}"
            }
          },
          "outputs": {
            "dc_output": {
              "metric": f"{string_metadata_other_type.type}_dc_output"
            }
          }
        },
      ],
      "input_table": "",
      "output_table": f"{string_metadata_this_type.type}_imt{string_metadata_this_type.imt_no}_sensors_irrad_dc_output_calc_{concise_date_start}_{concise_date_end}",
      "interval_start": f"{long_date_start}",
      "interval_end": f"{long_date_end}"
    }


def get_mid_edge_irrad_to_dc_chains_for_date(date_start: datetime, date_end: datetime) -> dict[str, dict]:
    result = []
    for string_type in [StringType.MID, StringType.EDGE]:
        result.append(create_irrad_to_dc_chain(
            string_type=string_type,
            date_start=date_start,
            date_end=date_end,
        ))

    return result[0], result[1]


mid_from_2025_08, edge_from_2025_08 = get_mid_edge_irrad_to_dc_chains_for_date(
    date_start=datetime(2025, 8, 15, 12, 57, 45, 0, ZoneInfo('Europe/Budapest')),
    date_end=datetime(2025, 9, 22, 16, 30, 0, 0, ZoneInfo('Europe/Budapest'))
)
