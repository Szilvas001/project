from .irrad_to_dc_simple import edge_from_2025_08, mid_from_2025_08
