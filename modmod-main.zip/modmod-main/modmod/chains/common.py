from enum import Enum, auto
from datetime import datetime

class StringType(Enum):
    MID = auto()
    EDGE = auto()

class StringMetadata():
    def __init__(self, string_type: StringType):
        if string_type == StringType.MID:
            self.type = "mid"
            self.imt_no = 16
            self.mppt_id = 0
            self.module_no = 14
            self.module_tilt = 12.33
        elif string_type == StringType.EDGE:
            self.type = "edge"
            self.imt_no = 15
            self.mppt_id = 1
            self.module_no = 16
            self.module_tilt = 15.48

    def __str__(self):
        return str({
            "type": self.type,
            "imt_no": self.imt_no,
            "mppt_id": self.mppt_id,
            "module_no": self.module_no
        })

class DateFormat(Enum):
    DATE = auto()
    MICROSEC_TZ = auto()

def format_datetime(date: datetime, format: DateFormat):
    if format == DateFormat.DATE:
        return date.strftime("%Y%m%d")
    elif format == DateFormat.MICROSEC_TZ:
        return date.strftime("%Y-%m-%d %H:%M:%S.%f%z")
