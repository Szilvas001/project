from typing import List, Dict, Any

from modmod.models import *
from modmod.parameter import InputParameter, OutputParameter, ParameterProcessor


def create_model(module_config: Dict[str, Any]) -> CalculationModel:
    model_map = {
        "pvlib": PVLibCalculationModel,
        "simulate_consumers": SimulateConsumersModel,
        "optimize_consumer": OptimizeConsumerModel,
        "ha_data_loader": HADataLoaderModel,
        "poa_effective_irradiance_model": PoaEffectiveIrradianceModel,
        "dc_output_model": DcOutputModel,
        "ac_output_model": AcOutputModel,
        "spectral_factor_model": SpectralFactorModel,
        "incident_angle_modifier_model": IncidentAngleModifierModel,
        "angle_of_incidence_model": AngleOfIncidenceModel,
        "solar_position_model": SolarPositionModel,
        "relative_airmass_model": RelativeAirmassModel,
        "absolute_airmass_model": AbsoluteAirmassModel,
        "precipitable_water_model": PrecipitableWaterModel,
        "temporary_loading_model": TemporaryLoadingModel,
        "consumer_test_model": ConsumerTestModel,
        "cloud_cover_pulling_model": CloudCoverPullingModel,
        "clear_sky_model": ClearSkyModel,
        "cloud_cover_pulling_openmeteo_model": CloudCoverPullingOpenmeteoModel,
        "openmeteo_irradiance_model": OpenmeteoIrradianceModel,
        "irradiance_pulling_openmeteo_model": IrradiancePullingOpenmeteoModel,
        "test_openmeteo_irradiance_model": TestOpenmeteoIrradianceModel,
        "openmeteo_pulling_model": OpenmeteoPullingModel,
        "openweathermap_pulling_model": OpenweathermapPullingModel,
        "interval_integral_model": IntervalIntegralModel,
        "meteomatics_data_loader_model": MeteomaticsDataLoaderModel,
        "poa_from_direct_model": PoaFromDirectModel,
        "poa_from_global_model": PoaFromGlobalModel,
        "cell_temp_model": CellTempModel,
        "average_model": AverageModel,
        "revert_imt_iam_model": RevertImtIamModel,
        "incident_angle_modifier_physical_model": IncidentAngleModifierPhysicalModel,
        "incident_angle_modifier_ashrae_model": IncidentAngleModifierAshraeModel,
        "incident_angle_modifier_martin_ruiz_model": IncidentAngleModifierMartinRuizModel,
    }
    model_name = module_config.get('model')
    if model_name not in model_map:
        raise ValueError(f"Unknown model: {model_name}")

    input_parameters = process_inputs(module_config.get('inputs', {}))
    output_parameters = process_outputs(module_config.get('outputs', {}))

    return model_map[model_name](input_parameters, output_parameters)


def process_outputs(outputs: Dict[str, Dict[str, str]]) -> List[OutputParameter]:
    return [ParameterProcessor.process_output(name, config) for name, config in outputs.items()]


def process_inputs(inputs: Dict[str, Dict[str, Any]]) -> List[InputParameter]:
    return [ParameterProcessor.process_input(name, config) for name, config in inputs.items()]
