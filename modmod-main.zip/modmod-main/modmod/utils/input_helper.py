from datetime import datetime

import pandas as pd
import pvlib

from modmod.weather_api import OpenMeteoAPI


class InputHelper:
    weather = OpenMeteoAPI(47.523533, 19.012432, "Europe/Budapest")

    @staticmethod
    def calc_solarpos(date: datetime, weatherApi: OpenMeteoAPI, apparent: bool = False) -> pd.DatetimeIndex:
        temperature, _ = weatherApi.get_most_recent_current_temp_with_timestamp(call_api=True)
        pressure, _ = weatherApi.get_most_recent_current_surface_pressure_with_timestamp(call_api=True)

        # Apparent zenith should be calculated at sea level:
        # https://pvlib-python.readthedocs.io/en/stable/reference/generated/pvlib.atmosphere.get_relative_airmass.html
        if (apparent):
            return pvlib.solarposition.get_solarposition(
                time=pd.DatetimeIndex(data=[date], tz='Europe/Budapest'),
                latitude=47.523533,
                longitude=19.012432,
                temperature=temperature
            )
        # For true zenith however, we supply both the altitude and pressure values
        else:
            return pvlib.solarposition.get_solarposition(
                time=pd.DatetimeIndex(data=[date], tz='Europe/Budapest'),
                latitude=47.523533,
                longitude=19.012432,
                altitude=250,
                pressure=pressure,
                temperature=temperature
            )
