from datetime import datetime
from zoneinfo import ZoneInfo
from chains.common import StringMetadata, StringType, DateFormat, format_datetime

def get_dc_prediction_error_analysis_modmod_chain(string_type: StringType, date_start: datetime, date_end: datetime, combine_strings: bool=False) -> dict:
    concise_date_start = format_datetime(date_start, DateFormat.DATE)
    concise_date_end = format_datetime(date_end, DateFormat.DATE)

    long_date_start = format_datetime(date_start, DateFormat.MICROSEC_TZ)
    long_date_end = format_datetime(date_end, DateFormat.MICROSEC_TZ)

    other_string_type = StringType.MID if string_type == StringType.EDGE else StringType.EDGE

    string_metadata_this_type = StringMetadata(string_type)
    string_metadata_other_type = StringMetadata(other_string_type)

    return {
      "modules": [
        {
          "model": "ha_data_loader",
          "inputs": {},
          "outputs": {
            "sensor.tvl9_imt_11_irrad": {
              "metric": "sensor.tvl9_imt_11_irrad",
              "transformations": []
            },
            "sensor.tvl9_imt_12_irrad": {
              "metric": "sensor.tvl9_imt_12_irrad",
              "transformations": []
            },
            "sensor.tvl9_imt_13_irrad": {
              "metric": "sensor.tvl9_imt_13_irrad",
              "transformations": []
            },
            "sensor.tvl9_rt1_mid_module_temp": {
              "metric": "sensor.tvl9_rt1_mid_module_temp",
              "transformations": []
            },
            "sensor.tvl9_rt1_edge_module_temp": {
              "metric": "sensor.tvl9_rt1_edge_module_temp",
              "transformations": []
            },
            "input_text.pv_module_name": {
              "metric": "input_text.pv_module_name",
              "transformations": []
            },
            "sensor.tvl9_gw2000a_absolute_pressure": {
                "metric": "sensor.tvl9_gw2000a_absolute_pressure"
            },
            "sensor.tvl9_gw2000a_outdoor_temperature": {
                "metric": "sensor.tvl9_gw2000a_outdoor_temperature"
            },
            f"sensor.tvl9_{string_metadata_this_type.type}_dc_power_output_calculation_singlediode_cec": {
              "metric": f"sensor.tvl9_{string_metadata_this_type.type}_dc_power_output_calculation_singlediode_cec",
              "transformations": []
            },
            f"sensor.tvl9_{string_metadata_other_type.type}_dc_power_output_calculation_singlediode_cec": {
              "metric": f"sensor.tvl9_{string_metadata_other_type.type}_dc_power_output_calculation_singlediode_cec",
              "transformations": []
            } if combine_strings else None,
            f"sensor.tvl9_fronius_mppt_module_{string_metadata_this_type.mppt_id}_dc_power": {
              "metric": f"sensor.tvl9_fronius_mppt_module_{string_metadata_this_type.mppt_id}_dc_power",
              "transformations": []
            },
            f"sensor.tvl9_fronius_mppt_module_{string_metadata_other_type.mppt_id}_dc_power": {
              "metric": f"sensor.tvl9_fronius_mppt_module_{string_metadata_other_type.mppt_id}_dc_power",
              "transformations": []
            } if combine_strings else None
          }
        },
        {
            "model": "solar_position_model",
            "inputs": {
                "ha_pressure_pa": {
                    "metric": "sensor.tvl9_gw2000a_absolute_pressure",
                    "transformations": []
                },
                "ha_temperature": {
                    "metric": "sensor.tvl9_gw2000a_outdoor_temperature",
                    "transformations": []
                },
                "latitude": {
                    "value": 47.523533
                },
                "longitude": {
                    "value": 19.012432
                },
                "altitude": {
                    "value": 240
                },
            },
            "outputs": {
                "solar_azimuth": {
                    "metric": "solar_azimuth",
                },
                "solar_zenith": {
                    "metric": "solar_zenith",
                }
            }
        },
        {
            "model": "angle_of_incidence_model",
            "inputs": {
                "panel_tilt": {
                    "value": string_metadata_this_type.module_tilt,
                },
                "panel_azimuth": {
                    "value": 183.0
                },
                "ha_pressure_pa": {
                    "metric": "sensor.tvl9_gw2000a_absolute_pressure",
                    "transformations": []
                },
                "ha_temperature": {
                    "metric": "sensor.tvl9_gw2000a_outdoor_temperature",
                    "transformations": []
                },
                "latitude": {
                    # why was this different?
                    # "value": 47.523618
                    "value": 47.523533
                },
                "longitude": {
                    # why was this different?
                    # "value": 19.012776
                    "value": 19.012432
                },
                "altitude": {
                    "value": 240
                },
            },
            "outputs": {
                "aoi": {
                    "metric": f"{string_metadata_this_type.type}_aoi",
                }
            }
        },
        {
            "model": "angle_of_incidence_model",
            "inputs": {
                "panel_tilt": {
                    "value": string_metadata_other_type.module_tilt,
                },
                "panel_azimuth": {
                    "value": 183.0
                },
                "ha_pressure_pa": {
                    "metric": "sensor.tvl9_gw2000a_absolute_pressure",
                    "transformations": []
                },
                "ha_temperature": {
                    "metric": "sensor.tvl9_gw2000a_outdoor_temperature",
                    "transformations": []
                },
                "latitude": {
                    # why was this different?
                    # "value": 47.523618
                    "value": 47.523533
                },
                "longitude": {
                    # why was this different?
                    # "value": 19.012776
                    "value": 19.012432
                },
                "altitude": {
                    "value": 240
                },
            },
            "outputs": {
                "aoi": {
                    "metric": f"{string_metadata_other_type.type}_aoi",
                }
            }
        } if combine_strings else None,
        {
            "model": "revert_imt_iam_model",
            "inputs": {
                "aoi": {
                    "metric": f"{string_metadata_this_type.type}_aoi"
                },
                "irradiance_with_imt_iam": {
                    "metric": f"sensor.tvl9_imt_{string_metadata_this_type.imt_no}_irrad"
                }
            },
            "outputs": {
                "iam_reversed_irradiance_output": {
                    "metric": f"iam_reversed_{string_metadata_this_type.type}_irradiance_output"
                },
                "included_imt_iam_factor": {
                    "metric": f"included_{string_metadata_this_type.type}_imt_iam_factor"
                }
            }
        },
        {
            "model": "revert_imt_iam_model",
            "inputs": {
                "aoi": {
                    "metric": f"{string_metadata_other_type.type}_aoi"
                },
                "irradiance_with_imt_iam": {
                    "metric": f"sensor.tvl9_imt_{string_metadata_other_type.imt_no}_irrad"
                }
            },
            "outputs": {
                "iam_reversed_irradiance_output": {
                    "metric": f"iam_reversed_{string_metadata_other_type.type}_irradiance_output"
                },
                "included_imt_iam_factor": {
                    "metric": f"included_{string_metadata_other_type.type}_imt_iam_factor"
                }
            }
        } if combine_strings else None,
        {
            "model": "incident_angle_modifier_ashrae_model",
            "inputs": {
                "aoi": {
                    "metric": f"{string_metadata_this_type.type}_aoi"
                },
                "irradiance_without_iam": {
                    "metric": f"iam_reversed_{string_metadata_this_type.type}_irradiance_output"
                },
                "iam_aoi_adjuster_b": {
                    "value": 0.02
                }
            },
            "outputs": {
                "iam": {
                    "metric": f"iam_ashrae_{string_metadata_this_type.type}"
                },
                "irradiance_with_iam": {
                    "metric": f"irradiance_with_iam_ashrae_{string_metadata_this_type.type}"
                }
            }
        },
        {
            "model": "incident_angle_modifier_ashrae_model",
            "inputs": {
                "aoi": {
                    "metric": f"{string_metadata_other_type.type}_aoi"
                },
                "irradiance_without_iam": {
                    "metric": f"iam_reversed_{string_metadata_other_type.type}_irradiance_output"
                },
                "iam_aoi_adjuster_b": {
                    "value": 0.02
                }
            },
            "outputs": {
                "iam": {
                    "metric": f"iam_ashrae_{string_metadata_other_type.type}"
                },
                "irradiance_with_iam": {
                    "metric": f"irradiance_with_iam_ashrae_{string_metadata_other_type.type}"
                }
            }
        } if combine_strings else None,
        {
            "model": "cell_temp_model",
            "inputs": {
                "mounting_key": {
                    "value": "open_rack_glass_polymer"
                },
                "ha_poa_irrad": {
                    "metric": f"sensor.tvl9_imt_{string_metadata_this_type.imt_no}_irrad",
                    "transformations": []
                },
                "ha_module_temp": {
                    "metric": f"sensor.tvl9_rt1_{string_metadata_this_type.type}_module_temp",
                    "transformations": []
                }
            },
            "outputs": {
                "cell_temp": {
                    "metric": f"cell_temp_{string_metadata_this_type.type}",
                }
            }
        },
        {
            "model": "cell_temp_model",
            "inputs": {
                "mounting_key": {
                    "value": "open_rack_glass_polymer"
                },
                "ha_poa_irrad": {
                    "metric": f"sensor.tvl9_imt_{string_metadata_other_type.imt_no}_irrad",
                    "transformations": []
                },
                "ha_module_temp": {
                    "metric": f"sensor.tvl9_rt1_{string_metadata_other_type.type}_module_temp",
                    "transformations": []
                }
            },
            "outputs": {
                "cell_temp": {
                    "metric": f"cell_temp_{string_metadata_other_type.type}",
                }
            }
        },
        {
            "model": "average_model",
            "inputs": {
                "avg_a_value": {
                    "metric": f"cell_temp_{string_metadata_other_type.type}",
                    "transformations": []
                },
                "avg_b_value": {
                    "metric": f"cell_temp_{string_metadata_this_type.type}",
                    "transformations": []
                }
            },
            "outputs": {
                "average_output": {
                    "metric": "cell_temp_average",
                }
            }
        },
        {
          "model": "dc_output_model",
          "inputs": {
            "irradiance": {
              "metric": f"sensor.tvl9_imt_{string_metadata_this_type.imt_no}_irrad"
            },
            "cell_temp": {
              "metric": "cell_temp_average"
            },
            "module_name": {
              "value": "Trina Solar TSM-400DE09.08"
            },
            "calc_type": {
              "value": "cec"
            },
            "module_no": {
              "value": f"{string_metadata_this_type.module_no}"
            }
          },
          "outputs": {
            "dc_output": {
              "metric": f"{string_metadata_this_type.type}_dc_output"
            }
          }
        },
        {
          "model": "dc_output_model",
          "inputs": {
            "irradiance": {
              "metric": f"irradiance_with_iam_ashrae_{string_metadata_other_type.type}"
            },
            "cell_temp": {
              "metric": "cell_temp_average"
            },
            "module_name": {
              "value": "Trina Solar TSM-400DE09.08"
            },
            "calc_type": {
              "value": "cec"
            },
            "module_no": {
              "value": f"{string_metadata_this_type.module_no}"
            }
          },
          "outputs": {
            "dc_output": {
              "metric": f"{string_metadata_this_type.type}_dc_output_iam_ashrae"
            }
          }
        },
        {
          "model": "dc_output_model",
          "inputs": {
            "irradiance": {
              "metric": f"sensor.tvl9_imt_{string_metadata_other_type.imt_no}_irrad"
            },
            "cell_temp": {
              "metric": "cell_temp_average"
            },
            "module_name": {
              "value": "Trina Solar TSM-400DE09.08"
            },
            "calc_type": {
              "value": "cec"
            },
            "module_no": {
              "value": f"{string_metadata_other_type.module_no}"
            }
          },
          "outputs": {
            "dc_output": {
              "metric": f"{string_metadata_other_type.type}_dc_output"
            }
          }
        } if combine_strings else None,
        {
          "model": "dc_output_model",
          "inputs": {
            "irradiance": {
              "metric": f"irradiance_with_iam_ashrae_{string_metadata_other_type.type}"
            },
            "cell_temp": {
              "metric": "cell_temp_average"
            },
            "module_name": {
              "value": "Trina Solar TSM-400DE09.08"
            },
            "calc_type": {
              "value": "cec"
            },
            "module_no": {
              "value": f"{string_metadata_other_type.module_no}"
            }
          },
          "outputs": {
            "dc_output": {
              "metric": f"{string_metadata_other_type.type}_dc_output_iam_ashrae"
            }
          }
        } if combine_strings else None,
        {
          "model": "dc_output_model",
          "inputs": {
            "irradiance": {
              "metric": f"sensor.tvl9_imt_13_irrad"
            },
            "cell_temp": {
              "metric": "cell_temp_average"
            },
            "module_name": {
              "value": "Trina Solar TSM-400DE09.08"
            },
            "calc_type": {
              "value": "cec"
            },
            "module_no": {
              "value": f"{StringMetadata(StringType.EDGE).module_no}"
            }
          },
          "outputs": {
            "dc_output": {
              "metric": f"counter_edge_13_dc_output"
            }
          }
        },
      ],
      "input_table": "",
      "output_table": f"dc_pred_error_source_{string_metadata_this_type.type}_imt{string_metadata_this_type.imt_no}_{concise_date_start}_{concise_date_end}" if not combine_strings
         else f"dc_pred_error_source_combined_{concise_date_start}_{concise_date_end}",
      "interval_start": f"{long_date_start}",
      "interval_end": f"{long_date_end}"
    }


def combined_mid_edge_dc_chains_for_period(date_start: datetime, date_end: datetime) -> dict:
    return get_dc_prediction_error_analysis_modmod_chain(
        # Does not matter when combine_strings=True
        string_type=StringType.MID,
        date_start=date_start,
        date_end=date_end,
        combine_strings=True
    )


def get_mid_edge_dc_chains_for_period(date_start: datetime, date_end: datetime) -> tuple[dict]:
    result = []
    for string_type in [StringType.MID, StringType.EDGE]:
        result.append(get_dc_prediction_error_analysis_modmod_chain(
            string_type=string_type,
            date_start=date_start,
            date_end=date_end,
        ))

    return result[0], result[1]


tilt_correction_start_date = datetime(2025, 4, 27, 5, 25, 0, 0, ZoneInfo('Europe/Budapest'))
end_date = datetime(2025, 6, 22, 20, 20, 0, 0, ZoneInfo('Europe/Budapest'))

mid_dc_pred_0427_0611, edge_dc_pred_0427_0611 = get_mid_edge_dc_chains_for_period(
    date_start=tilt_correction_start_date,
    date_end=datetime(2025, 6, 11, 20, 20, 0, 0, ZoneInfo('Europe/Budapest'))
)

combined_dc_pred_0427_0618 = combined_mid_edge_dc_chains_for_period(
    date_start=tilt_correction_start_date,
    date_end=end_date
)

combined_dc_counter_edge_pred_0427_0622 = combined_mid_edge_dc_chains_for_period(
    date_start=tilt_correction_start_date,
    date_end=end_date
)

mid_dc_pred_0427_0618, edge_dc_pred_0427_0618 = get_mid_edge_dc_chains_for_period(
    date_start=tilt_correction_start_date,
    date_end=end_date
)
