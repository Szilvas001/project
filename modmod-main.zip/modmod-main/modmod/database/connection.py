import os
from contextlib import contextmanager

from dotenv import load_dotenv
from psycopg2.extras import DictCursor
from psycopg2.pool import SimpleConnectionPool

load_dotenv()

# Print the current DB_NAME for debugging
print(f"Before override - DB_NAME: {os.getenv('DB_NAME')}")

# Explicitly set DB_NAME
os.environ['DB_NAME'] = 'kristof'

# Verify the override worked
print(f"After override - DB_NAME: {os.environ['DB_NAME']}")

# TODO: Ezt majd később kivenni (átmenetileg van ha_db létrehozva)
read_pool = SimpleConnectionPool(
    minconn=1,
    maxconn=10,
    dbname=os.environ['DB_NAME'],  # Use environ instead of getenv
    user=os.getenv('DB_USER'),
    password=os.getenv('DB_PASSWORD'),
    host=os.getenv('DB_HOST'),
    port=int(os.getenv('DB_PORT'))
)

write_pool = SimpleConnectionPool(
    minconn=1,
    maxconn=10,
    dbname=os.getenv('TIMESCALE_DB_NAME'),
    user=os.getenv('DB_USER'),
    password=os.getenv('DB_PASSWORD'),
    host=os.getenv('DB_HOST'),
    port=int(os.getenv('TIMESCALE_DB_PORT'))
)


@contextmanager
def get_db_connection(write=False):
    pool = write_pool if write else read_pool
    connection = pool.getconn()
    try:
        yield connection
    finally:
        pool.putconn(connection)


@contextmanager
def get_db_cursor(write=False, commit=False):
    with get_db_connection(write) as connection:
        cursor = connection.cursor(cursor_factory=DictCursor)
        try:
            yield cursor
            if commit:
                connection.commit()
        finally:
            cursor.close()
