from typing import List

import pandas as pd
from psycopg2.extras import execute_values

from modmod.database import get_db_cursor


# TODO: Use pd.load_sql where possible

def test_query_solar_data():
    query = "SELECT COUNT(*) FROM solar_data;"
    with get_db_cursor() as cur:
        cur.execute(query)
        results = cur.fetchall()
        dict_results = [dict(row) for row in results]
        return dict_results


def insert_simulated_data(metric_to_simulate: str):
    with get_db_cursor(write=True) as cursor:
        create_table_query = f"""
        CREATE TABLE IF NOT EXISTS test_{metric_to_simulate} (
            timestamp TIMESTAMPTZ NOT NULL,
            value DOUBLE PRECISION NOT NULL,
            PRIMARY KEY (timestamp)
        );
        """
        cursor.execute(create_table_query)

        hypertable_query = f"""
        SELECT create_hypertable('test_{metric_to_simulate}', by_range('timestamp'), if_not_exists => TRUE);
        """
        cursor.execute(hypertable_query)

        simulate_query = f"""
        INSERT INTO test_{metric_to_simulate} (timestamp, value)
        SELECT timestamp, value
        FROM (
            SELECT generate_series(now() - interval '24 hour', now(), interval '3 second') AS timestamp,
                   random()*100 AS value
        ) subquery
        RETURNING timestamp, value;
        """
        cursor.execute(simulate_query)
        values = cursor.fetchall()

        cursor.connection.commit()

        print(f"Inserted {len(values)} rows into test_{metric_to_simulate}")
        print("Sample of inserted values:")
        print(values[:5])


def read_data_into_df(metric: str, interval_start, interval_end) -> pd.DataFrame:
    query = f"""SELECT
                  state,
                  to_timestamp(last_updated_ts)
                FROM states
                WHERE metadata_id =
                  (
                    SELECT metadata_id
                    FROM states_meta
                    WHERE entity_id='{metric}'
                  )
                  AND to_timestamp(last_updated_ts) >= '{interval_start}'
                  AND to_timestamp(last_updated_ts) <= '{interval_end}'
                  ORDER BY last_updated_ts ASC;
            """
    with get_db_cursor(write=True) as cursor:
        cursor.execute(query)
        results = cursor.fetchall()
        dict_results = [dict(row) for row in results]

        df = pd.DataFrame(dict_results)

        df.rename(columns={'state': metric, 'to_timestamp': 'timestamp'}, inplace=True)

        return df


def align_dataframes(dataframes):
    if not dataframes:
        print("[DEBUG] align_dataframes: No dataframes provided, returning empty DataFrame")
        return pd.DataFrame()

    print(f"[DEBUG] align_dataframes: Aligning {len(dataframes)} dataframes")
    print(f"[DEBUG] First dataframe shape: {dataframes[0].shape}, columns: {dataframes[0].columns.tolist()}")
    
    result = dataframes[0]
    
    # Check for target date in the dataframes
    target_date = "2025-03-21"
    target_time = "17:28"
    
    for df in dataframes:
        target_idx = [idx for idx in df.index if target_date in str(idx)]
        if target_idx:
            print(f"[DEBUG] Found {len(target_idx)} rows with target date in a dataframe")
            target_time_idx = [idx for idx in target_idx if target_time in str(idx)]
            if target_time_idx:
                print(f"[DEBUG] Found row(s) with target time {target_time}")
                for idx in target_time_idx[:3]:  # Show up to 3 rows
                    print(f"[DEBUG] Values at {idx}: {df.loc[idx].to_dict()}")

    for i, df in enumerate(dataframes[1:], 1):
        print(f"[DEBUG] Merging with dataframe {i}, shape: {df.shape}, columns: {df.columns.tolist()}")
        
        # Check for potential overlapping columns
        overlap_cols = set(result.columns).intersection(set(df.columns))
        if overlap_cols:
            print(f"[DEBUG] Overlapping columns found: {overlap_cols}")
        
        combined_index = result.index.union(df.index)
        print(f"[DEBUG] Combined index size: {len(combined_index)}")
        
        # Print a few of the indices for debugging
        sample_indices = list(combined_index)[:5] + list(combined_index)[-5:] if len(combined_index) > 10 else list(combined_index)
        print(f"[DEBUG] Sample indices (first few and last few): {sample_indices}")
        
        result = result.reindex(combined_index)
        df = df.reindex(combined_index)
        
        print(f"[DEBUG] After reindexing - result shape: {result.shape}, df shape: {df.shape}")
        
        # Check for NaN values before forward fill
        result_nan = result.isna().sum().sum()
        df_nan = df.isna().sum().sum()
        print(f"[DEBUG] NaN counts before ffill - result: {result_nan}, df: {df_nan}")
        
        # Instead of simple forward fill, use a time-aware forward fill
        # First, make sure the index is sorted
        result = result.sort_index()
        df = df.sort_index()
        
        # Forward fill with time awareness for irradiance columns
        for col in result.columns:
            if 'irrad' in col.lower() or 'poa' in col.lower():
                # For irradiance columns, apply time-aware filling
                result[col] = time_aware_forward_fill(result.index, result[col])
            else:
                # For other columns, regular forward fill
                result[col] = result[col].ffill()
                
        for col in df.columns:
            if 'irrad' in col.lower() or 'poa' in col.lower():
                # For irradiance columns, apply time-aware filling
                df[col] = time_aware_forward_fill(df.index, df[col])
            else:
                # For other columns, regular forward fill
                df[col] = df[col].ffill()
        
        # Check for NaN values after forward fill
        result_nan_after = result.isna().sum().sum()
        df_nan_after = df.isna().sum().sum()
        print(f"[DEBUG] NaN counts after ffill - result: {result_nan_after}, df: {df_nan_after}")
        print(f"[DEBUG] Filled {result_nan - result_nan_after} NaNs in result and {df_nan - df_nan_after} NaNs in df")
        
        # Concatenate dataframes
        result = pd.concat([result, df], axis=1)
        print(f"[DEBUG] After concat, result shape: {result.shape}, columns: {result.columns.tolist()}")
        
        # Check for target date after merging
        target_idx = [idx for idx in result.index if target_date in str(idx)]
        if target_idx:
            target_time_idx = [idx for idx in target_idx if target_time in str(idx)]
            if target_time_idx:
                print(f"[DEBUG] After merging DF {i}, found {len(target_time_idx)} rows with target time")
                # Check specific column values
                irradiance_cols = [col for col in result.columns if 'irrad' in col.lower() or 'poa' in col.lower()]
                if irradiance_cols:
                    for idx in target_time_idx[:2]:  # Show up to 2 rows
                        irrad_vals = {col: result.loc[idx, col] for col in irradiance_cols if col in result.columns}
                        print(f"[DEBUG] After merge {i}, at {idx}: Irradiance values: {irrad_vals}")

    # Final check for time-day consistency
    irradiance_cols = [col for col in result.columns if 'irrad' in col.lower() or 'poa' in col.lower()]
    if irradiance_cols:
        for col in irradiance_cols:
            # Ensure consistency between daytime/nighttime and irradiance values
            result[col] = apply_day_night_constraints(result.index, result[col])
    
    # Final result stats
    print(f"[DEBUG] Final aligned DataFrame shape: {result.shape}")
    print(f"[DEBUG] Final aligned DataFrame columns: {result.columns.tolist()}")
    nan_counts = result.isna().sum()
    if (nan_counts > 0).any():
        print(f"[DEBUG] Final NaN counts: {nan_counts[nan_counts > 0]}")
    
    # Check min, max, mean for numeric columns
    numeric_cols = result.select_dtypes(include=['number']).columns
    if not numeric_cols.empty:
        print("[DEBUG] Final aligned DataFrame numeric column stats:")
        stats = result[numeric_cols].agg(['min', 'max', 'mean'])
        print(stats.to_string())

    return result


def load_required_inputs_from_db(required_inputs: List[str], interval_start: str, interval_end: str,
                                 input_table: str) -> pd.DataFrame:
    if interval_start is None and interval_end is None:
        print("[DEBUG] Load current moment only")
        return load_latest_inputs_from_db(required_inputs, input_table)
    else:
        return load_range_inputs_from_db(required_inputs, interval_start, interval_end, input_table)


def load_latest_inputs_from_db(required_inputs: List[str], input_table: str) -> pd.DataFrame:
    latest_data = {}
    latest_timestamp = None

    for required_input in required_inputs:
        query = f"""
        SELECT 
            timestamp, 
            {required_input}
        FROM {input_table}
        ORDER BY timestamp DESC
        LIMIT 1;
        """

        with get_db_cursor(write=True) as cursor:
            cursor.execute(query)
            result = cursor.fetchone()

        if result:
            timestamp, state = result
            latest_data[required_input] = state
            if latest_timestamp is None or timestamp > latest_timestamp:
                latest_timestamp = timestamp

    if not latest_data:
        return pd.DataFrame()

    result_df = pd.DataFrame([latest_data], index=[latest_timestamp])
    result_df.index.name = 'timestamp'
    result_df.reset_index(inplace=True)

    result_df = result_df.astype(float, errors="ignore")
    result_df['timestamp'] = pd.to_datetime(result_df['timestamp'], format='ISO8601')

    result_df.replace('unknown', pd.NA, inplace=True)
    result_df.replace('unavailable', pd.NA, inplace=True)

    print(result_df)
    return result_df


def load_range_inputs_from_db(required_inputs: List[str], interval_start: str, interval_end: str,
                              input_table: str) -> pd.DataFrame:
    print(f"[DEBUG] Loading data from {input_table} for date range: {interval_start} to {interval_end}")
    print(f"[DEBUG] Required inputs: {required_inputs}")
    
    # Check if we're looking for the target date
    target_date = "2025-03-21"
    if target_date in interval_start or target_date in interval_end:
        print(f"[DEBUG] Target date {target_date} is within the requested interval")
    
    dataframes = []

    for required_input in required_inputs:
        query = f"""
        SELECT
            timestamp,
            {required_input}
        FROM {input_table}
        WHERE timestamp >= '{interval_start}' AND timestamp <= '{interval_end}'
        ORDER BY timestamp ASC;
        """
        print(f"[DEBUG] Executing query for {required_input}: {query}")
        
        with get_db_cursor(write=True) as cursor:
            cursor.execute(query)
            results = cursor.fetchall()
            
        print(f"[DEBUG] Fetched {len(results)} rows for {required_input}")
        
        # Check for a specific value in the results
        if target_date in interval_start or target_date in interval_end:
            target_rows = [row for row in results if target_date in str(row[0])]
            if target_rows:
                print(f"[DEBUG] Found {len(target_rows)} rows for {required_input} on target date {target_date}")
                # Look for specific timestamp
                target_time = "17:28"
                target_time_rows = [row for row in target_rows if target_time in str(row[0])]
                if target_time_rows:
                    print(f"[DEBUG] Found {len(target_time_rows)} rows around {target_time} for {required_input}")
                    for row in target_time_rows[:5]:  # Show up to 5 rows
                        print(f"[DEBUG] {required_input} @ {row[0]}: {row[1]}")

        # Convert results to DataFrame
        df = pd.DataFrame(results, columns=['timestamp', required_input])
        
        # Debug: Show a few rows before setting index
        if not df.empty:
            print(f"[DEBUG] Sample values for {required_input} before processing:")
            print(df.head(3).to_string())
        
        df.set_index('timestamp', inplace=True)
        
        # Check types after setting index
        print(f"[DEBUG] DataFrame for {required_input} - shape: {df.shape}, index type: {type(df.index)}")
        
        dataframes.append(df)

    # Align and combine all dataframes
    print(f"[DEBUG] Aligning {len(dataframes)} dataframes")
    for i, df in enumerate(dataframes):
        print(f"[DEBUG] DataFrame {i}: shape={df.shape}, columns={df.columns.tolist()}")
    
    result_df = align_dataframes(dataframes)
    print(f"[DEBUG] Aligned DataFrame shape: {result_df.shape}, columns: {result_df.columns.tolist()}")
    
    # Check for NaN values after alignment
    nan_counts = result_df.isna().sum()
    if (nan_counts > 0).any():
        print(f"[DEBUG] NaN counts in aligned DataFrame: {nan_counts}")
    
    # Convert to float if possible
    try:
        result_df = result_df.astype(float)
        print("[DEBUG] Successfully converted DataFrame to float")
    except Exception as e:
        print(f"[WARNING] Error converting DataFrame to float: {str(e)}")
        # Try column by column
        for col in result_df.columns:
            try:
                result_df[col] = pd.to_numeric(result_df[col], errors='coerce')
                print(f"[DEBUG] Converted column {col} to numeric")
            except:
                print(f"[WARNING] Couldn't convert column {col} to numeric")
                
    # timestamp should be ISO8601 format pd.Timestamp
    result_df.index = pd.to_datetime(result_df.index, format='ISO8601')
    print(f"[DEBUG] Converted index to DateTimeIndex, index size: {len(result_df.index)}")
    
    # Check for target date in final DataFrame
    if target_date in interval_start or target_date in interval_end:
        target_idx = [idx for idx in result_df.index if target_date in str(idx)]
        if target_idx:
            print(f"[DEBUG] Found {len(target_idx)} entries for target date in final aligned DataFrame")
            target_time = "17:28"
            target_time_idx = [idx for idx in target_idx if target_time in str(idx)]
            if target_time_idx:
                print(f"[DEBUG] Found {len(target_time_idx)} entries around target time {target_time}")
                for idx in target_time_idx[:5]:  # Show up to 5 rows
                    print(f"[DEBUG] Values at {idx}: {result_df.loc[idx].to_dict()}")
                
    result_df.reset_index(inplace=True)
    print(f"[DEBUG] Reset index, DataFrame shape: {result_df.shape}")

    # Check for specific patterns in the data
    result_df.replace('unknown', pd.NA, inplace=True)
    result_df.replace('unavailable', pd.NA, inplace=True)
    
    # Check for non-numeric values
    for col in result_df.columns:
        if col != 'timestamp':
            non_numeric = result_df[col].apply(lambda x: not pd.api.types.is_number(x) if pd.notna(x) else False).any()
            if non_numeric:
                print(f"[WARNING] Column {col} contains non-numeric values")
                # Show sample of non-numeric values
                non_numeric_samples = result_df[col][result_df[col].apply(
                    lambda x: not pd.api.types.is_number(x) if pd.notna(x) else False)].head(5).tolist()
                print(f"[DEBUG] Sample non-numeric values in {col}: {non_numeric_samples}")

    result_df.bfill(inplace=True)
    print(f"[DEBUG] Final DataFrame after backward fill, shape: {result_df.shape}")

    # Print summary stats for numeric columns
    numeric_cols = result_df.select_dtypes(include=['number']).columns
    if not numeric_cols.empty:
        print("[DEBUG] Summary statistics for numeric columns:")
        print(result_df[numeric_cols].describe().to_string())

    print(result_df.head())
    return result_df


def get_pg_type(series):
    if pd.api.types.is_integer_dtype(series):
        return 'INTEGER'
    elif pd.api.types.is_float_dtype(series):
        return 'DOUBLE PRECISION'
    elif pd.api.types.is_bool_dtype(series):
        return 'BOOLEAN'
    elif pd.api.types.is_datetime64_any_dtype(series):
        return 'TIMESTAMPTZ'
    elif series.dtype == 'object':
        try:
            numeric_values = pd.to_numeric(series.dropna(), errors='raise')
            if numeric_values.notna().all():
                return 'DOUBLE PRECISION'
            else:
                datetime_values = pd.to_datetime(series.dropna(), errors='raise')
                if datetime_values.notna().all():
                    return 'TIMESTAMPTZ'
                else:
                    return 'TEXT'
        except ValueError:
            return 'TEXT'
    else:
        return 'TEXT'


def write_df_into_db(df: pd.DataFrame, table_name: str, column_types=None):
    start_time = pd.Timestamp.now()
    with get_db_cursor(write=True) as cursor:
        df_copy = df.copy()
        df_copy.reset_index(inplace=True)
        
        # Add debug logging for the specific date we're interested in
        print(f"[DEBUG] write_df_into_db - DataFrame shape before processing: {df_copy.shape}")
        
        # Check for target date in the dataframe
        if 'timestamp' in df_copy.columns:
            df_copy['timestamp'] = pd.to_datetime(df_copy['timestamp'], utc=True)
            target_date_str = "2025-03-21"
            target_date_rows = df_copy[df_copy['timestamp'].dt.strftime('%Y-%m-%d') == target_date_str]
            
            if not target_date_rows.empty:
                print(f"[DEBUG] Found {len(target_date_rows)} rows for target date {target_date_str}")
                print(f"[DEBUG] Sample rows from target date:")
                pd.set_option('display.max_columns', None)  # Show all columns
                pd.set_option('display.width', 1000)  # Wider display
                print(target_date_rows.head().to_string())
                
                # Check for the specific timestamp we're interested in
                specific_time = pd.to_datetime("2025-03-21 17:28:54", utc=True)
                window_start = specific_time - pd.Timedelta(minutes=5)
                window_end = specific_time + pd.Timedelta(minutes=5)
                
                specific_rows = df_copy[(df_copy['timestamp'] >= window_start) & 
                                        (df_copy['timestamp'] <= window_end)]
                
                if not specific_rows.empty:
                    print(f"[DEBUG] Found {len(specific_rows)} rows within 5 minutes of 17:28:54")
                    irradiance_cols = [col for col in specific_rows.columns if 'irrad' in col.lower() or 'poa' in col.lower()]
                    for _, row in specific_rows.iterrows():
                        ts = row['timestamp']
                        irrad_vals = {col: row[col] for col in irradiance_cols if col in row}
                        print(f"[DEBUG] {ts}: Irradiance values: {irrad_vals}")
            else:
                print(f"[DEBUG] No rows found for target date {target_date_str}")
        
        # if length is 1, then it is a single row DataFrame. Change index to be the timestamp
        if len(df_copy) == 1:
            print("[DEBUG] Single row DataFrame detected")
            if 'index' in df_copy.columns:
                print(f"[DEBUG] Converting 'index' to 'timestamp'. Current index value: {df_copy['index'].iloc[0]}")
                df_copy['timestamp'] = df_copy['index']
                df_copy.drop(columns=['index'], inplace=True)
        else:
            if 'index' in df_copy.columns:
                print(f"[DEBUG] Dropping 'index' column from multi-row DataFrame. Sample indices: {df_copy['index'].head(3).tolist()}")
                df_copy.drop(columns=['index'], inplace=True)

        # Check columns for potential dots that will be replaced
        column_dots = [col for col in df_copy.columns if '.' in col]
        if column_dots:
            print(f"[DEBUG] Columns with dots that will be replaced: {column_dots}")
            
        df_copy.columns = df_copy.columns.str.replace('.', '_')
        columns = df_copy.columns.tolist()
        
        print(f"[DEBUG] Final column names for database write: {columns}")

        if column_types is None:
            column_types = {col: get_pg_type(df_copy[col]) for col in columns if col != 'timestamp'}
            print(f"[DEBUG] Inferred column types: {column_types}")

        create_table_query = f"""
        CREATE TABLE IF NOT EXISTS {table_name} (
            timestamp TIMESTAMPTZ NOT NULL,
            {', '.join([f"{col} {column_types.get(col, get_pg_type(df_copy[col]))}" for col in columns if col != 'timestamp'])},
            PRIMARY KEY (timestamp)
        );
        """
        cursor.execute(create_table_query)

        hypertable_query = f"""
        SELECT create_hypertable('{table_name}', by_range('timestamp'), if_not_exists => TRUE);
        """
        cursor.execute(hypertable_query)

        print(f"[LOG] Table {table_name} created")

        data = [tuple(x) for x in df_copy.to_numpy()]
        
        # Debug first few rows to be inserted
        if data:
            print(f"[DEBUG] First 3 rows to be inserted (sample):")
            for i, row in enumerate(data[:3]):
                print(f"[DEBUG] Row {i}: {row}")
        
        # Check if there are any rows with the target timestamp
        target_time_str = "2025-03-21 17:28"
        target_rows = [(i, row) for i, row in enumerate(data) 
                      if isinstance(row[0], pd.Timestamp) and target_time_str in str(row[0])]
        
        if target_rows:
            print(f"[DEBUG] Found {len(target_rows)} rows with target time {target_time_str}")
            for i, row in target_rows[:5]:  # Show up to 5 rows
                print(f"[DEBUG] Target row {i}: {row}")

        insert_query = f"""
        INSERT INTO {table_name} ({', '.join(columns)})
        VALUES %s
        ON CONFLICT (timestamp) DO NOTHING;
        """

        execute_values(cursor, insert_query, data, page_size=10000)

        cursor.connection.commit()
        end_time = pd.Timestamp.now()
        print(f"[LOG] Database write operation run in {(end_time - start_time).seconds} seconds")
        print(f"[DEBUG] Wrote {len(data)} rows to table {table_name}")


def time_aware_forward_fill(index, series):
    """
    Perform forward filling that respects the day/night cycle.
    Values from daytime won't be carried forward to nighttime.
    """
    # Convert to a Series with the index if not already
    s = pd.Series(series, index=index)
    
    # Create hour-of-day Series from the index
    hour_of_day = pd.Series(index=index, data=[idx.hour for idx in index])
    
    # Define nighttime hours (approximate)
    is_night = (hour_of_day < 5) | (hour_of_day > 21)
    
    # Regular forward fill first
    s_filled = s.ffill()
    
    # If the value should be 0 during nighttime, set it
    nighttime_indices = s_filled.index[is_night]
    
    # This is a solar irradiance, so it should be close to 0 at night
    s_filled.loc[nighttime_indices] = s_filled.loc[nighttime_indices].apply(
        lambda x: 0 if pd.notna(x) and x > 10 else x
    )
    
    # Check for day transition boundaries
    indices = list(s_filled.index)
    for i in range(1, len(indices)):
        current_idx = indices[i]
        prev_idx = indices[i-1]
        
        # If we transition from night to day or day to night
        if (prev_idx.day != current_idx.day) or (is_night[prev_idx] != is_night[current_idx]):
            # Don't carry forward values across this boundary for irradiance
            if pd.isna(s.loc[current_idx]):
                if is_night[current_idx]:
                    s_filled.loc[current_idx] = 0  # At night, irradiance should be 0
                else:
                    # During day, try not to carry over from previous night
                    # Look ahead for the next valid value during this day
                    same_day_values = s[s.index.day == current_idx.day]
                    if not same_day_values.empty and same_day_values.notna().any():
                        # Use the first valid value from the same day if available
                        s_filled.loc[current_idx] = same_day_values.dropna().iloc[0]
    
    return s_filled


def apply_day_night_constraints(index, series):
    """
    Apply constraints based on day/night cycle to ensure irradiance values make sense.
    """
    # Convert to a Series with the index if not already
    s = pd.Series(series, index=index)
    
    # Create hour-of-day Series from the index
    hour_of_day = pd.Series(index=index, data=[idx.hour for idx in index])
    
    # Define nighttime hours (approximate)
    is_night = (hour_of_day < 5) | (hour_of_day > 21)
    
    # For nighttime entries, set irradiance close to 0
    nighttime_indices = s.index[is_night]
    if not nighttime_indices.empty:
        # Only modify values that are unrealistically high for nighttime
        night_vals = s.loc[nighttime_indices]
        high_night_vals = night_vals[night_vals > 10]
        
        if not high_night_vals.empty:
            s.loc[high_night_vals.index] = 0
            print(f"[DEBUG] Set {len(high_night_vals)} nighttime irradiance values to 0")
    
    return s
