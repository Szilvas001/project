from setuptools import setup, find_packages

setup(
    name='modmod',
    version='0.1',
    packages=find_packages(),
    install_requires=["pandas", "psycopg2-binary", "python-dotenv", "requests", "pvlib", "requests-cache",
                      "retry-requests", "numpy"],
    url='',
    license='',
    author='kristof',
    author_email='kristof@ulx.hu',
    description='Model Module framework',
    entry_points={
        'console_scripts': [
            'modmod=modmod.modmod_cli.modmod_cli:main',
        ],
    },
)
