# Modmod

## Basic execution steps

If you'd like to run a custom model chain, construct the chain (as a Python dict), import it in `modmod/main.py`,
then call `run_model_chain()` with your model chain as parameter at the end of main (under the line `if __name__ == "__main__":`).

You can optionally set the `write_to_db=True` kwarg if you'd like to persist the results to a database.

Before running modmod (with your own model chain), you should first install the updated version locally.

For that, you need to install modmod's dependencies:

```sh
pip install -r requirements.txt
```

Then install the locally customized version of modmod:

```sh
pip install . --no-cache-dir
```

Finally, run modmod:

```sh
python modmod/main.py
```
