import logging
import const
import boto3
import botocore

LOGGER = logging.getLogger(__name__)

def get_session():
    return boto3.Session(
        aws_access_key_id=const.UPLOADER_ACCESS_KEY_ID,
        aws_secret_access_key=const.UPLOADER_SECRET_ACCESS_KEY
    )


def get_s3():
    return get_session().resource(
        const.UPLOADER_RESOURCE_TYPE_NAME, endpoint_url=const.UPLOADER_ENDPOINT_URL
    )


def get_bucket():
    return get_s3().Bucket(const.UPLOADER_BUCKET_NAME)


def upload_file_to_bucket(file_path: str, key: str, retry_count: int = const.UPLOADER_RETRY_COUNT):
    LOGGER.info(f"Uploading file at {file_path} to S3: {const.UPLOADER_BUCKET_NAME}/{key}...")
    if retry_count >= 0:
        try:
            get_bucket().upload_file(
                file_path,
                key
            )
        except (botocore.exceptions.ClientError, boto3.exceptions.S3UploadFailedError) as e:
            LOGGER.warning(f"Got error {e}, retrying upload! ({retry_count} {"retries" if retry_count > 1 else "retry"} left)")
            upload_file_to_bucket(file_path, key, retry_count - 1)
    else:
        LOGGER.warning(f"Retries exceeded! NOT uploading {const.UPLOADER_BUCKET_NAME}/{key} to S3!")
        return
    LOGGER.info(f"Successfully uploaded ({const.UPLOADER_BUCKET_NAME}/{key}) to S3!")
