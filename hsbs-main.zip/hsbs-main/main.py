import time
from datetime import datetime, timedelta
from dotenv import load_dotenv
import logging

LOGGER = logging.getLogger(__name__)

def custom_module_init(script_path):
    from pathlib import Path
    import sys
    dir = str(Path(script_path).parent.resolve())
    if dir not in sys.path:
        sys.path.append(dir)


def setup_logging():
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    )


def init():
    # NOTE: this has to be invoked in the entrypoint script
    # as otherwise Blender won't find the referenced local
    # dependencies. Local modules can only be imported after
    # invocation.
    custom_module_init(__file__)
    load_dotenv()
    setup_logging()


def run_bake_sequence(start_date: datetime, end_date: datetime, temporal_res: timedelta):
    LOGGER.info(f"Starting bake sequence for period {start_date} - {end_date} with a temporal resolution of {temporal_res}...")

    bake_interval_full_timespan = const.BAKE_SEQ_END_DATETIME - const.BAKE_SEQ_START_DATETIME

    utils.sunposition_set_date(const.BAKE_SEQ_CURRENT_DATETIME)
    bake_durations = []
    scene_time = utils.get_scene_time()

    while scene_time < const.BAKE_SEQ_END_DATETIME:
        if utils.is_sun_up(scene_time):
            LOGGER.debug(f"Sun is up at {scene_time} in scene, running bake procedure...")
            bake_start_time = time.time()
            bake_export.run_bake_procedure(scene_time)
            bake_end_time = time.time()
            bake_durations.append(bake_end_time - bake_start_time)
            LOGGER.info(f"[STATISTICS] Last bake finished in {(bake_end_time - bake_start_time):.2f}s")
        else:
            LOGGER.debug(f"Sun is down at {scene_time}, skipping bake procedure.")

        utils.increment_and_set_scene_time()
        scene_time = utils.get_scene_time()

        if bake_durations:
            bake_duration_sum_secs = sum(bake_durations)
            bake_seq_progress = 1 - ((const.BAKE_SEQ_END_DATETIME - scene_time) / bake_interval_full_timespan)
            avg_bake_time = timedelta(seconds=bake_duration_sum_secs / len(bake_durations))
            est_secs_left = bake_duration_sum_secs / bake_seq_progress - bake_duration_sum_secs
            if scene_time < const.BAKE_SEQ_END_DATETIME:
                LOGGER.info(f"[STATISTICS] Bake sequence is running, progress: {bake_seq_progress:.2%} ({len(bake_durations)} bake(s) completed in {timedelta(seconds=bake_duration_sum_secs)})")
                LOGGER.info(f"[STATISTICS] Estimated time left: ~{est_secs_left:.2f}s (finishing at around: {datetime.now() + timedelta(seconds=est_secs_left)})")
            else:
                LOGGER.info(f"[STATISTICS] Bake sequence finished successfully ({len(bake_durations)} bake(s) completed in {timedelta(seconds=bake_duration_sum_secs)})!")

            LOGGER.info(f"[STATISTICS] Average bake duration: {avg_bake_time}")


if __name__ == "__main__":
    init()
    import bake_export
    import utils
    import const

    run_bake_sequence(const.BAKE_SEQ_START_DATETIME, const.BAKE_SEQ_END_DATETIME, const.BAKE_SEQ_TIME_STEP)
