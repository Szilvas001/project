import astral.sun
import logging
from datetime import datetime, timedelta
import const
import bpy  # ty:ignore[unresolved-import]

LOGGER = logging.getLogger(__name__)

def is_sun_up(date: datetime) -> bool:
    sunrise_time = astral.sun.sunrise(const.SCENE_OBSERVER, date, const.LOCATION_TZ)
    sunset_time = astral.sun.sunset(const.SCENE_OBSERVER, date, const.LOCATION_TZ)
    LOGGER.debug(f"{sunrise_time} < {date} < {sunset_time}")
    return sunrise_time < date < sunset_time


def increment_and_set_scene_time():
    const.BAKE_SEQ_CURRENT_DATETIME += const.BAKE_SEQ_TIME_STEP
    sunposition_set_date(const.BAKE_SEQ_CURRENT_DATETIME)


def datetime_naive_check(date: datetime):
    # https://docs.python.org/3/library/datetime.html#determining-if-an-object-is-aware-or-naive
    if date.tzinfo is None or date.tzinfo.utcoffset(date) is None:
        raise ValueError(f"Date {date} is naive! Date should be (timezone-) aware in order to correctly set UTC offset for bake!")


def datetime_dst_check(date: datetime):
    if date.dst() is None:
        raise ValueError(f"DST info for is not known for {date}!")


def check_date_metadata(date: datetime):
    datetime_naive_check(date)
    datetime_dst_check(date)


def sunposition_settings_init():
    if bpy.context.scene.sun_pos_properties.use_day_of_year:
        LOGGER.warning(
            "'Use day of year' setting is True in Blender!"
            + " Setting it to False in order to set date values correctly."
            + " Note: HSBS currently only supports setting the date with the `use_day_of_year` setting False."
        )
        bpy.context.scene.sun_pos_properties.use_day_of_year = False


def round_to_nearest_half(num):
    return round(num * 2) / 2


def sunposition_set_date(date: datetime):
    check_date_metadata(date)
    sunposition_settings_init()

    sun_pos_props = bpy.context.scene.sun_pos_properties

    sun_pos_props.year = date.year
    sun_pos_props.month = date.month
    sun_pos_props.day = date.day
    # We can assume utcoffset has a seconds attribute because of datetime_naive_check
    date_utc_zone = round_to_nearest_half(date.utcoffset().seconds / const.SECS_PER_HOUR)  # ty:ignore[possibly-missing-attribute]
    sun_pos_props.UTC_zone = date_utc_zone

    date_is_dst = date.dst() != timedelta(0)
    sun_pos_props.use_daylight_savings = date_is_dst

    hours_int = date.hour

    date_secs = const.SECS_PER_MIN * date.minute + date.second
    hour_fraction = date_secs / (const.MINS_PER_HOUR * const.SECS_PER_MIN)

    sun_pos_props.time = hours_int + hour_fraction
    LOGGER.debug(f"Set Blender sun position properties to match {date}.")


def get_scene_time() -> datetime:
    sun_pos_props = bpy.context.scene.sun_pos_properties
    scene_time_base = datetime(
        year = sun_pos_props.year,
        month = sun_pos_props.month,
        day = sun_pos_props.day,
        tzinfo=const.LOCATION_TZ
    )
    hour_fraction = timedelta(hours=sun_pos_props.time)
    scene_time = scene_time_base + hour_fraction

    LOGGER.debug(f"Parsed scene time: {scene_time}")
    return scene_time
