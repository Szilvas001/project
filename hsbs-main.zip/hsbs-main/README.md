# HSBS - Headless Shade Bake Script

> Started out from [codingsupply/blender-bake-export repo](https://github.com/codingsupply/blender-bake-export)

## Setup

### Set up env:

Create and enter a Python virtual env (venv) for installing the project's dependencies in an isolated environment:
> If you are using Python tools that already handle setting up isolated dev environments, skip the steps below.

```sh
python -m venv .venv
source .venv/bin/activate
```

Install the dependencies into this virtual environment:

```
pip install -r requirements.txt
```

### Specify your configuration using environment variables:

The service needs some configuration parameters to operate. The following are required at this point:

```env
LOCATION_ELEVATION="<location-elevation>"
LOCATION_LAT="<location-latitude>"
LOCATION_LONG="<location-longitude>"

# Needed for S3 support
UPLOADER_ENABLED=true
UPLOADER_ENDPOINT_URL=https://m3bs3.apps.ocp4.ulx.hu
UPLOADER_BUCKET_NAME="hsbs-bakes"
UPLOADER_ACCESS_KEY_ID="<access-key-id>"
UPLOADER_SECRET_ACCESS_KEY="<secret-access-key>"

# Optional, but recommended:
# SITE_MODEL_VERSION="<3d-model-version>"
# HSBS_RENDER_CYCLES_DIFFUSE_BOUNCES=0
# HSBS_RENDER_CYCLES_SAMPLES=64
# HSBS_RENDER_CYCLES_MAX_BOUNCES=2
# HSBS_RENDER_CYCLES_GLOSSY_BOUNCES=0
# HSBS_RENDER_CYCLES_TRANSMISSION_BOUNCES=0
# HSBS_RENDER_CYCLES_VOLUME_BOUNCES=0
# HSBS_RENDER_CYCLES_TRANSPARENT_MAX_BOUNCES=0
# HSBS_SCENE_RENDER_BAKE_USE_PASS_INDIRECT=False
# HSBS_SCENE_RENDER_BAKE_USE_PASS_DIRECT=True
# HSBS_SCENE_RENDER_BAKE_USE_PASS_COLOR=False
# HSBS_SCENE_RENDER_USE_PERSISTENT_DATA=True
```

### Additinal instructions to run on vast.ai:

> Using [Linux Desktop Container](https://cloud.vast.ai/?ref_id=62897&creator_id=62897&name=Linux%20Desktop%20Container) template.

1. Check for the installation directory of Blender:

```sh
[root@host /workspace]$ ls -la $(which blender)
lrwxrwxrwx 1 root root 36 Feb  5 15:13 /usr/bin/blender -> /opt/blender-5.0.1-linux-x64/blender
```

2. Find Blender's embedded Python under `<blender-install-dir>/<blender-version>/python/bin/`:

```sh
[root@host /workspace]$ cd /opt/blender-5.0.1-linux-x64/5.0/python/bin/
```

3. Install the needed modules using Blender's embedded Python:

```sh
[root@host /opt/blender-5.0.1-linux-x64/5.0/python/bin]$ ./python3.11 -m pip install -r <path-to-HSBS-requirements.txt>
```

### Additinal instructions to run when using Blender from Flatpak:

Since running Blender using Flatpak runs it inside a sandbox, it won't use the system Python install.

Therefore you must install the needed Python dependencies inside the Flatpak sandbox:

1. Start a shell in the sandbox:

```sh
flatpak run --command=bash org.blender.Blender
```

2. Install the dependencies:

```sh
/app/blender/5.0/python/bin/python3.11 -m pip install ...
```

For running HSBS, you'll need to set an alias to blender, with:

```sh
alias blender='flatpak run org.blender.Blender'
```

and you also need to enable alias expansion inside the non-interactive shell (`launch.sh`) before invoking the `alias` command:

```sh
shopt -s expand_aliases
```

## Usage

### Single time sequence

The script can be invoked using the following command for baking a single time sequence:

```sh
BAKE_START_TS="<bake-sequence-start-time-iso-8601>" \
  BAKE_END_TS="<bake-sequence-end-time-iso-8601>" \
  BAKE_SEQ_TIME_STEP="<bake-sequence-time-step-HH:MM:SS>" \
  scripts/launch.sh "<path-to-blender-file>" "<path-to-HSBS-main.py>"
```

> If the required [Sun Position extension](https://extensions.blender.org/add-ons/sun-position/) is not yet installed in Blender,
> either install it manually or run the script above, as it will ask if you'd like it to install the extension for you.

### Multiple time periods parallelly

> ATTENTION: This requires a computer with relatively high GPU performance and RAM based on the number of concurrent jobs (`HSBS_PARALLEL_JOBS`).

For baking multiple pre-defined periods parallelly, the `scripts/bake_periods_parallelly.sh`) script can be used. For example:

```sh
HSBS_PARALLEL_JOBS=5 \
  HSBS_CYCLES_DEVICE=CUDA \
  PER_MODULE_RES=256 \
  BAKE_SEQ_TIME_STEP="00:01:00" \
  scripts/bake_periods_parallelly.sh ~/Downloads/remodeled_v2_TVL9_texture-baking_256_source-texture.blend ~/CODE/energia/HSBS/main.py
```

By default the script starts 5 parallel runs, but it can be modified to lower numbers to match the available hardware capacity.

HSBS saves baked images to the local filesystem and also attempts to upload pictures to S3-compatible storage to make them
more accessible and to provide a more robust storage system for them.

HSBS will bake the textures of the **selected** objects/faces from the Blender file, so before using it select the needed objects/faces
in Blender and save the model file afterwards.
