import uploader
from datetime import datetime
import bpy  # ty:ignore[unresolved-import]
import os
import const
import logging

LOGGER = logging.getLogger(__name__)

def get_selected_meshes() -> list[bpy.types.Object]:
    return [o for o in bpy.context.selected_objects if o.type == 'MESH']


def run_obj_checks(obj: bpy.types.Object) -> bool:
    # b) Ensure UV map exists
    if not obj.data.uv_layers:
        raise RuntimeError(f"{obj.name} has no UV map!")

    # c) Get original material and Base Color image
    mat = obj.active_material
    if not mat:
        raise RuntimeError(f"{obj.name} has no node-based material!")
    bsdf = next((n for n in mat.node_tree.nodes if n.type == 'BSDF_PRINCIPLED'), None)
    if not bsdf:
        raise RuntimeError(f"No Principled BSDF found in material {mat.name}!")
    input_link = bsdf.inputs['Base Color'].links
    if not input_link:
        raise RuntimeError(f"Base Color of {mat.name} is not linked!")
    orig_node = input_link[0].from_node
    if orig_node.type != 'TEX_IMAGE':
        raise RuntimeError("Base Color link is not from an image texture node!")

    return True


def run_obj_checks_for_selected_mesh():
    LOGGER.debug("Running object property checks for all selected meshes...")
    checks_passed = all([run_obj_checks(obj) for obj in get_selected_meshes()])
    return checks_passed


def get_output_dir():
    blend_fp = bpy.data.filepath
    if not blend_fp:
        LOGGER.error("The Blender file has not been saved previously so its path cannot be determined!")
        raise RuntimeError("Please save the .blend file first!")

    blend_dir  = os.path.dirname(blend_fp)
    output_dir = os.path.join(blend_dir, const.BAKE_IMG_OUTPUT_SUBDIR)
    LOGGER.debug(f"Creating output directory at {output_dir} if it does not exist...")
    os.makedirs(output_dir, exist_ok=True)
    return output_dir


def set_scene_settings():
    LOGGER.debug("Setting Blender scene and render settings...")
    scene = bpy.context.scene
    scene.render.engine = const.RENDER_ENGINE
    scene.cycles.bake_type = const.BAKE_TYPE
    scene.render.bake.margin = const.RENDER_BAKE_MARGIN
    scene.cycles.max_bounces = const.RENDER_CYCLES_MAX_BOUNCES
    scene.cycles.diffuse_bounces = const.RENDER_CYCLES_DIFFUSE_BOUNCES
    scene.cycles.glossy_bounces = const.RENDER_CYCLES_GLOSSY_BOUNCES
    scene.cycles.transmission_bounces = const.RENDER_CYCLES_TRANSMISSION_BOUNCES
    scene.cycles.volume_bounces = const.RENDER_CYCLES_VOLUME_BOUNCES
    scene.cycles.transparent_max_bounces = const.RENDER_CYCLES_TRANSPARENT_MAX_BOUNCES
    scene.cycles.use_denoising = const.RENDER_CYCLES_USE_DENOISING
    if scene.cycles.use_denoising:
        scene.cycles.denoising_use_gpu = const.RENDER_CYCLES_DENOISING_USE_GPU
        scene.cycles.denoising_quality = const.RENDER_CYCLES_DENOISING_QUALITY
        scene.cycles.denoising_prefilter = const.RENDER_CYCLES_DENOISING_PREFILTER
    scene.cycles.samples = const.RENDER_CYCLES_SAMPLES
    scene.cycles.use_adaptive_sampling = const.RENDER_CYCLES_USE_ADAPTIVE_SAMPLING
    scene.cycles.tile_size = const.RENDER_CYCLES_TILE_SIZE
    scene.render.bake.use_pass_indirect = const.SCENE_RENDER_BAKE_USE_PASS_INDIRECT
    scene.render.bake.use_pass_direct = const.SCENE_RENDER_BAKE_USE_PASS_DIRECT
    scene.render.bake.use_pass_color = const.SCENE_RENDER_BAKE_USE_PASS_COLOR
    scene.render.compositor_device = const.SCENE_RENDER_COMPOSITOR_DEVICE
    scene.render.compositor_denoise_device = const.SCENE_RENDER_COMPOSITOR_DENOISE_DEVICE
    scene.render.use_persistent_data = const.SCENE_RENDER_USE_PERSISTENT_DATA
    scene.render.compositor_denoise_final_quality = const.SCENE_RENDER_COMPOSITOR_DENOISE_FINAL_QUALITY
    scene.cycles.debug_use_spatial_splits = const.SCENE_CYCLES_DEBUG_USE_SPATIAL_SPLITS
    scene.render.threads_mode = const.SCENE_RENDER_THREADS_MODE
    scene.cycles.debug_use_compact_bvh = const.SCENE_CYCLES_DEBUG_USE_COMPACT_BVH
    scene.cycles.debug_use_hair_bvh = const.SCENE_CYCLES_DEBUG_USE_HAIR_BVH
    scene.cycles.debug_bvh_time_steps = const.SCENE_CYCLES_DEBUG_BVH_TIME_STEPS


def prepare_bake(img_name: str, img_width: int, img_height: int, mat_name: str) -> bpy.types.Image:
    LOGGER.debug(f"Preparing bake for image '{img_name}' ({img_width} x {img_height}) and material '{mat_name}'...")
    bake_img = bpy.data.images.new(img_name, width=img_width, height=img_height)

    tree = bpy.data.materials[mat_name].node_tree
    bake_node = tree.nodes.new(const.IMAGE_TEXTURE_NODE_ID)
    bake_node.image = bake_img
    bake_node.image.colorspace_settings.name = const.BAKE_IMG_COLORSPACE
    bake_node.select = True
    tree.nodes.active = bake_node

    return bake_img


def bake(type: str, use_clear: bool):
    LOGGER.debug("Baking, this might take some time...")
    bpy.ops.object.bake(type=type, use_clear=use_clear)


def save_bake(bake_img) -> str:
    bake_path = os.path.join(get_output_dir(), bake_img.name + const.BAKE_IMG_EXTENSION)
    bake_img.filepath_raw = bake_path
    bake_img.file_format = const.BAKE_IMG_FORMAT
    bake_img.save()
    LOGGER.debug(f"Bake saved to path '{bake_path}'.")
    return bake_path


def run_bake_procedure(scene_time: datetime):
    LOGGER.debug(f"Running bake procedure for scene time {scene_time}")
    if run_obj_checks_for_selected_mesh():
        set_scene_settings()

        bake_dest_img = prepare_bake(
            f"{const.BAKE_IMG_NAME_PREFIX}{scene_time.isoformat()}{const.BAKE_IMG_NAME_SUFFIX}",
            const.BAKE_IMG_RES_WIDTH,
            const.BAKE_IMG_RES_HEIGHT,
            const.BAKE_MATERIAL_NAME
        )

        LOGGER.info(f"Starting bake for image '{bake_dest_img.name}'...")
        bake(const.BAKE_TYPE, const.BAKE_IMG_USE_CLEAR)

        LOGGER.info(f"Bake complete! Saving bake with name: {bake_dest_img.name}...")
        bake_file_path = save_bake(bake_dest_img)
        uploader_destination_path = f"{const.LOCATION_SITE_NAME}/{const.BAKE_IMG_OUTPUT_RUN_DIR_NAME}/{bake_dest_img.name}{const.BAKE_IMG_EXTENSION}"
        if const.UPLOADER_ENABLED:
            uploader.upload_file_to_bucket(bake_file_path, uploader_destination_path)
        else:
            LOGGER.warning("Uploading results to S3 is not enabled, bakes will only be saved locally!"
                + " Set `UPLOADER_ENABLED` to a truthy value to enable S3 uploads.")
    else:
        raise RuntimeError("Object checks were not successful for selected meshes! Check previous logs and selected meshes.")
