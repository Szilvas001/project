import os
from astral import Observer
import astral.sun
from datetime import datetime, timedelta
from dateutil import tz

LOCATION_LAT=float(os.getenv("LOCATION_LAT", "47.4980"))
LOCATION_LONG=float(os.getenv("LOCATION_LONG", "19.0402"))
LOCATION_ELEVATION=float(os.getenv("LOCATION_ELEVATION", "0"))
LOCATION_TZ_STR="Europe/Budapest"
LOCATION_TZ=tz.gettz(LOCATION_TZ_STR)
SCENE_OBSERVER = Observer(LOCATION_LAT, LOCATION_LONG, LOCATION_ELEVATION)

DEMO_REMAINING_PERIODS = [
    ("2025-09-04T04:00:00.000+00:00", "2025-09-04T17:30:00.000+00:00"),
    ("2025-10-01T04:45:00.000+00:00", "2025-10-01T16:30:00.000+00:00"),
    ("2025-10-05T04:50:00.000+00:00", "2025-10-05T16:20:00.000+00:00"),
    ("2025-10-10T05:00:00.000+00:00", "2025-10-10T16:10:00.000+00:00"),
    ("2025-11-03T05:40:00.000+00:00", "2025-11-03T15:20:00.000+00:00"),
    ("2025-11-28T06:15:00.000+00:00", "2025-11-28T14:55:00.000+00:00"),
    ("2025-09-07T04:10:00.000+00:00", "2025-09-07T04:39:29.000+00:00"),
    ("2025-09-07T12:07:43.000+00:00", "2025-09-07T17:20:00.000+00:00"),
    ("2025-12-28T06:30:00.000+00:00", "2025-12-28T07:07:51.003+00:00"),
    ("2025-12-28T12:01:12.672+00:00", "2025-12-28T15:05:00.000+00:00"),
    ("2026-03-05T05:25:00.000+00:00", "2026-03-05T16:45:00.000+00:00"),
    ("2025-09-21T04:30:00.000+00:00", "2025-09-21T06:42:03.053+00:00"),
    ("2025-09-21T14:57:43.272+00:00", "2025-09-21T17:00:00.000+00:00"),
    ("2025-10-04T04:50:00.000+00:00", "2025-10-04T05:38:13.142+00:00"),
    ("2025-10-04T15:29:09.465+00:00", "2025-10-04T16:20:00.000+00:00"),
    ("2025-10-08T04:55:00.000+00:00", "2025-10-08T05:47:40.678+00:00"),
    ("2025-10-08T15:10:31.525+00:00", "2025-10-08T16:15:00.000+00:00"),
    ("2025-11-05T05:45:00.000+00:00", "2025-11-05T06:10:44.304+00:00"),
    ("2025-11-05T09:46:39.406+00:00", "2025-11-05T15:15:00.000+00:00"),
    ("2025-12-30T06:35:00.000+00:00", "2025-12-30T08:42:51.629+00:00"),
    ("2025-12-30T14:25:45.840+00:00", "2025-12-30T15:10:00.000+00:00"),
    ("2026-02-27T05:40:00.000+00:00", "2026-02-27T06:14:01.630+00:00"),
    ("2026-02-27T13:33:09.079+00:00", "2026-02-27T16:35:00.000+00:00"),
    ("2026-03-06T05:25:00.000+00:00", "2026-03-06T06:26:31.871+00:00"),
    ("2026-03-06T15:57:54.366+00:00", "2026-03-06T16:45:00.000+00:00"),
]

CLEARSKY_PERIODS = [
    ("2025-08-10T04:19:44.002+00:00", "2025-08-10T10:02:07.588+00:00"),
    ("2025-08-11T04:42:31.134+00:00", "2025-08-11T09:12:31.916+00:00"),
    ("2025-08-11T14:19:42.164+00:00", "2025-08-11T17:11:52.020+00:00"),
    ("2025-08-13T04:42:42.555+00:00", "2025-08-13T16:54:41.616+00:00"),
    ("2025-08-14T04:32:52.255+00:00", "2025-08-14T12:39:43.063+00:00"),
    ("2025-08-15T04:46:39.700+00:00", "2025-08-15T09:33:15.840+00:00"),
    ("2025-08-16T04:40:09.309+00:00", "2025-08-16T09:04:21.981+00:00"),
    ("2025-08-19T00:00:00.000+00:00", "2025-08-20T00:00:00.000+00:00"),
    ("2025-08-24T00:00:00.000+00:00", "2025-08-25T00:00:00.000+00:00"),
    ("2025-08-27T06:02:23.389+00:00", "2025-08-27T12:13:07.588+00:00"),
    ("2025-09-01T04:43:07.353+00:00", "2025-09-01T11:51:00.000+00:00"),
    ("2025-09-02T04:33:51.000+00:00", "2025-09-02T10:53:24.000+00:00"),
    ("2025-09-07T04:39:29.000+00:00", "2025-09-07T12:07:43.000+00:00"),
    ("2025-09-12T05:09:17.396+00:00", "2025-09-12T11:59:23.920+00:00"),
    ("2025-09-15T10:53:12.247+00:00", "2025-09-15T14:44:05.813+00:00"),
    ("2025-09-19T05:03:52.523+00:00", "2025-09-19T16:14:14.997+00:00"),
    ("2025-09-20T08:15:39.774+00:00", "2025-09-20T16:09:40.073+00:00"),
    ("2025-09-21T06:42:03.053+00:00", "2025-09-21T14:57:43.272+00:00"),
    ("2025-10-04T05:38:13.142+00:00", "2025-10-04T15:29:09.465+00:00"),
    ("2025-10-08T05:47:40.678+00:00", "2025-10-08T15:10:31.525+00:00"),
    ("2025-10-19T06:00:59.608+00:00", "2025-10-19T10:40:22.529+00:00"),
    ("2025-10-20T06:02:17.796+00:00", "2025-10-20T13:35:29.491+00:00"),
    ("2025-11-01T08:25:35.064+00:00", "2025-11-01T14:54:24.155+00:00"),
    ("2025-11-05T06:10:44.304+00:00", "2025-11-05T09:46:39.406+00:00"),
    ("2025-11-06T06:14:43.636+00:00", "2025-11-06T09:54:16.363+00:00"),
    ("2025-11-07T06:16:37.625+00:00", "2025-11-07T12:49:19.591+00:00"),
    ("2025-11-18T09:58:14.582+00:00", "2025-11-18T13:16:56.660+00:00"),
    ("2025-12-27T11:01:40.951+00:00", "2025-12-27T14:30:06.844+00:00"),
    ("2025-12-28T07:07:51.003+00:00", "2025-12-28T12:01:12.672+00:00"),
    ("2025-12-29T01:00:00.000+00:00", "2025-12-29T20:00:00.000+00:00"),
    ("2025-12-30T08:42:51.629+00:00", "2025-12-30T14:25:45.840+00:00"),
    ("2026-01-18T07:01:02.972+00:00", "2026-01-18T15:01:39.426+00:00"),
    ("2026-01-27T06:45:50.253+00:00", "2026-01-27T13:01:44.323+00:00"),
    ("2026-02-26T06:08:50.735+00:00", "2026-02-26T11:05:14.156+00:00"),
    ("2026-02-27T06:14:01.630+00:00", "2026-02-27T13:33:09.079+00:00"),
    ("2026-03-06T06:26:31.871+00:00", "2026-03-06T15:57:54.366+00:00"),
    ("2026-03-07T05:44:39.765+00:00", "2026-03-07T16:05:21.717+00:00"),
    ("2026-03-08T05:52:44.027+00:00", "2026-03-08T09:59:14.490+00:00"),
    ("2026-03-09T05:48:43.360+00:00", "2026-03-09T11:10:14.231+00:00"),
]

def list_last_valid_bake_dates(period_list: list[tuple[str, str]]) -> list[datetime]:
    results = []
    time_step = timedelta(minutes=1)
    for period in period_list:
        last_valid_ts = last_valid_bake_date(period, time_step)
        # print(f"Last valid ts for period {period} is: {last_valid_ts}")
        results.append(last_valid_ts)

    return results


def list_valid_bake_periods(period_list: list[tuple[str, str]]) -> list[tuple[datetime, datetime]]:
    results = []
    time_step = timedelta(minutes=1)
    for period in period_list:
        first_valid_ts = first_valid_bake_date(period, time_step)
        last_valid_ts = last_valid_bake_date(period, time_step)
        # print(f"Last valid ts for period {period} is: {last_valid_ts}")
        results.append((first_valid_ts, last_valid_ts))

    return results


def last_valid_bake_date(period: tuple[str, str], time_step: timedelta) -> datetime:
    current_ts = None

    start, end = period
    start = datetime.fromisoformat(start)
    end = datetime.fromisoformat(end)

    if current_ts is None:
        current_ts = start

    while current_ts < end:

        if after_sunrise(current_ts) and not is_sun_up(current_ts):
            # print("\t[WARN] Sunrise is earlier than period's last timestamp. This is the last valid timestamp for bake!")
            return current_ts

        current_ts += time_step

    # print("Reached period's end, period's last timestamp is valid for bake.")
    return current_ts


def first_valid_bake_date(period: tuple[str, str], time_step: timedelta) -> datetime:
    current_ts = None

    start, end = period
    start = datetime.fromisoformat(start)
    end = datetime.fromisoformat(end)

    if current_ts is None:
        current_ts = start

    while current_ts < end:
        if is_sun_up(current_ts):
            return current_ts

        current_ts += time_step

    raise ValueError(f"First valid bake date (when sun is up) could not be found in bake period ({period}).")


def after_sunrise(date: datetime) -> bool:
    return date > astral.sun.sunrise(SCENE_OBSERVER, date, LOCATION_TZ)


def is_sun_up(date: datetime) -> bool:
    sunrise_time = astral.sun.sunrise(SCENE_OBSERVER, date, LOCATION_TZ)
    sunset_time = astral.sun.sunset(SCENE_OBSERVER, date, LOCATION_TZ)
    return sunrise_time < date < sunset_time


def format_last_valid_bake_dates(dates: list[datetime]) -> list[str]:
    return [date.astimezone(LOCATION_TZ).isoformat(timespec="minutes") for date in dates]


def format_valid_bake_dates(dates: list[tuple[datetime, datetime]]) -> list[str]:
    return [f"site_ts >= '{start.astimezone(LOCATION_TZ).isoformat(timespec="minutes")}' AND site_ts <= '{end.astimezone(LOCATION_TZ).isoformat(timespec="minutes")}'" for start, end in dates]


def get_minute_count_for_period(start: datetime, end: datetime) -> int:
    return round((end - start).total_seconds() / 60)


def main():
    # Last valid bake dates:
    # for str_min_date in format_last_valid_bake_dates(list_last_valid_bake_dates(CLEARSKY_PERIODS)):
    #     print(str_min_date)
    # Valid bake periods
    periods = list_valid_bake_periods(CLEARSKY_PERIODS)
    period_queries = format_valid_bake_dates(periods)
    minute_counts = []
    for start, end in periods:
        minute_counts.append(get_minute_count_for_period(start, end))
    for i in range(len(period_queries)):
        minutes = minute_counts[i]
        print(f"psql -h timescaledb-energia -U ardrift -d arnold -c \"SELECT '{periods[i][0]}' AS start, '{periods[i][1]}' AS end, COUNT(*) FILTER (WHERE metadata_id = (SELECT id FROM shadepow_analyses_metadata WHERE model_version = 'v2' AND cycles_sample_size = 64 LIMIT 1)) AS analyses_count, {minutes} AS minute_count, to_char(((COUNT(*)::NUMERIC / {minutes}::NUMERIC) * 100.0), '999D99%') AS completed_bakes FROM shadepow_analyses WHERE {period_queries[i]} AND completion_ts >= '2026-03-11';\"")

if __name__ == "__main__":
    main()
