#!/usr/bin/env bash

echo "## HSBS bake test: Starting test bakes with varying render settings..."

PARENT_PATH=$(cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P)
pushd "$PARENT_PATH" > /dev/null 2>&1

SAMPLE_SIZE_MIN=1
SAMPLE_SIZE_MAX=128

SAMPLE_SIZE=$SAMPLE_SIZE_MIN
while [ ! $SAMPLE_SIZE -gt $SAMPLE_SIZE_MAX ]; do
  echo "## HSBS bake test: Running with sample size $SAMPLE_SIZE..."
  HSBS_RENDER_CYCLES_SAMPLES=$SAMPLE_SIZE ./launch.sh $@

  SAMPLE_SIZE=$(( SAMPLE_SIZE * 2 ))

done

popd > /dev/null 2>&1
