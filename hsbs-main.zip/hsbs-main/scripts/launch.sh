#!/usr/bin/env bash

if [ $# -lt 2 ]; then
  echo "ERROR: Usage: $0 <path-to-blender-file> <path-to-HSBS-main.py>"
  exit 1
fi

blend_file_path=$1
HSBS_main_path=$2
HSBS_cycles_device=${HSBS_CYCLES_DEVICE:-CUDA}

blender_cmd="blender"

if ! command -v "$blender_cmd" > /dev/null 2>&1; then
  echo "Blender (\`$blender_cmd\`) must be on \$PATH to continue, it is a runtime dependency of HSBS, used for rendering. Install it to proceed."
  echo "Exiting..."
  exit 1
fi

sun_pos_ext_installed=$(blender --command extension list | grep "\[installed\]" | grep "sun_position")

if [ ! "$sun_pos_ext_installed" ]; then
  echo "Blender sun position extension is not installed but is a dependency for HSBS, it is needed for rendering at different scene times."
  read -rp "Would you like to install it now? (y/n)" to_install_ext
  case $to_install_ext in
    [Yy]* ) echo "Installing..."; blender --online-mode --command extension install -s -e sun_position ;;
    [Nn]* ) echo "Exiting as dependency is required for running HSBS...";;
    * ) echo "Invalid response, exiting..."
  esac
fi

sun_pos_ext_installed=$(blender --command extension list | grep "\[installed\]" | grep "sun_position")

if [ "$sun_pos_ext_installed" ]; then
  echo "Blender sun position extension is installed. Launching HSBS..."
  echo "Rendering using Cycles device: ${HSBS_cycles_device}"
  blender "$blend_file_path" -b --python "$HSBS_main_path" -- --cycles-device "${HSBS_cycles_device}" > /dev/null
fi
