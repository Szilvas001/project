#!/usr/bin/env bash

echo "### HSBS parallel execution script ### "

HSBS_PARALLEL_JOBS_MAX=20
HSBS_PARALLEL_JOBS_MIN=1
INTEGER_REGEX='^[0-9]+$'

if ! [[ "$HSBS_PARALLEL_JOBS" =~ $INTEGER_REGEX ]]; then
  echo "### ERROR: The value of the variable HSBS_PARALLEL_JOBS is not an integer! Its value must be an integer that specifies the number of maximum concurrent jobs! ###"
  exit 1
else
  if [ "$HSBS_PARALLEL_JOBS" -ge "$HSBS_PARALLEL_JOBS_MAX" ] || [ "$HSBS_PARALLEL_JOBS" -le "$HSBS_PARALLEL_JOBS_MIN" ]; then
    echo "### ERROR: Number of parallel jobs ($HSBS_PARALLEL_JOBS) is invalid! The value of HSBS_PARALLEL_JOBS must be an integer so that: $HSBS_PARALLEL_JOBS_MIN < HSBS_PARALLEL_JOBS < $HSBS_PARALLEL_JOBS_MAX ###"
    exit 1
  fi
fi

echo "### Starting bake for periods parallelly with ${HSBS_PARALLEL_JOBS} parallel jobs..."

PARENT_PATH=$(cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P)
pushd "$PARENT_PATH" > /dev/null 2>&1

BAKE_PERIODS=(
  # # TODO: 216 days from 2025-08-20 to 2026-03-24 divided equally to 5 periods
  # "2025-08-31T19:20:00.000+02:00,2025-10-02T00:00:00.000+00:00"
  # "2025-10-15T16:37:00.000+02:00,2025-11-14T00:00:00.000+00:00"
  # "2025-12-01T09:05:00.000+01:00,2025-12-27T00:00:00.000+00:00"
  # "2026-01-14T07:59:00.000+01:00,2026-02-08T00:00:00.000+00:00"
  # "2026-02-23T15:56:00.000+01:00,2026-03-24T00:00:00.000+00:00"
  #
  # 2026-04-09 daylight time divided equally to 5 periods
  "2026-04-09T06:00:00.000+02:00,2026-04-09T08:42:00.000+02:00"
  "2026-04-09T08:43:00.000+02:00,2026-04-09T11:24:00.000+02:00"
  "2026-04-09T11:25:00.000+02:00,2026-04-09T14:06:00.000+02:00"
  "2026-04-09T14:07:00.000+02:00,2026-04-09T16:48:00.000+02:00"
  "2026-04-09T16:48:00.000+02:00,2026-04-09T19:30:00.000+02:00"
)

for p in "${BAKE_PERIODS[@]}"
do
  IFS="," read START END <<< "${p}"

  echo "Running bake for period $START - $END with ${BAKE_SEQ_TIME_STEP:-00:30:00} temporal resolution."
  BAKE_START_TS=$START BAKE_END_TS=$END ./launch.sh $@ &

  # Limit maximum concurrent runs
  if [[ $(jobs | wc -l) -eq "$HSBS_PARALLEL_JOBS" ]]; then
    # Wait for next job
    wait -n
  fi

done

popd > /dev/null 2>&1
