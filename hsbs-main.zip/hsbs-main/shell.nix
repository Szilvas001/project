let
  pkgs = import <nixpkgs> {};
  
in pkgs.mkShell {
  packages = [
    pkgs.python313Packages.python-dotenv
    pkgs.python313Packages.python-dateutil
    pkgs.python313Packages.astral
  ];
}
